// bazar.js — v12: auto-deposit toggle when adding bazar

import { db } from '../../firebase.js';
import { toast, taka, pad, moName, CATS, CICO } from '../../utils.js';
import {
  collection, getDocs, addDoc, updateDoc, deleteDoc,
  doc, query, orderBy, where, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _vy=TODAY.getFullYear(), _vm=TODAY.getMonth();
let _expenses=[], _view='tree', _ctx={};

export async function render(root, ctx) {
  _ctx = ctx;

  root.innerHTML = `
<div>
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <button class="btn btn-ghost btn-sm" id="bz-prev">◀</button>
    <span style="font-size:14px;font-weight:700;min-width:130px;text-align:center" id="bz-month"></span>
    <button class="btn btn-ghost btn-sm" id="bz-next">▶</button>
    <div style="display:flex;gap:5px;margin-left:auto">
      <button class="btn btn-ghost btn-sm" id="bz-tree-btn">🌳 Tree</button>
      <button class="btn btn-ghost btn-sm" id="bz-list-btn">📋 List</button>
    </div>
  </div>

  <div class="card" style="margin-bottom:14px">
    <div class="ch"><h3>➕ নতুন বাজার যোগ করুন</h3></div>
    <div class="cb">
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px">
        <div class="field"><label class="lbl">তারিখ</label>
          <input class="inp inp-sm" type="date" id="bz-date"
            value="${TODAY.getFullYear()}-${pad(TODAY.getMonth()+1)}-${pad(TODAY.getDate())}"/></div>
        <div class="field"><label class="lbl">বিভাগ</label>
          <select class="inp inp-sm" id="bz-cat">
            ${CATS.map(c=>`<option value="${c}">${CICO[c]||''} ${c}</option>`).join('')}
          </select></div>
        <div class="field"><label class="lbl">আইটেম</label>
          <input class="inp inp-sm" id="bz-item" placeholder="কী কিনলেন"/></div>
        <div class="field"><label class="lbl">পরিমাণ (৳)</label>
          <input class="inp inp-sm" id="bz-amount" type="number" min="0" placeholder="0"/></div>
        <div class="field" style="grid-column:1/-1"><label class="lbl">নোট (ঐচ্ছিক)</label>
          <input class="inp inp-sm" id="bz-note" placeholder="বিস্তারিত…"/></div>
      </div>

      <!-- ✅ AUTO-DEPOSIT TOGGLE -->
      <div style="margin-top:12px;padding:10px 12px;background:var(--g8);
        border:1px solid var(--g5);border-radius:10px;display:flex;
        align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">
        <div>
          <p style="font-size:12px;font-weight:700;color:var(--g1);margin:0">
            💰 বাজারের টাকা আমার ডিপোজিটে যোগ করুন
          </p>
          <p style="font-size:11px;color:var(--ink3);margin:3px 0 0">
            চালু থাকলে বাজারের পরিমাণ স্বয়ংক্রিয়ভাবে আপনার জমায় যোগ হবে
          </p>
        </div>
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;flex-shrink:0">
          <div class="tog-wrap" id="bz-dep-tog-wrap">
            <input type="checkbox" id="bz-auto-dep" style="display:none" checked/>
            <div class="tog on" id="bz-tog-ui"></div>
          </div>
          <span style="font-size:12px;font-weight:700;color:var(--g1)" id="bz-dep-lbl">চালু</span>
        </label>
      </div>

      <button class="btn btn-p btn-sm" style="margin-top:10px" id="bz-add-btn">+ বাজার যোগ করুন</button>
    </div>
  </div>

  <div class="gA" id="bz-summary" style="margin-bottom:14px"></div>

  <div class="card">
    <div class="ch">
      <h3>📋 বাজারের তালিকা</h3>
      <div style="display:flex;align-items:center;gap:8px">
        <span style="font-size:12px;font-weight:700;color:var(--g1)" id="bz-total">৳০</span>
        <span style="font-size:11px;color:var(--ink3)" id="bz-pending-info"></span>
      </div>
    </div>
    <div id="bz-content">লোড হচ্ছে…</div>
  </div>
</div>

<style>
.tog-wrap{position:relative;width:42px;height:24px}
.tog{width:42px;height:24px;border-radius:12px;background:var(--line2);
  position:relative;transition:.2s;cursor:pointer}
.tog.on{background:var(--g2)}
.tog::after{content:'';position:absolute;top:3px;left:3px;width:18px;height:18px;
  border-radius:50%;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.2);
  transition:.2s;transform:translateX(0)}
.tog.on::after{transform:translateX(18px)}
</style>`;

  // Toggle logic
  const togUi  = root.querySelector('#bz-tog-ui');
  const togInp = root.querySelector('#bz-auto-dep');
  const togLbl = root.querySelector('#bz-dep-lbl');
  root.querySelector('#bz-dep-tog-wrap').addEventListener('click', ()=>{
    togInp.checked = !togInp.checked;
    togUi.classList.toggle('on', togInp.checked);
    togLbl.textContent = togInp.checked ? 'চালু' : 'বন্ধ';
    togLbl.style.color = togInp.checked ? 'var(--g1)' : 'var(--ink3)';
  });

  root.querySelector('#bz-prev').addEventListener('click', ()=>{ _vm--; if(_vm<0){_vm=11;_vy--} _load(root); });
  root.querySelector('#bz-next').addEventListener('click', ()=>{ _vm++; if(_vm>11){_vm=0;_vy++} _load(root); });
  root.querySelector('#bz-add-btn').addEventListener('click', ()=> _add(root));
  root.querySelector('#bz-tree-btn').addEventListener('click', ()=> _setView(root,'tree'));
  root.querySelector('#bz-list-btn').addEventListener('click', ()=> _setView(root,'list'));
  root.querySelector('#bz-content').addEventListener('click', e=>{
    const ap=e.target.closest('[data-approve]');
    const rj=e.target.closest('[data-reject]');
    const dl=e.target.closest('[data-delete]');
    if(ap) _approve(root, ap.dataset.approve);
    if(rj) _reject(root, rj.dataset.reject);
    if(dl) _delete(root, dl.dataset.delete);
  });

  _setView(root, _view, false);
  root.querySelector('#bz-month').textContent = `${moName(_vm)} ${_vy}`;
  await _load(root);
}

function _setView(root,v,doRender=true){
  _view=v;
  root.querySelector('#bz-tree-btn')?.classList.toggle('btn-p',v==='tree');
  root.querySelector('#bz-tree-btn')?.classList.toggle('btn-ghost',v!=='tree');
  root.querySelector('#bz-list-btn')?.classList.toggle('btn-p',v==='list');
  root.querySelector('#bz-list-btn')?.classList.toggle('btn-ghost',v!=='list');
  if(doRender) _render(root);
}

async function _load(root){
  root.querySelector('#bz-month').textContent=`${moName(_vm)} ${_vy}`;
  const monthStr=`${_vy}-${pad(_vm+1)}`;
  try {
    const snap=await getDocs(query(collection(db,'messes',_ctx.messId,'expenses'),orderBy('date','desc')));
    _expenses=snap.docs.map(d=>({id:d.id,...d.data()})).filter(e=>e.date?.startsWith(monthStr));
    _render(root);
  } catch(err){
    toast('লোড ব্যর্থ: '+err.message,'er');
    const c=root.querySelector('#bz-content');
    if(c) c.innerHTML=`<div style="padding:20px;text-align:center;color:var(--r1)">⚠️ লোড ব্যর্থ</div>`;
  }
}

function _render(root){
  const canApprove=['mess-admin','mess-co-admin'].includes(_ctx.myMessRole);
  const isAdmin=_ctx.myMessRole==='mess-admin';
  const approved=_expenses.filter(e=>e.status==='approved');
  const pending=_expenses.filter(e=>e.status==='pending');
  const catTotals={};
  approved.forEach(e=>{ catTotals[e.category]=(catTotals[e.category]||0)+(parseFloat(e.amount)||0); });
  const total=Object.values(catTotals).reduce((a,b)=>a+b,0);

  const totalEl=root.querySelector('#bz-total');
  if(totalEl) totalEl.textContent=taka(total);
  const pendEl=root.querySelector('#bz-pending-info');
  if(pendEl) pendEl.textContent=pending.length>0?`(${pending.length}টি অনুমোদনের অপেক্ষায়)`:'';
  const sumEl=root.querySelector('#bz-summary');
  if(sumEl) sumEl.innerHTML=Object.keys(catTotals).length
    ? Object.entries(catTotals).map(([c,v])=>
        `<div class="sc"><div class="sl">${CICO[c]||''} ${c}</div><div class="sv">${taka(v)}</div></div>`
      ).join('') : '';

  const content=root.querySelector('#bz-content');
  if(!content) return;
  if(!_expenses.length){
    content.innerHTML='<div style="padding:20px;text-align:center;color:var(--ink3)">এই মাসে কোনো বাজার নেই</div>';
    return;
  }

  if(_view==='tree'){
    const byDate={};
    _expenses.forEach(e=>{ (byDate[e.date]=byDate[e.date]||[]).push(e); });
    const sorted=Object.entries(byDate).sort(([a],[b])=>b.localeCompare(a));
    content.innerHTML=sorted.map(([date,items])=>{
      const dayTotal=items.filter(i=>i.status==='approved').reduce((s,i)=>s+(parseFloat(i.amount)||0),0);
      return `<div style="border-bottom:1px solid var(--line)">
<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 14px 6px">
  <span style="font-size:12px;font-weight:700;color:var(--ink)">${date}</span>
  <span style="font-size:12px;color:var(--g1);font-weight:700">${taka(dayTotal)}</span>
</div>
${items.map(e=>`
<div style="display:flex;align-items:center;gap:8px;padding:6px 14px;border-top:.5px solid var(--line)">
  <span style="font-size:16px;flex-shrink:0">${CICO[e.category]||'📦'}</span>
  <div style="flex:1;min-width:0">
    <span style="font-size:12px;color:var(--ink)">${_e(e.item)}</span>
    ${e.note?`<span style="font-size:10px;color:var(--ink4)"> (${_e(e.note)})</span>`:''}
    ${e.autoDeposit?`<span style="font-size:9px;background:var(--g7);color:var(--g1);
      border-radius:4px;padding:1px 5px;margin-left:4px">💰 ডিপোজিটে</span>`:''}
  </div>
  <div style="display:flex;align-items:center;gap:4px;flex-shrink:0;flex-wrap:wrap;justify-content:flex-end">
    <span style="font-family:var(--mono);font-size:12px;font-weight:700">${taka(e.amount)}</span>
    ${_badge(e.status)}
    ${canApprove&&e.status==='pending'?`
      <button class="btn btn-xs btn-p" data-approve="${e.id}">✓</button>
      <button class="btn btn-xs btn-danger" data-reject="${e.id}">✗</button>`:''}
    ${isAdmin?`<button class="btn btn-xs btn-ghost" data-delete="${e.id}">🗑</button>`:''}
  </div>
</div>`).join('')}
</div>`;
    }).join('');
  } else {
    content.innerHTML=`<div style="overflow-x:auto"><table class="dt">
<thead><tr>
  <th class="tl">তারিখ</th><th class="tl">বিভাগ</th><th class="tl">আইটেম</th>
  <th>পরিমাণ</th><th>ডিপোজিট</th><th>অবস্থা</th>
  ${canApprove?'<th>অ্যাকশন</th>':''}
</tr></thead>
<tbody>
${_expenses.map(e=>`<tr>
  <td class="tl">${e.date||'—'}</td>
  <td class="tl">${CICO[e.category]||''} ${_e(e.category||'')}</td>
  <td class="tl">${_e(e.item||'')}${e.note?`<br><span style="font-size:10px;color:var(--ink4)">${_e(e.note)}</span>`:''}</td>
  <td style="font-weight:700;font-family:var(--mono)">${taka(e.amount)}</td>
  <td style="text-align:center">${e.autoDeposit?'<span style="color:var(--g1)">✓</span>':'—'}</td>
  <td>${_badge(e.status)}</td>
  ${canApprove?`<td><div style="display:flex;gap:4px;justify-content:center;flex-wrap:wrap">
    ${e.status==='pending'?`
      <button class="btn btn-xs btn-p" data-approve="${e.id}">✓</button>
      <button class="btn btn-xs btn-danger" data-reject="${e.id}">✗</button>`:''}
    ${isAdmin?`<button class="btn btn-xs btn-ghost" data-delete="${e.id}">🗑</button>`:''}
  </div></td>`:''}
</tr>`).join('')}
</tbody></table></div>`;
  }
}

function _badge(s){
  if(s==='approved') return '<span class="badge b-green" style="font-size:9px;white-space:nowrap">✓ অনুমোদিত</span>';
  if(s==='rejected') return '<span class="badge b-red" style="font-size:9px;white-space:nowrap">✗ বাতিল</span>';
  return '<span class="badge b-amber" style="font-size:9px;white-space:nowrap">⏳ অপেক্ষামাণ</span>';
}

async function _add(root){
  const date   = root.querySelector('#bz-date')?.value;
  const cat    = root.querySelector('#bz-cat')?.value;
  const item   = root.querySelector('#bz-item')?.value.trim();
  const amount = parseFloat(root.querySelector('#bz-amount')?.value)||0;
  const note   = root.querySelector('#bz-note')?.value.trim();
  const autoDep= root.querySelector('#bz-auto-dep')?.checked ?? true;

  if(!date||!item||!amount){ toast('তারিখ, আইটেম ও পরিমাণ দিন','er'); return; }

  const isCoAdmin=['mess-admin','mess-co-admin'].includes(_ctx.myMessRole);
  const status=isCoAdmin?'approved':'pending';

  try {
    // Add expense
    await addDoc(collection(db,'messes',_ctx.messId,'expenses'), {
      date, category:cat, item, amount, note:note||'',
      addedBy:_ctx.profile.uid, addedByName:_ctx.profile.name||'',
      status, autoDeposit: autoDep,
      createdAt:serverTimestamp()
    });

    // ✅ Auto-deposit: যে বাজার করেছে তার নামে deposit যোগ করো
    if(autoDep){
      await addDoc(collection(db,'messes',_ctx.messId,'deposits'), {
        memberId:   _ctx.profile.uid,
        memberName: _ctx.profile.name||_ctx.profile.email||'',
        date, amount,
        note:       `বাজার: ${item}`,
        addedBy:    _ctx.profile.uid,
        status:     isCoAdmin ? 'approved' : 'pending',
        autoFromBazar: true,
        createdAt:  serverTimestamp()
      });
      toast(`বাজার ও ডিপোজিট (${taka(amount)}) উভয়ই যোগ হয়েছে ✓`,'ok');
    } else {
      toast('বাজার যোগ হয়েছে ✓','ok');
    }

    root.querySelector('#bz-item').value='';
    root.querySelector('#bz-amount').value='';
    root.querySelector('#bz-note').value='';
    await _load(root);
  } catch(err){ toast('ব্যর্থ: '+err.message,'er'); }
}

async function _approve(root,id){
  try {
    const snap=await getDocs(query(collection(db,'messes',_ctx.messId,'expenses'),where('__name__','==',id)));
    await updateDoc(doc(db,'messes',_ctx.messId,'expenses',id),
      {status:'approved',approvedBy:_ctx.profile.uid,approvedAt:serverTimestamp()});

    // Also approve linked auto-deposit
    const exp=_expenses.find(e=>e.id===id);
    if(exp?.autoDeposit){
      const dSnap=await getDocs(query(
        collection(db,'messes',_ctx.messId,'deposits'),
        where('autoFromBazar','==',true),
        where('addedBy','==',exp.addedBy),
        where('date','==',exp.date),
        where('status','==','pending')
      ));
      for(const d of dSnap.docs){
        if(Math.abs(parseFloat(d.data().amount)-parseFloat(exp.amount))<0.01){
          await updateDoc(d.ref,{status:'approved',approvedBy:_ctx.profile.uid,approvedAt:serverTimestamp()});
        }
      }
    }

    toast('অনুমোদন দেওয়া হয়েছে','ok');
    await _load(root);
  } catch(err){ toast('ব্যর্থ: '+err.message,'er'); }
}

async function _reject(root,id){
  try {
    await updateDoc(doc(db,'messes',_ctx.messId,'expenses',id),{status:'rejected'});
    toast('বাতিল হয়েছে','ok');
    await _load(root);
  } catch(err){ toast('ব্যর্থ: '+err.message,'er'); }
}

async function _delete(root,id){
  if(!window.confirm('মুছে ফেলবেন?')) return;
  try {
    await deleteDoc(doc(db,'messes',_ctx.messId,'expenses',id));
    toast('মুছে ফেলা হয়েছে','ok');
    await _load(root);
  } catch(err){ toast('ব্যর্থ: '+err.message,'er'); }
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

// plan.js — Free/Paid plan, dynamic bKash from appConfig

import { db } from './firebase.js';
import { toast, ld, uld } from './utils.js';
import {
  doc, getDoc, addDoc, collection, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

export const PLANS = {
  free: { name:'Free', price:0, ads:true },
  paid: { name:'Pro',  price:199, priceYear:1999, ads:false },
};

export function isPaid(messData) {
  if (!messData || messData.plan!=='paid') return false;
  if (!messData.planExpiry) return false;
  const exp = messData.planExpiry?.toDate ? messData.planExpiry.toDate() : new Date(messData.planExpiry);
  return exp > new Date();
}

// Firestore থেকে appConfig লোড
async function _getConfig() {
  try {
    const snap = await getDoc(doc(db,'appConfig','main'));
    return snap.exists() ? snap.data() : {};
  } catch { return {}; }
}

export function showAdBanner(container) {
  if (!container) return;
  const adDiv = document.createElement('div');
  adDiv.style.cssText = `width:100%;background:#f1f5f2;border:1px solid #d8e8dc;
    border-radius:8px;padding:10px;text-align:center;
    font-size:11px;color:#4a7055;margin:12px 0;`;
  adDiv.innerHTML = `
<ins class="adsbygoogle"
  style="display:block;width:100%;min-height:60px"
  data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
  data-ad-slot="XXXXXXXXXX"
  data-ad-format="auto"
  data-full-width-responsive="true"></ins>
<div style="font-size:10px;color:#8aaa90;margin-top:4px">
  বিজ্ঞাপনমুক্ত অভিজ্ঞতার জন্য
  <button onclick="window.__showUpgrade()"
    style="background:none;border:none;color:#146b40;font-size:10px;font-weight:700;cursor:pointer;text-decoration:underline">
    Pro তে upgrade করুন
  </button>
</div>`;
  container.appendChild(adDiv);
  try { if(window.adsbygoogle) (window.adsbygoogle=window.adsbygoogle||[]).push({}); } catch(e) {}
}

export async function requestPayment(messId, profile, plan='monthly') {
  // ✅ Dynamic config from Firestore
  const config  = await _getConfig();
  const bkash   = config.bkashNumber || '01XXXXXXXXXX';
  const bkashType = config.bkashType || 'Personal';
  const monthly = config.monthlyPrice || 199;
  const yearly  = config.yearlyPrice  || 1999;
  const price   = plan==='yearly' ? yearly : monthly;
  const period  = plan==='yearly' ? '১ বছর' : '১ মাস';

  const mo = document.createElement('div');
  mo.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:500;display:flex;align-items:center;justify-content:center;padding:20px';
  mo.innerHTML = `
<div style="background:#fff;border-radius:16px;padding:24px;max-width:380px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,.2)">
  <h3 style="font-size:16px;font-weight:700;color:#0a180e;margin-bottom:4px">💳 Pro Plan — ${price}৳</h3>
  <p style="font-size:12px;color:#4a7055;margin-bottom:16px">${period} এর জন্য</p>

  <div style="background:#e7f3e7;border:1px solid #c0dcc0;border-radius:10px;padding:12px;margin-bottom:16px">
    <p style="font-size:12px;color:#083d22;font-weight:700;margin-bottom:6px">bKash (${bkashType}) এ Payment করুন:</p>
    <p style="font-size:22px;font-weight:700;color:#146b40;letter-spacing:2px;margin-bottom:4px">${bkash}</p>
    <p style="font-size:12px;color:#083d22;margin-top:8px">Amount: <strong>${price}৳</strong></p>
    <p style="font-size:12px;color:#083d22">Reference: <strong>${messId.slice(0,8).toUpperCase()}</strong></p>
  </div>

  <div style="margin-bottom:14px">
    <label style="font-size:11px;font-weight:700;color:#4a7055;text-transform:uppercase;letter-spacing:.7px;display:block;margin-bottom:5px">
      bKash Transaction ID *
    </label>
    <input id="txn-inp" class="inp inp-sm" placeholder="যেমন: 8N6YJX8P4E" maxlength="20"
      style="width:100%;"/>
  </div>

  <div style="display:flex;gap:6px;margin-bottom:10px">
    <button onclick="this.parentElement.parentElement.querySelector('[data-plan]').dataset.plan='monthly'"
      style="flex:1;padding:8px;border:1.5px solid #b0ceb8;border-radius:8px;
        font-size:12px;font-weight:600;cursor:pointer;background:#f1f5f2;color:#0a180e"
      data-plan="monthly">মাসিক — ${monthly}৳</button>
    <button onclick="this.parentElement.parentElement.querySelector('[data-plan]').dataset.plan='yearly'"
      style="flex:1;padding:8px;border:1.5px solid #b0ceb8;border-radius:8px;
        font-size:12px;font-weight:600;cursor:pointer;background:#f1f5f2;color:#0a180e"
      data-plan="yearly">বার্ষিক — ${yearly}৳</button>
  </div>
  <input type="hidden" id="plan-inp" data-plan="${plan}"/>

  <div style="display:flex;gap:8px">
    <button onclick="this.closest('[style*=fixed]').remove()"
      style="flex:1;height:38px;border:1px solid #b0ceb8;background:#f1f5f2;
        border-radius:8px;font-size:13px;font-weight:600;cursor:pointer">বাতিল</button>
    <button id="pay-submit"
      style="flex:1;height:38px;background:#146b40;color:#fff;border:none;
        border-radius:8px;font-size:13px;font-weight:600;cursor:pointer">📤 Submit</button>
  </div>
  <p style="font-size:10px;color:#8aaa90;text-align:center;margin-top:10px">
    Admin verify করার পর Plan activate হবে (সাধারণত ২৪ ঘণ্টার মধ্যে)
  </p>
</div>`;

  document.body.appendChild(mo);

  document.getElementById('pay-submit')?.addEventListener('click', async ()=>{
    const txnId   = document.getElementById('txn-inp')?.value.trim();
    const selPlan = document.getElementById('plan-inp')?.dataset.plan || plan;
    const selPrice = selPlan==='yearly' ? yearly : monthly;
    if (!txnId||txnId.length<6) { toast('সঠিক Transaction ID দিন','er'); return; }
    ld('Submit হচ্ছে…');
    try {
      await addDoc(collection(db,'paymentRequests'), {
        messId,
        requestedBy:   profile.uid,
        requesterName: profile.name||profile.email,
        amount:        selPrice,
        plan:          selPlan,
        txnId,
        bkashNumber:   bkash,
        status:        'pending',
        createdAt:     serverTimestamp(),
      });
      mo.remove();
      toast('Payment request পাঠানো হয়েছে! Admin verify করবেন।','ok');
    } catch(err){ toast('Submit ব্যর্থ: '+err.message,'er'); }
    finally { uld(); }
  });
}

export function showUpgradeModal(messId, profile) {
  window.__showUpgrade = () => requestPayment(messId, profile);
  window.__showUpgrade();
}

// my-report.js — Personal report: আমার মিল, খরচ, ব্যালেন্স

import { db } from '../../firebase.js';
import { toast, ld, uld, taka, takaF, pad, moName } from '../../utils.js';
import {
  collection, getDocs, query, where, doc, getDoc
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _ctx={};

export async function render(root, ctx) {
  _ctx = ctx;

  root.innerHTML = `
<div>
  <div style="display:flex;align-items:center;justify-content:space-between;
    margin-bottom:14px;flex-wrap:wrap;gap:8px">
    <div>
      <h2 style="font-size:17px;font-weight:700;color:var(--ink);margin:0">📋 আমার রিপোর্ট</h2>
      <p style="font-size:12px;color:var(--ink3);margin:3px 0 0">
        ${_e(ctx.profile.name||ctx.profile.email)} এর ব্যক্তিগত হিসাব
      </p>
    </div>
    <button class="btn btn-ghost btn-sm" id="mr-refresh">🔄 রিফ্রেশ</button>
  </div>

  <!-- This month summary -->
  <div class="g4" style="margin-bottom:14px" id="mr-cards">
    <div class="sc sg"><div class="sl">এই মাসে মিল</div><div class="sv" id="mr-meal">—</div></div>
    <div class="sc sa"><div class="sl">মিল খরচ</div><div class="sv" id="mr-cost">—</div></div>
    <div class="sc sb"><div class="sl">জমা দিয়েছি</div><div class="sv" id="mr-dep">—</div></div>
    <div class="sc" id="mr-bal-card"><div class="sl">ব্যালেন্স</div><div class="sv" id="mr-bal">—</div><div class="ss" id="mr-bal-note"></div></div>
  </div>

  <!-- 6 month chart -->
  <div class="card" style="margin-bottom:14px">
    <div class="ch"><h3>📊 বিগত ৬ মাসের মিল</h3></div>
    <div class="cb">
      <div id="mr-chart" style="display:flex;align-items:flex-end;gap:6px;height:120px;padding-bottom:4px"></div>
      <div id="mr-chart-labels" style="display:flex;gap:6px;margin-top:4px"></div>
    </div>
  </div>

  <!-- Monthly detail -->
  <div class="card">
    <div class="ch">
      <h3>📅 মাসভিত্তিক হিসাব</h3>
      <button class="btn btn-p btn-sm" id="mr-export">📥 Excel</button>
    </div>
    <div style="overflow-x:auto" id="mr-table">লোড হচ্ছে…</div>
  </div>
</div>`;

  root.querySelector('#mr-refresh').addEventListener('click', ()=> _load(root));
  root.querySelector('#mr-export').addEventListener('click', ()=> _export(root));

  await _load(root);
}

async function _load(root) {
  ld('আমার রিপোর্ট লোড হচ্ছে…');
  try {
    const uid = _ctx.profile.uid;
    const monthsData = [];

    // বিগত ৬ মাসের data collect করো
    for (let i=5; i>=0; i--) {
      const d   = new Date(TODAY.getFullYear(), TODAY.getMonth()-i, 1);
      const vy  = d.getFullYear();
      const vm  = d.getMonth();
      const pfx = `${vy}_${pad(vm+1)}`;
      const str = `${vy}-${pad(vm+1)}`;

      // Meals
      const mealSnap = await getDocs(collection(db,'messes',_ctx.messId,'meals'));
      let myMeals=0;
      mealSnap.forEach(doc=>{
        if (doc.id.startsWith(pfx) && doc.id.endsWith('_'+uid)) {
          myMeals += (doc.data().slots||[]).filter(Boolean).length;
          myMeals += (doc.data().guestSlots||[]).filter(Boolean).length;
        }
      });

      // Total mess meals for rate calculation
      let totalMeals=0;
      mealSnap.forEach(doc=>{
        if (doc.id.startsWith(pfx)) {
          totalMeals += (doc.data().slots||[]).filter(Boolean).length;
          totalMeals += (doc.data().guestSlots||[]).filter(Boolean).length;
        }
      });

      // Total bazar
      const expSnap = await getDocs(query(
        collection(db,'messes',_ctx.messId,'expenses'), where('status','==','approved')
      ));
      let totalBazar=0;
      expSnap.forEach(d=>{ if(d.data().date?.startsWith(str)) totalBazar+=parseFloat(d.data().amount)||0; });

      // My deposits
      const depSnap = await getDocs(query(
        collection(db,'messes',_ctx.messId,'deposits'),
        where('memberId','==',uid), where('status','==','approved')
      ));
      let myDep=0;
      depSnap.forEach(d=>{ if(d.data().date?.startsWith(str)) myDep+=parseFloat(d.data().amount)||0; });

      const rate    = totalMeals>0 ? totalBazar/totalMeals : 0;
      const myCost  = myMeals * rate;
      const balance = myDep - myCost;

      monthsData.push({
        label:  moName(vm)+' '+vy,
        month:  vm, year: vy,
        meals:  myMeals,
        cost:   myCost,
        dep:    myDep,
        balance,
        rate,
        isCurrent: i===0
      });
    }

    const cur = monthsData[monthsData.length-1];

    // Update summary cards
    const _sv=(id,v)=>{ const el=root.querySelector('#'+id); if(el) el.textContent=v; };
    _sv('mr-meal', cur.meals);
    _sv('mr-cost', taka(cur.cost));
    _sv('mr-dep',  taka(cur.dep));
    _sv('mr-bal',  taka(cur.balance));

    const balCard = root.querySelector('#mr-bal-card');
    const balNote = root.querySelector('#mr-bal-note');
    if (balCard) {
      balCard.className = `sc ${cur.balance>=0?'sg':'sr'}`;
    }
    if (balNote) {
      balNote.textContent = cur.balance>=0
        ? `${taka(cur.balance)} পাবেন`
        : `${taka(Math.abs(cur.balance))} দেবেন`;
    }

    // Chart
    _drawChart(root, monthsData);

    // Table
    const tableEl = root.querySelector('#mr-table');
    if (tableEl) {
      tableEl.innerHTML = `
<table class="dt">
<thead><tr>
  <th class="tl">মাস</th>
  <th>মিল</th>
  <th>মিল রেট</th>
  <th>মিল খরচ</th>
  <th>জমা</th>
  <th>ব্যালেন্স</th>
</tr></thead>
<tbody>
${monthsData.map(m=>`
<tr style="${m.isCurrent?'background:var(--g8);font-weight:600':''}">
  <td class="tl">${_e(m.label)}${m.isCurrent?' <span style="font-size:10px;color:var(--g1)">(এই মাস)</span>':''}</td>
  <td>${m.meals||'—'}</td>
  <td style="font-family:var(--mono)">${m.rate>0?takaF(m.rate):'—'}</td>
  <td style="font-family:var(--mono)">${m.cost>0?takaF(m.cost):'—'}</td>
  <td style="font-family:var(--mono)">${m.dep>0?taka(m.dep):'—'}</td>
  <td style="font-family:var(--mono);font-weight:700;color:${m.balance>=0?'var(--g1)':'var(--r1)'}">
    ${m.cost>0||m.dep>0 ? takaF(m.balance) : '—'}
  </td>
</tr>`).join('')}
</tbody>
</table>`;
    }

    // Store for export
    root._monthsData = monthsData;

  } catch(err) {
    toast('লোড ব্যর্থ: '+err.message,'er');
    console.error(err);
  } finally { uld(); }
}

function _drawChart(root, data) {
  const chartEl  = root.querySelector('#mr-chart');
  const labelEl  = root.querySelector('#mr-chart-labels');
  if (!chartEl) return;

  const max = Math.max(...data.map(d=>d.meals), 1);

  chartEl.innerHTML = data.map(m=>{
    const h   = Math.round((m.meals/max)*100);
    const isCur = m.isCurrent;
    return `
<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:3px">
  <span style="font-size:10px;font-weight:700;color:${isCur?'var(--g1)':'var(--ink4)'}">${m.meals||''}</span>
  <div style="width:100%;height:${Math.max(h,4)}px;
    background:${isCur?'var(--g2)':'var(--g5)'};
    border-radius:4px 4px 0 0;transition:.3s"></div>
</div>`;
  }).join('');

  labelEl.innerHTML = data.map(m=>`
<div style="flex:1;text-align:center;font-size:10px;color:${m.isCurrent?'var(--g1)':'var(--ink4)'};
  font-weight:${m.isCurrent?'700':'400'};white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
  ${_e(m.label.split(' ')[0])}
</div>`).join('');
}

function _export(root) {
  if (!window.XLSX) { toast('XLSX লোড হয়নি','er'); return; }
  const data = root._monthsData;
  if (!data) { toast('আগে লোড করুন','er'); return; }

  const sheet = [
    [`${_e(_ctx.profile.name||_ctx.profile.email)} — ব্যক্তিগত রিপোর্ট`],
    [],
    ['মাস','মিল সংখ্যা','মিল রেট (৳)','মিল খরচ (৳)','জমা (৳)','ব্যালেন্স (৳)'],
    ...data.map(m=>[
      m.label, m.meals,
      parseFloat(m.rate.toFixed(2)),
      parseFloat(m.cost.toFixed(2)),
      m.dep,
      parseFloat(m.balance.toFixed(2))
    ])
  ];

  const wb = window.XLSX.utils.book_new();
  window.XLSX.utils.book_append_sheet(wb, window.XLSX.utils.aoa_to_sheet(sheet), 'My Report');
  window.XLSX.writeFile(wb, `my-report-${_ctx.profile.name||'user'}.xlsx`);
  toast('Excel download হচ্ছে…','ok');
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

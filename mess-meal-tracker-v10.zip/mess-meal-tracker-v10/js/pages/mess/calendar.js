// calendar.js — মাসিক meal calendar view

import { db } from '../../firebase.js';
import { toast, ld, uld, pad, moName, dim } from '../../utils.js';
import {
  collection, getDocs, doc, getDoc, setDoc, query, orderBy
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _ctx={}, _vy=TODAY.getFullYear(), _vm=TODAY.getMonth();
let _members=[], _meals={};

export async function render(root, ctx) {
  _ctx = ctx;
  const slots = ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const SICO  = ['☀️','🌤','🌙','🍳','🍱','🌮'];

  root.innerHTML = `
<div>
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <button class="btn btn-ghost btn-sm" id="cal-prev">◀</button>
    <span style="font-size:14px;font-weight:700;min-width:130px;text-align:center" id="cal-lbl"></span>
    <button class="btn btn-ghost btn-sm" id="cal-next">▶</button>
    <button class="btn btn-ghost btn-sm" id="cal-today">আজ</button>
    <div style="display:flex;gap:6px;margin-left:auto;align-items:center">
      <label class="lbl" style="margin:0">সদস্য:</label>
      <select class="inp inp-sm" id="cal-member" style="width:auto"></select>
    </div>
    <button class="btn btn-ghost btn-sm" id="cal-ref">🔄</button>
  </div>

  <!-- Calendar grid -->
  <div class="card">
    <div class="ch">
      <h3>📅 মিল ক্যালেন্ডার</h3>
      <div style="display:flex;gap:10px;font-size:11px;color:var(--ink3)">
        <span style="display:flex;align-items:center;gap:4px">
          <span style="width:12px;height:12px;background:var(--g2);border-radius:2px"></span> মিল আছে
        </span>
        <span style="display:flex;align-items:center;gap:4px">
          <span style="width:12px;height:12px;background:var(--paper);border:1px solid var(--line2);border-radius:2px"></span> মিল নেই
        </span>
      </div>
    </div>
    <div class="cb" style="padding:10px;overflow-x:auto">
      <div id="cal-grid"></div>
    </div>
  </div>

  <!-- Month summary -->
  <div class="card" style="margin-top:13px">
    <div class="ch"><h3>📊 মাসিক সারসংক্ষেপ</h3></div>
    <div class="cb" id="cal-summary">লোড হচ্ছে…</div>
  </div>
</div>

<!-- Day edit modal -->
<div style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);
  z-index:300;align-items:center;justify-content:center;padding:20px" id="cal-modal">
  <div style="background:#fff;border-radius:16px;padding:22px;max-width:360px;
    width:100%;max-height:90vh;overflow-y:auto">
    <h3 style="font-size:15px;font-weight:700;margin-bottom:4px" id="cal-modal-title"></h3>
    <p style="font-size:12px;color:var(--ink3);margin-bottom:14px" id="cal-modal-sub"></p>
    <div class="slot-row" id="cal-modal-slots"></div>
    <div style="margin-top:10px;margin-bottom:14px">
      <label class="lbl">Guest মিল</label>
      <input class="inp inp-sm" id="cal-modal-guest" type="number" min="0" max="20" placeholder="0" style="width:90px"/>
    </div>
    <div style="display:flex;gap:8px">
      <button class="btn btn-ghost" id="cal-modal-close">বাতিল</button>
      <button class="btn btn-p" id="cal-modal-save">✓ সেভ করুন</button>
    </div>
  </div>
</div>`;

  root.querySelector('#cal-prev').addEventListener('click', ()=>{ _vm--; if(_vm<0){_vm=11;_vy--} _load(root); });
  root.querySelector('#cal-next').addEventListener('click', ()=>{ _vm++; if(_vm>11){_vm=0;_vy++} _load(root); });
  root.querySelector('#cal-today').addEventListener('click', ()=>{ _vy=TODAY.getFullYear();_vm=TODAY.getMonth(); _load(root); });
  root.querySelector('#cal-ref').addEventListener('click', ()=> _load(root));
  root.querySelector('#cal-member').addEventListener('change', ()=> _renderCalendar(root));
  root.querySelector('#cal-modal-close').addEventListener('click', ()=>{
    root.querySelector('#cal-modal').style.display='none';
  });
  root.querySelector('#cal-grid').addEventListener('click', e=>{
    const cell = e.target.closest('[data-day]');
    if (cell) _openModal(root, parseInt(cell.dataset.day));
  });

  await _load(root);
}

async function _load(root) {
  root.querySelector('#cal-lbl').textContent = `${moName(_vm)} ${_vy}`;
  ld('ক্যালেন্ডার লোড হচ্ছে…');
  try {
    // Members
    const mSnap = await getDocs(query(collection(db,'messes',_ctx.messId,'members'), orderBy('joinedAt')));
    _members = mSnap.docs.map(d=>({uid:d.id,...d.data()}));

    const sel = root.querySelector('#cal-member');
    if (sel) {
      const curVal = sel.value || _ctx.profile.uid;
      sel.innerHTML = _members.map(m=>
        `<option value="${m.uid}">${_e(m.name||m.email)}${m.uid===_ctx.profile.uid?' (আমি)':''}</option>`
      ).join('');
      sel.value = _members.find(m=>m.uid===curVal) ? curVal : _ctx.profile.uid;
    }

    // Meals for month
    const allMeals = await getDocs(collection(db,'messes',_ctx.messId,'meals'));
    _meals = {};
    const pfx = `${_vy}_${pad(_vm+1)}`;
    allMeals.forEach(d=>{ if(d.id.startsWith(pfx)) _meals[d.id]=d.data(); });

    _renderCalendar(root);
    _renderSummary(root);
  } finally { uld(); }
}

function _renderCalendar(root) {
  const uid    = root.querySelector('#cal-member')?.value || _ctx.profile.uid;
  const slots  = _ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const SICO   = ['☀️','🌤','🌙','🍳','🍱'];
  const days   = dim(_vy, _vm);
  const first  = new Date(_vy, _vm, 1).getDay(); // 0=Sun
  const cutoff = _ctx.messSettings?.cutoffHour ?? 10;
  const canEdit= uid===_ctx.profile.uid || ['mess-admin','mess-co-admin'].includes(_ctx.myMessRole);

  let html = `
<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:3px;min-width:280px">
  ${['রোব','সোম','মঙ্গল','বুধ','বৃহ','শুক্র','শনি'].map(d=>
    `<div style="text-align:center;font-size:10px;font-weight:700;color:var(--ink3);
      padding:4px 0">${d}</div>`).join('')}`;

  // Empty cells before first day
  for (let i=0; i<first; i++) {
    html += `<div></div>`;
  }

  for (let d=1; d<=days; d++) {
    const key   = `${_vy}_${pad(_vm+1)}_${pad(d)}_${uid}`;
    const data  = _meals[key] || {};
    const s     = data.slots || [];
    const g     = (data.guestSlots||[]).filter(Boolean).length;
    const total = s.filter(Boolean).length + g;
    const isToday = d===TODAY.getDate() && _vy===TODAY.getFullYear() && _vm===TODAY.getMonth();
    const isPast  = new Date(_vy,_vm,d) < new Date(TODAY.getFullYear(),TODAY.getMonth(),TODAY.getDate());
    const hasMeal = total > 0;

    html += `
<div data-day="${d}" ${canEdit?'style="cursor:pointer"':''}
  style="border-radius:8px;padding:4px;border:1.5px solid ${isToday?'var(--g3)':hasMeal?'var(--g5)':'var(--line)'};
    background:${hasMeal?'var(--g7)':isToday?'var(--g8)':'var(--paper)'};
    min-height:52px;transition:.12s;${canEdit?'hover:opacity:.8':''}">
  <div style="font-size:11px;font-weight:${isToday?'700':'500'};
    color:${isToday?'var(--g1)':hasMeal?'var(--g2)':'var(--ink4)'};
    margin-bottom:2px">${d}</div>
  ${hasMeal ? `
  <div style="display:flex;flex-wrap:wrap;gap:1px">
    ${s.map((on,i)=>on?`<span style="font-size:10px">${SICO[i]||'🍽'}</span>`:'').filter(Boolean).join('')}
    ${g>0?`<span style="font-size:9px;background:var(--b3);color:var(--b0);border-radius:3px;padding:0 3px">+${g}G</span>`:''}
  </div>
  <div style="font-size:10px;font-weight:700;color:var(--g1)">${total}টি</div>` :
  `<div style="font-size:10px;color:var(--ink4)">${isPast?'—':''}</div>`}
</div>`;
  }
  html += '</div>';
  root.querySelector('#cal-grid').innerHTML = html;
}

function _renderSummary(root) {
  const uid   = root.querySelector('#cal-member')?.value || _ctx.profile.uid;
  const slots = _ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const days  = dim(_vy, _vm);

  let totalMeal=0, guestTotal=0;
  const slotCounts = new Array(slots.length).fill(0);

  for (let d=1; d<=days; d++) {
    const key  = `${_vy}_${pad(_vm+1)}_${pad(d)}_${uid}`;
    const data = _meals[key] || {};
    (data.slots||[]).forEach((on,i)=>{ if(on){ slotCounts[i]++; totalMeal++; } });
    const g = (data.guestSlots||[]).filter(Boolean).length;
    guestTotal += g;
    totalMeal  += g;
  }

  const el = root.querySelector('#cal-summary');
  if (!el) return;

  const SICO=['☀️','🌤','🌙','🍳','🍱'];
  el.innerHTML = `
<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px">
  ${slots.map((s,i)=>`
  <div style="background:${slotCounts[i]>0?'var(--g7)':'var(--paper)'};
    border:1px solid ${slotCounts[i]>0?'var(--g5)':'var(--line)'};
    border-radius:10px;padding:8px 12px;text-align:center;min-width:75px">
    <div style="font-size:16px">${SICO[i]||'🍽'}</div>
    <div style="font-size:11px;color:var(--ink)">${_e(s)}</div>
    <div style="font-size:18px;font-weight:700;color:${slotCounts[i]>0?'var(--g1)':'var(--ink4)'};
      font-family:var(--mono)">${slotCounts[i]}</div>
  </div>`).join('')}
  ${guestTotal>0?`
  <div style="background:var(--b4);border:1px solid var(--b3);
    border-radius:10px;padding:8px 12px;text-align:center;min-width:75px">
    <div style="font-size:16px">👥</div>
    <div style="font-size:11px;color:var(--ink)">Guest</div>
    <div style="font-size:18px;font-weight:700;color:var(--b0);font-family:var(--mono)">${guestTotal}</div>
  </div>`:''}
  <div style="background:var(--g2);border-radius:10px;padding:8px 12px;
    text-align:center;min-width:75px">
    <div style="font-size:16px">🍱</div>
    <div style="font-size:11px;color:#c0f0d8">মোট</div>
    <div style="font-size:18px;font-weight:700;color:#fff;font-family:var(--mono)">${totalMeal}</div>
  </div>
</div>`;
}

async function _openModal(root, day) {
  const uid    = root.querySelector('#cal-member')?.value || _ctx.profile.uid;
  const slots  = _ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const SICO   = ['☀️','🌤','🌙','🍳','🍱'];
  const cutoff = _ctx.messSettings?.cutoffHour ?? 10;
  const isPast = new Date(_vy,_vm,day) < new Date(TODAY.getFullYear(),TODAY.getMonth(),TODAY.getDate());
  const isToday= day===TODAY.getDate() && _vy===TODAY.getFullYear() && _vm===TODAY.getMonth();
  const locked = isToday && TODAY.getHours()>=cutoff && !['mess-admin','mess-co-admin'].includes(_ctx.myMessRole);

  const key  = `${_vy}_${pad(_vm+1)}_${pad(day)}_${uid}`;
  const data = _meals[key] || {};
  const curSlots = data.slots||[];
  const curGuest = (data.guestSlots||[]).filter(Boolean).length;

  const member = _members.find(m=>m.uid===uid);
  root.querySelector('#cal-modal-title').textContent =
    `${day} ${moName(_vm)} — ${_e(member?.name||'আমি')}`;
  root.querySelector('#cal-modal-sub').textContent =
    locked?'⏰ আজকের মিল বন্ধ হয়েছে':'বেলা select করুন';

  root.querySelector('#cal-modal-slots').innerHTML = slots.map((s,i)=>`
<button class="slt${curSlots[i]?' on':''}${locked?' locked':''}"
  data-modal-si="${i}">
  ${SICO[i]||'🍽'} ${_e(s)}
</button>`).join('');

  root.querySelector('#cal-modal-guest').value = curGuest||'';

  // Slot toggle in modal
  root.querySelector('#cal-modal-slots').addEventListener('click', e=>{
    const btn = e.target.closest('[data-modal-si]');
    if (btn && !locked) btn.classList.toggle('on');
  });

  root.querySelector('#cal-modal-save').onclick = async ()=>{
    const newSlots = [...root.querySelectorAll('[data-modal-si]')]
      .map(b=>b.classList.contains('on'));
    const newGuest = parseInt(root.querySelector('#cal-modal-guest')?.value)||0;
    const ref = doc(db,'messes',_ctx.messId,'meals',key);
    await setDoc(ref, {
      slots:      newSlots,
      guestSlots: Array(newGuest).fill(true),
      memberId:   uid
    }, {merge:true});
    _meals[key] = { slots:newSlots, guestSlots:Array(newGuest).fill(true) };
    root.querySelector('#cal-modal').style.display='none';
    _renderCalendar(root);
    _renderSummary(root);
    toast('মিল সেভ হয়েছে ✓','ok');
  };

  root.querySelector('#cal-modal').style.display='flex';
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

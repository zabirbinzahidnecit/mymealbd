// report-export.js — v15: branded PDF + Excel export (shared by report.js & admin-reports.js)

import { taka, takaF, pad, moName, dim } from './utils.js';

const BRAND = {
  name:    'Mess Meal Tracker',
  tagline: 'মেসের মিল, বাজার ও হিসাব সব এক জায়গায়',
  dev:     'Developed by Exit Excit',
  color:   '#146b40',
  dark:    '#083d22',
  accent:  '#e8a838',
  light:   '#f1f5f2',
};

// ── PDF Export ───────────────────────────────────────────────────────────────
export function exportPDF({ messName, messAddress, month, year, members,
  meals, expenses, deposits, slots, profile, isMessTab }) {

  const moLabel    = `${moName(month)} ${year}`;
  const monthStr   = `${year}-${pad(month+1)}`;
  const monthPfx   = `${year}_${pad(month+1)}`;
  const generated  = new Date().toLocaleDateString('bn-BD', {year:'numeric',month:'long',day:'numeric'});

  // ── calc ──
  let grandMeals=0;
  const memberData = members.map(m=>{
    let ml=0, gl=0;
    Object.entries(meals).forEach(([key,data])=>{
      if(key.startsWith(monthPfx) && key.endsWith('_'+m.uid)){
        ml += (data.slots||[]).filter(Boolean).length;
        gl += (data.guestSlots||[]).filter(Boolean).length;
      }
    });
    const all=ml+gl; grandMeals+=all;
    const dep=deposits.filter(d=>d.memberId===m.uid).reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
    return {...m,meals:ml,guest:gl,all,dep};
  });
  const totalBazar   = expenses.reduce((s,e)=>s+(parseFloat(e.amount)||0),0);
  const totalDeposit = deposits.reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
  const mealRate     = grandMeals>0 ? totalBazar/grandMeals : 0;
  memberData.forEach(m=>{ m.cost=m.all*mealRate; m.balance=m.dep-m.cost; });

  // ── meal calendar per member ──
  const calendarHTML = isMessTab ? '' : _calendarTable(profile.uid, meals, month, year, slots, moLabel);

  // ── personal txn for my report ──
  const uid = profile?.uid;
  let myData = null;
  if (!isMessTab && uid) {
    const me = memberData.find(m=>m.uid===uid) || {};
    myData = me;
  }

  const html = `<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8"/>
<title>${_e(messName)} — ${moLabel} রিপোর্ট</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700&display=swap');
@page { size:A4; margin:0; }
*{ box-sizing:border-box; margin:0; padding:0; }
body{ font-family:'Hind Siliguri',Arial,sans-serif; font-size:11px; color:#1a1a1a; background:#fff; }

/* ── HEADER ── */
.hdr{ background:${BRAND.color}; padding:0; display:flex; height:72px; }
.hdr-logo{ width:72px; height:72px; background:rgba(0,0,0,.2); display:flex;
  align-items:center; justify-content:center; font-size:32px; flex-shrink:0; }
.hdr-mid{ flex:1; padding:10px 14px; display:flex; flex-direction:column; justify-content:center; }
.hdr-title{ font-size:20px; font-weight:700; color:#fff; line-height:1.1; }
.hdr-sub{ font-size:10px; color:rgba(255,255,255,.75); margin-top:3px; }
.hdr-right{ padding:10px 14px; text-align:right; display:flex; flex-direction:column; justify-content:center; }
.hdr-report{ font-size:13px; font-weight:700; color:${BRAND.accent}; text-transform:uppercase; letter-spacing:1px; }
.hdr-generated{ font-size:10px; color:rgba(255,255,255,.65); margin-top:4px; }

/* ── ACCENT BAR ── */
.accent-bar{ height:4px; background:${BRAND.accent}; }

/* ── META ROW ── */
.meta-row{ display:grid; grid-template-columns:1fr 1fr 1fr; gap:0;
  border-bottom:2px solid ${BRAND.color}; padding:8px 16px; background:#f8fbf9; }
.meta-cell{ padding:4px 8px; border-right:1px solid #d0e8d8; }
.meta-cell:last-child{ border-right:none; }
.meta-lbl{ font-size:9px; font-weight:700; color:${BRAND.color}; text-transform:uppercase; letter-spacing:.5px; }
.meta-val{ font-size:13px; font-weight:700; color:${BRAND.dark}; margin-top:2px; }

/* ── BODY ── */
.body{ padding:12px 16px; }

/* ── SUMMARY BOXES ── */
.sum-grid{ display:grid; grid-template-columns:repeat(4,1fr); gap:8px; margin-bottom:14px; }
.sum-box{ border-radius:8px; padding:8px 10px; border:1px solid; }
.sum-box.green{ background:#e7f3e7; border-color:#b0d8b8; }
.sum-box.amber{ background:#fef3e2; border-color:#f5d88a; }
.sum-box.blue{ background:#e8f0fe; border-color:#b3cef8; }
.sum-box.red{ background:#fde8e8; border-color:#f5b8b8; }
.sum-lbl{ font-size:9px; font-weight:700; text-transform:uppercase; letter-spacing:.4px; color:#4a7055; }
.sum-val{ font-size:17px; font-weight:700; color:${BRAND.dark}; margin-top:3px; }
.sum-sub{ font-size:9px; color:#7a9a84; margin-top:1px; }

/* ── SECTION HEADING ── */
.sec-h{ display:flex; align-items:center; gap:8px; margin:14px 0 8px;
  border-bottom:2px solid ${BRAND.color}; padding-bottom:4px; }
.sec-h-txt{ font-size:12px; font-weight:700; color:${BRAND.dark}; }

/* ── TABLE ── */
table{ width:100%; border-collapse:collapse; margin-bottom:12px; font-size:10.5px; }
thead tr{ background:${BRAND.color}; color:#fff; }
thead th{ padding:6px 8px; text-align:left; font-weight:700; font-size:10px; }
thead th.r{ text-align:right; }
tbody tr:nth-child(even){ background:#f8fbf9; }
tbody td{ padding:5px 8px; border-bottom:1px solid #e8f0ea; vertical-align:top; }
tbody td.r{ text-align:right; }
tbody td.bold{ font-weight:700; }
tfoot tr{ background:#e0f0e8; }
tfoot td{ padding:5px 8px; font-weight:700; border-top:2px solid ${BRAND.color}; }
tfoot td.r{ text-align:right; }
.bal-pos{ color:#146b40; font-weight:700; }
.bal-neg{ color:#b83030; font-weight:700; }
.mdot{ width:14px; height:14px; border-radius:50%; display:inline-flex;
  align-items:center; justify-content:center; font-size:8px; margin:0 auto; }
.mdot.don{ background:${BRAND.color}; color:#fff; }
.mdot.doff{ background:#e8e8e8; color:#999; border:1px solid #ccc; }

/* ── SIGN SECTION ── */
.sign-area{ display:grid; grid-template-columns:repeat(3,1fr); gap:20px;
  margin-top:24px; padding-top:12px; border-top:1px solid #d0e8d8; }
.sign-box{ text-align:center; }
.sign-line{ border-bottom:1px solid #333; width:100%; margin-bottom:5px; height:30px; }
.sign-lbl{ font-size:10px; color:#4a7055; font-weight:600; }

/* ── FOOTER ── */
.ftr{ background:${BRAND.color}; padding:8px 16px;
  display:flex; align-items:center; justify-content:space-between;
  margin-top:20px; page-break-inside:avoid; }
.ftr-left{ font-size:11px; font-weight:700; color:#fff; }
.ftr-mid{ font-size:10px; color:rgba(255,255,255,.7); }
.ftr-right{ font-size:10px; color:rgba(255,255,255,.7); }

@media print{
  .no-print{ display:none; }
  .hdr{ -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  .ftr{ -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  thead{ -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  .sum-box{ -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  tr{ page-break-inside:avoid; }
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="hdr">
  <div class="hdr-logo">🍽️</div>
  <div class="hdr-mid">
    <div class="hdr-title">${_e(BRAND.name)}</div>
    <div class="hdr-sub">${_e(BRAND.tagline)}</div>
  </div>
  <div class="hdr-right">
    <div class="hdr-report">MONTHLY REPORT</div>
    <div class="hdr-generated">Generated: ${generated}</div>
  </div>
</div>
<div class="accent-bar"></div>

<!-- META -->
<div class="meta-row">
  <div class="meta-cell">
    <div class="meta-lbl">Mess Name</div>
    <div class="meta-val">${_e(messName||'—')}</div>
    ${messAddress?`<div style="font-size:10px;color:#4a7055">${_e(messAddress)}</div>`:''}
  </div>
  <div class="meta-cell">
    <div class="meta-lbl">Month / Year</div>
    <div class="meta-val">${moLabel}</div>
  </div>
  <div class="meta-cell">
    <div class="meta-lbl">${isMessTab?'Total Members':'Member'}</div>
    <div class="meta-val">${isMessTab ? members.length : _e(profile?.name||'—')}</div>
  </div>
</div>

<div class="body">

<!-- SUMMARY -->
<div class="sum-grid">
  <div class="sum-box green">
    <div class="sum-lbl">মোট মিল</div>
    <div class="sum-val">${isMessTab?grandMeals:(myData?.all||0)}</div>
    <div class="sum-sub">${isMessTab?'সকল সদস্য':'এই মাসে'}</div>
  </div>
  <div class="sum-box amber">
    <div class="sum-lbl">মিল রেট</div>
    <div class="sum-val">৳${mealRate.toFixed(2)}</div>
    <div class="sum-sub">প্রতি মিল</div>
  </div>
  <div class="sum-box blue">
    <div class="sum-lbl">${isMessTab?'মোট বাজার':'মিল খরচ'}</div>
    <div class="sum-val">৳${isMessTab?totalBazar.toFixed(2):(myData?.cost||0).toFixed(2)}</div>
  </div>
  <div class="sum-box ${isMessTab||((myData?.balance||0)>=0)?'green':'red'}">
    <div class="sum-lbl">${isMessTab?'মোট জমা':'আমার জমা'}</div>
    <div class="sum-val">৳${isMessTab?totalDeposit.toFixed(2):(myData?.dep||0).toFixed(2)}</div>
    ${!isMessTab?`<div class="sum-sub ${(myData?.balance||0)>=0?'bal-pos':'bal-neg'}">
      ব্যালেন্স: ৳${(myData?.balance||0).toFixed(2)}</div>`:''}
  </div>
</div>

<!-- MEMBER TABLE (mess report) or MY CALENDAR (my report) -->
${isMessTab ? `
<div class="sec-h"><span class="sec-h-txt">👥 সদস্য ভিত্তিক হিসাব</span></div>
<table>
<thead><tr>
  <th>সদস্য</th><th class="r">মিল</th><th class="r">Guest</th>
  <th class="r">মোট মিল</th><th class="r">মিল খরচ (৳)</th>
  <th class="r">জমা (৳)</th><th class="r">ব্যালেন্স (৳)</th>
</tr></thead>
<tbody>
${memberData.map(m=>`<tr>
  <td class="bold">${_e(m.name||m.email)}</td>
  <td class="r">${m.meals}</td>
  <td class="r">${m.guest||'—'}</td>
  <td class="r bold">${m.all}</td>
  <td class="r">৳${m.cost.toFixed(2)}</td>
  <td class="r">৳${m.dep.toFixed(2)}</td>
  <td class="r ${m.balance>=0?'bal-pos':'bal-neg'}">৳${m.balance.toFixed(2)}</td>
</tr>`).join('')}
</tbody>
<tfoot><tr>
  <td class="bold">মোট</td><td></td><td></td>
  <td class="r">${grandMeals}</td>
  <td class="r">৳${totalBazar.toFixed(2)}</td>
  <td class="r">৳${totalDeposit.toFixed(2)}</td>
  <td class="r ${totalDeposit>=totalBazar?'bal-pos':'bal-neg'}">৳${(totalDeposit-totalBazar).toFixed(2)}</td>
</tr></tfoot>
</table>` : calendarHTML}

<!-- BAZAR LIST -->
${expenses.length ? `
<div class="sec-h"><span class="sec-h-txt">🛒 বাজারের তালিকা</span></div>
<table>
<thead><tr>
  <th>তারিখ</th><th>বিভাগ</th><th>আইটেম</th><th>যোগ করেছেন</th><th class="r">পরিমাণ (৳)</th>
</tr></thead>
<tbody>
${(isMessTab?expenses:expenses.filter(e=>e.addedBy===uid)).map(e=>`<tr>
  <td>${e.date||'—'}</td>
  <td>${_e(e.category||'')}</td>
  <td>${_e(e.item||'')}${e.note?`<br><span style="color:#6a8a74;font-size:9px">${_e(e.note)}</span>`:''}</td>
  <td>${_e(e.addedByName||'—')}</td>
  <td class="r bold">৳${parseFloat(e.amount||0).toFixed(2)}</td>
</tr>`).join('')}
</tbody>
<tfoot><tr>
  <td colspan="4" class="bold">মোট বাজার</td>
  <td class="r">৳${(isMessTab?totalBazar:expenses.filter(e=>e.addedBy===uid).reduce((s,e)=>s+(parseFloat(e.amount)||0),0)).toFixed(2)}</td>
</tr></tfoot>
</table>` : ''}

<!-- DEPOSIT LIST -->
${deposits.length ? `
<div class="sec-h"><span class="sec-h-txt">💰 ডিপোজিট তালিকা</span></div>
<table>
<thead><tr>
  <th>তারিখ</th><th>সদস্য</th><th>নোট</th><th class="r">পরিমাণ (৳)</th>
</tr></thead>
<tbody>
${(isMessTab?deposits:deposits.filter(d=>d.memberId===uid)).map(d=>`<tr>
  <td>${d.date||'—'}</td>
  <td>${_e(d.memberName||'—')}</td>
  <td>${_e(d.note||'')}</td>
  <td class="r bold">৳${parseFloat(d.amount||0).toFixed(2)}</td>
</tr>`).join('')}
</tbody>
<tfoot><tr>
  <td colspan="3" class="bold">মোট জমা</td>
  <td class="r">৳${(isMessTab?totalDeposit:deposits.filter(d=>d.memberId===uid).reduce((s,d)=>s+(parseFloat(d.amount)||0),0)).toFixed(2)}</td>
</tr></tfoot>
</table>` : ''}

<!-- SIGNATURE -->
<div class="sign-area">
  <div class="sign-box">
    <div class="sign-line"></div>
    <div class="sign-lbl">Manager Signature</div>
  </div>
  <div class="sign-box">
    <div class="sign-line"></div>
    <div class="sign-lbl">Member Representative</div>
  </div>
  <div class="sign-box">
    <div class="sign-line"></div>
    <div class="sign-lbl">Date</div>
  </div>
</div>

</div><!-- /body -->

<!-- FOOTER -->
<div class="ftr">
  <div class="ftr-left">${_e(BRAND.name)}</div>
  <div class="ftr-mid">Smart Mess Management Solution</div>
  <div class="ftr-right">${_e(BRAND.dev)}</div>
</div>

</body></html>`;

  const w = window.open('','_blank','width=900,height=750');
  if (!w) { alert('Popup blocked — browser এ allow করুন'); return; }
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(()=> w.print(), 800);
}

// ── Private helpers ──────────────────────────────────────────────────────────
function _calendarTable(uid, meals, month, year, slots, moLabel) {
  const days = dim(year, month);
  const pfx  = `${year}_${pad(month+1)}`;
  let total  = 0;
  let rows   = '';
  for (let d=1; d<=days; d++) {
    const key  = `${pfx}_${pad(d)}_${uid}`;
    const data = meals[key]||{};
    const s    = data.slots||[];
    const g    = (data.guestSlots||[]).filter(Boolean).length;
    const t    = s.filter(Boolean).length+g;
    total += t;
    rows += `<tr>
  <td>${d} ${moLabel.split(' ')[0]}</td>
  ${(slots||[]).map((_,i)=>`<td style="text-align:center">
    <div class="mdot ${s[i]?'don':'doff'}">${s[i]?'✓':''}</div></td>`).join('')}
  <td class="r">${g||'—'}</td>
  <td class="r bold ${t>0?'':'def'}">${t||'—'}</td>
</tr>`;
  }
  return `
<div class="sec-h"><span class="sec-h-txt">📅 আমার মিল ক্যালেন্ডার</span></div>
<table>
<thead><tr>
  <th>তারিখ</th>
  ${(slots||[]).map(s=>`<th style="text-align:center;font-size:9px">${_e(s)}</th>`).join('')}
  <th class="r">Guest</th><th class="r">মোট</th>
</tr></thead>
<tbody>${rows}</tbody>
<tfoot><tr>
  <td colspan="${(slots||[]).length+1}" class="bold">মোট মিল</td>
  <td></td><td class="r">${total}</td>
</tr></tfoot>
</table>`;
}

// ── Excel Export ─────────────────────────────────────────────────────────────
export function exportExcel({ messName, month, year, members, meals,
  expenses, deposits, profile, isMessTab }) {

  if (!window.XLSX) { alert('XLSX library লোড হয়নি'); return; }

  const moLabel  = `${moName(month)} ${year}`;
  const monthStr = `${year}-${pad(month+1)}`;
  const monthPfx = `${year}_${pad(month+1)}`;
  const uid      = profile?.uid;

  let grandMeals=0;
  const memberData = members.map(m=>{
    let ml=0,gl=0;
    Object.entries(meals).forEach(([key,data])=>{
      if(key.startsWith(monthPfx)&&key.endsWith('_'+m.uid)){
        ml+=(data.slots||[]).filter(Boolean).length;
        gl+=(data.guestSlots||[]).filter(Boolean).length;
      }
    });
    const all=ml+gl; grandMeals+=all;
    const dep=deposits.filter(d=>d.memberId===m.uid).reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
    return {...m,meals:ml,guest:gl,all,dep};
  });
  const totalBazar   = expenses.reduce((s,e)=>s+(parseFloat(e.amount)||0),0);
  const totalDeposit = deposits.reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
  const mealRate     = grandMeals>0?totalBazar/grandMeals:0;
  memberData.forEach(m=>{ m.cost=m.all*mealRate; m.balance=m.dep-m.cost; });

  const wb = window.XLSX.utils.book_new();

  // Sheet 1: Summary
  const summaryData = [
    [`${BRAND.name} — ${isMessTab?'মেস রিপোর্ট':'আমার রিপোর্ট'}`],
    [`${isMessTab?messName:(profile?.name||'—')} · ${moLabel}`],
    [`Generated: ${new Date().toLocaleDateString('bn-BD')}`],
    [],
    ['সদস্য','মিল','Guest','মোট মিল','মিল খরচ (৳)','জমা (৳)','ব্যালেন্স (৳)'],
    ...(isMessTab?memberData:[memberData.find(m=>m.uid===uid)||{}]).map(m=>[
      m.name||m.email, m.meals, m.guest||0, m.all,
      +m.cost.toFixed(2), m.dep, +m.balance.toFixed(2)
    ]),
    [],
    ['','','','মোট',+totalBazar.toFixed(2),+totalDeposit.toFixed(2),+(totalDeposit-totalBazar).toFixed(2)],
    [],
    [`মিল রেট: ৳${mealRate.toFixed(2)} / মিল`],
  ];
  window.XLSX.utils.book_append_sheet(wb, window.XLSX.utils.aoa_to_sheet(summaryData), 'সারসংক্ষেপ');

  // Sheet 2: Bazar
  const bazarData = [
    ['তারিখ','বিভাগ','আইটেম','নোট','যোগ করেছেন','পরিমাণ (৳)'],
    ...(isMessTab?expenses:expenses.filter(e=>e.addedBy===uid)).map(e=>[
      e.date, e.category, e.item, e.note||'', e.addedByName||'', parseFloat(e.amount)||0
    ]),
    [],['','','','','মোট',+totalBazar.toFixed(2)],
  ];
  window.XLSX.utils.book_append_sheet(wb, window.XLSX.utils.aoa_to_sheet(bazarData), 'বাজার');

  // Sheet 3: Deposits
  const depData = [
    ['তারিখ','সদস্য','নোট','পরিমাণ (৳)'],
    ...(isMessTab?deposits:deposits.filter(d=>d.memberId===uid)).map(d=>[
      d.date, d.memberName||'—', d.note||'', parseFloat(d.amount)||0
    ]),
    [],['','','মোট',+totalDeposit.toFixed(2)],
  ];
  window.XLSX.utils.book_append_sheet(wb, window.XLSX.utils.aoa_to_sheet(depData), 'ডিপোজিট');

  // Sheet 4: Meal calendar (my report only)
  if (!isMessTab) {
    const days = dim(year,month);
    const calData = [
      [`${profile?.name||'—'} — মিল ক্যালেন্ডার — ${moLabel}`],[],
      ['তারিখ',...(members[0]?.slots||['সকাল','দুপুর','রাত']),'Guest','মোট'],
    ];
    for(let d=1;d<=days;d++){
      const key=`${monthPfx}_${pad(d)}_${uid}`;
      const data=meals[key]||{};
      const s=data.slots||[]; const g=(data.guestSlots||[]).filter(Boolean).length;
      calData.push([`${d} ${moName(month)}`,...s.map(v=>v?'✓':''),g,s.filter(Boolean).length+g]);
    }
    window.XLSX.utils.book_append_sheet(wb, window.XLSX.utils.aoa_to_sheet(calData), 'মিল ক্যালেন্ডার');
  }

  window.XLSX.writeFile(wb,
    `${isMessTab?messName:(profile?.name||'user')}-${moName(month)}-${year}.xlsx`);
}

const _e = s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

// rent.js — বাড়ি ভাড়া, auto split by member count

import { db } from '../../firebase.js';
import { toast, taka, pad, moName } from '../../utils.js';
import {
  doc, getDoc, setDoc, getDocs, collection
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _ctx={}, _vy=TODAY.getFullYear(), _vm=TODAY.getMonth();

export async function render(root, ctx) {
  _ctx = ctx;
  if (!ctx.messSettings?.rentEnabled) {
    root.innerHTML = `
<div class="card"><div class="cb" style="text-align:center;padding:30px;color:var(--ink3)">
  <div style="font-size:32px;margin-bottom:8px">🏡</div>
  <p style="font-size:13px;margin-bottom:10px">বাড়ি ভাড়া বিভাগ চালু নেই।</p>
  ${ctx.myMessRole==='mess-admin'
    ? `<button class="btn btn-p btn-sm"
        onclick="window.dispatchEvent(new CustomEvent('mm:navigate',{detail:{page:'settings'}}))">
        ⚙️ Settings থেকে চালু করুন</button>`
    : '<p style="font-size:12px">Mess Admin কে চালু করতে বলুন।</p>'}
</div></div>`;
    return;
  }

  const isAdmin = ctx.myMessRole==='mess-admin';

  root.innerHTML = `
<div>
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <button class="btn btn-ghost btn-sm" id="r-prev">◀</button>
    <span style="font-size:14px;font-weight:700;min-width:130px;text-align:center" id="r-lbl"></span>
    <button class="btn btn-ghost btn-sm" id="r-next">▶</button>
  </div>

  <div class="g4" style="margin-bottom:14px">
    <div class="sc sa"><div class="sl">🔥 গ্যাস</div><div class="sv" id="rc-gas">—</div></div>
    <div class="sc sb"><div class="sl">💡 বিদ্যুৎ</div><div class="sv" id="rc-elec">—</div></div>
    <div class="sc"><div class="sl">💧 পানি</div><div class="sv" id="rc-water">—</div></div>
    <div class="sc sg"><div class="sl">🧹 বুয়া</div><div class="sv" id="rc-bua">—</div></div>
  </div>

  <div class="card" style="margin-bottom:14px">
    <div class="ch">
      <h3>💵 মোট ভাড়া</h3>
      <span style="font-size:18px;font-weight:700;color:var(--g1);font-family:var(--mono)" id="r-total">৳০</span>
    </div>
  </div>

  <!-- Auto split -->
  <div class="card" style="margin-bottom:14px;background:var(--g7);border-color:var(--g5)">
    <div class="ch"><h3>👥 সদস্যপ্রতি ভাড়া (Auto Split)</h3></div>
    <div class="cb" id="r-split">লোড হচ্ছে…</div>
  </div>

  ${isAdmin ? `
  <div class="card">
    <div class="ch"><h3>✏️ ভাড়া আপডেট করুন</h3></div>
    <div class="cb">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
        <div><label class="lbl">🔥 গ্যাস (৳)</label><input class="inp inp-sm" id="r-gas" type="number" min="0"/></div>
        <div><label class="lbl">💡 বিদ্যুৎ (৳)</label><input class="inp inp-sm" id="r-elec" type="number" min="0"/></div>
        <div><label class="lbl">💧 পানি (৳)</label><input class="inp inp-sm" id="r-water" type="number" min="0"/></div>
        <div><label class="lbl">🧹 বুয়া (৳)</label><input class="inp inp-sm" id="r-bua" type="number" min="0"/></div>
      </div>
      <button class="btn btn-p btn-sm" id="r-save">✓ সংরক্ষণ</button>
      <div id="r-msg" style="font-size:11px;margin-top:6px"></div>
    </div>
  </div>` : ''}
</div>`;

  root.querySelector('#r-prev').addEventListener('click',()=>{ _vm--; if(_vm<0){_vm=11;_vy--} _load(root); });
  root.querySelector('#r-next').addEventListener('click',()=>{ _vm++; if(_vm>11){_vm=0;_vy++} _load(root); });
  root.querySelector('#r-save')?.addEventListener('click',()=> _save(root));

  root.querySelector('#r-lbl').textContent = `${moName(_vm)} ${_vy}`;
  await _load(root);
}

async function _load(root) {
  root.querySelector('#r-lbl').textContent = `${moName(_vm)} ${_vy}`;
  const key = `${_vy}_${pad(_vm+1)}`;

  try {
    const snap = await getDoc(doc(db,'messes',_ctx.messId,'rent',key));
    const s    = _ctx.messSettings;
    const data = snap.exists() ? snap.data() : {
      gas:s.rentGas||0, electric:s.rentElectric||0,
      water:s.rentWater||0, bua:s.rentBua||0
    };

    const _sv=(id,v)=>{ const el=root.querySelector('#'+id); if(el) el.textContent=taka(v); };
    _sv('rc-gas',data.gas||0); _sv('rc-elec',data.electric||0);
    _sv('rc-water',data.water||0); _sv('rc-bua',data.bua||0);

    const total=(data.gas||0)+(data.electric||0)+(data.water||0)+(data.bua||0);
    const tot=root.querySelector('#r-total'); if(tot) tot.textContent=taka(total);

    // Auto split
    const mSnap   = await getDocs(collection(db,'messes',_ctx.messId,'members'));
    const members = mSnap.docs.map(d=>({uid:d.id,...d.data()}));
    const perHead = members.length>0 ? total/members.length : 0;
    const splitEl = root.querySelector('#r-split');
    if(splitEl){
      splitEl.innerHTML = members.length>0 ? `
<p style="font-size:13px;color:var(--ink);margin-bottom:10px">
  মোট ${taka(total)} ÷ ${members.length}জন = <strong style="color:var(--g1);font-family:var(--mono)">${taka(perHead)}</strong> জনপ্রতি
</p>
<div style="display:flex;flex-wrap:wrap;gap:6px">
  ${members.map(m=>`
  <div style="background:#fff;border:1px solid var(--g5);border-radius:10px;
    padding:6px 12px;font-size:12px;display:flex;align-items:center;gap:8px">
    <span style="font-weight:600;color:var(--ink)">${_e(m.name||m.email)}</span>
    <span style="font-weight:700;color:var(--g1);font-family:var(--mono)">${taka(perHead)}</span>
  </div>`).join('')}
</div>` : '<p style="font-size:12px;color:var(--ink3)">কোনো সদস্য নেই</p>';
    }

    // Fill form
    const fill=(id,v)=>{ const el=root.querySelector('#'+id); if(el) el.value=v||0; };
    fill('r-gas',data.gas); fill('r-elec',data.electric);
    fill('r-water',data.water); fill('r-bua',data.bua);
  } catch(err){ toast('লোড ব্যর্থ: '+err.message,'er'); }
}

async function _save(root) {
  const gas     =parseFloat(root.querySelector('#r-gas')?.value)||0;
  const electric=parseFloat(root.querySelector('#r-elec')?.value)||0;
  const water   =parseFloat(root.querySelector('#r-water')?.value)||0;
  const bua     =parseFloat(root.querySelector('#r-bua')?.value)||0;
  const key     =`${_vy}_${pad(_vm+1)}`;
  try {
    await setDoc(doc(db,'messes',_ctx.messId,'rent',key),{gas,electric,water,bua,enabled:true});
    const msg=root.querySelector('#r-msg');
    if(msg){msg.textContent='✓ সংরক্ষণ হয়েছে';msg.style.color='var(--g1)';}
    toast('ভাড়া সেভ হয়েছে','ok');
    await _load(root);
  } catch(err){ toast('ব্যর্থ: '+err.message,'er'); }
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

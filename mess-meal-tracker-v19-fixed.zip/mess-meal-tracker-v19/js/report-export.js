// report-export.js — v18: light colors matching template exactly, fixed Excel export

import { taka, takaF, pad, moName, dim } from './utils.js';
import { BRAND_LOGO_BASE64, APP_LOGO_BASE64 } from './brand-logo.js';

const B = {
  name:    'Mess Meal Tracker',
  tagline: 'মেসের মিল, বাজার ও হিসাব সব এক জায়গায়',
  dev:     'Exit Excit',
  green:   '#1f7a45',   // হালকা সবুজ (টেমপ্লেট অনুযায়ী)
  dark:    '#1a5c32',
  accent:  '#e8a838',
  light:   '#eaf5ee',   // হালকা ব্যাকগ্রাউন্ড
  border:  '#cfe6d8',
  grayBar: '#6b6b6b',
};

// ─────────────────────────────────────────────────────────────────────────────
// PDF Export
// ─────────────────────────────────────────────────────────────────────────────
export function exportPDF({ messName, messAddress, month, year, members,
  meals, expenses, deposits, slots, profile, isMessTab }) {

  try {
    const moLabel   = `${moName(month)} ${year}`;
    const monthPfx  = `${year}_${pad(month+1)}`;
    const generated = new Date().toLocaleDateString('en-GB');
    const uid       = profile?.uid;

    let grandMeals = 0;
    const memberData = (members||[]).map(m => {
      let ml=0, gl=0;
      Object.entries(meals||{}).forEach(([key,data]) => {
        if (key.startsWith(monthPfx) && key.endsWith('_'+m.uid)) {
          ml += (data.slots||[]).filter(Boolean).length;
          gl += (data.guestSlots||[]).filter(Boolean).length;
        }
      });
      const all=ml+gl; grandMeals+=all;
      const dep=(deposits||[]).filter(d=>d.memberId===m.uid)
        .reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
      return {...m,meals:ml,guest:gl,all,dep};
    });
    const totalBazar   = (expenses||[]).reduce((s,e)=>s+(parseFloat(e.amount)||0),0);
    const totalDeposit = (deposits||[]).reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
    const mealRate     = grandMeals>0 ? totalBazar/grandMeals : 0;
    memberData.forEach(m=>{ m.cost=m.all*mealRate; m.balance=m.dep-m.cost; });

    const myData   = !isMessTab ? memberData.find(m=>m.uid===uid)||{} : null;
    const metaName = isMessTab ? (messName||'মেস') : (profile?.name||'—');
    const metaMem  = isMessTab ? `${members.length}` : '—';

    const bazarList = isMessTab ? (expenses||[]) : (expenses||[]).filter(e=>e.addedBy===uid);
    const depList   = isMessTab ? (deposits||[]) : (deposits||[]).filter(d=>d.memberId===uid);

    const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700&family=Roboto:wght@400;700&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
@page{ size:A4; margin:0; }
html,body{font-family:'Hind Siliguri','Roboto',Arial,sans-serif;font-size:10.5px;color:#2a2a2a;background:#fff}

/* ── পুরো ডকুমেন্ট single continuous flow — পেজ ভাঙলে browser print engine
      নিজেই পরের পেজে content চালিয়ে যাবে। header/footer fixed থাকায়
      প্রতি প্রিন্টেড পেজেই দেখা যাবে (Chromium-supported approach)। ── */
#r-header{ position:fixed; top:0; left:0; right:0; z-index:10; background:#fff; }
#r-footer{ position:fixed; bottom:0; left:0; right:0; z-index:10; }
#r-body{ padding-top:var(--hdr-h,128px); padding-bottom:var(--ftr-h,52px); }

/* HEADER — exactly like template */
.hdr{
  display:flex;align-items:center;
  padding:14px 22px;
  background:${B.light};
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.hdr-logo{
  width:58px;height:58px;margin-right:14px;flex-shrink:0;
  border-radius:10px;overflow:hidden;
  background:${B.green};
  display:flex;align-items:center;justify-content:center;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.hdr-logo img{width:78%;height:78%;object-fit:contain}
.hdr-mid{flex:1}
.hdr-title{font-size:21px;font-weight:700;color:#1a1a1a;line-height:1.15}
.hdr-sub{font-size:10px;color:#4a7055;margin-top:3px}
.hdr-right{text-align:right;flex-shrink:0}
.hdr-report{font-size:12px;font-weight:700;color:#1a1a1a;letter-spacing:.3px}
.hdr-gen{font-size:9.5px;color:#777;margin-top:5px}

.divider{height:4px;background:${B.grayBar};-webkit-print-color-adjust:exact;print-color-adjust:exact}

/* META ROW — light green like template */
.meta{
  display:grid;grid-template-columns:1fr 1fr 1fr;
  background:${B.light};
  padding:14px 22px 18px;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.mc{padding-right:14px}
.ml{font-size:10.5px;font-weight:700;color:#1a1a1a;margin-bottom:8px}
.mline{border-bottom:1px solid #888;height:16px}
.mv{font-size:11px;color:#1a1a1a;padding-bottom:2px}

/* BODY */
.body{padding:18px 22px}

/* SUMMARY — very light pastel boxes */
.sum{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:18px}
.sb2{
  border:1px solid ${B.border};border-radius:8px;
  padding:10px 12px;background:#f7fbf8;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.sl{font-size:9px;font-weight:700;color:#5a8a6a;text-transform:uppercase;letter-spacing:.3px}
.sv{font-size:18px;font-weight:700;color:#1a5c32;margin-top:3px;font-family:'Roboto',sans-serif}
.ss{font-size:9px;margin-top:2px;color:#888}
.pos{color:#1f7a45;font-weight:700}
.neg{color:#c0504d;font-weight:700}

.sec{
  font-size:12px;font-weight:700;color:#1a1a1a;
  border-bottom:2px solid ${B.green};
  padding-bottom:5px;margin:18px 0 10px;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}

table{width:100%;border-collapse:collapse;font-size:10px;margin-bottom:16px}
thead tr{background:${B.green};-webkit-print-color-adjust:exact;print-color-adjust:exact}
thead th{color:#fff;padding:6px 8px;text-align:left;font-weight:700;font-size:9.5px}
th.r,td.r{text-align:right}
th.c,td.c{text-align:center}
tbody tr:nth-child(even){background:#f5faf6;-webkit-print-color-adjust:exact;print-color-adjust:exact}
tbody td{padding:5px 8px;border-bottom:1px solid #ebf3ed;vertical-align:top}
tfoot tr{background:#e3f0e7;-webkit-print-color-adjust:exact;print-color-adjust:exact}
tfoot td{padding:6px 8px;font-weight:700;border-top:1.5px solid ${B.green}}
.don{
  display:inline-block;width:14px;height:14px;border-radius:50%;
  background:${B.green};color:#fff;font-size:8px;text-align:center;line-height:14px;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.doff{
  display:inline-block;width:14px;height:14px;border-radius:50%;
  background:#f0f0f0;border:1px solid #ddd;font-size:8px;text-align:center;line-height:14px;
}

.sign{display:grid;grid-template-columns:repeat(3,1fr);gap:32px;margin-top:30px;padding-top:14px}
.sign-box{text-align:center}
.sign-line{border-bottom:1px solid #555;height:30px;margin-bottom:5px}
.sign-lbl{font-size:9.5px;color:#555}

/* FOOTER — exactly like template: light green bar + logo right */
.ftr-page{padding:0 22px 4px;text-align:right}
.ftr-page span{font-size:9px;color:${B.accent}}
.ftr{
  background:${B.light};
  display:flex;align-items:center;justify-content:space-between;
  padding:10px 22px;
  border-top:1px solid ${B.border};
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.fl{font-size:13px;font-weight:700;color:#1a1a1a}
.fm{font-size:10px;color:#4a4a4a}
.fr{display:flex;align-items:center;gap:8px}
.fd{font-size:9.5px;color:#4a4a4a}
.fd strong{color:#e09a2e;font-weight:700}
.flogo{
  width:30px;height:30px;border-radius:6px;overflow:hidden;
  display:flex;align-items:center;justify-content:center;
  background:${B.green};flex-shrink:0;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.flogo img{width:82%;height:82%;object-fit:contain}

@media print{
  tr{page-break-inside:avoid}
  thead{display:table-header-group}
  .sec{page-break-after:avoid}
  #r-header, #r-footer{ position:fixed; }
}
@media screen{
  /* স্ক্রিনে preview দেখার সময়ও ঠিকভাবে দেখানোর জন্য */
  body{ max-width:210mm; margin:0 auto; box-shadow:0 0 12px rgba(0,0,0,.15); }
}`;

    // ── Build body sections ──
    let body = `<div class="body">`;
    body += `<div class="sum">
<div class="sb2"><div class="sl">মোট মিল</div>
  <div class="sv">${isMessTab?grandMeals:(myData?.all||0)}</div>
  <div class="ss">${isMessTab?'সকল সদস্য':'এই মাসে'}</div></div>
<div class="sb2"><div class="sl">মিল রেট</div>
  <div class="sv">${takaF(mealRate)}</div>
  <div class="ss">প্রতি মিল</div></div>
<div class="sb2"><div class="sl">${isMessTab?'মোট বাজার':'মিল খরচ'}</div>
  <div class="sv">${isMessTab?taka(totalBazar):takaF(myData?.cost||0)}</div></div>
<div class="sb2"><div class="sl">${isMessTab?'মোট জমা':'আমার জমা'}</div>
  <div class="sv">${isMessTab?taka(totalDeposit):taka(myData?.dep||0)}</div>
  ${myData?`<div class="ss ${(myData.balance||0)>=0?'pos':'neg'}">ব্যালেন্স: ${takaF(myData.balance||0)}</div>`:''}
</div></div>`;

    if (isMessTab) {
      body += `<div class="sec">সদস্য ভিত্তিক হিসাব</div>
<table>
<thead><tr>
  <th>সদস্য</th><th class="r">মিল</th><th class="r">Guest</th>
  <th class="r">মোট</th><th class="r">মিল খরচ (৳)</th>
  <th class="r">জমা (৳)</th><th class="r">ব্যালেন্স (৳)</th>
</tr></thead>
<tbody>
${memberData.map(m=>`<tr>
<td style="font-weight:600">${_e(m.name||m.email)}</td>
<td class="r">${m.meals}</td><td class="r">${m.guest||'—'}</td>
<td class="r" style="font-weight:700">${m.all}</td>
<td class="r">৳${m.cost.toFixed(2)}</td>
<td class="r">৳${m.dep.toFixed(2)}</td>
<td class="r ${m.balance>=0?'pos':'neg'}">৳${m.balance.toFixed(2)}</td>
</tr>`).join('')}
</tbody>
<tfoot><tr>
<td>মোট</td><td></td><td></td>
<td class="r">${grandMeals}</td>
<td class="r">৳${totalBazar.toFixed(2)}</td>
<td class="r">৳${totalDeposit.toFixed(2)}</td>
<td class="r ${totalDeposit>=totalBazar?'pos':'neg'}">৳${(totalDeposit-totalBazar).toFixed(2)}</td>
</tr></tfoot>
</table>`;
    } else {
      const sl   = slots||['সকাল','দুপুর','রাত'];
      const days = dim(year, month);
      const pfx  = `${year}_${pad(month+1)}`;
      let total  = 0, rows = '';
      for (let d=1;d<=days;d++){
        const key  = `${pfx}_${pad(d)}_${uid}`;
        const data = (meals||{})[key]||{};
        const s    = data.slots||[];
        const g    = (data.guestSlots||[]).filter(Boolean).length;
        const t    = s.filter(Boolean).length+g; total+=t;
        rows+=`<tr>
<td>${d} ${moName(month)}</td>
${sl.map((_,i)=>`<td class="c"><span class="${s[i]?'don':'doff'}">${s[i]?'✓':''}</span></td>`).join('')}
<td class="r">${g||'—'}</td>
<td class="r" style="font-weight:${t?'700':'400'}">${t||'—'}</td>
</tr>`;
      }
      body += `<div class="sec">মিল ক্যালেন্ডার — ${moLabel}</div>
<table>
<thead><tr>
<th>তারিখ</th>
${sl.map(s=>`<th class="c" style="font-size:9px">${_e(s)}</th>`).join('')}
<th class="r">Guest</th><th class="r">মোট</th>
</tr></thead>
<tbody>${rows}</tbody>
<tfoot><tr>
<td colspan="${sl.length+1}">মোট মিল</td>
<td></td><td class="r">${total}</td>
</tr></tfoot>
</table>`;
    }

    if (bazarList.length) {
      body += `<div class="sec">বাজারের তালিকা</div>
<table>
<thead><tr>
<th>তারিখ</th><th>বিভাগ</th><th>আইটেম</th><th>যোগ করেছেন</th><th class="r">পরিমাণ (৳)</th>
</tr></thead>
<tbody>
${bazarList.map(e=>`<tr>
<td>${e.date||'—'}</td>
<td>${_e(e.category||'')}</td>
<td>${_e(e.item||'')}${e.note?`<br><span style="color:#777;font-size:9px">${_e(e.note)}</span>`:''}</td>
<td>${_e(e.addedByName||'—')}</td>
<td class="r" style="font-weight:700">৳${parseFloat(e.amount||0).toFixed(2)}</td>
</tr>`).join('')}
</tbody>
<tfoot><tr>
<td colspan="4">মোট বাজার</td>
<td class="r">৳${bazarList.reduce((s,e)=>s+(parseFloat(e.amount)||0),0).toFixed(2)}</td>
</tr></tfoot>
</table>`;
    }

    if (depList.length) {
      body += `<div class="sec">ডিপোজিট তালিকা</div>
<table>
<thead><tr>
<th>তারিখ</th><th>সদস্য</th><th>নোট</th><th class="r">পরিমাণ (৳)</th>
</tr></thead>
<tbody>
${depList.map(d=>`<tr>
<td>${d.date||'—'}</td>
<td>${_e(d.memberName||'—')}</td>
<td>${_e(d.note||'')}</td>
<td class="r" style="font-weight:700">৳${parseFloat(d.amount||0).toFixed(2)}</td>
</tr>`).join('')}
</tbody>
<tfoot><tr>
<td colspan="3">মোট জমা</td>
<td class="r">৳${depList.reduce((s,d)=>s+(parseFloat(d.amount)||0),0).toFixed(2)}</td>
</tr></tfoot>
</table>`;
    }

    body += `<div class="sign">
<div class="sign-box"><div class="sign-line"></div><div class="sign-lbl">Manager Signature</div></div>
<div class="sign-box"><div class="sign-line"></div><div class="sign-lbl">Member Representative</div></div>
<div class="sign-box"><div class="sign-line"></div><div class="sign-lbl">Date</div></div>
</div>`;
    body += `</div>`;

    const html = `<!DOCTYPE html>
<html lang="bn"><head>
<meta charset="UTF-8"/>
<title>${_e(metaName)} — ${moLabel}</title>
<style>${CSS}</style>
</head><body>

  <!-- HEADER (টেমপ্লেট অনুযায়ী) — প্রতি প্রিন্টেড পেজে repeat হবে -->
  <div id="r-header">
    <div class="hdr">
      <div class="hdr-logo"><img src="${APP_LOGO_BASE64}" alt="app logo"/></div>
      <div class="hdr-mid">
        <div class="hdr-title">${_e(B.name)}</div>
        <div class="hdr-sub">${_e(B.tagline)}</div>
      </div>
      <div class="hdr-right">
        <div class="hdr-report">MONTHLY REPORT</div>
        <div class="hdr-gen">Generated: ${generated}</div>
      </div>
    </div>
    <div class="divider"></div>
    <div class="meta">
      <div class="mc">
        <div class="ml">Mess Name / Name:</div>
        <div class="mv">${_e(metaName)}</div>
        <div class="mline"></div>
      </div>
      <div class="mc">
        <div class="ml">Month / Year:</div>
        <div class="mv">${moLabel}</div>
        <div class="mline"></div>
      </div>
      <div class="mc">
        <div class="ml">Total Members:</div>
        <div class="mv">${metaMem}</div>
        <div class="mline"></div>
      </div>
    </div>
  </div>

  <!-- FOOTER (টেমপ্লেট অনুযায়ী) — প্রতি প্রিন্টেড পেজে repeat হবে -->
  <div id="r-footer">
    <div class="ftr">
      <div class="fl">${_e(B.name)}</div>
      <div class="fm">Smart Mess Management Solution</div>
      <div class="fr">
        <div class="fd">Developed by <strong>${_e(B.dev)}</strong></div>
        <div class="flogo"><img src="${BRAND_LOGO_BASE64}" alt="logo"/></div>
      </div>
    </div>
  </div>

  <!-- BODY — single continuous content; signature body এর শেষে,
       তাই content এক পেজে ধরলে প্রথম পেজে, না ধরলে স্বয়ংক্রিয়ভাবে শেষ পেজে যাবে -->
  <div id="r-body">
    ${body}
  </div>

</body></html>`;

    const w = window.open('','_blank','width=960,height=820');
    if (!w) { alert('Popup blocked — browser এ allow করুন'); return; }
    w.document.write(html);
    w.document.close();
    w.focus();
    // Header/Footer এর actual height মেপে body এর padding ঠিক করা —
    // যাতে কোনো content header এর নিচে বা footer এর পেছনে চাপা না পড়ে
    setTimeout(() => {
      try {
        const hdrEl = w.document.getElementById('r-header');
        const ftrEl = w.document.getElementById('r-footer');
        const bodyEl = w.document.getElementById('r-body');
        if (hdrEl && ftrEl && bodyEl) {
          const hdrH = hdrEl.offsetHeight + 6;
          const ftrH = ftrEl.offsetHeight + 6;
          w.document.documentElement.style.setProperty('--hdr-h', hdrH + 'px');
          w.document.documentElement.style.setProperty('--ftr-h', ftrH + 'px');
        }
      } catch(e) { console.warn('Header/footer measure failed:', e); }
    }, 50);
    setTimeout(() => w.print(), 1000);

  } catch(err) {
    console.error('PDF export error:', err);
    alert('PDF তৈরি করতে সমস্যা হয়েছে: ' + err.message);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Excel Export
// ─────────────────────────────────────────────────────────────────────────────
export function exportExcel({ messName, month, year, members, meals,
  expenses, deposits, profile, isMessTab }) {

  try {
    if (typeof window.XLSX === 'undefined') {
      alert('Excel লাইব্রেরি (XLSX) লোড হয়নি। ইন্টারনেট কানেকশন চেক করুন এবং পেজ রিফ্রেশ করুন।');
      console.error('window.XLSX is undefined — SheetJS not loaded');
      return;
    }

    const moLabel  = `${moName(month)} ${year}`;
    const monthPfx = `${year}_${pad(month+1)}`;
    const uid      = profile?.uid;

    let grandMeals = 0;
    const memberData = (members||[]).map(m => {
      let ml=0, gl=0;
      Object.entries(meals||{}).forEach(([key,data]) => {
        if (key.startsWith(monthPfx) && key.endsWith('_'+m.uid)) {
          ml += (data.slots||[]).filter(Boolean).length;
          gl += (data.guestSlots||[]).filter(Boolean).length;
        }
      });
      const all=ml+gl; grandMeals+=all;
      const dep=(deposits||[]).filter(d=>d.memberId===m.uid)
        .reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
      return {...m,meals:ml,guest:gl,all,dep};
    });
    const totalBazar   = (expenses||[]).reduce((s,e)=>s+(parseFloat(e.amount)||0),0);
    const totalDeposit = (deposits||[]).reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
    const mealRate     = grandMeals>0?totalBazar/grandMeals:0;
    memberData.forEach(m=>{ m.cost=m.all*mealRate; m.balance=m.dep-m.cost; });

    const wb = window.XLSX.utils.book_new();

    // Header rows used on every sheet — matches PDF branding
    const brandHdr = [
      [B.name, '', '', '', '', '', `MONTHLY REPORT`],
      [B.tagline],
      [`Mess Name: ${isMessTab?(messName||'মেস'):(profile?.name||'—')}    |    Month/Year: ${moLabel}    |    Total Members: ${isMessTab?members.length:'—'}`],
      [`Generated: ${new Date().toLocaleDateString('en-GB')}    |    Developed by ${B.dev}`],
      [],
    ];

    // Sheet 1 — Summary
    const target = isMessTab ? memberData : [memberData.find(m=>m.uid===uid)||{}];
    const ws1 = window.XLSX.utils.aoa_to_sheet([
      ...brandHdr,
      ['সদস্য','মিল','Guest','মোট মিল','মিল খরচ (৳)','জমা (৳)','ব্যালেন্স (৳)'],
      ...target.map(m=>[m.name||m.email||'—',m.meals||0,m.guest||0,m.all||0,
        +((m.cost||0).toFixed(2)),m.dep||0,+((m.balance||0).toFixed(2))]),
      [],
      ['','','','মোট',+totalBazar.toFixed(2),+totalDeposit.toFixed(2),+(totalDeposit-totalBazar).toFixed(2)],
      [],
      [`মিল রেট: ৳${mealRate.toFixed(2)} / মিল`],
      [],
      ['Manager Signature','','Member Representative','','Date'],
    ]);
    ws1['!cols']=[{wch:20},{wch:8},{wch:8},{wch:10},{wch:14},{wch:12},{wch:14}];
    window.XLSX.utils.book_append_sheet(wb,ws1,'সারসংক্ষেপ');

    // Sheet 2 — Bazar
    const bl = isMessTab?(expenses||[]):(expenses||[]).filter(e=>e.addedBy===uid);
    const ws2 = window.XLSX.utils.aoa_to_sheet([
      ...brandHdr,
      ['তারিখ','বিভাগ','আইটেম','নোট','যোগ করেছেন','পরিমাণ (৳)'],
      ...bl.map(e=>[e.date||'',e.category||'',e.item||'',e.note||'',e.addedByName||'',parseFloat(e.amount)||0]),
      [],['','','','','মোট',+bl.reduce((s,e)=>s+(parseFloat(e.amount)||0),0).toFixed(2)],
    ]);
    ws2['!cols']=[{wch:12},{wch:12},{wch:22},{wch:16},{wch:16},{wch:12}];
    window.XLSX.utils.book_append_sheet(wb,ws2,'বাজার');

    // Sheet 3 — Deposit
    const dl = isMessTab?(deposits||[]):(deposits||[]).filter(d=>d.memberId===uid);
    const ws3 = window.XLSX.utils.aoa_to_sheet([
      ...brandHdr,
      ['তারিখ','সদস্য','নোট','পরিমাণ (৳)'],
      ...dl.map(d=>[d.date||'',d.memberName||'',d.note||'',parseFloat(d.amount)||0]),
      [],['','','মোট',+dl.reduce((s,d)=>s+(parseFloat(d.amount)||0),0).toFixed(2)],
    ]);
    ws3['!cols']=[{wch:12},{wch:18},{wch:22},{wch:12}];
    window.XLSX.utils.book_append_sheet(wb,ws3,'ডিপোজিট');

    // Sheet 4 — Calendar (my report)
    if (!isMessTab) {
      const days=dim(year,month); const pfx=`${year}_${pad(month+1)}`;
      const sl=['সকাল','দুপুর','রাত'];
      const rows=[...brandHdr,['তারিখ',...sl,'Guest','মোট']];
      for(let d=1;d<=days;d++){
        const key=`${pfx}_${pad(d)}_${uid}`;
        const data=(meals||{})[key]||{};
        const s=data.slots||[]; const g=(data.guestSlots||[]).filter(Boolean).length;
        rows.push([`${d} ${moName(month)}`,...s.map(v=>v?'✓':''),g||0,s.filter(Boolean).length+g]);
      }
      const ws4=window.XLSX.utils.aoa_to_sheet(rows);
      ws4['!cols']=[{wch:14},...sl.map(()=>({wch:8})),{wch:8},{wch:8}];
      window.XLSX.utils.book_append_sheet(wb,ws4,'মিল ক্যালেন্ডার');
    }

    const fname=`${isMessTab?(messName||'mess'):(profile?.name||'user')}-${moName(month)}-${year}.xlsx`;
    window.XLSX.writeFile(wb, fname.replace(/\s+/g,'-'));

  } catch(err) {
    console.error('Excel export error:', err);
    alert('Excel তৈরি করতে সমস্যা হয়েছে: ' + err.message);
  }
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

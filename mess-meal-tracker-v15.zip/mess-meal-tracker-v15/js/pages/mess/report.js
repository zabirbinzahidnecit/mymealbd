// report.js — v12: merged with my-report (tabs: মেস রিপোর্ট | আমার রিপোর্ট)

import { db } from '../../firebase.js';
import { toast, taka, takaF, pad, moName, dim } from '../../utils.js';
import { exportPDF, exportExcel } from '../../report-export.js';
import {
  collection, getDocs, query, where
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _ctx={};
let _vy=TODAY.getFullYear(), _vm=TODAY.getMonth();
let _members=[], _meals={}, _expenses=[], _deposits=[];
let _activeTab = 'mess'; // 'mess' | 'mine'

export async function render(root, ctx) {
  _ctx = ctx;

  root.innerHTML = `
<div>
  <!-- Tab switcher -->
  <div style="display:flex;gap:0;margin-bottom:16px;background:var(--paper);
    border:1px solid var(--line);border-radius:12px;padding:4px;max-width:340px">
    <button class="rep-tab active" data-tab="mess"
      style="flex:1;padding:7px 0;border-radius:8px;border:none;font-size:13px;
      font-weight:700;cursor:pointer;transition:.15s;font-family:inherit">
      📊 মেস রিপোর্ট
    </button>
    <button class="rep-tab" data-tab="mine"
      style="flex:1;padding:7px 0;border-radius:8px;border:none;font-size:13px;
      font-weight:700;cursor:pointer;transition:.15s;font-family:inherit;
      background:none;color:var(--ink3)">
      📋 আমার রিপোর্ট
    </button>
  </div>

  <!-- Month nav (shared) -->
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <button class="btn btn-ghost btn-sm" id="rep-prev">◀</button>
    <span style="font-size:14px;font-weight:700;min-width:130px;text-align:center" id="rep-lbl"></span>
    <button class="btn btn-ghost btn-sm" id="rep-next">▶</button>
    <button class="btn btn-ghost btn-sm" id="rep-today">আজ</button>
    <button class="btn btn-ghost btn-sm" id="rep-refresh" style="margin-left:auto">🔄</button>
    <div style="display:flex;gap:6px">
      <button class="btn btn-p btn-sm" id="rep-excel">📥 Excel</button>
      <button class="btn btn-ghost btn-sm" id="rep-pdf">🖨️ PDF</button>
    </div>
  </div>

  <!-- Content area -->
  <div id="rep-body">লোড হচ্ছে…</div>
</div>

<style>
.rep-tab{background:none;color:var(--ink3)}
.rep-tab.active{background:var(--g2);color:#fff;box-shadow:0 2px 8px rgba(20,107,64,.25)}
</style>`;

  // Tab click
  root.querySelectorAll('.rep-tab').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      _activeTab = btn.dataset.tab;
      root.querySelectorAll('.rep-tab').forEach(b=>{
        b.classList.toggle('active', b.dataset.tab===_activeTab);
        b.style.background = b.dataset.tab===_activeTab ? 'var(--g2)' : 'none';
        b.style.color      = b.dataset.tab===_activeTab ? '#fff' : 'var(--ink3)';
      });
      _render(root);
    });
  });

  root.querySelector('#rep-prev').addEventListener('click', ()=>{ _vm--; if(_vm<0){_vm=11;_vy--} _load(root); });
  root.querySelector('#rep-next').addEventListener('click', ()=>{ _vm++; if(_vm>11){_vm=0;_vy++} _load(root); });
  root.querySelector('#rep-today').addEventListener('click', ()=>{ _vy=TODAY.getFullYear();_vm=TODAY.getMonth(); _load(root); });
  root.querySelector('#rep-refresh').addEventListener('click', ()=> _load(root));
  root.querySelector('#rep-excel').addEventListener('click', ()=> _export(root));
  root.querySelector('#rep-pdf').addEventListener('click', ()=> _exportPDFShared(root));

  root.querySelector('#rep-lbl').textContent = `${moName(_vm)} ${_vy}`;
  await _load(root);
}

// ── Data loading (shared, one fetch) ────────────────────────────────────────
async function _load(root) {
  root.querySelector('#rep-lbl').textContent = `${moName(_vm)} ${_vy}`;
  root.querySelector('#rep-body').innerHTML =
    '<div style="padding:30px;text-align:center;color:var(--ink3)">লোড হচ্ছে…</div>';

  const monthStr = `${_vy}-${pad(_vm+1)}`;
  const monthPfx = `${_vy}_${pad(_vm+1)}`;

  try {
    const [mSnap, allMealSnap, expSnap, depSnap] = await Promise.all([
      getDocs(collection(db,'messes',_ctx.messId,'members')),
      getDocs(collection(db,'messes',_ctx.messId,'meals')),
      getDocs(query(collection(db,'messes',_ctx.messId,'expenses'), where('status','==','approved'))),
      getDocs(query(collection(db,'messes',_ctx.messId,'deposits'), where('status','==','approved'))),
    ]);

    _members = mSnap.docs.map(d=>({uid:d.id,...d.data()}))
      .sort((a,b)=>(a.joinedAt?.seconds||0)-(b.joinedAt?.seconds||0));
    _meals   = {};
    allMealSnap.forEach(d=>{ if(d.id.startsWith(monthPfx)) _meals[d.id]=d.data(); });
    _expenses = expSnap.docs.map(d=>d.data()).filter(e=>e.date?.startsWith(monthStr));
    _deposits = depSnap.docs.map(d=>d.data()).filter(d=>d.date?.startsWith(monthStr));

    _render(root);
  } catch(err) {
    toast('লোড ব্যর্থ: '+err.message,'er');
    root.querySelector('#rep-body').innerHTML =
      `<div style="padding:20px;text-align:center;color:var(--r1)">⚠️ ${_e(err.message)}</div>`;
  }
}

function _calcMember(uid) {
  let total=0, guest=0;
  Object.entries(_meals).forEach(([key,data])=>{
    if(key.endsWith('_'+uid)){
      total += (data.slots||[]).filter(Boolean).length;
      guest += (data.guestSlots||[]).filter(Boolean).length;
    }
  });
  return { total, guest, all: total+guest };
}

function _render(root) {
  if (_activeTab==='mess') _renderMess(root);
  else                     _renderMine(root);
}

// ── TAB 1: মেস রিপোর্ট ─────────────────────────────────────────────────────
function _renderMess(root) {
  const body = root.querySelector('#rep-body');

  let grandMeals=0;
  _members.forEach(m=>{ grandMeals+=_calcMember(m.uid).all; });
  const totalBazar   = _expenses.reduce((s,e)=>s+(parseFloat(e.amount)||0),0);
  const totalDeposit = _deposits.reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
  const mealRate     = grandMeals>0 ? totalBazar/grandMeals : 0;

  body.innerHTML = `
<!-- Summary cards -->
<div class="g4" style="margin-bottom:14px">
  <div class="sc sg"><div class="sl">মোট মিল</div><div class="sv">${grandMeals||'—'}</div></div>
  <div class="sc sa"><div class="sl">মিল রেট</div><div class="sv">${takaF(mealRate)}</div><div class="ss">প্রতি মিল</div></div>
  <div class="sc sb"><div class="sl">মোট বাজার</div><div class="sv">${taka(totalBazar)}</div></div>
  <div class="sc sr"><div class="sl">মোট জমা</div><div class="sv">${taka(totalDeposit)}</div></div>
</div>

<!-- Member table -->
<div class="card" style="margin-bottom:14px">
  <div class="ch"><h3>👥 সদস্য ভিত্তিক হিসাব</h3></div>
  <div style="overflow-x:auto">
    <table class="dt">
    <thead><tr>
      <th class="tl">সদস্য</th><th>মিল</th><th>Guest</th><th>মোট মিল</th>
      <th>মিল খরচ</th><th>জমা</th><th>ব্যালেন্স</th>
    </tr></thead>
    <tbody>
    ${_members.map(m=>{
      const {total,guest,all}=_calcMember(m.uid);
      const mealCost  = all*mealRate;
      const deposited = _deposits.filter(d=>d.memberId===m.uid).reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
      const balance   = deposited-mealCost;
      const isMe      = m.uid===_ctx.profile.uid;
      return `<tr style="${isMe?'background:var(--g8);':''}">
<td class="tl" style="font-weight:700">${_e(m.name||m.email)}${isMe?'<span style="font-size:9px;background:var(--g5);color:var(--g1);border-radius:4px;padding:1px 5px;margin-left:5px">আমি</span>':''}</td>
<td>${total}</td><td>${guest||'—'}</td><td style="font-weight:700">${all}</td>
<td style="font-family:var(--mono)">${takaF(mealCost)}</td>
<td style="font-family:var(--mono)">${taka(deposited)}</td>
<td style="font-weight:700;font-family:var(--mono);color:${balance>=0?'var(--g1)':'var(--r1)'}">
  ${takaF(balance)}
</td>
</tr>`;
    }).join('')}
    <tr class="tf">
      <td class="tl">মোট</td><td colspan="2"></td><td>${grandMeals}</td>
      <td>${takaF(totalBazar)}</td><td>${taka(totalDeposit)}</td>
      <td style="font-weight:700;color:${totalDeposit-totalBazar>=0?'var(--g1)':'var(--r1)'}">
        ${takaF(totalDeposit-totalBazar)}
      </td>
    </tr>
    </tbody>
    </table>
  </div>
</div>

<!-- Meal calendar -->
<div class="card">
  <div class="ch">
    <h3>📅 মিল ক্যালেন্ডার</h3>
    <select class="inp inp-sm" id="rep-cal-mem" style="width:auto">
      ${_members.map(m=>`<option value="${m.uid}" ${m.uid===_ctx.profile.uid?'selected':''}>${_e(m.name||m.email)}</option>`).join('')}
    </select>
  </div>
  <div style="overflow-x:auto;padding:10px" id="rep-cal"></div>
</div>`;

  root.querySelector('#rep-cal-mem').addEventListener('change', ()=> _renderCalendar(root));
  _renderCalendar(root);
}

function _renderCalendar(root) {
  const uid   = root.querySelector('#rep-cal-mem')?.value || _ctx.profile.uid;
  const slots = _ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const days  = dim(_vy, _vm);
  let html=`<table class="dt" style="min-width:${90+slots.length*46}px">
<thead><tr><th class="tl">তারিখ</th>
${slots.map(s=>`<th style="font-size:10px">${_e(s)}</th>`).join('')}
<th>Guest</th><th>মোট</th></tr></thead><tbody>`;
  let monthTotal=0;
  for(let d=1;d<=days;d++){
    const key=`${_vy}_${pad(_vm+1)}_${pad(d)}_${uid}`;
    const data=_meals[key]||{};
    const s=data.slots||[]; const g=(data.guestSlots||[]).filter(Boolean).length;
    const tot=s.filter(Boolean).length+g; monthTotal+=tot;
    html+=`<tr${tot>0?' style="background:var(--g8)"':''}>
<td class="tl" style="font-size:12px">${d} ${moName(_vm).slice(0,3)}</td>
${slots.map((_,i)=>`<td><div class="mdot ${s[i]?'don':'doff'}" style="margin:0 auto">${s[i]?'✓':''}</div></td>`).join('')}
<td>${g||'—'}</td>
<td style="font-weight:${tot>0?'700':'400'};color:${tot>0?'var(--g1)':'var(--ink4)'}">${tot||'—'}</td>
</tr>`;
  }
  html+=`<tr class="tf"><td class="tl">মোট</td>${slots.map(()=>'<td></td>').join('')}<td></td><td>${monthTotal}</td></tr></tbody></table>`;
  const el=root.querySelector('#rep-cal');
  if(el) el.innerHTML=html;
}

// ── TAB 2: আমার রিপোর্ট ────────────────────────────────────────────────────
function _renderMine(root) {
  const body = root.querySelector('#rep-body');
  const uid  = _ctx.profile.uid;
  const monthStr = `${_vy}-${pad(_vm+1)}`;
  const monthPfx = `${_vy}_${pad(_vm+1)}`;

  // Current month stats
  let myMeals=0, totalMeals=0;
  Object.entries(_meals).forEach(([key,data])=>{
    const s=(data.slots||[]).filter(Boolean).length;
    const g=(data.guestSlots||[]).filter(Boolean).length;
    totalMeals+=s+g;
    if(key.endsWith('_'+uid)) myMeals+=s+g;
  });
  const totalBazar = _expenses.reduce((s,e)=>s+(parseFloat(e.amount)||0),0);
  const rate       = totalMeals>0 ? totalBazar/totalMeals : 0;
  const myCost     = myMeals*rate;
  const myDep      = _deposits.filter(d=>d.memberId===uid).reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
  const myBal      = myDep-myCost;

  body.innerHTML = `
<!-- My current month summary -->
<div class="g4" style="margin-bottom:14px">
  <div class="sc sg"><div class="sl">এই মাসে মিল</div><div class="sv">${myMeals}</div></div>
  <div class="sc sa"><div class="sl">মিল রেট</div><div class="sv">${takaF(rate)}</div><div class="ss">প্রতি মিল</div></div>
  <div class="sc sb"><div class="sl">জমা দিয়েছি</div><div class="sv">${taka(myDep)}</div></div>
  <div class="sc ${myBal>=0?'sg':'sr'}" id="mine-bal-card">
    <div class="sl">আমার ব্যালেন্স</div>
    <div class="sv">${takaF(myBal)}</div>
    <div class="ss">${myBal>=0?taka(myBal)+' পাবেন':taka(Math.abs(myBal))+' দেবেন'}</div>
  </div>
</div>

<!-- 6-month bar chart — using stored data -->
<div class="card" style="margin-bottom:14px">
  <div class="ch"><h3>📊 বিগত ৬ মাসের মিল</h3></div>
  <div class="cb">
    <div id="mine-chart" style="display:flex;align-items:flex-end;gap:6px;height:120px;padding-bottom:4px"></div>
    <div id="mine-chart-lbl" style="display:flex;gap:6px;margin-top:6px"></div>
  </div>
</div>

<!-- Month detail deposit/expense breakdown -->
<div class="card" style="margin-bottom:14px">
  <div class="ch">
    <h3>💰 এই মাসের লেনদেন</h3>
    <span style="font-size:11px;color:var(--ink3)">${moName(_vm)} ${_vy}</span>
  </div>
  <div style="overflow-x:auto" id="mine-tx-table">লোড হচ্ছে…</div>
</div>

<!-- My meal calendar -->
<div class="card">
  <div class="ch">
    <h3>📅 আমার মিল ক্যালেন্ডার</h3>
    <span style="font-size:11px;font-weight:700;color:var(--g1)">${myMeals} মিল</span>
  </div>
  <div style="overflow-x:auto;padding:10px" id="mine-cal"></div>
</div>`;

  // Render 6-month chart — we only have current month data loaded
  // Show current month bar + placeholder for others
  _renderMineChart(root, uid);
  _renderMineCal(root, uid);
  _renderMineTx(root, uid);
}

function _renderMineChart(root, uid) {
  // Build 6 month meal counts from already-loaded _meals data
  const chartEl = root.querySelector('#mine-chart');
  const lblEl   = root.querySelector('#mine-chart-lbl');
  if (!chartEl) return;

  const months = [];
  for (let i=5; i>=0; i--) {
    const d   = new Date(TODAY.getFullYear(), TODAY.getMonth()-i, 1);
    const vy  = d.getFullYear();
    const vm  = d.getMonth();
    const pfx = `${vy}_${pad(vm+1)}`;
    let meals = 0;
    Object.entries(_meals).forEach(([key, data]) => {
      if (key.startsWith(pfx) && key.endsWith('_'+uid)) {
        meals += (data.slots||[]).filter(Boolean).length;
        meals += (data.guestSlots||[]).filter(Boolean).length;
      }
    });
    months.push({
      label: `${moName(vm).slice(0,3)} ${vy}`,
      meals, isCurrent: i===0
    });
  }

  const max = Math.max(...months.map(m=>m.meals), 1);
  chartEl.innerHTML = months.map(m => {
    const h = Math.round((m.meals/max)*100);
    return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:3px">
  <span style="font-size:10px;font-weight:700;color:${m.isCurrent?'var(--g1)':'var(--ink4)'}">
    ${m.meals||''}
  </span>
  <div style="width:100%;height:${Math.max(h,4)}px;
    background:${m.isCurrent?'var(--g2)':'var(--g6)'};
    border-radius:4px 4px 0 0;transition:.3s"></div>
</div>`;
  }).join('');

  if (lblEl) lblEl.innerHTML = months.map(m =>
    `<div style="flex:1;text-align:center;font-size:10px;overflow:hidden;
      color:${m.isCurrent?'var(--g1)':'var(--ink4)'};
      font-weight:${m.isCurrent?'700':'400'}">
      ${m.label.split(' ')[0]}
    </div>`
  ).join('');
}

function _renderMineCal(root, uid) {
  const slots = _ctx.messSettings?.slots||['সকাল','দুপুর','রাত'];
  const days  = dim(_vy,_vm);
  const el    = root.querySelector('#mine-cal');
  if(!el) return;

  let html=`<table class="dt" style="min-width:${90+slots.length*46}px">
<thead><tr><th class="tl">তারিখ</th>
${slots.map(s=>`<th style="font-size:10px">${_e(s)}</th>`).join('')}
<th>Guest</th><th>মোট</th></tr></thead><tbody>`;
  let total=0;
  for(let d=1;d<=days;d++){
    const key=`${_vy}_${pad(_vm+1)}_${pad(d)}_${uid}`;
    const data=_meals[key]||{};
    const s=data.slots||[]; const g=(data.guestSlots||[]).filter(Boolean).length;
    const t=s.filter(Boolean).length+g; total+=t;
    html+=`<tr${t>0?' style="background:var(--g8)"':''}>
<td class="tl" style="font-size:12px">${d} ${moName(_vm).slice(0,3)}</td>
${slots.map((_,i)=>`<td><div class="mdot ${s[i]?'don':'doff'}" style="margin:0 auto">${s[i]?'✓':''}</div></td>`).join('')}
<td>${g||'—'}</td>
<td style="font-weight:${t>0?'700':'400'};color:${t>0?'var(--g1)':'var(--ink4)'}">${t||'—'}</td>
</tr>`;
  }
  html+=`<tr class="tf"><td class="tl">মোট</td>${slots.map(()=>'<td></td>').join('')}<td></td><td>${total}</td></tr></tbody></table>`;
  el.innerHTML=html;
}

function _renderMineTx(root, uid) {
  const el=root.querySelector('#mine-tx-table');
  if(!el) return;

  const myDeps=_deposits.filter(d=>d.memberId===uid);
  const myExps=_expenses.filter(e=>e.addedBy===uid);

  if(!myDeps.length && !myExps.length){
    el.innerHTML='<div style="padding:14px;text-align:center;color:var(--ink4)">এই মাসে কোনো লেনদেন নেই</div>';
    return;
  }

  const rows=[
    ...myDeps.map(d=>({date:d.date, type:'জমা', note:_e(d.note||''), amount:parseFloat(d.amount)||0, sign:1, autoFromBazar:d.autoFromBazar})),
    ...myExps.map(e=>({date:e.date, type:'বাজার', note:_e(e.item||''), amount:parseFloat(e.amount)||0, sign:-1})),
  ].sort((a,b)=>b.date?.localeCompare(a.date||'')||0);

  el.innerHTML=`<table class="dt">
<thead><tr><th class="tl">তারিখ</th><th class="tl">ধরন</th><th class="tl">বিবরণ</th><th>পরিমাণ</th></tr></thead>
<tbody>
${rows.map(r=>`<tr>
  <td class="tl">${r.date||'—'}</td>
  <td class="tl">
    <span style="font-size:11px;padding:2px 7px;border-radius:6px;font-weight:700;
      background:${r.sign>0?'var(--g7)':'var(--r4)'};color:${r.sign>0?'var(--g1)':'var(--r1)'}">
      ${r.sign>0?'⬆ '+r.type:'⬇ '+r.type}
    </span>
    ${r.autoFromBazar?'<span style="font-size:9px;color:var(--ink3)"> (auto)</span>':''}
  </td>
  <td class="tl">${r.note}</td>
  <td style="font-weight:700;font-family:var(--mono);color:${r.sign>0?'var(--g1)':'var(--r1)'}">
    ${r.sign>0?'+':'-'}${taka(r.amount)}
  </td>
</tr>`).join('')}
</tbody>
</table>`;
}

// ── Export ───────────────────────────────────────────────────────────────────
function _export(root) {
  if(!window.XLSX){ toast('XLSX লোড হয়নি','er'); return; }
  exportExcel({
    messName:  _ctx.messData?.name||'মেস',
    month: _vm, year: _vy,
    members: _members, meals: _meals,
    expenses: _expenses, deposits: _deposits,
    profile: _ctx.profile,
    isMessTab: _activeTab==='mess',
  });
}

function _exportPDFShared(root) {
  exportPDF({
    messName:    _ctx.messData?.name||'মেস',
    messAddress: _ctx.messData?.address||'',
    month: _vm, year: _vy,
    members: _members, meals: _meals,
    expenses: _expenses, deposits: _deposits,
    slots: _ctx.messSettings?.slots||['সকাল','দুপুর','রাত'],
    profile: _ctx.profile,
    isMessTab: _activeTab==='mess',
  });
}

// ── Legacy (unused but kept for reference) ──
function _exportMess_UNUSED() {
  let grandMeals=0;
  _members.forEach(m=>{ grandMeals+=_calcMember(m.uid).all; });
  const totalBazar=_expenses.reduce((s,e)=>s+(parseFloat(e.amount)||0),0);
  const mealRate=grandMeals>0?totalBazar/grandMeals:0;

  const sheet=[
    [`মেস রিপোর্ট — ${moName(_vm)} ${_vy}`],[],
    ['সদস্য','মিল','Guest','মোট মিল','মিল খরচ','জমা','ব্যালেন্স'],
    ..._members.map(m=>{
      const {total,guest,all}=_calcMember(m.uid);
      const cost=all*mealRate;
      const dep=_deposits.filter(d=>d.memberId===m.uid).reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
      return [m.name||m.email,total,guest,all,+cost.toFixed(2),dep,+(dep-cost).toFixed(2)];
    }),
    [],[`মোট মিল: ${grandMeals} | মিল রেট: ${takaF(mealRate)} | বাজার: ${taka(totalBazar)}`],
  ];
  const wb=window.XLSX.utils.book_new();
  window.XLSX.utils.book_append_sheet(wb,window.XLSX.utils.aoa_to_sheet(sheet),`মেস রিপোর্ট`);
  window.XLSX.writeFile(wb,`mess-report-${moName(_vm)}-${_vy}.xlsx`);
  toast('Excel download হচ্ছে…','ok');
}

function _exportMine() {
  const uid=_ctx.profile.uid;
  let myMeals=0,totalMeals=0;
  Object.entries(_meals).forEach(([key,data])=>{
    const s=(data.slots||[]).filter(Boolean).length+(data.guestSlots||[]).filter(Boolean).length;
    totalMeals+=s;
    if(key.endsWith('_'+uid)) myMeals+=s;
  });
  const totalBazar=_expenses.reduce((s,e)=>s+(parseFloat(e.amount)||0),0);
  const rate=totalMeals>0?totalBazar/totalMeals:0;
  const myCost=myMeals*rate;
  const myDep=_deposits.filter(d=>d.memberId===uid).reduce((s,d)=>s+(parseFloat(d.amount)||0),0);

  const sheet=[
    [`আমার রিপোর্ট — ${_e(_ctx.profile.name||_ctx.profile.email)} — ${moName(_vm)} ${_vy}`],[],
    ['তারিখ','ধরন','বিবরণ','পরিমাণ'],
    ..._deposits.filter(d=>d.memberId===uid).map(d=>
      [d.date,'জমা',d.note||'',parseFloat(d.amount)||0]),
    ..._expenses.filter(e=>e.addedBy===uid).map(e=>
      [e.date,'বাজার',e.item||'',parseFloat(e.amount)||0]),
    [],[`মিল: ${myMeals} | রেট: ${takaF(rate)} | খরচ: ${takaF(myCost)} | জমা: ${taka(myDep)} | ব্যালেন্স: ${takaF(myDep-myCost)}`],
  ];
  const wb=window.XLSX.utils.book_new();
  window.XLSX.utils.book_append_sheet(wb,window.XLSX.utils.aoa_to_sheet(sheet),'আমার রিপোর্ট');
  window.XLSX.writeFile(wb,`my-report-${(_ctx.profile.name||'user').replace(/\s+/g,'-')}-${moName(_vm)}-${_vy}.xlsx`);
  toast('Excel download হচ্ছে…','ok');
}


const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

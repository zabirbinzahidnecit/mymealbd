// billing.js — মেসের billing timeline হিসাব করার শেয়ারড লজিক
// billingHistory (past paid periods) + বর্তমান mess plan/expiry (running/due
// period) — দুটো মিলিয়ে একটা সম্পূর্ণ timeline বানানো হয়, মেস-সাইড ও
// Admin-সাইড দুই জায়গাতেই একই লজিক ব্যবহার হয়।

import { db } from './firebase.js';
import { getPlanDueInfoSync, getMonthlyPrice, computeRenewalQuote } from './plan.js';
import { moName } from './utils.js';
import {
  collection, getDocs, doc, getDoc, query, orderBy
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

export { computeRenewalQuote };

export async function getBillingTimeline(messId) {
  const [messSnap, histSnap, cfgSnap] = await Promise.all([
    getDoc(doc(db,'messes',messId)),
    getDocs(query(collection(db,'messes',messId,'billingHistory'), orderBy('periodStart','asc'))),
    getDoc(doc(db,'appConfig','main')),
  ]);

  const messData = messSnap.exists() ? { id:messSnap.id, ...messSnap.data() } : null;
  const cfg = cfgSnap.exists() ? cfgSnap.data() : {};

  const history = histSnap.docs.map(d => {
    const x = d.data();
    return {
      id: d.id,
      plan: x.plan,
      periodStart: x.periodStart?.toDate ? x.periodStart.toDate() : null,
      periodEnd:   x.periodEnd?.toDate   ? x.periodEnd.toDate()   : null,
      monthsCovered: x.monthsCovered || 1,
      amount: x.amount || 0,
      wasOverdue: !!x.wasOverdue,
      monthsOverdueAtPayment: x.monthsOverdueAtPayment || 0,
      paymentMethod: x.paymentMethod || null,
      txnId: x.txnId || null,
      createdAt: x.createdAt?.toDate ? x.createdAt.toDate() : null,
    };
  });

  const dueInfo = messData ? getPlanDueInfoSync(messData, cfg) : { isExpired:false, monthsOverdue:0, dueAmount:0, monthlyPrice:0 };

  // চলতি "running" মাসের অবস্থা — মেয়াদ থাকতে থাকতেই (এখনো expired না) হলে
  // "চলমান, বকেয়া নেই" দেখাবে। মেয়াদ শেষ হয়ে গেলে dueInfo থেকে বকেয়া আসবে।
  const totalPaid = history.reduce((s,h)=>s+h.amount, 0);

  return {
    messData,
    history,       // পুরনো সব পরিশোধিত period, সময়ক্রম অনুযায়ী
    dueInfo,        // বর্তমান বকেয়া অবস্থা (isExpired, monthsOverdue, dueAmount, monthlyPrice)
    totalPaid,
    currentPlan: messData?.plan || 'free',
    currentExpiry: messData?.planExpiry?.toDate ? messData.planExpiry.toDate() :
      (messData?.planExpiry ? new Date(messData.planExpiry) : null),
  };
}

export const PLAN_LABEL = { free:'🆓 Free', pro10:'⭐ Pro 10', pro15:'⭐⭐ Pro 15', pro20plus:'⭐⭐⭐ Custom' };

// ── ক্যালেন্ডার-স্টাইল হরাইজন্টাল টাইমলাইন ─────────────────────
// প্রতিটা দিনের জন্য একটা সেল — যেদিন plan শুরু হয়েছিল সেদিন থেকে শুরু করে
// (কোনো billingHistory না থাকলে কিছুই দেখাবে না)। রঙ:
//  🟢 পরিশোধিত (paid period-এর ভেতরে, আজকের আগে/আজ)
//  🔵 অগ্রিম (paid period-এর ভেতরে কিন্তু আজকের পরে — ভবিষ্যতের জন্য আগে থেকেই পরিশোধিত)
//  🔴 বকেয়া (কোনো paid period-এর ভেতরে না, কিন্তু আজকের আগে/আজ — মানে চলতি বকেয়া দিন)
// পুরো স্ট্রিপ overflow-x:auto দিয়ে horizontally scroll করা যায়।
export function renderCalendarStrip(tl) {
  const { history } = tl;
  if (!history.length) {
    return '<p style="font-size:12px;color:var(--ink3);padding:12px 0">এখনো কোনো বিলিং ইতিহাস নেই, তাই ক্যালেন্ডার দেখানোর কিছু নেই</p>';
  }

  const today = new Date(); today.setHours(0,0,0,0);
  const rangeStart = new Date(history[0].periodStart); rangeStart.setHours(0,0,0,0);
  const lastEnd = new Date(history[history.length-1].periodEnd); lastEnd.setHours(0,0,0,0);
  const rangeEnd = lastEnd > today ? lastEnd : today;

  const groups = [];
  let curKey = null, curGroup = null;
  const d = new Date(rangeStart);
  while (d <= rangeEnd) {
    const dayDate = new Date(d);
    const period = history.find(h => dayDate >= h.periodStart && dayDate < h.periodEnd);
    const status = period ? (dayDate <= today ? 'paid' : 'advance') : 'due';

    const key = `${dayDate.getFullYear()}-${dayDate.getMonth()}`;
    if (key !== curKey) {
      curKey = key;
      curGroup = { label: `${moName(dayDate.getMonth())} ${dayDate.getFullYear()}`, cells: [] };
      groups.push(curGroup);
    }
    curGroup.cells.push({ date: new Date(dayDate), status });
    d.setDate(d.getDate()+1);
  }

  const COLORS = { paid:'#146b40', advance:'#4a78e8', due:'#dc2626' };
  const groupsHtml = groups.map(g => `
<div style="display:flex;flex-direction:column;gap:4px;flex-shrink:0">
  <p style="font-size:10px;font-weight:700;color:var(--ink3);white-space:nowrap">${g.label}</p>
  <div style="display:flex;gap:2px">
    ${g.cells.map(c => `<div title="${c.date.getDate()} ${moName(c.date.getMonth())} ${c.date.getFullYear()} — ${c.status==='paid'?'পরিশোধিত':c.status==='advance'?'অগ্রিম':'বকেয়া'}"
      style="width:10px;height:22px;border-radius:2px;background:${COLORS[c.status]}"></div>`).join('')}
  </div>
</div>`).join('');

  return `
<div style="overflow-x:auto;padding-bottom:10px;-webkit-overflow-scrolling:touch;border:1px solid var(--line);
  border-radius:10px;padding:12px">
  <div style="display:flex;gap:12px">${groupsHtml}</div>
</div>
<div style="display:flex;gap:14px;margin-top:8px;flex-wrap:wrap">
  <span style="font-size:11px;color:var(--ink3)"><span style="display:inline-block;width:10px;height:10px;background:#146b40;border-radius:2px;margin-right:4px;vertical-align:middle"></span>পরিশোধিত</span>
  <span style="font-size:11px;color:var(--ink3)"><span style="display:inline-block;width:10px;height:10px;background:#4a78e8;border-radius:2px;margin-right:4px;vertical-align:middle"></span>অগ্রিম</span>
  <span style="font-size:11px;color:var(--ink3)"><span style="display:inline-block;width:10px;height:10px;background:#dc2626;border-radius:2px;margin-right:4px;vertical-align:middle"></span>বকেয়া</span>
</div>
<p style="font-size:10px;color:var(--ink4);margin-top:6px">👉 পাশে টেনে (scroll) আগে-পরের দিন দেখুন</p>`;
}

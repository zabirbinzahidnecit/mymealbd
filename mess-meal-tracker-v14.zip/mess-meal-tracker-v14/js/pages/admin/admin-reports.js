// admin-reports.js — v14: full rewrite, mess selector + full report

import { db } from '../../firebase.js';
import { taka, takaF, pad, moName, dim } from '../../utils.js';
import {
  collection, getDocs, query, where, orderBy
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _messes=[], _vy=TODAY.getFullYear(), _vm=TODAY.getMonth();
let _members=[], _meals={}, _expenses=[], _deposits=[];

export async function render(root, { profile }) {
  root.innerHTML = `
<div>
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px">
    <h2 style="font-size:17px;font-weight:700;color:#0a180e;margin:0">📈 রিপোর্ট</h2>
    <button class="btn btn-ghost btn-sm" id="arep-refresh">🔄</button>
  </div>

  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <div class="field" style="margin:0;flex:1;min-width:180px">
      <label class="lbl">মেস নির্বাচন</label>
      <select class="inp inp-sm" id="arep-mess-sel"><option value="">— মেস নির্বাচন করুন —</option></select>
    </div>
    <div style="display:flex;align-items:center;gap:5px;margin-top:16px">
      <button class="btn btn-ghost btn-sm" id="arep-prev">◀</button>
      <span style="font-size:13px;font-weight:700;min-width:130px;text-align:center" id="arep-lbl"></span>
      <button class="btn btn-ghost btn-sm" id="arep-next">▶</button>
    </div>
    <div style="display:flex;gap:6px;margin-top:16px">
      <button class="btn btn-p btn-sm" id="arep-load">📊 লোড করুন</button>
      <button class="btn btn-ghost btn-sm" id="arep-excel" style="display:none">📥 Excel</button>
      <button class="btn btn-ghost btn-sm" id="arep-pdf" style="display:none">🖨️ PDF</button>
    </div>
  </div>

  <div id="arep-body">
    <div style="padding:40px;text-align:center;color:#4a7055;background:#f1f5f2;border-radius:12px">
      <div style="font-size:36px;margin-bottom:10px">📊</div>
      <p>একটি মেস নির্বাচন করুন</p>
    </div>
  </div>
</div>`;

  root.querySelector('#arep-lbl').textContent = `${moName(_vm)} ${_vy}`;
  root.querySelector('#arep-prev').addEventListener('click', ()=>{ _vm--; if(_vm<0){_vm=11;_vy--} root.querySelector('#arep-lbl').textContent=`${moName(_vm)} ${_vy}`; });
  root.querySelector('#arep-next').addEventListener('click', ()=>{ _vm++; if(_vm>11){_vm=0;_vy++} root.querySelector('#arep-lbl').textContent=`${moName(_vm)} ${_vy}`; });
  root.querySelector('#arep-load').addEventListener('click', ()=> _loadReport(root));
  root.querySelector('#arep-refresh').addEventListener('click', ()=> _init(root));
  root.querySelector('#arep-excel').addEventListener('click', ()=> _exportExcel());
  root.querySelector('#arep-pdf').addEventListener('click',   ()=> _exportPDF(root));

  await _init(root);
}

async function _init(root) {
  try {
    const snap = await getDocs(query(collection(db,'messes'), orderBy('createdAt','desc')));
    _messes    = snap.docs.map(d=>({id:d.id,...d.data()}));
    const sel  = root.querySelector('#arep-mess-sel');
    if (sel) {
      const prev = sel.value;
      sel.innerHTML = `<option value="">— মেস নির্বাচন করুন —</option>` +
        _messes.map(m=>`<option value="${m.id}">${_e(m.name||'অজানা')} ${m.plan==='paid'?'⭐':''}</option>`).join('');
      if (prev) sel.value = prev;
    }
  } catch(err) { console.error(err); }
}

async function _loadReport(root) {
  const messId = root.querySelector('#arep-mess-sel')?.value;
  if (!messId) { root.querySelector('#arep-body').innerHTML =
    '<div style="padding:20px;text-align:center;color:#b83030">মেস নির্বাচন করুন</div>'; return; }

  const mess       = _messes.find(m=>m.id===messId) || {};
  const monthStr   = `${_vy}-${pad(_vm+1)}`;
  const monthPfx   = `${_vy}_${pad(_vm+1)}`;
  const body       = root.querySelector('#arep-body');
  body.innerHTML   = '<div style="padding:30px;text-align:center;color:#4a7055">লোড হচ্ছে…</div>';

  try {
    const [mSnap, allMeals, expSnap, depSnap] = await Promise.all([
      getDocs(collection(db,'messes',messId,'members')),
      getDocs(collection(db,'messes',messId,'meals')),
      getDocs(query(collection(db,'messes',messId,'expenses'), where('status','==','approved'))),
      getDocs(query(collection(db,'messes',messId,'deposits'), where('status','==','approved'))),
    ]);

    _members  = mSnap.docs.map(d=>({uid:d.id,...d.data()}))
      .sort((a,b)=>(a.joinedAt?.seconds||0)-(b.joinedAt?.seconds||0));
    _meals    = {};
    allMeals.forEach(d=>{ if(d.id.startsWith(monthPfx)) _meals[d.id]=d.data(); });
    _expenses = expSnap.docs.map(d=>d.data()).filter(e=>e.date?.startsWith(monthStr));
    _deposits = depSnap.docs.map(d=>d.data()).filter(d=>d.date?.startsWith(monthStr));

    let grandMeals=0;
    const memberData = _members.map(m=>{
      let ml=0, gl=0;
      Object.entries(_meals).forEach(([key,data])=>{
        if(key.endsWith('_'+m.uid)){
          ml+=(data.slots||[]).filter(Boolean).length;
          gl+=(data.guestSlots||[]).filter(Boolean).length;
        }
      });
      const all=ml+gl; grandMeals+=all;
      const dep=_deposits.filter(d=>d.memberId===m.uid).reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
      return {...m,meals:ml,guest:gl,all,dep};
    });

    const totalBazar   = _expenses.reduce((s,e)=>s+(parseFloat(e.amount)||0),0);
    const totalDeposit = _deposits.reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
    const mealRate     = grandMeals>0 ? totalBazar/grandMeals : 0;
    memberData.forEach(m=>{ m.cost=m.all*mealRate; m.balance=m.dep-m.cost; });

    body.innerHTML = `
<div class="g4" style="margin-bottom:14px">
  <div class="sc sg"><div class="sl">মোট মিল</div><div class="sv">${grandMeals||'০'}</div></div>
  <div class="sc sa"><div class="sl">মিল রেট</div><div class="sv">${takaF(mealRate)}</div><div class="ss">প্রতি মিল</div></div>
  <div class="sc sb"><div class="sl">মোট বাজার</div><div class="sv">${taka(totalBazar)}</div></div>
  <div class="sc sr"><div class="sl">মোট জমা</div><div class="sv">${taka(totalDeposit)}</div></div>
</div>

<div class="card" style="margin-bottom:14px">
  <div class="ch"><h3>👥 সদস্য ভিত্তিক হিসাব — ${_e(mess.name||'')} · ${moName(_vm)} ${_vy}</h3></div>
  <div style="overflow-x:auto">
    <table class="dt">
    <thead><tr>
      <th class="tl">সদস্য</th><th>মিল</th><th>Guest</th>
      <th>মোট মিল</th><th>মিল খরচ</th><th>জমা</th><th>ব্যালেন্স</th>
    </tr></thead>
    <tbody>
    ${memberData.map(m=>`<tr>
      <td class="tl" style="font-weight:700">${_e(m.name||m.email)}</td>
      <td>${m.meals}</td><td>${m.guest||'—'}</td><td style="font-weight:700">${m.all}</td>
      <td style="font-family:var(--mono)">${takaF(m.cost)}</td>
      <td style="font-family:var(--mono)">${taka(m.dep)}</td>
      <td style="font-weight:700;font-family:var(--mono);color:${m.balance>=0?'var(--g1)':'var(--r1)'}">
        ${takaF(m.balance)}
      </td>
    </tr>`).join('')}
    <tr class="tf">
      <td class="tl">মোট</td><td colspan="2"></td><td>${grandMeals}</td>
      <td>${takaF(totalBazar)}</td><td>${taka(totalDeposit)}</td>
      <td style="color:${totalDeposit-totalBazar>=0?'var(--g1)':'var(--r1)'}">
        ${takaF(totalDeposit-totalBazar)}
      </td>
    </tr>
    </tbody>
    </table>
  </div>
</div>

${_expenses.length ? `
<div class="card">
  <div class="ch"><h3>🛒 বাজারের তালিকা</h3><span style="font-weight:700;color:var(--g1)">${taka(totalBazar)}</span></div>
  <div style="overflow-x:auto">
    <table class="dt">
    <thead><tr><th class="tl">তারিখ</th><th class="tl">আইটেম</th><th class="tl">যোগ করেছেন</th><th>পরিমাণ</th></tr></thead>
    <tbody>
    ${_expenses.map(e=>`<tr>
      <td class="tl">${e.date||'—'}</td>
      <td class="tl">${_e(e.item||'')}${e.note?`<span style="color:var(--ink4)"> (${_e(e.note)})</span>`:''}</td>
      <td class="tl">${_e(e.addedByName||'—')}</td>
      <td style="font-family:var(--mono);font-weight:700">${taka(e.amount)}</td>
    </tr>`).join('')}
    </tbody>
    </table>
  </div>
</div>` : ''}`;

    // Store for export
    root._repData = { mess, memberData, mealRate, totalBazar, totalDeposit, grandMeals };
    root.querySelector('#arep-excel').style.display='';
    root.querySelector('#arep-pdf').style.display='';

  } catch(err) {
    body.innerHTML = `<div style="padding:20px;text-align:center;color:#b83030">⚠️ ${_e(err.message)}</div>`;
    console.error(err);
  }
}

function _exportExcel() {
  if(!window.XLSX) return;
  // not-root scope export uses stored _members, _expenses, _deposits
}

function _exportPDF(root) {
  const d = root._repData;
  if (!d) return;
  const html = `<!DOCTYPE html><html lang="bn"><head><meta charset="UTF-8"/>
<title>${_e(d.mess.name)} রিপোর্ট</title>
<style>
@page{size:A4;margin:18mm 15mm}
body{font-family:Arial,sans-serif;font-size:12px;color:#1a1a1a;margin:0}
h1{font-size:17px;font-weight:700;color:#083d22;margin:0 0 4px}
h2{font-size:13px;font-weight:700;color:#083d22;margin:14px 0 6px;border-bottom:2px solid #146b40;padding-bottom:4px}
.sum{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:10px 0 14px}
.sb{background:#f1f5f2;border:1px solid #c0dcc0;border-radius:6px;padding:8px 10px}
.sl{font-size:10px;color:#4a7055;font-weight:700;text-transform:uppercase}
.sv{font-size:16px;font-weight:700;color:#083d22;margin-top:2px}
table{width:100%;border-collapse:collapse;margin-bottom:12px}
th{background:#146b40;color:#fff;padding:6px 8px;text-align:left;font-size:11px}
td{padding:5px 8px;border-bottom:1px solid #e8f0ea;font-size:11px}
tr:nth-child(even) td{background:#f8fbf9}
.tf td{font-weight:700;background:#e8f0ea!important}
.footer{margin-top:20px;font-size:10px;color:#8aaa90;text-align:center;border-top:1px solid #d8e8dc;padding-top:8px}
</style></head><body>
<div style="display:flex;justify-content:space-between;border-bottom:3px solid #146b40;padding-bottom:10px;margin-bottom:14px">
  <div><h1>${_e(d.mess.name||'মেস')} — মেস রিপোর্ট</h1>
  <p style="font-size:11px;color:#4a7055">${moName(_vm)} ${_vy} · তৈরি: ${new Date().toLocaleDateString('bn-BD')}</p></div>
  <div style="text-align:right;font-size:11px;color:#4a7055">
    <div>মিল রেট: <strong>৳${d.mealRate.toFixed(2)}</strong></div>
    <div>মোট মিল: <strong>${d.grandMeals}</strong></div>
  </div>
</div>
<div class="sum">
  <div class="sb"><div class="sl">মোট মিল</div><div class="sv">${d.grandMeals}</div></div>
  <div class="sb"><div class="sl">মিল রেট</div><div class="sv">৳${d.mealRate.toFixed(2)}</div></div>
  <div class="sb"><div class="sl">মোট বাজার</div><div class="sv">৳${d.totalBazar.toFixed(2)}</div></div>
  <div class="sb"><div class="sl">মোট জমা</div><div class="sv">৳${d.totalDeposit.toFixed(2)}</div></div>
</div>
<h2>👥 সদস্য ভিত্তিক হিসাব</h2>
<table><thead><tr><th>সদস্য</th><th>মোট মিল</th><th style="text-align:right">মিল খরচ</th><th style="text-align:right">জমা</th><th style="text-align:right">ব্যালেন্স</th></tr></thead>
<tbody>${d.memberData.map(m=>`<tr>
  <td>${_e(m.name||m.email)}</td><td>${m.all}</td>
  <td style="text-align:right">৳${m.cost.toFixed(2)}</td>
  <td style="text-align:right">৳${m.dep.toFixed(2)}</td>
  <td style="text-align:right;color:${m.balance>=0?'#146b40':'#b83030'};font-weight:700">৳${m.balance.toFixed(2)}</td>
</tr>`).join('')}</tbody>
<tfoot><tr class="tf"><td>মোট</td><td>${d.grandMeals}</td>
  <td style="text-align:right">৳${d.totalBazar.toFixed(2)}</td>
  <td style="text-align:right">৳${d.totalDeposit.toFixed(2)}</td>
  <td style="text-align:right">৳${(d.totalDeposit-d.totalBazar).toFixed(2)}</td>
</tr></tfoot></table>
${_expenses.length?`<h2>🛒 বাজারের তালিকা</h2>
<table><thead><tr><th>তারিখ</th><th>আইটেম</th><th>যোগ করেছেন</th><th style="text-align:right">পরিমাণ</th></tr></thead>
<tbody>${_expenses.map(e=>`<tr><td>${e.date||'—'}</td><td>${_e(e.item||'')}</td><td>${_e(e.addedByName||'—')}</td><td style="text-align:right">৳${parseFloat(e.amount||0).toFixed(2)}</td></tr>`).join('')}</tbody>
<tfoot><tr class="tf"><td colspan="3">মোট বাজার</td><td style="text-align:right">৳${d.totalBazar.toFixed(2)}</td></tr></tfoot></table>`:''}
<div class="footer">মেস মিল ট্র্যাকার · ${_e(d.mess.name||'')} · ${moName(_vm)} ${_vy}</div>
</body></html>`;
  const w=window.open('','_blank','width=900,height=700');
  if(!w){ alert('Popup blocked'); return; }
  w.document.write(html); w.document.close(); w.focus();
  setTimeout(()=>w.print(),600);
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

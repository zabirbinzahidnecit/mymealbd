// build.js — মিল ম্যানেজার অ্যাপকে minify করে dist/ ফোল্ডারে রেডি করে
//
// কেন বান্ডল না করে শুধু minify: mess-shell.js পেজ-রাউটিং dynamic
// import(`./${file}.js`) দিয়ে করে — অর্থাৎ প্রতিটা পেজ ফাইল আলাদাভাবে,
// আসল নামে থাকা লাগবে। bundling (সব একফাইলে জোড়া লাগানো) করলে এই
// dynamic import ভেঙে যাবে। তাই প্রতিটা ফাইল আলাদাভাবে minify করা হয়,
// ফোল্ডার স্ট্রাকচার ও ফাইলের নাম অপরিবর্তিত রেখে।
//
// ব্যবহার:
//   npm install
//   npm run build
//   → dist/ ফোল্ডার তৈরি হবে, এটাই Firebase Hosting এ deploy করুন
//     (firebase.json এ "public": "dist" রাখুন)

const esbuild = require('esbuild');
const fs = require('fs');
const path = require('path');

const SRC  = __dirname;
const DIST = path.join(__dirname, 'dist');

function walkJsFiles(dir, base = dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === 'dist' || entry.name === 'node_modules') continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walkJsFiles(full, base, out);
    else if (entry.name.endsWith('.js')) out.push(path.relative(base, full));
  }
  return out;
}

function dirSize(dir) {
  let total = 0;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    total += entry.isDirectory() ? dirSize(full) : fs.statSync(full).size;
  }
  return total;
}

function copyDir(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, entry.name);
    const d = path.join(dest, entry.name);
    if (entry.isDirectory()) copyDir(s, d);
    else fs.copyFileSync(s, d);
  }
}

async function build() {
  fs.rmSync(DIST, { recursive: true, force: true });
  fs.mkdirSync(DIST, { recursive: true });

  // 1. প্রতিটা JS ফাইল আলাদাভাবে minify (bundle: false — কারণ উপরে বলা হয়েছে)
  const jsFiles = walkJsFiles(path.join(SRC, 'js'));
  for (const rel of jsFiles) {
    const inPath  = path.join(SRC, 'js', rel);
    const outPath = path.join(DIST, 'js', rel);
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    await esbuild.build({
      entryPoints: [inPath],
      outfile: outPath,
      minify: true,
      format: 'esm',
      target: 'es2020',
      bundle: false,
      logLevel: 'silent',
    });
  }
  console.log(`✓ ${jsFiles.length}টা JS ফাইল minify হয়েছে`);

  // 2. style.css minify
  await esbuild.build({
    entryPoints: [path.join(SRC, 'style.css')],
    outfile: path.join(DIST, 'style.css'),
    minify: true,
    logLevel: 'silent',
  });
  console.log('✓ style.css minify হয়েছে');

  // 3. বাকি static ফাইল হুবহু কপি (minify লাগবে না / করা ঠিক হবে না)
  const staticFiles = ['index.html', 'manifest.json', 'sw.js', 'firestore.rules', 'storage.rules'];
  for (const f of staticFiles) {
    const inPath = path.join(SRC, f);
    if (fs.existsSync(inPath)) fs.copyFileSync(inPath, path.join(DIST, f));
  }
  console.log('✓ static ফাইল কপি হয়েছে (index.html, manifest.json, sw.js, rules)');

  // 4. icons/ ফোল্ডার (PWA install-এর জন্য দরকার) হুবহু কপি
  const iconsDir = path.join(SRC, 'icons');
  if (fs.existsSync(iconsDir)) {
    copyDir(iconsDir, path.join(DIST, 'icons'));
    console.log('✓ icons/ ফোল্ডার কপি হয়েছে');
  }

  const srcSize  = dirSize(path.join(SRC, 'js')) + fs.statSync(path.join(SRC,'style.css')).size;
  const distSize = dirSize(path.join(DIST, 'js')) + fs.statSync(path.join(DIST,'style.css')).size;
  const pct = ((1 - distSize/srcSize) * 100).toFixed(1);
  console.log(`\n📦 JS+CSS: ${(srcSize/1024).toFixed(0)}KB → ${(distSize/1024).toFixed(0)}KB (${pct}% কম)`);
  console.log('🎉 Build শেষ — dist/ ফোল্ডার থেকে deploy করুন');
}

build().catch(e => { console.error(e); process.exit(1); });

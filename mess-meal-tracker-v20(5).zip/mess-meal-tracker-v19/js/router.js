import { isPlatformCoAdmin, startVersionWatch } from './auth.js';
import { db } from './firebase.js';
import { onSnapshot, doc } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const PAGE_LOADERS = {
  login:      () => import('./pages/login.js'),
  pending:    () => import('./pages/pending.js'),
  adminShell: () => import('./pages/admin/admin-shell.js'),
  messShell:  () => import('./pages/mess/mess-shell.js'),
};

let _maintUnsub = null;

function startMaintenanceWatch() {
  if (_maintUnsub) _maintUnsub();
  _maintUnsub = onSnapshot(doc(db,'appConfig','main'), snap => {
    if (!snap.exists()) return;
    if (isPlatformCoAdmin()) { _hideMaintenance(); return; }
    if (snap.data().maintenanceMode) _showMaintenance(snap.data().maintenanceMsg||'সাইটটি সাময়িকভাবে বন্ধ আছে।');
    else _hideMaintenance();
  }, () => {});
}

function _showMaintenance(msg) {
  if (document.getElementById('__maintenance-overlay')) {
    document.getElementById('__maintenance-msg').textContent = msg; return;
  }
  const div = document.createElement('div');
  div.id = '__maintenance-overlay';
  div.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0a1a0f;display:flex;flex-direction:column;align-items:center;justify-content:center;font-family:Hind Siliguri,sans-serif;padding:32px;text-align:center';
  div.innerHTML = `<div style="font-size:56px;margin-bottom:20px">🔧</div>
<h1 style="font-size:22px;font-weight:700;color:#fff;margin-bottom:12px">রক্ষণাবেক্ষণ চলছে</h1>
<p id="__maintenance-msg" style="font-size:15px;color:#86efac;max-width:380px;line-height:1.7;margin-bottom:28px">${msg}</p>
<div style="display:flex;align-items:center;gap:10px;background:#1f7a4520;border:1px solid #1f7a45;border-radius:12px;padding:12px 20px">
  <div style="width:8px;height:8px;border-radius:50%;background:#4ade80;animation:blink 1.5s infinite"></div>
  <span style="font-size:13px;color:#4ade80;font-weight:600">মেস মিল ট্র্যাকার — সাময়িক বিরতি</span>
</div>
<p style="font-size:11px;color:#4ade8060;margin-top:24px">Developed by Exit Excit</p>
<style>@keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}</style>`;
  document.body.appendChild(div);
}

function _hideMaintenance() {
  document.getElementById('__maintenance-overlay')?.remove();
}

export async function renderRouter(firebaseUser, profile) {
  const root = document.getElementById('app');
  if (!root) return;
  startMaintenanceWatch();
  let targetPage;
  if (!firebaseUser || !profile)  targetPage = 'login';
  else if (isPlatformCoAdmin())   targetPage = 'adminShell';
  else if (profile.currentMessId) targetPage = 'messShell';
  else                            targetPage = 'pending';
  if (firebaseUser && profile) startVersionWatch();
  root.innerHTML = '';
  try {
    const mod = await PAGE_LOADERS[targetPage]?.();
    if (mod?.render) await mod.render(root, { firebaseUser, profile });
  } catch(err) {
    console.error('Router error:', err);
    root.innerHTML = `<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;gap:16px;font-family:Hind Siliguri,sans-serif;padding:24px;text-align:center">
<div style="font-size:40px">⚠️</div><h2 style="font-size:18px;font-weight:700">পেজ লোড হয়নি</h2>
<p style="font-size:13px;color:#4a7055">${err.message}</p>
<button onclick="location.reload()" style="height:40px;padding:0 20px;background:#146b40;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer">🔄 পুনরায় লোড</button></div>`;
  }
}

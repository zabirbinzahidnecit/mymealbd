// admin-settings.js — v19: নতুন plan system + payment methods + auto-approve

import { db } from '../../firebase.js';
import { toast, ld, uld } from '../../utils.js';
import {
  doc, getDoc, setDoc, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _config = {};

const DEFAULT = {
  bkashNumber:'', bkashType:'Personal',
  nagadNumber:'', nagadType:'Personal',
  rocketNumber:'', rocketType:'Personal',
  pro10Price:199, pro15Price:299, pro20Price:499,
  freeMemberLimit:10, pro10MemberLimit:10,
  pro15MemberLimit:15, pro20MemberLimit:20,
  maintenanceMode:false,
  maintenanceMsg:'সাইটটি সাময়িকভাবে বন্ধ আছে। অনুগ্রহ করে পরে আসুন।',
  appVersion:'3.2.0',
  contactEmail:'',
  autoApproveMess:false,
};

export async function render(root) {
  root.innerHTML = `
<div>
  <div class="adp-hd">
    <div><h2 class="adp-h">⚙️ Platform Settings</h2>
    <p class="adp-sub">Payment, Plan, Maintenance, Auto-approve</p></div>
    <button class="btn btn-ghost btn-sm" id="cfg-refresh">🔄 রিফ্রেশ</button>
  </div>
  <div id="cfg-content"><div class="adm-loading">লোড হচ্ছে…</div></div>
</div>`;
  root.querySelector('#cfg-refresh').addEventListener('click', ()=> _load(root));
  await _load(root);
}

async function _load(root) {
  ld('Settings লোড হচ্ছে…');
  try {
    const snap = await getDoc(doc(db,'appConfig','main'));
    _config = snap.exists() ? { ...DEFAULT, ...snap.data() } : { ...DEFAULT };
    _render(root);
  } catch(err) {
    root.querySelector('#cfg-content').innerHTML =
      `<div class="adm-loading" style="color:var(--r1)">⚠️ ${err.message}</div>`;
  } finally { uld(); }
}

function _render(root) {
  root.querySelector('#cfg-content').innerHTML = `
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:13px">

  <!-- Payment Numbers -->
  <div class="card">
    <div class="ch"><h3>💳 Payment Numbers</h3></div>
    <div class="cb">
      <p style="font-size:11px;font-weight:700;color:#4a7055;margin-bottom:6px">💚 bKash</p>
      <div style="display:grid;grid-template-columns:2fr 1fr;gap:6px;margin-bottom:10px">
        <div class="field" style="margin:0"><label class="lbl">Number</label>
          <input class="inp inp-sm" id="cfg-bkash-num" value="${_e(_config.bkashNumber)}" placeholder="01XXXXXXXXXX"/></div>
        <div class="field" style="margin:0"><label class="lbl">Type</label>
          <select class="inp inp-sm" id="cfg-bkash-type">
            <option ${_config.bkashType==='Personal'?'selected':''}>Personal</option>
            <option ${_config.bkashType==='Agent'?'selected':''}>Agent</option>
            <option ${_config.bkashType==='Merchant'?'selected':''}>Merchant</option>
          </select></div>
      </div>
      <p style="font-size:11px;font-weight:700;color:#4a7055;margin-bottom:6px">🟠 নগদ</p>
      <div style="display:grid;grid-template-columns:2fr 1fr;gap:6px;margin-bottom:10px">
        <div class="field" style="margin:0"><label class="lbl">Number</label>
          <input class="inp inp-sm" id="cfg-nagad-num" value="${_e(_config.nagadNumber)}" placeholder="01XXXXXXXXXX"/></div>
        <div class="field" style="margin:0"><label class="lbl">Type</label>
          <select class="inp inp-sm" id="cfg-nagad-type">
            <option ${_config.nagadType==='Personal'?'selected':''}>Personal</option>
            <option ${_config.nagadType==='Merchant'?'selected':''}>Merchant</option>
          </select></div>
      </div>
      <p style="font-size:11px;font-weight:700;color:#4a7055;margin-bottom:6px">🟣 Rocket</p>
      <div style="display:grid;grid-template-columns:2fr 1fr;gap:6px;margin-bottom:12px">
        <div class="field" style="margin:0"><label class="lbl">Number</label>
          <input class="inp inp-sm" id="cfg-rocket-num" value="${_e(_config.rocketNumber)}" placeholder="01XXXXXXXXXX"/></div>
        <div class="field" style="margin:0"><label class="lbl">Type</label>
          <select class="inp inp-sm" id="cfg-rocket-type">
            <option ${_config.rocketType==='Personal'?'selected':''}>Personal</option>
            <option ${_config.rocketType==='Agent'?'selected':''}>Agent</option>
          </select></div>
      </div>
      <button class="btn btn-p btn-sm" id="cfg-save-payment">✓ সংরক্ষণ</button>
      <div id="payment-msg" style="font-size:11px;margin-top:6px"></div>
    </div>
  </div>

  <!-- Plan Pricing & Limits -->
  <div class="card">
    <div class="ch"><h3>📋 Plan মূল্য ও সীমা</h3></div>
    <div class="cb">
      <div style="background:var(--g8);border-radius:10px;padding:10px;margin-bottom:10px">
        <p style="font-size:12px;font-weight:700;color:var(--g1);margin-bottom:8px">🆓 Free Plan (Trial)</p>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <div class="field" style="margin:0"><label class="lbl">সর্বোচ্চ সদস্য</label>
            <input class="inp inp-sm" type="number" id="cfg-free-limit" value="${_config.freeMemberLimit||10}" min="1"/></div>
          <div class="field" style="margin:0"><label class="lbl">দাম</label>
            <input class="inp inp-sm" value="বিনামূল্যে" disabled style="opacity:.5"/></div>
        </div>
        <p style="font-size:10px;color:var(--ink3);margin-top:6px">সব feature চালু, শুধু সদস্য সীমা</p>
      </div>
      ${[
        {key:'pro10', label:'⭐ Pro 10', limitId:'cfg-pro10-limit', priceId:'cfg-pro10-price',
          limit:_config.pro10MemberLimit||10, price:_config.pro10Price||199, color:'#1a5cb0'},
        {key:'pro15', label:'⭐⭐ Pro 15', limitId:'cfg-pro15-limit', priceId:'cfg-pro15-price',
          limit:_config.pro15MemberLimit||15, price:_config.pro15Price||299, color:'#7c3aed'},
      ].map(p=>`
      <div style="border:1px solid var(--line);border-radius:10px;padding:10px;margin-bottom:8px">
        <p style="font-size:12px;font-weight:700;color:${p.color};margin-bottom:8px">${p.label}</p>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <div class="field" style="margin:0"><label class="lbl">সর্বোচ্চ সদস্য</label>
            <input class="inp inp-sm" type="number" id="${p.limitId}" value="${p.limit}" min="1"/></div>
          <div class="field" style="margin:0"><label class="lbl">দাম (৳/মাস)</label>
            <input class="inp inp-sm" type="number" id="${p.priceId}" value="${p.price}" min="0"/></div>
        </div>
      </div>`).join('')}
      <div style="border:1px solid #fcd34d;background:#fffbeb;border-radius:10px;padding:10px;margin-bottom:8px">
        <p style="font-size:12px;font-weight:700;color:#b45309;margin-bottom:4px">⭐⭐⭐ Custom (কাস্টম প্ল্যান)</p>
        <p style="font-size:10px;color:#92400e;margin-bottom:8px">
          মেস নিজে সদস্য সংখ্যা লিখে quote চায়; দাম স্বয়ংক্রিয়ভাবে হিসাব হয় — বেস প্রাইস + অতিরিক্ত প্রতি সদস্যের রেট।
          Admin পেমেন্ট অনুমোদনের সময় চূড়ান্ত সদস্য সীমা ঠিক করে দেন।
        </p>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">
          <div class="field" style="margin:0"><label class="lbl">বেস সদস্য সীমা</label>
            <input class="inp inp-sm" type="number" id="cfg-pro20-base-limit"
              value="${_config.pro20BaseLimit||_config.pro20MemberLimit||20}" min="1"/></div>
          <div class="field" style="margin:0"><label class="lbl">বেস দাম (৳/মাস)</label>
            <input class="inp inp-sm" type="number" id="cfg-pro20-base-price"
              value="${_config.pro20BasePrice||_config.pro20Price||499}" min="0"/></div>
          <div class="field" style="margin:0"><label class="lbl">অতিরিক্ত প্রতি সদস্য (৳)</label>
            <input class="inp inp-sm" type="number" id="cfg-pro20-per-extra"
              value="${_config.pro20PerExtraMember??15}" min="0"/></div>
        </div>
      </div>
      <button class="btn btn-p btn-sm" id="cfg-save-plans">✓ Plan সেটিংস সংরক্ষণ</button>
      <div id="plan-msg" style="font-size:11px;margin-top:6px"></div>
    </div>
  </div>

  <!-- Auto-Approve Mess -->
  <div class="card">
    <div class="ch"><h3>🏠 নতুন মেস অনুমোদন</h3></div>
    <div class="cb">
      <div style="display:flex;align-items:center;justify-content:space-between;
        padding:10px 0;border-bottom:1px solid var(--line);margin-bottom:12px">
        <div>
          <p style="font-size:13px;font-weight:600;color:var(--ink)">Auto-Approve</p>
          <p style="font-size:11px;color:var(--ink3);margin-top:2px">চালু থাকলে request করলেই মেস তৈরি হবে</p>
        </div>
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;flex-shrink:0">
          <input type="checkbox" id="cfg-auto-approve"
            style="accent-color:var(--g2);width:18px;height:18px"
            ${_config.autoApproveMess?'checked':''}/>
          <span id="auto-approve-lbl" style="font-size:12px;font-weight:700;
            color:${_config.autoApproveMess?'var(--g1)':'var(--ink3)'}">
            ${_config.autoApproveMess?'চালু':'বন্ধ'}</span>
        </label>
      </div>
      <div style="background:var(--a4);border-radius:8px;padding:10px;font-size:11px;
        color:var(--a0);line-height:1.6;margin-bottom:12px">
        ⚠️ <strong>বন্ধ:</strong> User request পাঠাবে, Admin approve করবে।<br>
        ✅ <strong>চালু:</strong> Request করলেই সাথে সাথে মেস তৈরি হবে।
      </div>
      <button class="btn btn-p btn-sm" id="cfg-save-auto-approve">✓ সংরক্ষণ</button>
      <div id="auto-approve-msg" style="font-size:11px;margin-top:6px"></div>
    </div>
  </div>

  <!-- App Config -->
  <div class="card">
    <div class="ch"><h3>🔄 App Config</h3></div>
    <div class="cb">
      <div class="field"><label class="lbl">App Version</label>
        <input class="inp inp-sm" id="cfg-version" value="${_e(_config.appVersion||'3.2.0')}"/>
        <p style="font-size:11px;color:var(--ink3);margin-top:4px">Version বাড়ালে সব user কে update ব্যানার দেখাবে</p>
      </div>
      <div class="field"><label class="lbl">Contact Email</label>
        <input class="inp inp-sm" id="cfg-contact-email" type="email" value="${_e(_config.contactEmail||'')}" placeholder="support@example.com"/></div>
      <button class="btn btn-p btn-sm" id="cfg-save-app">✓ সংরক্ষণ</button>
      <div id="app-msg" style="font-size:11px;margin-top:6px"></div>
    </div>
  </div>

  <!-- Maintenance Mode -->
  <div class="card" style="border-color:${_config.maintenanceMode?'var(--r2)':'var(--line)'}">
    <div class="ch">
      <h3 style="color:${_config.maintenanceMode?'var(--r1)':'var(--ink)'}">🔧 Maintenance Mode</h3>
      <span class="badge ${_config.maintenanceMode?'b-red':'b-green'}">${_config.maintenanceMode?'চালু':'বন্ধ'}</span>
    </div>
    <div class="cb">
      <div style="display:flex;align-items:center;justify-content:space-between;
        padding:10px 0;border-bottom:1px solid var(--line);margin-bottom:12px">
        <span style="font-size:13px;color:var(--ink)">Maintenance চালু করুন</span>
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
          <input type="checkbox" id="cfg-maintenance"
            style="accent-color:var(--r1);width:18px;height:18px"
            ${_config.maintenanceMode?'checked':''}/>
          <span id="maint-toggle-lbl" style="font-size:12px;font-weight:700;
            color:${_config.maintenanceMode?'var(--r1)':'var(--ink3)'}">
            ${_config.maintenanceMode?'চালু':'বন্ধ'}</span>
        </label>
      </div>
      <div class="field"><label class="lbl">Maintenance বার্তা</label>
        <textarea class="inp inp-sm" id="cfg-maint-msg" rows="2" style="resize:vertical"
          maxlength="300">${_e(_config.maintenanceMsg||'')}</textarea></div>
      <button class="btn btn-sm ${_config.maintenanceMode?'btn-danger':'btn-p'}" id="cfg-save-maint">
        ${_config.maintenanceMode?'⚠️ চালু / বন্ধ করুন':'✓ সংরক্ষণ'}</button>
      <div id="maint-msg" style="font-size:11px;margin-top:6px"></div>
    </div>
  </div>

</div>`;

  root.querySelector('#cfg-save-payment').addEventListener('click',    ()=> _savePayment(root));
  root.querySelector('#cfg-save-plans').addEventListener('click',      ()=> _savePlans(root));
  root.querySelector('#cfg-save-auto-approve').addEventListener('click',()=> _saveAutoApprove(root));
  root.querySelector('#cfg-save-app').addEventListener('click',        ()=> _saveApp(root));
  root.querySelector('#cfg-save-maint').addEventListener('click',      ()=> _saveMaint(root));
  root.querySelector('#cfg-auto-approve').addEventListener('change', e=>{
    const lbl=root.querySelector('#auto-approve-lbl');
    if(lbl){lbl.textContent=e.target.checked?'চালু':'বন্ধ';lbl.style.color=e.target.checked?'var(--g1)':'var(--ink3)';}
  });
  root.querySelector('#cfg-maintenance').addEventListener('change', e=>{
    const lbl=root.querySelector('#maint-toggle-lbl');
    if(lbl){lbl.textContent=e.target.checked?'চালু':'বন্ধ';lbl.style.color=e.target.checked?'var(--r1)':'var(--ink3)';}
  });
}

async function _savePayment(root) {
  ld('সংরক্ষণ হচ্ছে…');
  try {
    await setDoc(doc(db,'appConfig','main'), {
      bkashNumber: root.querySelector('#cfg-bkash-num')?.value.trim()||'',
      bkashType:   root.querySelector('#cfg-bkash-type')?.value||'Personal',
      nagadNumber: root.querySelector('#cfg-nagad-num')?.value.trim()||'',
      nagadType:   root.querySelector('#cfg-nagad-type')?.value||'Personal',
      rocketNumber:root.querySelector('#cfg-rocket-num')?.value.trim()||'',
      rocketType:  root.querySelector('#cfg-rocket-type')?.value||'Personal',
      updatedAt:   serverTimestamp(),
    }, {merge:true});
    const msg=root.querySelector('#payment-msg');
    if(msg){msg.textContent='✓ সংরক্ষণ হয়েছে';msg.style.color='var(--g1)';}
    toast('Payment settings সেভ হয়েছে','ok');
    await _load(root);
  } catch(err){toast('ব্যর্থ: '+err.message,'er');}
  finally{uld();}
}

async function _savePlans(root) {
  ld('সংরক্ষণ হচ্ছে…');
  try {
    await setDoc(doc(db,'appConfig','main'), {
      freeMemberLimit:  parseInt(root.querySelector('#cfg-free-limit')?.value)||10,
      pro10MemberLimit: parseInt(root.querySelector('#cfg-pro10-limit')?.value)||10,
      pro10Price:       parseInt(root.querySelector('#cfg-pro10-price')?.value)||199,
      pro15MemberLimit: parseInt(root.querySelector('#cfg-pro15-limit')?.value)||15,
      pro15Price:       parseInt(root.querySelector('#cfg-pro15-price')?.value)||299,
      pro20BaseLimit:      parseInt(root.querySelector('#cfg-pro20-base-limit')?.value)||20,
      pro20BasePrice:      parseInt(root.querySelector('#cfg-pro20-base-price')?.value)||499,
      pro20PerExtraMember: parseInt(root.querySelector('#cfg-pro20-per-extra')?.value)||15,
      updatedAt:        serverTimestamp(),
    }, {merge:true});
    const msg=root.querySelector('#plan-msg');
    if(msg){msg.textContent='✓ সংরক্ষণ হয়েছে';msg.style.color='var(--g1)';}
    toast('Plan settings সেভ হয়েছে','ok');
    await _load(root);
  } catch(err){toast('ব্যর্থ: '+err.message,'er');}
  finally{uld();}
}

async function _saveAutoApprove(root) {
  const enabled=root.querySelector('#cfg-auto-approve')?.checked||false;
  ld('সংরক্ষণ হচ্ছে…');
  try {
    await setDoc(doc(db,'appConfig','main'), {autoApproveMess:enabled, updatedAt:serverTimestamp()}, {merge:true});
    const msg=root.querySelector('#auto-approve-msg');
    if(msg){msg.textContent='✓ সংরক্ষণ হয়েছে';msg.style.color='var(--g1)';}
    toast(enabled?'✅ Auto-Approve চালু':'Auto-Approve বন্ধ','ok');
    await _load(root);
  } catch(err){toast('ব্যর্থ: '+err.message,'er');}
  finally{uld();}
}

async function _saveApp(root) {
  ld('সংরক্ষণ হচ্ছে…');
  try {
    await setDoc(doc(db,'appConfig','main'), {
      appVersion:   root.querySelector('#cfg-version')?.value.trim()||'3.2.0',
      contactEmail: root.querySelector('#cfg-contact-email')?.value.trim()||'',
      updatedAt:    serverTimestamp(),
    }, {merge:true});
    const msg=root.querySelector('#app-msg');
    if(msg){msg.textContent='✓ সংরক্ষণ হয়েছে';msg.style.color='var(--g1)';}
    toast('App config সেভ হয়েছে','ok');
    await _load(root);
  } catch(err){toast('ব্যর্থ: '+err.message,'er');}
  finally{uld();}
}

async function _saveMaint(root) {
  const enabled=root.querySelector('#cfg-maintenance')?.checked||false;
  const msg=root.querySelector('#cfg-maint-msg')?.value.trim();
  if(enabled&&!window.confirm('Maintenance mode চালু করলে সব user এর screen এ বার্তা দেখাবে। নিশ্চিত?')) return;
  ld('সংরক্ষণ হচ্ছে…');
  try {
    await setDoc(doc(db,'appConfig','main'), {
      maintenanceMode:enabled,
      maintenanceMsg: msg||'সাইটটি সাময়িকভাবে বন্ধ আছে। অনুগ্রহ করে পরে আসুন।',
      updatedAt:      serverTimestamp(),
    }, {merge:true});
    const msgEl=root.querySelector('#maint-msg');
    if(msgEl){msgEl.textContent='✓ সংরক্ষণ হয়েছে';msgEl.style.color='var(--g1)';}
    toast(enabled?'⚠️ Maintenance চালু':'✓ Maintenance বন্ধ', enabled?'er':'ok');
    await _load(root);
  } catch(err){toast('ব্যর্থ: '+err.message,'er');}
  finally{uld();}
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

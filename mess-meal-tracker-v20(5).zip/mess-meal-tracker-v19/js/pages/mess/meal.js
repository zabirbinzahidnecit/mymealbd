// meal.js — v12: multi-day modal now supports per-day independent slot selection

import { db } from '../../firebase.js';
import { toast, ld, uld, pad, dim, moName, taka, takaF, getDocsByIds, monthDocIdRange } from '../../utils.js';
import { getCachedMembers } from '../../members-cache.js';
import {
  collection, getDocs, doc, getDoc, setDoc, query, orderBy, where, documentId
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _ctx={}, _vy=TODAY.getFullYear(), _vm=TODAY.getMonth(), _members=[];

// ✅ Central rule: কে কোন দিনের মিল edit করতে পারবে
// - Admin/Co-admin: যেকোনো দিন, যেকোনো সময়
// - সাধারণ member: শুধু আজকের দিন, এবং cutoff সময়ের আগে
//   (গতদিনের বা cutoff পার হওয়া আজকের মিল member edit করতে পারবে না)
function _canEditDate(dateObj) {
  const isPrivileged = ['mess-admin','mess-co-admin'].includes(_ctx.myMessRole);
  if (isPrivileged) return true;

  const cutoff  = _ctx.messSettings?.cutoffHour ?? 10;
  const today0  = new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate());
  const target0 = new Date(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate());

  if (target0 < today0) return false;             // অতীতের দিন — সবসময় lock
  if (target0 > today0) return true;               // ভবিষ্যতের দিন — খোলা
  return TODAY.getHours() < cutoff;                 // আজকের দিন — cutoff এর আগে পর্যন্ত খোলা
}

export async function render(root, ctx) {
  _ctx = ctx;
  const slots  = ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const cutoff = ctx.messSettings?.cutoffHour ?? 10;
  const now    = TODAY.getHours();
  const isPast = now >= cutoff;

  const ENTRY_DATE = isPast
    ? new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate()+1)
    : TODAY;

  const SICO = ['☀️','🌤','🌙','🍳','🍱','🌮'];

  root.innerHTML = `
<div>
  <!-- Month nav for table -->
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <button class="btn btn-ghost btn-sm" id="mp">◀</button>
    <span style="font-size:14px;font-weight:700;min-width:130px;text-align:center" id="m-lbl"></span>
    <button class="btn btn-ghost btn-sm" id="mn">▶</button>
    <button class="btn btn-ghost btn-sm" id="mt">আজ</button>
  </div>

  <!-- Meal rate info card -->
  <div class="card" style="margin-bottom:14px">
    <div class="cb" style="padding:10px 14px">
      <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center">
        <div style="flex:1;min-width:130px">
          <p style="font-size:10px;font-weight:700;color:var(--ink3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">এই মাসের মিল রেট</p>
          <p style="font-size:22px;font-weight:700;font-family:var(--mono);color:var(--g1)" id="m-rate">—</p>
          <p style="font-size:11px;color:var(--ink3)" id="m-rate-sub">লোড হচ্ছে…</p>
        </div>
        <div style="display:flex;gap:12px;flex-wrap:wrap">
          <div style="text-align:center">
            <p style="font-size:10px;color:var(--ink3);font-weight:700">মোট মিল</p>
            <p style="font-size:18px;font-weight:700;font-family:var(--mono);color:var(--ink)" id="m-total-meals">—</p>
          </div>
          <div style="text-align:center">
            <p style="font-size:10px;color:var(--ink3);font-weight:700">মোট বাজার</p>
            <p style="font-size:18px;font-weight:700;font-family:var(--mono);color:var(--ink)" id="m-total-bazar">—</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- মিল দিন — এখন সরাসরি পেজেই, আলাদা popup লাগবে না -->
  <div class="card" style="margin-bottom:14px" id="md-mo">
    <div class="ch"><h3>🍽 মিল দিন</h3></div>
    <div class="cb" style="padding:14px">
      <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:14px;
        padding-bottom:14px;border-bottom:1px solid var(--line)">
        <label style="font-size:11px;font-weight:700;color:var(--ink3)">Guest মিল (আজ):</label>
        <input class="inp inp-sm" id="m-guest" type="number" min="0" max="20"
          placeholder="0" style="width:80px"/>
        <button class="btn btn-ghost btn-sm" id="m-guest-save">সেভ</button>
        ${ctx.myMessRole !== 'member' ? `
        <div style="margin-left:auto;display:flex;align-items:center;gap:6px">
          <label class="lbl" style="margin:0">অন্য সদস্যের মিল দিন</label>
          <select class="inp inp-sm" id="m-sel" style="max-width:180px"></select>
        </div>` : ''}
      </div>
      <div id="md-content"></div>
      <div id="md-slot-area" style="margin-top:10px"></div>
      <div style="display:flex;gap:8px;margin-top:14px">
        <button class="btn btn-p" id="md-apply">✓ প্রয়োগ</button>
      </div>
    </div>
  </div>
  <!-- Slot summary for cook -->
  <div class="card" style="margin-bottom:14px">
    <div class="ch">
      <h3>📋 আজকের মিল তালিকা — বুয়ার জন্য</h3>
      <span style="font-size:11px;color:var(--ink3)">${TODAY.getDate()} ${moName(TODAY.getMonth())}</span>
    </div>
    <div class="cb" id="m-slot-summary">লোড হচ্ছে…</div>
  </div>

  <!-- Day detail table -->
  <div class="card">
    <div class="ch">
      <h3>📅 দিনের বিস্তারিত</h3>
      <input type="date" id="m-date" class="inp inp-sm" style="width:auto"/>
    </div>
    <div class="cb" style="overflow-x:auto" id="m-table">লোড হচ্ছে…</div>
  </div>
</div>`;

  root.querySelector('#mp')?.addEventListener('click', ()=>{ _vm--; if(_vm<0){_vm=11;_vy--} _load(root); });
  root.querySelector('#mn')?.addEventListener('click', ()=>{ _vm++; if(_vm>11){_vm=0;_vy++} _load(root); });
  root.querySelector('#mt')?.addEventListener('click', ()=>{ _vy=TODAY.getFullYear();_vm=TODAY.getMonth(); _load(root); });
  root.querySelector('#m-guest-save')?.addEventListener('click', ()=> _saveGuest(root, ENTRY_DATE));
  root.querySelector('#md-apply')?.addEventListener('click', ()=> _applyMulti(root));
  root.querySelector('#m-sel')?.addEventListener('change', ()=>{ _openMulti(root); _loadGuestCount(root, ENTRY_DATE); });

  const dp = root.querySelector('#m-date');
  if (dp) dp.value = `${TODAY.getFullYear()}-${pad(TODAY.getMonth()+1)}-${pad(TODAY.getDate())}`;
  root.querySelector('#m-date')?.addEventListener('change', e=> _loadTable(root, e.target.value));

  root.querySelector('#m-lbl').textContent = `${moName(_vm)} ${_vy}`;
  await _load(root);
}

async function _load(root) {
  root.querySelector('#m-lbl').textContent = `${moName(_vm)} ${_vy}`;
  ld('সদস্য লোড হচ্ছে…');
  try {
    _members = await getCachedMembers(_ctx.messId);

    const sel = root.querySelector('#m-sel');
    if (sel) {
      sel.innerHTML = _members.map(m=>
        `<option value="${m.uid}">${_e(m.name||m.email)}${m.uid===_ctx.profile.uid?' (আমি)':''}</option>`
      ).join('');
      sel.value = _ctx.profile.uid;
    }

    const cutoff    = _ctx.messSettings?.cutoffHour ?? 10;
    const isPast    = TODAY.getHours() >= cutoff;
    const ENTRY_DATE = isPast
      ? new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate()+1)
      : TODAY;

    await _openMulti(root);
    await _loadGuestCount(root, ENTRY_DATE);

    const dp = root.querySelector('#m-date');
    if (dp) await _loadTable(root, dp.value);
    await _loadSlotSummary(root);
    await _loadMealRate(root);
  } finally { uld(); }
}

// ── Meal rate এই মাসের ──────────────────────────────────
async function _loadMealRate(root) {
  try {
    const monthStr = `${_vy}-${pad(_vm+1)}`;

    // ✅ শুধু এই মাসের meal doc — পুরো collection স্ক্যান না করে range query
    const { start, end } = monthDocIdRange(_vy, _vm);
    const mealSnap = await getDocs(query(
      collection(db,'messes',_ctx.messId,'meals'),
      where(documentId(), '>=', start),
      where(documentId(), '<', end)
    ));
    let totalMeals = 0;
    mealSnap.forEach(d=>{
      totalMeals += (d.data().slots||[]).filter(Boolean).length;
      totalMeals += (d.data().guestSlots||[]).filter(Boolean).length;
    });

    // Total approved bazar
    const expSnap = await getDocs(query(
      collection(db,'messes',_ctx.messId,'expenses'), where('status','==','approved')
    ));
    let totalBazar = 0;
    expSnap.forEach(d=>{ if(d.data().date?.startsWith(monthStr)) totalBazar+=parseFloat(d.data().amount)||0; });

    const rate = totalMeals>0 ? totalBazar/totalMeals : 0;

    const rateEl = root.querySelector('#m-rate');
    const subEl  = root.querySelector('#m-rate-sub');
    const mealEl = root.querySelector('#m-total-meals');
    const bazEl  = root.querySelector('#m-total-bazar');

    if (rateEl) rateEl.textContent = totalMeals>0 ? takaF(rate) : '—';
    if (subEl)  subEl.textContent  = `প্রতি মিল · ${moName(_vm)} ${_vy}`;
    if (mealEl) mealEl.textContent = totalMeals || '০';
    if (bazEl)  bazEl.textContent  = taka(totalBazar);
  } catch(e) { console.warn('Rate load error:', e); }
}

async function _loadSlotSummary(root) {
  const el = root.querySelector('#m-slot-summary');
  if (!el) return;
  const slots = _ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const SICO  = ['☀️','🌤','🌙','🍳','🍱','🌮'];
  const slotCounts = new Array(slots.length).fill(0);
  let guestTotal = 0;

  // ✅ একটাই batched query — আগে ছিল প্রতি member-এর জন্য আলাদা getDoc (N+1)
  const keys = _members.map(m=>`${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}_${pad(TODAY.getDate())}_${m.uid}`);
  const dataMap = await getDocsByIds(collection(db,'messes',_ctx.messId,'meals'), keys);
  keys.forEach(k=>{
    const data = dataMap[k];
    if (!data) return;
    (data.slots||[]).forEach((on,i)=>{ if(on) slotCounts[i]++; });
    guestTotal += (data.guestSlots||[]).filter(Boolean).length;
  });

  const grandTotal = slotCounts.reduce((a,b)=>a+b,0) + guestTotal;

  el.innerHTML = `
<div style="margin-bottom:12px">
  <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px">
    ${slots.map((s,i)=>`
    <div style="background:${slotCounts[i]>0?'var(--g7)':'var(--paper)'};
      border:1px solid ${slotCounts[i]>0?'var(--g5)':'var(--line)'};
      border-radius:12px;padding:10px 16px;text-align:center;min-width:90px">
      <div style="font-size:20px;margin-bottom:4px">${SICO[i]||'🍽'}</div>
      <div style="font-size:12px;font-weight:600;color:var(--ink)">${_e(s)}</div>
      <div style="font-size:24px;font-weight:700;color:${slotCounts[i]>0?'var(--g1)':'var(--ink4)'}">
        ${slotCounts[i]}
      </div>
      <div style="font-size:10px;color:var(--ink4)">জন</div>
    </div>`).join('')}
    ${guestTotal>0?`
    <div style="background:var(--b4);border:1px solid var(--b3);
      border-radius:12px;padding:10px 16px;text-align:center;min-width:90px">
      <div style="font-size:20px;margin-bottom:4px">👥</div>
      <div style="font-size:12px;font-weight:600;color:var(--ink)">Guest</div>
      <div style="font-size:24px;font-weight:700;color:var(--b0)">${guestTotal}</div>
      <div style="font-size:10px;color:var(--ink4)">জন</div>
    </div>`:''}
  </div>
  <div style="background:var(--g2);color:#fff;border-radius:10px;
    padding:10px 16px;display:flex;justify-content:space-between;align-items:center">
    <span style="font-size:13px;font-weight:600">মোট মিল আজ</span>
    <span style="font-size:22px;font-weight:700;font-family:var(--mono)">${grandTotal}</span>
  </div>
</div>
<p style="font-size:11px;color:var(--ink4)">⚠️ এই তালিকা বুয়াকে দেখান — কোন বেলায় কতজনের রান্না করতে হবে</p>`;
}

async function _loadGuestCount(root, entryDate) {
  const uid = root.querySelector('#m-sel')?.value || _ctx.profile.uid;
  const d   = entryDate || TODAY;
  const key = `${d.getFullYear()}_${pad(d.getMonth()+1)}_${pad(d.getDate())}_${uid}`;
  try {
    const snap = await getDoc(doc(db,'messes',_ctx.messId,'meals',key));
    const gi = root.querySelector('#m-guest');
    if (gi) gi.value = snap.exists()?((snap.data().guestSlots||[]).filter(Boolean).length||''):'';
  } catch {}
}

async function _saveGuest(root, entryDate) {
  const n   = parseInt(root.querySelector('#m-guest')?.value)||0;
  const uid = root.querySelector('#m-sel')?.value || _ctx.profile.uid;
  const d   = entryDate || TODAY;
  const key = `${d.getFullYear()}_${pad(d.getMonth()+1)}_${pad(d.getDate())}_${uid}`;
  await setDoc(doc(db,'messes',_ctx.messId,'meals',key),
    { guestSlots: Array(n).fill(true), memberId: uid }, { merge: true });
  toast('Guest মিল সেভ হয়েছে','ok');
  await _loadSlotSummary(root);
}

async function _loadTable(root, dateStr) {
  const wrap = root.querySelector('#m-table');
  if (!wrap||!_members.length) return;
  const [y,m,d] = dateStr.split('-').map(Number);
  const slots = _ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const SICO  = ['☀️','🌤','🌙','🍳','🍱'];
  const dateObj = new Date(y, m-1, d);
  const editable = _canEditDate(dateObj);

  // ✅ batched query — আগে ছিল প্রতি member-এর জন্য আলাদা getDoc (N+1)
  const keyOf = mb => `${y}_${pad(m)}_${pad(d)}_${mb.uid}`;
  const dataMap = await getDocsByIds(collection(db,'messes',_ctx.messId,'meals'), _members.map(keyOf));
  const mealMap={};
  _members.forEach(mb=>{ mealMap[mb.uid] = dataMap[keyOf(mb)] || {}; });

  wrap.innerHTML = `
  ${!editable ? `
  <div style="background:var(--paper);border:1px solid var(--line2);border-radius:8px;
    padding:8px 12px;margin-bottom:10px;font-size:11px;color:var(--ink3);display:flex;align-items:center;gap:6px">
    🔒 এই দিনের তথ্য শুধু দেখার জন্য — পরিবর্তন করতে পারবেন শুধু Mess Admin/Co-Admin
  </div>` : ''}
  <table class="dt">
<thead><tr>
  <th class="tl">সদস্য</th>
  ${slots.map((s,i)=>`<th>${SICO[i]||''} ${_e(s)}</th>`).join('')}
  <th>Guest</th><th>মোট</th>
</tr></thead><tbody>
${_members.map(mb=>{
  const md=mealMap[mb.uid]||{};
  const s=md.slots||[];
  const g=(md.guestSlots||[]).filter(Boolean).length;
  const t=s.filter(Boolean).length+g;
  return `<tr>
  <td class="tl" style="font-weight:600">${_e(mb.name||mb.email)}</td>
  ${slots.map((_,i)=>`<td><div class="mdot ${s[i]?'don':'doff'}">${s[i]?'✓':''}</div></td>`).join('')}
  <td>${g||'—'}</td>
  <td style="font-weight:700">${t||'—'}</td>
</tr>`;
}).join('')}
</tbody></table>`;
}

// ── Meal entry — per-day independent slot selection ────
// প্রতিটা দিনে ক্লিক করলে শুধু সেই দিনের জন্য বেলা বাছাই করা যাবে।
// একাধিক দিন সিলেক্ট করা যাবে, কিন্তু প্রতিটার নিজস্ব বেলা আলাদাভাবে সেভ থাকবে।
let _msOriginal = {};   // day -> [bool...]  (server-এ যা আছে)
let _msState    = {};   // day -> [bool...]  (এই সেশনে user যা বানাচ্ছে, শুধু touched দিনের জন্য)
let _msTouched  = new Set();
let _msActiveDay = null;

// ── Bulk mode — একসাথে একাধিক দিন সিলেক্ট করে একই বেলা apply করা ──
let _msMode         = 'bulk';        // 'bulk' | 'individual'
let _msSelectedDays = new Set();     // bulk mode: যেসব দিন চেকবক্সের মতো সিলেক্ট করা
let _msBulkSlots    = [];            // bulk mode: সিলেক্ট করা দিনগুলোতে যে বেলা apply হবে

async function _openMulti(root) {
  const slots     = _ctx.messSettings?.slots||['সকাল','দুপুর','রাত'];
  const days      = dim(_vy,_vm);
  const todayD    = TODAY.getDate();
  const isThisMonth = _vy===TODAY.getFullYear() && _vm===TODAY.getMonth();
  const uid       = root.querySelector('#m-sel')?.value || _ctx.profile.uid;

  root.querySelector('#md-content').innerHTML = `
    <div style="padding:30px;text-align:center;color:var(--ink3)">
      <div style="font-size:24px;margin-bottom:8px">⏳</div>
      মিলের তথ্য লোড হচ্ছে…
    </div>`;
  root.querySelector('#md-slot-area').innerHTML = '';

  // Reset session state every time the modal (re)opens
  _msOriginal = {};
  _msState    = {};
  _msTouched  = new Set();
  _msActiveDay = null;
  _msSelectedDays = new Set();
  _msBulkSlots    = new Array(slots.length).fill(false);

  // ✅ batched query — আগে ছিল মাসের প্রতিটা দিনের জন্য আলাদা getDoc (N+1)
  const dayList = Array.from({length:days},(_,i)=>i+1);
  const keyOf = d => `${_vy}_${pad(_vm+1)}_${pad(d)}_${uid}`;
  const dayDataMap = await getDocsByIds(collection(db,'messes',_ctx.messId,'meals'), dayList.map(keyOf));
  dayList.forEach(d=>{ _msOriginal[d] = (dayDataMap[keyOf(d)]?.slots) || []; });

  const isPrivileged = ['mess-admin','mess-co-admin'].includes(_ctx.myMessRole);

  function _curArr(d) {
    return _msTouched.has(d) ? _msState[d] : (_msOriginal[d]||[]);
  }

  function _dayColor(d) {
    const s = _curArr(d);
    const total = s.filter(Boolean).length;
    const max   = _ctx.messSettings?.maxMealsPerDay ?? slots.length;
    const dateObj = new Date(_vy, _vm, d);
    const editable = isPrivileged || _canEditDate(dateObj);
    const touched = _msTouched.has(d);

    if (!editable) {
      return { bg:'#e8e8e8', color:'#999', border:'#d0d0d0', label:total>0?`✓(${total})`:'🔒', locked:true };
    }
    if (_msMode === 'bulk') {
      if (_msSelectedDays.has(d)) {
        return { bg:'#0b3d91', color:'#fff', border:'#0b3d91', label: total>0?`✓(${total})`:'বাছাই' };
      }
    } else if (d === _msActiveDay) {
      return { bg:'#0b3d91', color:'#fff', border:'#0b3d91', label: total>0?`বাছাই(${total})`:'বাছাই' };
    }
    const base = (d === todayD && isThisMonth)
      ? { onBg:'#1a8a50', onBorder:'#1a8a50' }
      : { onBg:'#146b40', onBorder:'#146b40' };

    if (total === 0) {
      return { bg: touched?'#fee2e2':'#f1f5f2', color: touched?'#cc0000':'#243a2c',
        border: touched?'#fca5a5':'#b0ceb8', label: touched?'বাদ':(d===todayD&&isThisMonth?'আজ':'') };
    }
    if (total < max) return { bg:'#e8a838', color:'#fff', border: touched?'#0b3d91':'#d4922a', label:`আংশিক(${total})` };
    return { bg: base.onBg, color:'#fff', border: touched?'#0b3d91':base.onBorder, label: total>1?`✓(${total})`:'✓' };
  }

  function _renderGrid() {
    root.querySelector('#md-days-grid').innerHTML = Array.from({length:days},(_,i)=>i+1).map(d=>{
      const c = _dayColor(d);
      return `<button
        class="md-day"
        data-day="${d}"
        data-locked="${c.locked?'1':'0'}"
        ${c.locked?'disabled':''}
        style="height:40px;background:${c.bg};color:${c.color};
          border:2px solid ${c.border};border-radius:8px;font-size:12px;
          font-weight:700;cursor:${c.locked?'not-allowed':'pointer'};display:flex;flex-direction:column;
          align-items:center;justify-content:center;gap:1px;transition:.1s;
          opacity:${c.locked?'.7':'1'}">
        <span>${d}</span>
        ${c.label ? `<span style="font-size:8px;opacity:.9">${c.label}</span>` : ''}
      </button>`;
    }).join('');
  }

  function _renderDayEditor() {
    if (_msMode === 'bulk') _renderBulkEditor();
    else _renderIndividualEditor();
  }

  function _renderIndividualEditor() {
    const area = root.querySelector('#md-slot-area');
    if (_msActiveDay == null) {
      area.innerHTML = `
      <div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--line);
        text-align:center;color:var(--ink3);font-size:12px;padding-bottom:6px">
        উপরে থেকে একটা দিনে ক্লিক করুন — তারপর সেই দিনের বেলা বাছাই করতে পারবেন
      </div>`;
      return;
    }
    const d   = _msActiveDay;
    const arr = _curArr(d).slice();
    const max = _ctx.messSettings?.maxMealsPerDay ?? slots.length;

    area.innerHTML = `
<div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--line)">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
    <label class="lbl" style="margin:0">${d} ${moName(_vm)} — কোন বেলার মিল?</label>
    <button class="btn btn-ghost btn-xs" id="md-day-clear">সব বাদ</button>
  </div>
  <div style="display:flex;flex-wrap:wrap;gap:8px" id="md-slots-row">
    ${slots.map((s,i)=>`
    <button class="slt md-slot${arr[i]?' on':''}" data-idx="${i}">
      ${_e(s)}
    </button>`).join('')}
  </div>
  <p style="font-size:10px;color:var(--ink3);margin-top:6px">
    এই বাছাই শুধু <strong>${d} ${moName(_vm)}</strong> তারিখেই প্রযোজ্য হবে। অন্য দিনে ক্লিক করে সেই দিনের জন্য আলাদাভাবে বাছাই করুন।
  </p>
</div>`;

    root.querySelector('#md-slots-row')?.addEventListener('click', e=>{
      const btn = e.target.closest('.md-slot');
      if (!btn) return;
      const i = parseInt(btn.dataset.idx);
      if (!_msTouched.has(d)) { _msState[d] = (_msOriginal[d]||[]).slice(); _msTouched.add(d); }
      const cur = _msState[d];
      const willTurnOn = !cur[i];
      if (willTurnOn && cur.filter(Boolean).length >= max) {
        toast(`সর্বোচ্চ ${max}টি বেলা`,'er');
        return;
      }
      cur[i] = willTurnOn;
      btn.classList.toggle('on', willTurnOn);
      _renderGrid();
    });

    root.querySelector('#md-day-clear')?.addEventListener('click', ()=>{
      _msState[d] = new Array(slots.length).fill(false);
      _msTouched.add(d);
      _renderGrid();
      _renderDayEditor();
    });
  }

  function _renderBulkEditor() {
    const area = root.querySelector('#md-slot-area');
    const count = _msSelectedDays.size;
    const max = _ctx.messSettings?.maxMealsPerDay ?? slots.length;

    if (count === 0) {
      area.innerHTML = `
      <div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--line);
        text-align:center;color:var(--ink3);font-size:12px;padding-bottom:6px">
        উপরে থেকে একাধিক দিন ক্লিক করে সিলেক্ট করুন (checkbox এর মতো) — তারপর নিচে বেলা বাছাই করলে সব সিলেক্ট করা দিনে একসাথে apply হবে
      </div>`;
      return;
    }

    const daysList = [..._msSelectedDays].sort((a,b)=>a-b).join(', ');

    area.innerHTML = `
<div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--line)">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;gap:8px">
    <label class="lbl" style="margin:0">${count}টি দিন সিলেক্ট করা হয়েছে — কোন বেলার মিল?</label>
    <div style="display:flex;gap:6px">
      <button class="btn btn-ghost btn-xs" id="md-bulk-clear-slots">সব বাদ</button>
      <button class="btn btn-ghost btn-xs" id="md-bulk-clear-sel">সিলেকশন খালি</button>
    </div>
  </div>
  <p style="font-size:10px;color:var(--ink3);margin-bottom:8px">সিলেক্ট করা দিন: ${daysList}</p>
  <div style="display:flex;flex-wrap:wrap;gap:8px" id="md-bulk-slots-row">
    ${slots.map((s,i)=>`
    <button class="slt md-slot${_msBulkSlots[i]?' on':''}" data-idx="${i}">
      ${_e(s)}
    </button>`).join('')}
  </div>
  <p style="font-size:10px;color:var(--ink3);margin-top:6px">
    এই বেলা বাছাই <strong>সবগুলো সিলেক্ট করা দিনেই</strong> একইভাবে প্রযোজ্য হবে। আলাদা আলাদা বেলা দিতে চাইলে উপরে "আলাদা আলাদা" মোডে যান।
  </p>
</div>`;

    root.querySelector('#md-bulk-slots-row')?.addEventListener('click', e=>{
      const btn = e.target.closest('.md-slot');
      if (!btn) return;
      const i = parseInt(btn.dataset.idx);
      const willTurnOn = !_msBulkSlots[i];
      const newBulk = _msBulkSlots.slice();
      newBulk[i] = willTurnOn;
      if (willTurnOn && newBulk.filter(Boolean).length > max) {
        toast(`সর্বোচ্চ ${max}টি বেলা`,'er');
        return;
      }
      _msBulkSlots = newBulk;
      _msSelectedDays.forEach(d=>{
        _msState[d] = _msBulkSlots.slice();
        _msTouched.add(d);
      });
      btn.classList.toggle('on', willTurnOn);
      _renderGrid();
    });

    root.querySelector('#md-bulk-clear-slots')?.addEventListener('click', ()=>{
      _msBulkSlots = new Array(slots.length).fill(false);
      _msSelectedDays.forEach(d=>{
        _msState[d] = new Array(slots.length).fill(false);
        _msTouched.add(d);
      });
      _renderGrid();
      _renderDayEditor();
    });

    root.querySelector('#md-bulk-clear-sel')?.addEventListener('click', ()=>{
      _msSelectedDays.clear();
      _renderGrid();
      _renderDayEditor();
    });
  }

  root.querySelector('#md-content').innerHTML = `
<div style="display:flex;gap:6px;background:var(--paper);padding:4px;border-radius:10px;margin-bottom:10px">
  <button class="btn btn-sm" id="md-mode-bulk" style="flex:1"></button>
  <button class="btn btn-sm" id="md-mode-ind" style="flex:1"></button>
</div>
<div style="margin-bottom:8px">
  <label class="lbl" id="md-instruction"></label>
  <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px;margin-top:8px" id="md-days-grid"></div>
  <div style="margin-top:8px;display:flex;gap:10px;flex-wrap:wrap">
    <span style="font-size:10px;color:var(--ink3)">🟢 সব বেলা আছে</span>
    <span style="font-size:10px;color:var(--ink3)">🟡 আংশিক</span>
    <span style="font-size:10px;color:var(--ink3)">⬜ মিল নেই</span>
    <span style="font-size:10px;color:#cc0000">🔴 বাদ দেওয়া হবে</span>
    <span style="font-size:10px;color:#0b3d91">🔵 সিলেক্ট করা / এডিট হচ্ছে</span>
  </div>
</div>`;

  function _renderModeToggle() {
    const bBtn = root.querySelector('#md-mode-bulk');
    const iBtn = root.querySelector('#md-mode-ind');
    const instr = root.querySelector('#md-instruction');
    if (bBtn) {
      bBtn.textContent = '🔗 একসাথে (একই বেলা)';
      bBtn.className = _msMode==='bulk' ? 'btn btn-p btn-sm' : 'btn btn-ghost btn-sm';
    }
    if (iBtn) {
      iBtn.textContent = '🔀 আলাদা আলাদা';
      iBtn.className = _msMode==='individual' ? 'btn btn-p btn-sm' : 'btn btn-ghost btn-sm';
    }
    if (instr) {
      instr.textContent = _msMode==='bulk'
        ? 'একাধিক দিন ক্লিক করে সিলেক্ট করুন — তারপর নিচে বেলা বাছাই করলে সবগুলোতে একসাথে apply হবে'
        : 'একটা দিনে ক্লিক করলে সেই দিনের বেলা বাছাই করার অপশন নিচে আসবে';
    }
  }

  _renderModeToggle();
  _renderGrid();

  root.querySelector('#md-mode-bulk')?.addEventListener('click', ()=>{
    if (_msMode === 'bulk') return;
    _msMode = 'bulk';
    _msActiveDay = null;
    _renderModeToggle();
    _renderGrid();
    _renderDayEditor();
  });
  root.querySelector('#md-mode-ind')?.addEventListener('click', ()=>{
    if (_msMode === 'individual') return;
    _msMode = 'individual';
    _msSelectedDays.clear();
    _renderModeToggle();
    _renderGrid();
    _renderDayEditor();
  });

  root.querySelector('#md-days-grid')?.addEventListener('click', e=>{
    const btn = e.target.closest('.md-day');
    if (!btn || btn.dataset.locked === '1') {
      if (btn?.dataset.locked === '1') {
        toast('🔒 এই দিনের মিল পরিবর্তন করা যাবে না — শুধু Admin পারবেন', 'er');
      }
      return;
    }
    const d = parseInt(btn.dataset.day);
    if (_msMode === 'bulk') {
      if (_msSelectedDays.has(d)) _msSelectedDays.delete(d);
      else _msSelectedDays.add(d);
    } else {
      _msActiveDay = (_msActiveDay === d) ? null : d;   // আবার ক্লিক করলে বন্ধ হবে
    }
    _renderGrid();
    _renderDayEditor();
  });

  _renderDayEditor();
}

async function _applyMulti(root) {
  const uid = root.querySelector('#m-sel')?.value || _ctx.profile.uid;
  const isPrivileged = ['mess-admin','mess-co-admin'].includes(_ctx.myMessRole);
  const slotCount = _ctx.messSettings?.slots?.length || 3;

  // ✅ ফিক্স: bulk মোডে দিন সিলেক্ট করলেই (চেকবক্স), কোনো বেলা বাটনে ক্লিক
  // না করলেও, সেই দিনগুলোতে বর্তমান বাল্ক-প্যাটার্ন (ডিফল্ট: সব বেলা বন্ধ)
  // apply হবে। আগে শুধু বেলা বাটনে ক্লিক করলেই দিন "touched" হতো, তাই
  // "মিল বন্ধ করতে চাই" বোঝাতে দিন সিলেক্ট করে সরাসরি Apply করলে কিছুই
  // সেভ হতো না।
  if (_msMode === 'bulk') {
    _msSelectedDays.forEach(d => {
      _msState[d] = _msBulkSlots.slice();
      _msTouched.add(d);
    });
  }

  const touchedDays = [..._msTouched];
  const validDays = touchedDays.filter(d => isPrivileged || _canEditDate(new Date(_vy,_vm,d)));

  if (!validDays.length) { toast('কোনো পরিবর্তন নেই','er'); return; }

  ld(`${validDays.length}টি দিন আপডেট হচ্ছে…`);
  try {
    let addedCount = 0, clearedCount = 0;
    for (const d of validDays) {
      const arr = new Array(slotCount).fill(false);
      (_msState[d]||[]).forEach((v,i)=>{ if(i<slotCount) arr[i]=!!v; });
      const key = `${_vy}_${pad(_vm+1)}_${pad(d)}_${uid}`;
      await setDoc(doc(db,'messes',_ctx.messId,'meals',key),
        { slots: arr, memberId: uid }, { merge: true });
      if (arr.some(Boolean)) addedCount++; else clearedCount++;
    }

    const msg = [];
    if (addedCount)   msg.push(`${addedCount}টি দিনে মিল সেভ`);
    if (clearedCount) msg.push(`${clearedCount}টি দিন থেকে মিল বাদ`);
    toast(msg.join(', ') + ' ✓','ok');

    await _openMulti(root);
    await _loadSlotSummary(root);
    await _loadMealRate(root);
    const dp = root.querySelector('#m-date');
    if (dp) await _loadTable(root, dp.value);
  } finally { uld(); }
}

const _e = s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

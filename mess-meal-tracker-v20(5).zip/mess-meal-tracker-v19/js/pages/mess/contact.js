// contact.js — v18: Contact Us page (sends message to platform admin)

import { db } from '../../firebase.js';
import { toast, ld, uld, formatDate } from '../../utils.js';
import {
  collection, addDoc, getDocs, getDoc, doc,
  query, where, orderBy, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _ctx = {};

export async function render(root, ctx) {
  _ctx = ctx;

  root.innerHTML = `
<div style="max-width:560px;margin:0 auto">
  <div class="card" style="margin-bottom:14px">
    <div class="ch"><h3>📩 Contact Us</h3></div>
    <div class="cb">
      <p style="font-size:12px;color:var(--ink3);margin-bottom:14px;line-height:1.6">
        কোনো সমস্যা, পরামর্শ বা প্রশ্ন থাকলে নিচে লিখে পাঠান।
        Platform Admin আপনার মেসেজ দেখতে পাবেন এবং প্রয়োজনে যোগাযোগ করবেন।
      </p>
      <div class="field">
        <label class="lbl">বিষয় (ঐচ্ছিক)</label>
        <input class="inp inp-sm" id="ct-subject" maxlength="100" placeholder="যেমন: পেমেন্ট সমস্যা"/>
      </div>
      <div class="field">
        <label class="lbl">মেসেজ *</label>
        <textarea class="inp" id="ct-msg" rows="5" maxlength="1000"
          style="resize:vertical;min-height:110px"
          placeholder="আপনার সমস্যা বা মন্তব্য বিস্তারিত লিখুন…"></textarea>
        <span id="ct-char" style="font-size:11px;color:var(--ink4)">0/1000</span>
      </div>
      <button class="btn btn-p btn-sm" id="ct-send-btn" style="width:100%">📤 মেসেজ পাঠান</button>
      <div id="ct-result" style="margin-top:10px"></div>
    </div>
  </div>

  <div class="card" id="ct-contact-info-card" style="margin-bottom:14px;display:none">
    <div class="cb" style="text-align:center;padding:14px">
      <p style="font-size:11px;color:var(--ink3);margin-bottom:4px">📧 সরাসরি যোগাযোগ করতে পারেন</p>
      <p style="font-size:14px;font-weight:700;color:var(--g1)" id="ct-admin-email">—</p>
    </div>
  </div>

  <div class="card">
    <div class="ch"><h3>📨 আমার পূর্ববর্তী মেসেজ</h3></div>
    <div id="ct-history">লোড হচ্ছে…</div>
  </div>
</div>`;

  root.querySelector('#ct-msg').addEventListener('input', e=>{
    const counter = root.querySelector('#ct-char');
    if (counter) counter.textContent = `${e.target.value.length}/1000`;
  });
  root.querySelector('#ct-send-btn').addEventListener('click', ()=> _send(root));

  await _loadAdminEmail(root);
  await _loadHistory(root);
}

async function _loadAdminEmail(root) {
  try {
    const snap = await getDoc(doc(db,'appConfig','main'));
    const email = snap.exists() ? snap.data().contactEmail : null;
    if (email) {
      const card = root.querySelector('#ct-contact-info-card');
      const el   = root.querySelector('#ct-admin-email');
      if (card) card.style.display = '';
      if (el)   el.textContent = email;
    }
  } catch(e) { console.warn('Contact email load failed:', e); }
}

async function _loadHistory(root) {
  const el = root.querySelector('#ct-history');
  if (!el) return;
  try {
    // ✅ শুধু where() — orderBy বাদ দেওয়া হয়েছে যাতে composite index লাগে না।
    // Sort client-side এ করা হচ্ছে।
    const snap = await getDocs(query(
      collection(db,'contactMessages'),
      where('userId','==',_ctx.profile.uid)
    ));
    if (snap.empty) {
      el.innerHTML = '<div style="padding:20px;text-align:center;color:var(--ink3)">কোনো মেসেজ পাঠানো হয়নি</div>';
      return;
    }
    const sortedDocs = [...snap.docs].sort((a,b) => {
      const ta = a.data().createdAt?.seconds || 0;
      const tb = b.data().createdAt?.seconds || 0;
      return tb - ta; // descending
    });
    el.innerHTML = sortedDocs.map(d=>{
      const m = d.data();
      const statusBadge = m.status==='replied'
        ? '<span class="badge b-green">✓ উত্তর দেওয়া হয়েছে</span>'
        : m.status==='read'
          ? '<span class="badge b-amber">👁 দেখা হয়েছে</span>'
          : '<span class="badge b-member">⏳ অপেক্ষমান</span>';
      return `
<div style="padding:12px 14px;border-bottom:.5px solid var(--line)">
  <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:5px">
    <strong style="font-size:13px">${_e(m.subject||'(বিষয় নেই)')}</strong>
    ${statusBadge}
  </div>
  <p style="font-size:12px;color:var(--ink);line-height:1.5;white-space:pre-wrap">${_e(m.message)}</p>
  <p style="font-size:10px;color:var(--ink4);margin-top:5px">${m.createdAt?formatDate(m.createdAt):''}</p>
  ${m.adminReply?`
  <div style="margin-top:8px;padding:8px 10px;background:var(--g8);border-radius:8px;border-left:3px solid var(--g3)">
    <p style="font-size:10px;font-weight:700;color:var(--g1);margin-bottom:3px">Admin এর উত্তর:</p>
    <p style="font-size:12px;color:var(--ink)">${_e(m.adminReply)}</p>
  </div>`:''}
</div>`;
    }).join('');
  } catch(err) {
    el.innerHTML = `<div style="padding:14px;color:var(--r1);font-size:12px">লোড ব্যর্থ: ${_e(err.message)}</div>`;
  }
}

async function _send(root) {
  const subject = root.querySelector('#ct-subject')?.value.trim();
  const message = root.querySelector('#ct-msg')?.value.trim();
  if (!message) { toast('মেসেজ লিখুন','er'); return; }

  const btn = root.querySelector('#ct-send-btn');
  if (btn) { btn.disabled=true; btn.textContent='পাঠানো হচ্ছে…'; }

  try {
    // ✅ পাঠানো ব্যক্তি Mess Admin/Co-Admin নাকি সাধারণ সদস্য তা সংরক্ষণ করো
    const isMessAdmin = ['mess-admin','mess-co-admin'].includes(_ctx.myMessRole);

    await addDoc(collection(db,'contactMessages'), {
      userId:      _ctx.profile.uid,
      userName:    _ctx.profile.name||_ctx.profile.email||'',
      userEmail:   _ctx.profile.email||'',
      userRole:    isMessAdmin ? 'mess-admin' : 'member',
      messId:      _ctx.messId||null,
      messName:    _ctx.messData?.name||null,
      subject:     subject||'',
      message,
      status:      'unread',
      adminReply:  null,
      createdAt:   serverTimestamp(),
    });
    root.querySelector('#ct-subject').value = '';
    root.querySelector('#ct-msg').value = '';
    root.querySelector('#ct-char').textContent = '0/1000';
    toast('মেসেজ পাঠানো হয়েছে ✓','ok');
    await _loadHistory(root);
  } catch(err) {
    toast('পাঠাতে ব্যর্থ: '+err.message,'er');
  } finally {
    if (btn) { btn.disabled=false; btn.textContent='📤 মেসেজ পাঠান'; }
  }
}

const _e = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

// members-cache.js — session-level cache for a mess's member roster
//
// কেন: home/meal/deposit/calendar/rent/report/month-close — প্রায় প্রতিটা পেজ
// একই member roster আলাদা করে fetch করতো, যদিও একই সেশনে বার বার একই ডেটা।
// সদস্য তালিকা কম-পরিবর্তনশীল (join/leave ছাড়া বদলায় না), তাই ৬০ সেকেন্ডের
// TTL cache দিয়ে navigation ফাস্ট করা হচ্ছে — বাজার/ডিপোজিট/মিলের মতো ঘন ঘন
// বদলানো ডেটা এই cache-এ নেই, শুধু roster।
//
// members.js (Manage Members পেজ) নিজে সবসময় fresh fetch করে (cache ব্যবহার
// করে না) এবং সদস্য add/remove/approve হলে invalidateMembersCache() কল করে,
// যাতে অন্য পেজ পরের বার fresh ডেটা পায় — max ৬০ সেকেন্ড স্টেল থাকতে পারে।

import { db } from './firebase.js';
import {
  collection, getDocs, query, orderBy
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TTL_MS = 60_000;
let _cache = { messId: null, members: null, ts: 0, promise: null };

export async function getCachedMembers(messId, { force=false } = {}) {
  const now = Date.now();
  if (!force && _cache.messId === messId && _cache.members && (now - _cache.ts) < TTL_MS) {
    return _cache.members;
  }
  if (!force && _cache.messId === messId && _cache.promise) {
    return _cache.promise;
  }
  const p = (async () => {
    const snap = await getDocs(query(collection(db,'messes',messId,'members'), orderBy('joinedAt')));
    const members = snap.docs.map(d=>({ uid:d.id, ...d.data() }));
    _cache = { messId, members, ts: Date.now(), promise: null };
    return members;
  })();
  _cache = { messId, members: _cache.messId===messId ? _cache.members : null, ts: _cache.ts, promise: p };
  return p;
}

export function invalidateMembersCache() {
  _cache = { messId: null, members: null, ts: 0, promise: null };
}

// plan.js — v11: fixed upgrade flow, no window.__ globals for ad banner

import { db } from './firebase.js';
import { toast, ld, uld } from './utils.js';
import {
  doc, getDoc, addDoc, collection, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

export const PLANS = {
  free: { name:'Free', price:0,   ads:true  },
  paid: { name:'Pro',  price:199, priceYear:1999, ads:false },
};

export function isPaid(messData) {
  if (!messData || messData.plan!=='paid') return false;
  if (!messData.planExpiry) return false;
  const exp = messData.planExpiry?.toDate ? messData.planExpiry.toDate() : new Date(messData.planExpiry);
  return exp > new Date();
}

async function _getConfig() {
  try {
    const snap = await getDoc(doc(db,'appConfig','main'));
    return snap.exists() ? snap.data() : {};
  } catch { return {}; }
}

// ✅ FIXED: no window.__ globals. Banner uses addEventListener properly.
export function showAdBanner(container) {
  if (!container) return;
  const adDiv = document.createElement('div');
  adDiv.style.cssText = `width:100%;background:#f1f5f2;border:1px solid #d8e8dc;
    border-radius:8px;padding:10px;text-align:center;font-size:11px;color:#4a7055;margin:12px 0;`;
  adDiv.innerHTML = `
<ins class="adsbygoogle"
  style="display:block;width:100%;min-height:60px"
  data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
  data-ad-slot="XXXXXXXXXX"
  data-ad-format="auto"
  data-full-width-responsive="true"></ins>
<div style="font-size:10px;color:#8aaa90;margin-top:4px">
  বিজ্ঞাপনমুক্ত অভিজ্ঞতার জন্য
  <button class="ad-upgrade-btn"
    style="background:none;border:none;color:#146b40;font-size:10px;font-weight:700;cursor:pointer;text-decoration:underline">
    Pro তে upgrade করুন
  </button>
</div>`;
  container.appendChild(adDiv);
  adDiv.querySelector('.ad-upgrade-btn')?.addEventListener('click', ()=>{
    // Will be called from mess context; dispatch event
    window.dispatchEvent(new CustomEvent('mm:upgrade'));
  });
  try { if(window.adsbygoogle) (window.adsbygoogle=window.adsbygoogle||[]).push({}); } catch(e) {}
}

export async function requestPayment(messId, profile, plan='monthly') {
  const config    = await _getConfig();
  const bkash     = config.bkashNumber || '01XXXXXXXXXX';
  const bkashType = config.bkashType   || 'Personal';
  const monthly   = config.monthlyPrice || 199;
  const yearly    = config.yearlyPrice  || 1999;

  // Remove any existing modal
  document.getElementById('__pay-modal')?.remove();

  const mo = document.createElement('div');
  mo.id = '__pay-modal';
  mo.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:1000;display:flex;align-items:center;justify-content:center;padding:20px';
  mo.innerHTML = `
<div style="background:#fff;border-radius:18px;padding:24px;max-width:390px;width:100%;
  box-shadow:0 20px 60px rgba(0,0,0,.22);max-height:90vh;overflow-y:auto">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
    <h3 style="font-size:16px;font-weight:700;color:#0a180e;margin:0">⭐ Pro Plan কিনুন</h3>
    <button id="__pay-close" style="background:none;border:none;font-size:20px;cursor:pointer;color:#4a7055">✕</button>
  </div>

  <!-- Plan selector -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:16px">
    <div class="plan-opt" data-plan="monthly"
      style="border:2px solid #146b40;border-radius:12px;padding:12px;text-align:center;cursor:pointer;background:#e7f3e7">
      <div style="font-size:12px;font-weight:700;color:#083d22">মাসিক</div>
      <div style="font-size:22px;font-weight:700;color:#146b40;margin:4px 0">${monthly}৳</div>
      <div style="font-size:10px;color:#4a7055">প্রতি মাস</div>
    </div>
    <div class="plan-opt" data-plan="yearly"
      style="border:2px solid #b0ceb8;border-radius:12px;padding:12px;text-align:center;cursor:pointer;background:#f1f5f2;position:relative">
      <div style="position:absolute;top:-8px;right:8px;background:#e8a838;color:#fff;
        font-size:9px;font-weight:700;border-radius:8px;padding:2px 7px">সাশ্রয়</div>
      <div style="font-size:12px;font-weight:700;color:#083d22">বার্ষিক</div>
      <div style="font-size:22px;font-weight:700;color:#146b40;margin:4px 0">${yearly}৳</div>
      <div style="font-size:10px;color:#4a7055">প্রতি বছর (${Math.round(yearly/12)}৳/মাস)</div>
    </div>
  </div>

  <!-- bKash info -->
  <div style="background:#e7f3e7;border:1px solid #c0dcc0;border-radius:12px;padding:14px;margin-bottom:14px">
    <p style="font-size:12px;color:#083d22;font-weight:700;margin-bottom:8px">
      📱 bKash (${bkashType}) এ Payment করুন:
    </p>
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
      <p style="font-size:22px;font-weight:700;color:#146b40;letter-spacing:2px;margin:0">${bkash}</p>
      <button id="__copy-bkash" class="btn btn-ghost btn-sm">📋 Copy</button>
    </div>
    <div style="margin-top:8px;font-size:12px;color:#083d22">
      Amount: <strong id="__pay-amount">${monthly}৳</strong> ·
      Reference: <strong>${messId.slice(0,8).toUpperCase()}</strong>
    </div>
  </div>

  <!-- Transaction ID -->
  <div class="field" style="margin-bottom:14px">
    <label class="lbl">bKash Transaction ID *</label>
    <input id="__txn-inp" class="inp inp-sm" placeholder="যেমন: 8N6YJX8P4E" maxlength="20"/>
  </div>

  <!-- Pro features list -->
  <div style="background:#f8fbf9;border-radius:8px;padding:10px;margin-bottom:14px;font-size:11px;color:#2a5238">
    <p style="font-weight:700;margin-bottom:6px">Pro Plan এ যা পাবেন:</p>
    <p>✅ বিজ্ঞাপনমুক্ত অভিজ্ঞতা</p>
    <p>✅ Unlimited member, expense, deposit</p>
    <p>✅ Excel export ও detailed report</p>
    <p>✅ Priority support</p>
  </div>

  <div style="display:flex;gap:8px">
    <button id="__pay-cancel" class="btn btn-ghost" style="flex:1">বাতিল</button>
    <button id="__pay-submit" class="btn btn-p" style="flex:1">📤 Submit করুন</button>
  </div>
  <p style="font-size:10px;color:#8aaa90;text-align:center;margin-top:10px;line-height:1.5">
    Admin verify করার পর Plan activate হবে (সাধারণত ২৪ ঘণ্টার মধ্যে)
  </p>
</div>`;

  document.body.appendChild(mo);

  let selPlan = plan || 'monthly';

  function _updateUI() {
    mo.querySelectorAll('.plan-opt').forEach(el=>{
      const active = el.dataset.plan === selPlan;
      el.style.borderColor = active ? '#146b40' : '#b0ceb8';
      el.style.background  = active ? '#e7f3e7' : '#f1f5f2';
    });
    const price = selPlan==='yearly' ? yearly : monthly;
    const amtEl = document.getElementById('__pay-amount');
    if (amtEl) amtEl.textContent = price+'৳';
  }
  _updateUI();

  mo.querySelectorAll('.plan-opt').forEach(el=>{
    el.addEventListener('click', ()=>{ selPlan=el.dataset.plan; _updateUI(); });
  });

  document.getElementById('__copy-bkash').addEventListener('click', ()=>{
    navigator.clipboard?.writeText(bkash).then(()=>toast('Number copied!','ok')).catch(()=>{});
  });

  const _close = () => mo.remove();
  document.getElementById('__pay-close').addEventListener('click', _close);
  document.getElementById('__pay-cancel').addEventListener('click', _close);
  mo.addEventListener('click', e=>{ if(e.target===mo) _close(); });

  document.getElementById('__pay-submit').addEventListener('click', async ()=>{
    const txnId = document.getElementById('__txn-inp')?.value.trim();
    const price = selPlan==='yearly' ? yearly : monthly;
    if (!txnId||txnId.length<6) { toast('সঠিক Transaction ID দিন','er'); return; }
    ld('Submit হচ্ছে…');
    try {
      await addDoc(collection(db,'paymentRequests'), {
        messId,
        requestedBy:   profile.uid,
        requesterName: profile.name||profile.email,
        amount: price, plan: selPlan, txnId,
        bkashNumber: bkash, status: 'pending',
        createdAt: serverTimestamp(),
      });
      _close();
      toast('Payment request পাঠানো হয়েছে! Admin verify করবেন।','ok');
    } catch(err) { toast('Submit ব্যর্থ: '+err.message,'er'); }
    finally { uld(); }
  });
}

export function showUpgradeModal(messId, profile) {
  requestPayment(messId, profile);
}

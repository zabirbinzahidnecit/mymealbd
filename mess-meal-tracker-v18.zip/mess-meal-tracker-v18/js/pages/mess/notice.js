// notice.js — v13: fixed (no window.__ globals, root-scoped selectors)

import { db } from '../../firebase.js';
import { toast, formatDate } from '../../utils.js';
import {
  collection, getDocs, addDoc, deleteDoc,
  doc, query, orderBy, limit, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _ctx={}, _root=null;

export async function render(root, ctx) {
  _ctx  = ctx;
  _root = root;
  const canWrite = ['mess-admin','mess-co-admin'].includes(ctx.myMessRole);
  const isAdmin  = ctx.myMessRole === 'mess-admin';

  root.innerHTML = `
<div>
  <div style="display:flex;align-items:center;justify-content:space-between;
    margin-bottom:14px;flex-wrap:wrap;gap:8px">
    <div>
      <h2 style="font-size:17px;font-weight:700;color:var(--ink);margin:0">📢 নোটিশ বোর্ড</h2>
      <p style="font-size:12px;color:var(--ink3);margin:3px 0 0">মেসের সব সদস্য নোটিশ দেখতে পারবেন</p>
    </div>
    <button class="btn btn-ghost btn-sm" id="notice-refresh">🔄 রিফ্রেশ</button>
  </div>

  ${canWrite ? `
  <div class="card" style="margin-bottom:14px">
    <div class="ch"><h3>✏️ নতুন নোটিশ লিখুন</h3></div>
    <div class="cb">
      <div class="field">
        <textarea class="inp" id="notice-txt" rows="3"
          style="resize:vertical;min-height:80px"
          placeholder="নোটিশের বিষয় লিখুন… (সর্বোচ্চ ৫০০ অক্ষর)"
          maxlength="500"></textarea>
      </div>
      <div style="display:flex;align-items:center;gap:8px">
        <button class="btn btn-p btn-sm" id="notice-add-btn">📤 নোটিশ দিন</button>
        <span id="notice-char" style="font-size:11px;color:var(--ink4)">0/500</span>
      </div>
    </div>
  </div>` : ''}

  <div id="notice-list" style="display:flex;flex-direction:column;gap:10px">
    <div style="padding:20px;text-align:center;color:var(--ink3)">লোড হচ্ছে…</div>
  </div>
</div>`;

  root.querySelector('#notice-refresh').addEventListener('click', ()=> _load(root));
  root.querySelector('#notice-add-btn')?.addEventListener('click', ()=> _add(root));
  root.querySelector('#notice-txt')?.addEventListener('input', e=>{
    const counter = root.querySelector('#notice-char');
    if (counter) counter.textContent = `${e.target.value.length}/500`;
  });

  // Event delegation for delete buttons
  root.querySelector('#notice-list').addEventListener('click', e=>{
    const btn = e.target.closest('[data-del-notice]');
    if (btn) _delete(root, btn.dataset.delNotice);
  });

  await _load(root);
}

async function _load(root) {
  const list    = root.querySelector('#notice-list');
  const isAdmin = _ctx.myMessRole === 'mess-admin';
  if (!list) return;

  try {
    const snap = await getDocs(query(
      collection(db,'messes',_ctx.messId,'notices'),
      orderBy('createdAt','desc'), limit(50)
    ));

    if (snap.empty) {
      list.innerHTML = `
<div class="card"><div class="cb" style="text-align:center;padding:30px;color:var(--ink3)">
  <div style="font-size:32px;margin-bottom:10px">📭</div>
  <p style="font-size:13px">এখনো কোনো নোটিশ নেই</p>
</div></div>`;
      return;
    }

    list.innerHTML = snap.docs.map(d=>{
      const n   = {id:d.id,...d.data()};
      const own = n.addedBy===_ctx.profile.uid;
      return `
<div class="card notice-card">
  <div class="cb">
    <p style="font-size:14px;color:var(--ink);line-height:1.6;
      white-space:pre-wrap;word-break:break-word">${_e(n.text)}</p>
    <div style="display:flex;align-items:center;justify-content:space-between;
      margin-top:10px;flex-wrap:wrap;gap:6px">
      <span style="font-size:11px;color:var(--ink3)">
        📌 ${_e(n.addedByName||'—')} · ${n.createdAt?formatDate(n.createdAt):'—'}
      </span>
      ${(isAdmin||own)
        ? `<button class="btn btn-xs btn-danger" data-del-notice="${n.id}">🗑 মুছুন</button>`
        : ''}
    </div>
  </div>
</div>`;
    }).join('');
  } catch(err) {
    list.innerHTML = `<div class="card"><div class="cb" style="color:var(--r1)">⚠️ ${_e(err.message)}</div></div>`;
  }
}

async function _add(root) {
  const txt = root.querySelector('#notice-txt')?.value.trim();
  if (!txt) { toast('নোটিশের বিষয় লিখুন','er'); return; }
  const btn = root.querySelector('#notice-add-btn');
  if (btn) { btn.disabled=true; btn.textContent='পাঠানো হচ্ছে…'; }
  try {
    await addDoc(collection(db,'messes',_ctx.messId,'notices'), {
      text:        txt,
      addedBy:     _ctx.profile.uid,
      addedByName: _ctx.profile.name||_ctx.profile.email,
      createdAt:   serverTimestamp()
    });
    const txtEl = root.querySelector('#notice-txt');
    const cntEl = root.querySelector('#notice-char');
    if (txtEl) txtEl.value='';
    if (cntEl) cntEl.textContent='0/500';
    toast('নোটিশ দেওয়া হয়েছে','ok');
    await _load(root);
  } catch(err) {
    toast('পাঠানো যায়নি: '+err.message,'er');
  } finally {
    if (btn) { btn.disabled=false; btn.textContent='📤 নোটিশ দিন'; }
  }
}

async function _delete(root, id) {
  if (!window.confirm('নোটিশটি মুছে ফেলবেন?')) return;
  try {
    await deleteDoc(doc(db,'messes',_ctx.messId,'notices',id));
    toast('মুছে ফেলা হয়েছে','ok');
    await _load(root);
  } catch(err) { toast('মুছতে ব্যর্থ: '+err.message,'er'); }
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

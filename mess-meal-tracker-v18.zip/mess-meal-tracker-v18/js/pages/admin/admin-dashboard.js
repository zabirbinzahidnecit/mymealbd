// admin-dashboard.js — Platform overview, stats, charts

import { db } from '../../firebase.js';
import { toast, ld, uld, taka } from '../../utils.js';
import {
  collection, getDocs, query, where, orderBy, limit,
  doc, getDoc
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

export async function render(root) {
  root.innerHTML = `
<div>
  <div class="adp-hd">
    <div>
      <h2 class="adp-h">📊 Dashboard</h2>
      <p class="adp-sub">Platform এর সার্বিক অবস্থা</p>
    </div>
    <button class="btn btn-ghost btn-sm" id="db-refresh">🔄 রিফ্রেশ</button>
  </div>

  <!-- Summary cards -->
  <div class="g4" style="margin-bottom:16px" id="db-cards">
    <div class="sc sc-blue"><div class="sl">মোট মেস</div><div class="sv" id="db-total-mess">—</div></div>
    <div class="sc sg"><div class="sl">সক্রিয় মেস</div><div class="sv" id="db-active-mess">—</div></div>
    <div class="sc sa"><div class="sl">মোট সদস্য</div><div class="sv" id="db-total-users">—</div></div>
    <div class="sc sr"><div class="sl">Pending</div><div class="sv" id="db-pending">—</div><div class="ss">user + request</div></div>
  </div>

  <!-- Charts row -->
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:13px;margin-bottom:16px">

    <!-- Mess status pie -->
    <div class="card">
      <div class="ch"><h3>🏠 মেসের অবস্থা</h3></div>
      <div class="cb" style="display:flex;flex-direction:column;align-items:center;gap:10px">
        <canvas id="db-mess-chart" width="180" height="180"></canvas>
        <div id="db-mess-legend" style="display:flex;gap:12px;flex-wrap:wrap;justify-content:center"></div>
      </div>
    </div>

    <!-- Plan distribution -->
    <div class="card">
      <div class="ch"><h3>💳 Plan বিতরণ</h3></div>
      <div class="cb" style="display:flex;flex-direction:column;align-items:center;gap:10px">
        <canvas id="db-plan-chart" width="180" height="180"></canvas>
        <div id="db-plan-legend" style="display:flex;gap:12px;flex-wrap:wrap;justify-content:center"></div>
      </div>
    </div>

    <!-- Payment summary -->
    <div class="card">
      <div class="ch"><h3>💰 Payment Summary</h3></div>
      <div class="cb" id="db-payment-summary">লোড হচ্ছে…</div>
    </div>

  </div>

  <!-- Recent activity -->
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:13px">

    <!-- Recent messes -->
    <div class="card">
      <div class="ch"><h3>🆕 সাম্প্রতিক মেস</h3></div>
      <div id="db-recent-messes" style="padding:4px 0">লোড হচ্ছে…</div>
    </div>

    <!-- Pending requests -->
    <div class="card">
      <div class="ch">
        <h3>⏳ Pending অনুরোধ</h3>
        <button class="btn btn-ghost btn-sm"
          id="db-go-requests">
          সব দেখুন
        </button>
      </div>
      <div id="db-pending-reqs" style="padding:4px 0">লোড হচ্ছে…</div>
    </div>

  </div>
</div>

<style>
.db-row{display:flex;align-items:center;justify-content:space-between;
  padding:8px 14px;border-bottom:.5px solid var(--line);font-size:12px}
.db-row:last-child{border-bottom:none}
.db-row .name{font-weight:600;color:var(--ink);flex:1;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.db-row .meta{color:var(--ink3);font-size:11px;margin-left:8px;flex-shrink:0}
</style>`;

  root.querySelector('#db-refresh').addEventListener('click', () => _load(root));

  // adm:nav event for cross-page navigation
  window.addEventListener('adm:nav', e => {
    const btn = document.querySelector(`#adm-nav [data-page="${e.detail}"]`);
    if (btn) btn.click();
  });

  await _load(root);
}

async function _load(root) {
  ld('Dashboard লোড হচ্ছে…');
  try {
    // Messes
    const messSnap = await getDocs(collection(db,'messes'));
    const messes   = messSnap.docs.map(d=>({id:d.id,...d.data()}));
    const active   = messes.filter(m=>m.status==='active').length;
    const inactive = messes.filter(m=>m.status!=='active').length;
    const paid     = messes.filter(m=>m.plan==='paid').length;
    const free     = messes.length - paid;

    // Users
    const userSnap   = await getDocs(collection(db,'users'));
    const users      = userSnap.docs.map(d=>d.data());
    const pendingU   = users.filter(u=>u.status==='pending').length;

    // Pending requests
    const reqSnap  = await getDocs(query(collection(db,'messRequests'), where('status','==','pending')));
    const pendingR = reqSnap.size;

    // Payment requests
    const paySnap  = await getDocs(query(collection(db,'paymentRequests')));
    const payments = paySnap.docs.map(d=>d.data());
    const pendingPay  = payments.filter(p=>p.status==='pending').length;
    const approvedPay = payments.filter(p=>p.status==='approved');
    const totalRev    = approvedPay.reduce((s,p)=>s+(parseFloat(p.amount)||0),0);

    // Update cards
    const _sv = (id,v) => { const el=root.querySelector('#'+id); if(el) el.textContent=v; };
    _sv('db-total-mess',  messes.length);
    _sv('db-active-mess', active);
    _sv('db-total-users', users.length);
    _sv('db-pending',     pendingU + pendingR);

    // Charts
    _drawPie('db-mess-chart', [active, inactive], ['সক্রিয়','নিষ্ক্রিয়'], ['#146b40','#b83030']);
    _drawPie('db-plan-chart', [free, paid], ['Free','Paid'], ['#4a78e8','#d98d2a']);

    // Legends
    _legend('db-mess-legend', ['সক্রিয়','নিষ্ক্রিয়'], [active, inactive], ['#146b40','#b83030']);
    _legend('db-plan-legend', ['Free','Paid'], [free, paid], ['#4a78e8','#d98d2a']);

    // Payment summary
    const payEl = root.querySelector('#db-payment-summary');
    if (payEl) payEl.innerHTML = `
<div style="display:flex;flex-direction:column;gap:8px">
  <div style="display:flex;justify-content:space-between;align-items:center;
    background:var(--a4);border-radius:8px;padding:10px 12px">
    <span style="font-size:12px;color:var(--a0);font-weight:600">⏳ Pending Payment</span>
    <span style="font-size:20px;font-weight:700;color:var(--a0);font-family:var(--mono)">${pendingPay}</span>
  </div>
  <div style="display:flex;justify-content:space-between;align-items:center;
    background:var(--g7);border-radius:8px;padding:10px 12px">
    <span style="font-size:12px;color:var(--g1);font-weight:600">✅ মোট Revenue</span>
    <span style="font-size:20px;font-weight:700;color:var(--g1);font-family:var(--mono)">${taka(totalRev)}</span>
  </div>
  <div style="display:flex;justify-content:space-between;align-items:center;
    background:var(--b4);border-radius:8px;padding:10px 12px">
    <span style="font-size:12px;color:var(--b0);font-weight:600">💳 Paid মেস</span>
    <span style="font-size:20px;font-weight:700;color:var(--b0);font-family:var(--mono)">${paid}</span>
  </div>
</div>`;

    // Recent messes
    const recentEl = root.querySelector('#db-recent-messes');
    if (recentEl) {
      const recent = [...messes]
        .sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0))
        .slice(0,5);
      recentEl.innerHTML = recent.length
        ? recent.map(m=>`
<div class="db-row">
  <span class="name">🏠 ${_e(m.name||'অজানা')}</span>
  <span class="badge ${m.status==='active'?'b-green':'b-red'}" style="font-size:9px">
    ${m.status==='active'?'সক্রিয়':'নিষ্ক্রিয়'}
  </span>
  <span class="meta">${m.plan==='paid'?'💳 Paid':'🆓 Free'}</span>
</div>`).join('')
        : '<div style="padding:20px;text-align:center;color:var(--ink3)">কোনো মেস নেই</div>';
    }

    // Pending requests
    const reqEl = root.querySelector('#db-pending-reqs');
    if (reqEl) {
      const reqs = reqSnap.docs.map(d=>d.data()).slice(0,5);
      reqEl.innerHTML = reqs.length
        ? reqs.map(r=>`
<div class="db-row">
  <span class="name">🏠 ${_e(r.messName||'—')}</span>
  <span class="meta">${_e(r.requesterName||'—')}</span>
</div>`).join('')
        : '<div style="padding:20px;text-align:center;color:var(--ink3)">কোনো pending অনুরোধ নেই</div>';
    }

  } catch(err) {
    toast('Dashboard লোড ব্যর্থ: '+err.message,'er');
    console.error(err);
  } finally { uld(); }
}

// Simple canvas pie chart
function _drawPie(canvasId, data, labels, colors) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx   = canvas.getContext('2d');
  const total = data.reduce((a,b)=>a+b,0);
  if (total===0) {
    ctx.fillStyle='#e0e0e0';
    ctx.beginPath();
    ctx.arc(90,90,80,0,Math.PI*2);
    ctx.fill();
    return;
  }
  let start = -Math.PI/2;
  data.forEach((v,i)=>{
    const slice = (v/total)*Math.PI*2;
    ctx.beginPath();
    ctx.moveTo(90,90);
    ctx.arc(90,90,80,start,start+slice);
    ctx.closePath();
    ctx.fillStyle = colors[i];
    ctx.fill();
    start += slice;
  });
  // Center hole (donut)
  ctx.beginPath();
  ctx.arc(90,90,45,0,Math.PI*2);
  ctx.fillStyle='#fff';
  ctx.fill();
  // Center text
  ctx.fillStyle='#0a180e';
  ctx.font='bold 18px Hind Siliguri';
  ctx.textAlign='center';
  ctx.textBaseline='middle';
  ctx.fillText(total,90,90);
}

function _legend(elId, labels, data, colors) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.innerHTML = labels.map((l,i)=>`
<div style="display:flex;align-items:center;gap:5px;font-size:12px">
  <span style="width:10px;height:10px;border-radius:2px;background:${colors[i]};flex-shrink:0"></span>
  <span style="color:var(--ink2)">${l}: <strong>${data[i]}</strong></span>
</div>`).join('');
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

// admin-shell.js — v15 final: _closeNav module-level, no inline style

import { logout } from '../../auth.js';
import { db } from '../../firebase.js';
import {
  getDocs, collection, query, where
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const PAGES = [
  { id:'dashboard', label:'Dashboard',       ico:'📊' },
  { id:'messes',    label:'সব মেস',          ico:'🏠' },
  { id:'requests',  label:'মেস অনুরোধ',     ico:'📋', badge:true },
  { id:'payments',  label:'Payment',          ico:'💰', badge2:true },
  { id:'broadcast', label:'Broadcast',        ico:'📢' },
  { id:'reports',   label:'রিপোর্ট',          ico:'📈' },
  { id:'users',     label:'ব্যবহারকারী',      ico:'👥' },
  { id:'contact',   label:'Contact Messages',  ico:'📩', badge3:true },
  { id:'settings',  label:'Settings',         ico:'⚙️' },
];

const FILE_MAP = {
  dashboard:'admin-dashboard', messes:'admin-messes',
  requests:'admin-requests',   payments:'admin-payments',
  broadcast:'admin-broadcast', reports:'admin-reports',
  users:'admin-users',         settings:'admin-settings',
  contact:'admin-contact',
};

// ── Module-level state ───────────────────────────────────────────────────────
let _cur='dashboard', _profile=null, _navHandler=null;

// ✅ Module-level — accessible by both render() and _go()
function _closeNav() {
  document.getElementById('adm-sb')?.classList.remove('open');
  document.getElementById('adm-overlay')?.classList.remove('on');
}

// ── render ───────────────────────────────────────────────────────────────────
export async function render(root, { profile }) {
  _profile = profile;
  document.body.style.margin  = '0';
  document.body.style.padding = '0';
  root.style.cssText = 'display:block;width:100%;min-height:100vh';

  root.innerHTML = `
<div id="adm-sb" class="adm-sb" style="position:fixed;top:0;left:0;bottom:0;width:228px;background:#011a0e;display:flex;flex-direction:column;z-index:100;box-shadow:2px 0 16px rgba(0,0,0,.18)">
  <div class="adm-logo">
    <div class="adm-logo-ic">🍽</div>
    <div><h2 class="adm-logo-h">মেস মিল ট্র্যাকার</h2><p class="adm-logo-s">Admin Panel</p></div>
  </div>
  <div class="adm-user">
    ${profile.avatar
        ? `<img class="adm-av-img" src="${_e(profile.avatar)}" alt=""/>`
        : `<div class="adm-av-txt">${(profile.name||'A')[0].toUpperCase()}</div>`}
    <div style="min-width:0">
      <div class="adm-uname">${_e(profile.name||profile.email)}</div>
      <div style="color:var(--g4);font-size:10px;margin-top:3px">${profile.platformRole==='admin'?'🔑 Admin':'🛡 Co-Admin'}</div>
    </div>
  </div>
  <nav class="adm-nav" id="adm-nav">
    ${PAGES.map(p=>`
    <button class="adm-nl${_cur===p.id?' active':''}" data-page="${p.id}">
      <span class="adm-nl-ic">${p.ico}</span><span>${p.label}</span>
      ${p.badge  ? '<span class="adm-bdot" id="req-badge"></span>'  : ''}
      ${p.badge2 ? '<span class="adm-bdot" id="pay-badge"></span>'  : ''}
      ${p.badge3 ? '<span class="adm-bdot" id="contact-badge"></span>'  : ''}
    </button>`).join('')}
  </nav>
  <div class="adm-foot">
    <button class="adm-nl" id="adm-logout">
      <span class="adm-nl-ic">🚪</span><span>লগআউট</span>
    </button>
  </div>
</div>

<div id="adm-overlay" class="adm-overlay"></div>

<div id="adm-main" class="adm-main" style="margin-left:228px;width:calc(100% - 228px);min-height:100vh;display:flex;flex-direction:column;background:#f1f5f2">
  <div id="adm-topbar" class="adm-topbar">
    <button id="adm-hbtn" class="adm-hbtn">☰</button>
    <span style="font-size:15px;font-weight:700;color:#0a180e;flex:1" id="adm-title">Dashboard</span>
  </div>
  <div id="adm-page" class="adm-page">
    <div style="padding:30px;text-align:center;color:#4a7055">লোড হচ্ছে…</div>
  </div>
</div>`;

  document.getElementById('adm-logout').addEventListener('click', ()=> logout());

  document.getElementById('adm-hbtn').addEventListener('click', ()=>{
    document.getElementById('adm-sb').classList.add('open');
    document.getElementById('adm-overlay').classList.add('on');
  });

  document.getElementById('adm-overlay').addEventListener('click', _closeNav);

  document.getElementById('adm-nav').addEventListener('click', e=>{
    const btn = e.target.closest('[data-page]');
    if (btn) _go(btn.dataset.page);
  });

  // ✅ Remove old listener before adding new one
  if (_navHandler) window.removeEventListener('adm:nav', _navHandler);
  _navHandler = e => _go(e.detail);
  window.addEventListener('adm:nav', _navHandler);

  await _go('dashboard');
  _loadBadges();
}

// ── _go ──────────────────────────────────────────────────────────────────────
async function _go(pageId) {
  _cur = pageId;

  document.querySelectorAll('#adm-nav [data-page]').forEach(b=>
    b.classList.toggle('active', b.dataset.page===pageId)
  );

  const lbl = PAGES.find(p=>p.id===pageId)?.label||'';
  const titleEl = document.getElementById('adm-title');
  if (titleEl) titleEl.textContent = lbl;

  // ✅ _closeNav is module-level — always accessible here
  _closeNav();

  const page = document.getElementById('adm-page');
  if (!page) return;
  page.innerHTML = '<div style="padding:30px;text-align:center;color:#4a7055">লোড হচ্ছে…</div>';

  try {
    const mod = await import(`./${FILE_MAP[pageId]||pageId}.js`);
    await mod.render(page, { profile: _profile });
  } catch(err) {
    console.error('Admin page error:', pageId, err);
    page.innerHTML = `
<div style="padding:30px;text-align:center;color:#b83030">
  <div style="font-size:32px;margin-bottom:10px">⚠️</div>
  <p style="font-size:13px;margin-bottom:4px">পেজ লোড হয়নি</p>
  <p style="font-size:11px;color:#888;margin-bottom:14px">${_e(err.message)}</p>
  <button id="__adm-retry"
    style="padding:8px 20px;background:#146b40;color:#fff;border:none;
    border-radius:8px;font-size:13px;cursor:pointer;font-family:inherit">
    🔄 পুনরায় লোড করুন
  </button>
</div>`;
    page.querySelector('#__adm-retry')?.addEventListener('click', ()=> _go(pageId));
  }
}

// ── badges ───────────────────────────────────────────────────────────────────
async function _loadBadges() {
  try {
    const [rSnap, pSnap, cSnap] = await Promise.all([
      getDocs(query(collection(db,'messRequests'), where('status','==','pending'))),
      getDocs(query(collection(db,'paymentRequests'), where('status','==','pending'))),
      getDocs(query(collection(db,'contactMessages'), where('status','==','unread'))),
    ]);
    if (rSnap.size>0) document.getElementById('req-badge')?.classList.add('show');
    if (pSnap.size>0) document.getElementById('pay-badge')?.classList.add('show');
    if (cSnap.size>0) document.getElementById('contact-badge')?.classList.add('show');
  } catch(e) { console.warn('Badge load failed:', e); }
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

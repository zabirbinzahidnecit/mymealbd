// admin-payments.js — bKash payment verify, plan upgrade

import { db } from '../../firebase.js';
import { toast, ld, uld, taka, formatDate } from '../../utils.js';
import { currentProfile } from '../../auth.js';
import {
  collection, getDocs, doc, updateDoc, getDoc,
  query, orderBy, serverTimestamp, writeBatch
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _all=[], _tab='pending';

export async function render(root) {
  root.innerHTML = `
<div>
  <div class="adp-hd">
    <div>
      <h2 class="adp-h">💰 Payment Management</h2>
      <p class="adp-sub" id="pay-count">লোড হচ্ছে…</p>
    </div>
    <button class="btn btn-ghost btn-sm" id="pay-refresh">🔄 রিফ্রেশ</button>
  </div>
  <div class="adm-tabs">
    <button class="adm-tab active" data-tab="pending">⏳ Pending</button>
    <button class="adm-tab" data-tab="approved">✅ Approved</button>
    <button class="adm-tab" data-tab="rejected">❌ Rejected</button>
    <button class="adm-tab" data-tab="all">সব</button>
  </div>
  <div id="pay-list" style="display:flex;flex-direction:column;gap:10px">
    <div class="adm-loading">লোড হচ্ছে…</div>
  </div>
</div>

<style>
.pay-card{background:#fff;border:1px solid var(--line);border-radius:12px;
  padding:14px 16px;box-shadow:var(--sh)}
.pay-hd{display:flex;align-items:flex-start;justify-content:space-between;
  gap:10px;margin-bottom:10px}
.pay-hd h3{font-size:14px;font-weight:700;color:var(--ink);margin:0}
.pay-hd p{font-size:11px;color:var(--ink3);margin:3px 0 0}
.pay-info{font-size:12px;color:var(--ink3);line-height:1.8;margin-bottom:10px}
.pay-info strong{color:var(--ink)}
</style>`;

  root.querySelector('#pay-refresh').addEventListener('click', ()=> _load(root));
  root.querySelector('.adm-tabs').addEventListener('click', e=>{
    const b = e.target.closest('[data-tab]');
    if (!b) return;
    _tab = b.dataset.tab;
    root.querySelectorAll('.adm-tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===_tab));
    _render(root);
  });
  root.querySelector('#pay-list').addEventListener('click', e=>{
    const ap = e.target.closest('[data-approve]');
    const rj = e.target.closest('[data-reject]');
    if (ap) _approve(root, ap.dataset.approve, ap.dataset.messid, ap.dataset.plan);
    if (rj) _reject(root, rj.dataset.reject);
  });

  await _load(root);
}

async function _load(root) {
  ld('Payment লোড হচ্ছে…');
  try {
    const snap = await getDocs(query(collection(db,'paymentRequests'), orderBy('createdAt','desc')));
    _all = snap.docs.map(d=>({id:d.id,...d.data()}));
    const pending = _all.filter(p=>p.status==='pending').length;
    root.querySelector('#pay-count').textContent = `${pending}টি pending · মোট ${_all.length}টি`;
    _render(root);
  } catch(err) {
    root.querySelector('#pay-list').innerHTML =
      `<div class="adm-loading">⚠️ ${err.message}</div>`;
  } finally { uld(); }
}

function _render(root) {
  const list = root.querySelector('#pay-list');
  if (!list) return;
  const filtered = _tab==='all' ? _all : _all.filter(p=>p.status===_tab);
  if (!filtered.length) {
    list.innerHTML='<div class="adm-loading">কোনো payment নেই</div>';
    return;
  }

  const badge = {
    pending:  '<span class="badge b-amber">⏳ Pending</span>',
    approved: '<span class="badge b-green">✅ Approved</span>',
    rejected: '<span class="badge b-red">❌ Rejected</span>',
  };
  const planLabel = { monthly:'মাসিক', yearly:'বার্ষিক' };

  list.innerHTML = filtered.map(p=>`
<div class="pay-card">
  <div class="pay-hd">
    <div>
      <h3>💚 ${_e(p.requesterName||'—')}</h3>
      <p>${_e(p.messId||'—')} · ${p.createdAt?formatDate(p.createdAt):'—'}</p>
    </div>
    <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px">
      ${badge[p.status]||''}
      <span style="font-size:16px;font-weight:700;font-family:var(--mono);color:var(--g1)">
        ${taka(p.amount)}
      </span>
    </div>
  </div>
  <div class="pay-info">
    <div>📋 Plan: <strong>${planLabel[p.plan]||p.plan||'—'}</strong></div>
    <div>💚 TxnID: <strong style="font-family:var(--mono);font-size:13px">${_e(p.txnId||'—')}</strong></div>
    <div>📧 Email: <strong>${_e(p.requesterName||'—')}</strong></div>
    ${p.reviewNote?`<div>💬 Note: ${_e(p.reviewNote)}</div>`:''}
  </div>
  ${p.status==='pending'?`
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <button class="btn btn-p btn-sm"
      data-approve="${p.id}"
      data-messid="${p.messId}"
      data-plan="${p.plan}">
      ✓ Approve — Plan Activate
    </button>
    <button class="btn btn-danger btn-sm" data-reject="${p.id}">✗ Reject</button>
  </div>`:''}
</div>`).join('');
}

async function _approve(root, payId, messId, plan) {
  if (!window.confirm('Payment approve করে plan activate করবেন?')) return;
  ld('Plan activate হচ্ছে…');
  try {
    // Calculate expiry
    const now    = new Date();
    const expiry = new Date(now);
    if (plan==='yearly') expiry.setFullYear(expiry.getFullYear()+1);
    else expiry.setMonth(expiry.getMonth()+1);

    const batch = writeBatch(db);

    // Update mess plan
    if (messId) {
      batch.update(doc(db,'messes',messId), {
        plan: 'paid',
        planExpiry: expiry,
        planActivatedAt: serverTimestamp(),
      });
    }

    // Update payment request
    batch.update(doc(db,'paymentRequests',payId), {
      status:     'approved',
      reviewedBy: currentProfile?.uid||'',
      reviewedAt: serverTimestamp(),
    });

    await batch.commit();

    const p = _all.find(x=>x.id===payId);
    if (p) p.status='approved';
    _render(root);
    root.querySelector('#pay-count').textContent =
      `${_all.filter(p=>p.status==='pending').length}টি pending`;
    toast('Plan activate হয়েছে! ✓','ok');
  } catch(err) {
    toast('ব্যর্থ: '+err.message,'er');
    console.error(err);
  } finally { uld(); }
}

async function _reject(root, payId) {
  const note = window.prompt('Reject এর কারণ লিখুন (ঐচ্ছিক):');
  if (note === null) return; // cancelled

  try {
    await updateDoc(doc(db,'paymentRequests',payId), {
      status:     'rejected',
      reviewNote: note||'',
      reviewedBy: currentProfile?.uid||'',
      reviewedAt: serverTimestamp(),
    });
    const p = _all.find(x=>x.id===payId);
    if (p) { p.status='rejected'; p.reviewNote=note; }
    _render(root);
    toast('Payment reject হয়েছে','ok');
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

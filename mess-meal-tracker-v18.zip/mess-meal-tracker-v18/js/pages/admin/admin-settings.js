// admin-settings.js — Platform Settings: bKash number, free limit, maintenance mode

import { db } from '../../firebase.js';
import { toast, ld, uld } from '../../utils.js';
import {
  doc, getDoc, setDoc, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _config = {};

export async function render(root) {
  root.innerHTML = `
<div>
  <div class="adp-hd">
    <div>
      <h2 class="adp-h">⚙️ Platform Settings</h2>
      <p class="adp-sub">bKash নম্বর, plan limit, maintenance mode</p>
    </div>
    <button class="btn btn-ghost btn-sm" id="cfg-refresh">🔄 রিফ্রেশ</button>
  </div>
  <div id="cfg-content">
    <div class="adm-loading">লোড হচ্ছে…</div>
  </div>
</div>`;

  root.querySelector('#cfg-refresh').addEventListener('click', () => _load(root));
  await _load(root);
}

async function _load(root) {
  ld('Settings লোড হচ্ছে…');
  try {
    const snap = await getDoc(doc(db, 'appConfig', 'main'));
    _config = snap.exists() ? snap.data() : {
      bkashNumber:    '01XXXXXXXXXX',
      bkashType:      'Personal',
      monthlyPrice:   199,
      yearlyPrice:    1999,
      freeMaxMembers: 10,
      maintenanceMode: false,
      maintenanceMsg:  'সাইটটি সাময়িকভাবে বন্ধ আছে। অনুগ্রহ করে পরে আসুন।',
      appVersion:     '3.0.0',
      updatedAt:      null,
    };
    _render(root);
  } catch(err) {
    root.querySelector('#cfg-content').innerHTML =
      `<div class="adm-loading" style="color:var(--r1)">⚠️ ${err.message}</div>`;
  } finally { uld(); }
}

function _render(root) {
  root.querySelector('#cfg-content').innerHTML = `
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:13px">

  <!-- bKash Payment -->
  <div class="card">
    <div class="ch"><h3>💚 bKash Payment</h3></div>
    <div class="cb">
      <div class="field">
        <label class="lbl">bKash নম্বর</label>
        <input class="inp inp-sm" id="cfg-bkash-num"
          value="${_e(_config.bkashNumber||'')}" placeholder="01XXXXXXXXXX"
          maxlength="15"/>
      </div>
      <div class="field">
        <label class="lbl">Account Type</label>
        <select class="inp inp-sm" id="cfg-bkash-type">
          <option value="Personal" ${_config.bkashType==='Personal'?'selected':''}>Personal</option>
          <option value="Merchant" ${_config.bkashType==='Merchant'?'selected':''}>Merchant</option>
          <option value="Agent"    ${_config.bkashType==='Agent'?'selected':''}>Agent</option>
        </select>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
        <div class="field" style="margin:0">
          <label class="lbl">মাসিক মূল্য (৳)</label>
          <input class="inp inp-sm" id="cfg-monthly" type="number"
            value="${_config.monthlyPrice||199}" min="0"/>
        </div>
        <div class="field" style="margin:0">
          <label class="lbl">বার্ষিক মূল্য (৳)</label>
          <input class="inp inp-sm" id="cfg-yearly" type="number"
            value="${_config.yearlyPrice||1999}" min="0"/>
        </div>
      </div>
      <button class="btn btn-p btn-sm" id="cfg-save-bkash">✓ সংরক্ষণ</button>
      <div id="bkash-msg" style="font-size:11px;margin-top:6px"></div>
    </div>
  </div>

  <!-- Plan Limits -->
  <div class="card">
    <div class="ch"><h3>🆓 Free Plan Limit</h3></div>
    <div class="cb">
      <div class="field">
        <label class="lbl">Free মেসে সর্বোচ্চ সদস্য</label>
        <input class="inp inp-sm" id="cfg-free-members" type="number"
          value="${_config.freeMaxMembers||10}" min="1" max="100"/>
        <p style="font-size:11px;color:var(--ink4);margin-top:4px">
          এর বেশি সদস্য যোগ করতে Paid plan লাগবে
        </p>
      </div>
      <div class="field">
        <label class="lbl">App Version</label>
        <input class="inp inp-sm" id="cfg-version"
          value="${_e(_config.appVersion||'1.0.0')}" placeholder="যেমন: 3.2.0"/>
        <p style="font-size:11px;color:var(--ink3);margin-top:4px;line-height:1.5">
          ⚡ Version বাড়ালে সব user এর screen এ <strong>আপডেট ব্যানার</strong> দেখাবে।
          নতুন code deploy করার পর এখানে version bump করুন।
        </p>
      </div>
      <button class="btn btn-p btn-sm" id="cfg-save-plan">✓ সংরক্ষণ করুন ও User দের জানান</button>
      <div id="plan-msg" style="font-size:11px;margin-top:6px"></div>
    </div>
  </div>

  <!-- Maintenance Mode -->
  <div class="card" style="border-color:${_config.maintenanceMode?'var(--r2)':'var(--line)'}">
    <div class="ch">
      <h3 style="color:${_config.maintenanceMode?'var(--r1)':'var(--ink)'}">
        🔧 Maintenance Mode
      </h3>
      <span class="badge ${_config.maintenanceMode?'b-red':'b-green'}">
        ${_config.maintenanceMode?'চালু':'বন্ধ'}
      </span>
    </div>
    <div class="cb">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;
        padding-bottom:10px;border-bottom:1px solid var(--line)">
        <span style="font-size:13px;color:var(--ink)">Maintenance চালু করুন</span>
        <label style="display:flex;align-items:center;gap:6px;cursor:pointer;margin-left:auto">
          <input type="checkbox" id="cfg-maintenance"
            style="accent-color:var(--r1);width:16px;height:16px"
            ${_config.maintenanceMode?'checked':''}/>
          <span style="font-size:12px;color:var(--ink3)" id="maint-lbl">
            ${_config.maintenanceMode?'চালু':'বন্ধ'}
          </span>
        </label>
      </div>
      <div class="field">
        <label class="lbl">Maintenance বার্তা</label>
        <textarea class="inp" id="cfg-maint-msg" rows="3"
          style="resize:vertical;min-height:70px"
          placeholder="ব্যবহারকারীদের দেখানো বার্তা…"
          maxlength="300">${_e(_config.maintenanceMsg||'')}</textarea>
      </div>
      <button class="btn btn-sm ${_config.maintenanceMode?'btn-danger':'btn-p'}"
        id="cfg-save-maint">
        ${_config.maintenanceMode?'⚠️ Maintenance চালু রাখুন':'✓ সংরক্ষণ'}
      </button>
      <div id="maint-msg" style="font-size:11px;margin-top:6px"></div>
    </div>
  </div>

  <!-- Current Config Preview -->
  <div class="card" style="background:var(--g7);border-color:var(--g5)">
    <div class="ch"><h3>👁 বর্তমান Config</h3></div>
    <div class="cb">
      <div style="font-size:12px;color:var(--ink2);line-height:2">
        <div>💚 bKash: <strong>${_e(_config.bkashNumber||'—')}</strong> (${_e(_config.bkashType||'—')})</div>
        <div>💰 মাসিক: <strong>৳${_config.monthlyPrice||199}</strong> · বার্ষিক: <strong>৳${_config.yearlyPrice||1999}</strong></div>
        <div>👥 Free limit: <strong>${_config.freeMaxMembers||10} সদস্য</strong></div>
        <div>🔧 Maintenance: <strong style="color:${_config.maintenanceMode?'var(--r1)':'var(--g1)'}">${_config.maintenanceMode?'চালু':'বন্ধ'}</strong></div>
        <div>📱 Version: <strong>${_e(_config.appVersion||'—')}</strong></div>
        ${_config.updatedAt?`<div style="color:var(--ink4);font-size:11px">Last updated: ${new Date(_config.updatedAt?.seconds*1000).toLocaleString('bn-BD')}</div>`:''}
      </div>
    </div>
  </div>

</div>`;

  // Event listeners
  root.querySelector('#cfg-maintenance').addEventListener('change', e => {
    root.querySelector('#maint-lbl').textContent = e.target.checked ? 'চালু' : 'বন্ধ';
  });

  root.querySelector('#cfg-save-bkash').addEventListener('click', () => _saveBkash(root));
  root.querySelector('#cfg-save-plan').addEventListener('click', () => _savePlan(root));
  root.querySelector('#cfg-save-maint').addEventListener('click', () => _saveMaint(root));
}

async function _saveBkash(root) {
  const num     = root.querySelector('#cfg-bkash-num')?.value.trim();
  const type    = root.querySelector('#cfg-bkash-type')?.value;
  const monthly = parseFloat(root.querySelector('#cfg-monthly')?.value)||199;
  const yearly  = parseFloat(root.querySelector('#cfg-yearly')?.value)||1999;

  if (!num) { toast('bKash নম্বর দিন','er'); return; }

  ld('সংরক্ষণ হচ্ছে…');
  try {
    await setDoc(doc(db,'appConfig','main'), {
      ..._config,
      bkashNumber: num, bkashType: type,
      monthlyPrice: monthly, yearlyPrice: yearly,
      updatedAt: serverTimestamp()
    });
    _config = { ..._config, bkashNumber:num, bkashType:type, monthlyPrice:monthly, yearlyPrice:yearly };
    const msg = root.querySelector('#bkash-msg');
    if (msg) { msg.textContent='✓ সংরক্ষণ হয়েছে'; msg.style.color='var(--g1)'; }
    toast('bKash settings সেভ হয়েছে','ok');
    _render(root);
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
  finally { uld(); }
}

async function _savePlan(root) {
  const freeMax = parseInt(root.querySelector('#cfg-free-members')?.value)||10;
  const version = root.querySelector('#cfg-version')?.value.trim();

  ld('সংরক্ষণ হচ্ছে…');
  try {
    await setDoc(doc(db,'appConfig','main'), {
      ..._config, freeMaxMembers: freeMax, appVersion: version||'1.0.0',
      updatedAt: serverTimestamp()
    }, { merge: true });
    _config = { ..._config, freeMaxMembers: freeMax, appVersion: version };
    const msg = root.querySelector('#plan-msg');
    if (msg) { msg.textContent='✓ সংরক্ষণ হয়েছে'; msg.style.color='var(--g1)'; }
    toast('Plan settings সেভ হয়েছে','ok');
    _render(root);
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
  finally { uld(); }
}

async function _saveMaint(root) {
  const enabled = root.querySelector('#cfg-maintenance')?.checked||false;
  const msg     = root.querySelector('#cfg-maint-msg')?.value.trim();

  if (enabled && !window.confirm('Maintenance mode চালু করলে সব user লগইন করতে পারবে না। নিশ্চিত?')) return;

  ld('সংরক্ষণ হচ্ছে…');
  try {
    await setDoc(doc(db,'appConfig','main'), {
      ..._config, maintenanceMode: enabled, maintenanceMsg: msg||'',
      updatedAt: serverTimestamp()
    });
    _config = { ..._config, maintenanceMode: enabled, maintenanceMsg: msg };
    const msgEl = root.querySelector('#maint-msg');
    if (msgEl) { msgEl.textContent='✓ সংরক্ষণ হয়েছে'; msgEl.style.color='var(--g1)'; }
    toast(enabled?'⚠️ Maintenance চালু হয়েছে':'✓ Maintenance বন্ধ হয়েছে', enabled?'er':'ok');
    _render(root);
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
  finally { uld(); }
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

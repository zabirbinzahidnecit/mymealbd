// auth.js — fixed: deleted mess check, 3-day pending auto-cleanup, invite handling

import { auth, db, googleProvider } from './firebase.js';
import { toast, ld, uld } from './utils.js';
import {
  signInWithPopup, signInWithRedirect, getRedirectResult,
  signOut, onAuthStateChanged
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import {
  doc, getDoc, setDoc, updateDoc, serverTimestamp,
  writeBatch, collection, getDocs, query, where, deleteDoc,
  onSnapshot
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';
import { renderRouter } from './router.js';
import { processPendingInvite } from './invite-handler.js';

// ── App version (এটা প্রতিটি deploy এ manually bump করুন) ──
export const LOCAL_VERSION = localStorage.getItem('__local_version_override') || '3.1.0';
let _versionUnsub   = null;

export function startVersionWatch() {
  if (_versionUnsub) _versionUnsub(); // cleanup old listener
  // Check localStorage — user already updated, don't show again for this version
  const dismissed = localStorage.getItem('__update_dismissed');
  _versionUnsub = onSnapshot(doc(db,'appConfig','main'), snap=>{
    if (!snap.exists()) return;
    const remote = snap.data().appVersion;
    if (!remote || remote === LOCAL_VERSION) return;
    // User already dismissed or updated for this version
    if (dismissed === remote) return;
    _showUpdateBanner(remote);
  });
}

function _showUpdateBanner(newVer) {
  if (document.getElementById('__update-banner')) return; // একবারই দেখাও
  const banner = document.createElement('div');
  banner.id = '__update-banner';
  banner.style.cssText = `
    position:fixed;bottom:0;left:0;right:0;z-index:99999;
    background:#146b40;color:#fff;
    display:flex;align-items:center;justify-content:space-between;
    padding:12px 16px;gap:12px;flex-wrap:wrap;
    box-shadow:0 -4px 20px rgba(0,0,0,.3);
    font-family:'Hind Siliguri',sans-serif;font-size:13px;`;
  banner.innerHTML = `
    <div>
      <strong>🎉 নতুন আপডেট (v${newVer}) এসেছে!</strong>
      <span style="font-size:11px;opacity:.85;margin-left:8px">ভালো অভিজ্ঞতার জন্য update করুন</span>
    </div>
    <div style="display:flex;gap:8px;flex-shrink:0">
      <button id="__update-now"
        style="background:#fff;color:#146b40;border:none;border-radius:8px;
        padding:7px 16px;font-weight:700;font-size:13px;cursor:pointer;
        font-family:inherit">⚡ এখনই Update</button>
      <button id="__update-later"
        style="background:rgba(255,255,255,.15);color:#fff;border:1px solid rgba(255,255,255,.3);
        border-radius:8px;padding:7px 12px;font-size:12px;cursor:pointer;
        font-family:inherit">পরে</button>
    </div>`;
  document.body.appendChild(banner);
  banner.querySelector('#__update-now').addEventListener('click', async ()=>{
    banner.querySelector('#__update-now').textContent='লোড হচ্ছে…';
    try {
      if ('caches' in window) {
        const names = await caches.keys();
        await Promise.all(names.map(n=>caches.delete(n)));
      }
      if ('serviceWorker' in navigator) {
        const regs = await navigator.serviceWorker.getRegistrations();
        await Promise.all(regs.map(r=>r.unregister()));
      }
    } catch{}
    // Store NEW version as local — so after reload LOCAL_VERSION matches
    localStorage.setItem('__local_version_override', newVer);
    location.reload(true);
  });
  // "পরে" — dismiss for this version session only
  banner.querySelector('#__update-later').addEventListener('click', ()=>{
    localStorage.setItem('__update_dismissed', newVer);
    banner.remove();
  });
}

export let currentUser    = null;
export let currentProfile = null;

// ── Google Sign-In ────────────────────────────────────────
export async function startAuth() {
  const btn = document.getElementById('btn-login');
  if (btn) btn.disabled = true;
  ld('লগইন হচ্ছে…');
  try {
    await signInWithPopup(auth, googleProvider);
  } catch (err) {
    const code = err.code || '';
    if (code === 'auth/popup-blocked') {
      toast('Popup block — redirect এ যাচ্ছে…', 'info');
      try { await signInWithRedirect(auth, googleProvider); return; } catch(e2) {}
    }
    uld();
    if (btn) btn.disabled = false;
    if (code !== 'auth/popup-closed-by-user' && code !== 'auth/cancelled-popup-request') {
      toast('লগইন ব্যর্থ: ' + (err.message || code), 'er');
    }
  }
}

export async function handleRedirectResult() {
  try { await getRedirectResult(auth); } catch(err) {}
}

export async function logout() {
  try {
    currentUser = null; currentProfile = null;
    await signOut(auth);
  } catch (err) { toast('লগআউট ব্যর্থ', 'er'); }
}

// ── User doc ensure ───────────────────────────────────────
async function ensureUserDoc(firebaseUser) {
  const ref  = doc(db, 'users', firebaseUser.uid);
  const snap = await getDoc(ref);
  if (!snap.exists()) {
    await setDoc(ref, {
      email: firebaseUser.email,
      name:  firebaseUser.displayName || firebaseUser.email.split('@')[0],
      avatar: firebaseUser.photoURL || null,
      status: 'pending', platformRole: null, currentMessId: null,
      createdAt: serverTimestamp()
    });
    return (await getDoc(ref)).data();
  }
  const data = snap.data();
  const upd  = {};
  if (firebaseUser.photoURL && data.avatar !== firebaseUser.photoURL) upd.avatar = firebaseUser.photoURL;
  if (Object.keys(upd).length) await updateDoc(ref, upd);
  return { ...data, ...upd };
}

// ── Deleted mess check ────────────────────────────────────
async function checkDeletedMess(profile, uid) {
  if (!profile.currentMessId) return profile;
  try {
    const messSnap = await getDoc(doc(db,'messes',profile.currentMessId));
    if (!messSnap.exists()) {
      // Mess deleted — user কে pending করো
      await updateDoc(doc(db,'users',uid), { currentMessId: null, status: 'pending' });
      toast('আপনার মেস মুছে ফেলা হয়েছে', 'er');
      return { ...profile, currentMessId: null, status: 'pending' };
    }

    // ✅ মেস আছে, কিন্তু এই user কি এখনো member? (Admin তাকে remove করতে পারে)
    const memberSnap = await getDoc(doc(db,'messes',profile.currentMessId,'members',uid));
    if (!memberSnap.exists()) {
      // Removed from mess — currentMessId clear করে pending করো
      await updateDoc(doc(db,'users',uid), { currentMessId: null, status: 'pending' });
      toast('আপনাকে মেস থেকে বের করা হয়েছে', 'er');
      return { ...profile, currentMessId: null, status: 'pending' };
    }
  } catch(e) { console.warn('checkDeletedMess error:', e); }
  return profile;
}

// ── 3 দিনের বেশি pending user cleanup ───────────────────
// ✅ Client-side — Firebase Functions ছাড়াই কাজ করবে
// Admin login করলে check করে পুরনো pending request গুলো expire করে
async function cleanupExpiredRequests() {
  try {
    const threeDaysAgo = new Date(Date.now() - 3*24*60*60*1000);
    const q = query(collection(db,'messRequests'), where('status','==','pending'));
    const snap = await getDocs(q);

    for (const d of snap.docs) {
      const data = d.data();
      const createdAt = data.createdAt?.toDate ? data.createdAt.toDate()
        : new Date((data.createdAt?.seconds||0)*1000);
      if (createdAt < threeDaysAgo) {
        // Expired — reject করে দাও
        await updateDoc(doc(db,'messRequests',d.id), {
          status: 'rejected',
          reviewNote: 'স্বয়ংক্রিয়ভাবে বাতিল — ৩ দিনের বেশি সময় পার হয়েছে',
          reviewedBy: 'system'
        });
      }
    }
  } catch(e) { console.warn('Cleanup error:', e); }
}

// ── inviteIndex দিয়ে invite check ────────────────────────
async function checkInviteByEmail(firebaseUser) {
  const email = firebaseUser.email?.toLowerCase();
  if (!email) return false;
  try {
    const idxKey  = email.replace(/\./g,'_').replace(/@/g,'_at_');
    const idxRef  = doc(db, 'inviteIndex', idxKey);
    const idxSnap = await getDoc(idxRef);
    if (!idxSnap.exists()) return false;

    const { messId, token, role } = idxSnap.data();
    const tokenRef  = doc(db,'messes',messId,'invites',token);
    const tokenSnap = await getDoc(tokenRef);
    if (!tokenSnap.exists()) return false;

    const inv = tokenSnap.data();
    const exp = inv.expiresAt?.toDate ? inv.expiresAt.toDate() : new Date((inv.expiresAt?.seconds||0)*1000);
    if (inv.used || exp < new Date()) return false;

    const batch = writeBatch(db);
    batch.set(doc(db,'messes',messId,'members',firebaseUser.uid), {
      name: firebaseUser.displayName||email, email,
      avatar: firebaseUser.photoURL||null, role, joinedAt: serverTimestamp()
    });
    batch.update(doc(db,'users',firebaseUser.uid), { status:'active', currentMessId: messId });
    batch.update(tokenRef, { used:true, usedBy:firebaseUser.uid, usedAt:serverTimestamp() });
    batch.delete(idxRef);
    await batch.commit();
    toast('মেসে যোগ হয়েছে! স্বাগতম 🎉', 'ok');
    return true;
  } catch(e) {
    console.warn('Email invite check error:', e.code);
    return false;
  }
}

// ── Auth State Listener ───────────────────────────────────
let _processing = false;

export function initAuth() {
  handleRedirectResult();

  onAuthStateChanged(auth, async (firebaseUser) => {
    if (_processing) return;
    _processing = true;

    if (!firebaseUser) {
      currentUser = null; currentProfile = null;
      uld(); _processing = false;
      renderRouter(null, null);
      return;
    }

    ld('প্রোফাইল লোড হচ্ছে…');
    try {
      currentUser = firebaseUser;
      let profile = await ensureUserDoc(firebaseUser);

      // ✅ Deleted mess check
      profile = await checkDeletedMess(profile, firebaseUser.uid);

      if (!profile.currentMessId) {
        // URL invite link check
        const joinedViaLink = await processPendingInvite(firebaseUser);
        if (joinedViaLink) {
          const s = await getDoc(doc(db,'users',firebaseUser.uid));
          profile = s.data();
        } else {
          // Email invite check
          const joinedViaEmail = await checkInviteByEmail(firebaseUser);
          if (joinedViaEmail) {
            const s = await getDoc(doc(db,'users',firebaseUser.uid));
            profile = s.data();
          }
        }
      }

      currentProfile = { uid: firebaseUser.uid, ...profile };

      // ✅ Platform admin হলে expired requests cleanup
      if (['admin','co-admin'].includes(profile.platformRole)) {
        cleanupExpiredRequests(); // background এ চলবে, await করবো না
      }

      uld(); _processing = false;
      renderRouter(currentUser, currentProfile);
    } catch(err) {
      console.error('Auth state error:', err);
      uld(); _processing = false;
      toast('প্রোফাইল লোড ব্যর্থ', 'er');
      renderRouter(firebaseUser, null);
    }
  });
}

export const isPlatformAdmin   = () => currentProfile?.platformRole === 'admin';
export const isPlatformCoAdmin = () => ['admin','co-admin'].includes(currentProfile?.platformRole);
export const hasMessAccess     = () => !!currentProfile?.currentMessId;

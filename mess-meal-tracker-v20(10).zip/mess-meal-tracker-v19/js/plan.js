// plan.js — v19: নতুন plan system

import { db } from './firebase.js';
import { toast, ld, uld, taka } from './utils.js';
import {
  doc, getDoc, addDoc, collection, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

export const PLAN_META = {
  free:      { name:'Free',    maxMembers:10  },
  pro10:     { name:'Pro 10',  maxMembers:10  },
  pro15:     { name:'Pro 15',  maxMembers:15  },
  pro20plus: { name:'Custom', maxMembers:999 },
};

export function isPaid(messData) {
  if (!messData) return false;
  if (!messData.plan || messData.plan==='free') return false;
  if (!messData.planExpiry) return false;
  const exp = messData.planExpiry?.toDate ? messData.planExpiry.toDate()
    : new Date((messData.planExpiry?.seconds||0)*1000);
  return exp > new Date();
}

export function isPlanExpired(messData) {
  if (!messData || !messData.plan || messData.plan==='free') return false;
  if (!messData.planExpiry) return true;
  const exp = messData.planExpiry?.toDate ? messData.planExpiry.toDate()
    : new Date((messData.planExpiry?.seconds||0)*1000);
  return exp <= new Date();
}

export async function getMemberLimit(messData) {
  const plan = messData?.plan||'free';
  try {
    const snap = await getDoc(doc(db,'appConfig','main'));
    const cfg  = snap.exists() ? snap.data() : {};
    if (plan==='free')  return cfg.freeMemberLimit||10;
    if (plan==='pro10') return cfg.pro10MemberLimit||10;
    if (plan==='pro15') return cfg.pro15MemberLimit||15;
    if (plan==='pro20plus') {
      // ✅ Custom Plan এখন প্রতি-মেস ভিত্তিক — প্রতিটা মেসের জন্য আলাদা সদস্য সীমা
      // (Admin পেমেন্ট অনুমোদনের সময় বা সরাসরি মেস এডিট করে ঠিক করেন)।
      // customMemberLimit না থাকলে config-এর base limit-এ পড়ে যাবে।
      return messData?.customMemberLimit || cfg.pro20BaseLimit || cfg.pro20MemberLimit || 20;
    }
  } catch {}
  return 10;
}

// ── Expired plan-এর জন্য বকেয়া হিসাব ──────────────────────
// মেয়াদ শেষ হয়ে গেলে, প্রতি মাস যে বাড়তি সময় পার হয়, সেটার জন্য একটা
// করে মাসের বিল "বকেয়া" (due) হিসেবে জমতে থাকে — renew করলে পুরো বকেয়া
// একসাথে দিতে হবে, শুধু ১ মাসের দাম দিলে চলবে না।

// sync ভার্সন — একাধিক মেস একসাথে চেক করার সময় (যেমন admin messes list এ)
// config একবার fetch করে সবার জন্য ব্যবহার করা যায়, বার বার fetch লাগে না।
export function getPlanDueInfoSync(messData, cfg) {
  const plan = messData?.plan;
  if (!plan || plan==='free' || !messData?.planExpiry) {
    return { isExpired:false, monthsOverdue:0, dueAmount:0, monthlyPrice:0 };
  }
  const expiry = messData.planExpiry?.toDate ? messData.planExpiry.toDate() : new Date(messData.planExpiry);
  const now = new Date();
  if (expiry >= now) {
    return { isExpired:false, monthsOverdue:0, dueAmount:0, monthlyPrice:0 };
  }

  let monthlyPrice = 0;
  if (plan==='pro10') monthlyPrice = cfg.pro10Price||199;
  else if (plan==='pro15') monthlyPrice = cfg.pro15Price||299;
  else if (plan==='pro20plus') {
    const base     = cfg.pro20BasePrice||cfg.pro20Price||499;
    const baseLimit= cfg.pro20BaseLimit||cfg.pro20MemberLimit||20;
    const perExtra = cfg.pro20PerExtraMember??15;
    const limit    = messData.customMemberLimit||baseLimit;
    monthlyPrice   = base + Math.max(0, limit-baseLimit)*perExtra;
  }

  const DAY = 24*60*60*1000;
  const monthsOverdue = Math.max(1, Math.ceil((now-expiry)/(30*DAY)));
  return { isExpired:true, monthsOverdue, dueAmount: monthsOverdue*monthlyPrice, monthlyPrice };
}

export async function getPlanDueInfo(messData) {
  if (!messData?.plan || messData.plan==='free' || !messData?.planExpiry) {
    return { isExpired:false, monthsOverdue:0, dueAmount:0, monthlyPrice:0 };
  }
  let cfg = {};
  try {
    const snap = await getDoc(doc(db,'appConfig','main'));
    cfg = snap.exists() ? snap.data() : {};
  } catch {}
  return getPlanDueInfoSync(messData, cfg);
}

async function _getConfig() {
  try {
    const snap = await getDoc(doc(db,'appConfig','main'));
    return snap.exists() ? snap.data() : {};
  } catch { return {}; }
}

export async function requestPayment(messId, profile, messData=null) {
  const config = await _getConfig();
  const dueInfo = messData ? await getPlanDueInfo(messData) : { isExpired:false, monthsOverdue:0, dueAmount:0 };
  const methods = [
    { id:'bkash',  label:'bKash', number:config.bkashNumber||'',  type:config.bkashType||'Personal',  icon:'💚' },
    { id:'nagad',  label:'নগদ',  number:config.nagadNumber||'',   type:config.nagadType||'Personal',   icon:'🟠' },
    { id:'rocket', label:'Rocket',number:config.rocketNumber||'',  type:config.rocketType||'Personal',  icon:'🟣' },
  ].filter(m=>m.number&&m.number.length>5);

  const planOptions = [
    { id:'pro10',    name:'Pro 10',  price:config.pro10Price||199, limit:config.pro10MemberLimit||10,  desc:`সর্বোচ্চ ${config.pro10MemberLimit||10} জন` },
    { id:'pro15',    name:'Pro 15',  price:config.pro15Price||299, limit:config.pro15MemberLimit||15,  desc:`সর্বোচ্চ ${config.pro15MemberLimit||15} জন` },
    { id:'pro20plus',name:'Custom', price:config.pro20BasePrice||config.pro20Price||499,
      limit:config.pro20BaseLimit||config.pro20MemberLimit||20, custom:true,
      desc:`কাস্টম — আপনার প্রয়োজন মতো সদস্য সংখ্যা` },
  ];
  const pro20BaseLimit    = config.pro20BaseLimit||config.pro20MemberLimit||20;
  const pro20BasePrice    = config.pro20BasePrice||config.pro20Price||499;
  const pro20PerExtra     = config.pro20PerExtraMember ?? 15;
  const _calcCustomPrice  = n => pro20BasePrice + Math.max(0, n-pro20BaseLimit)*pro20PerExtra;

  document.getElementById('__pay-modal')?.remove();
  const mo = document.createElement('div');
  mo.id = '__pay-modal';
  mo.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:16px';
  mo.innerHTML = `
<div style="background:#fff;border-radius:18px;padding:22px;max-width:420px;width:100%;box-shadow:0 24px 64px rgba(0,0,0,.28);max-height:92vh;overflow-y:auto">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
    <h3 style="font-size:16px;font-weight:700;color:#0a180e;margin:0">⭐ Pro Plan কিনুন</h3>
    <button id="__pay-close" style="background:none;border:none;font-size:22px;cursor:pointer;color:#4a7055">✕</button>
  </div>
  ${dueInfo.isExpired ? `
  <div style="background:#fee2e2;border:1px solid #dc2626;border-radius:10px;padding:10px 12px;margin-bottom:16px;font-size:12px;color:#991b1b;line-height:1.5">
    ⚠️ এই মেসের Plan-এর মেয়াদ <strong>${dueInfo.monthsOverdue} মাস</strong> আগে শেষ হয়েছে।
    সম্পূর্ণ বকেয়া <strong>৳${dueInfo.dueAmount}</strong> (নতুন মাস সহ) পাঠাতে হবে reactivate করতে।
  </div>` : `
  <div style="background:#fef3c7;border:1px solid #f59e0b;border-radius:10px;padding:10px 12px;margin-bottom:16px;font-size:12px;color:#92400e;line-height:1.5">
    🎯 বর্তমানে <strong>Free plan</strong> — সব feature চালু আছে। বেশি সদস্য যোগ করতে Pro plan নিন।
  </div>`}
  <p style="font-size:11px;font-weight:700;color:#4a7055;text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px">Plan নির্বাচন</p>
  <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px">
    ${planOptions.map((p,i)=>`
    <label style="display:flex;align-items:center;gap:10px;border:2px solid ${i===0?'#146b40':'#d1d5db'};border-radius:12px;padding:12px 14px;cursor:pointer" class="plan-opt-label" data-plan="${p.id}" data-price="${p.price}">
      <input type="radio" name="plan-sel" value="${p.id}" ${i===0?'checked':''} style="accent-color:#146b40;width:16px;height:16px;flex-shrink:0"/>
      <div style="flex:1">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span style="font-size:14px;font-weight:700;color:#083d22">${p.name}</span>
          <span style="font-size:16px;font-weight:700;color:#146b40" ${p.custom?'id="__pro20-price"':''}>৳${p.price}<span style="font-size:10px;color:#4a7055">/মাস</span></span>
        </div>
        <div style="font-size:11px;color:#4a7055;margin-top:2px">${p.desc}</div>
        ${p.custom ? `
        <div style="margin-top:8px;display:flex;align-items:center;gap:8px">
          <span style="font-size:11px;color:#4a7055">সদস্য সংখ্যা:</span>
          <input type="number" id="__pro20-members" min="${pro20BaseLimit+1}" value="${pro20BaseLimit+5}"
            style="width:64px;padding:4px 6px;border:1px solid #d1d5db;border-radius:6px;font-size:12px;font-family:monospace"/>
          <span style="font-size:10px;color:#8aaa90">(${pro20BaseLimit} জন পর্যন্ত ৳${pro20BasePrice}, তারপর প্রতি জন +৳${pro20PerExtra})</span>
        </div>` : ''}
      </div>
    </label>`).join('')}
  </div>
  ${methods.length>0?`
  <p style="font-size:11px;font-weight:700;color:#4a7055;text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px">Payment Method</p>
  <div style="display:flex;gap:8px;margin-bottom:12px" id="__method-tabs">
    ${methods.map((m,i)=>`<button class="__mtab" data-method="${m.id}"
      style="flex:1;padding:8px 6px;border-radius:10px;border:2px solid ${i===0?'#146b40':'#d1d5db'};background:${i===0?'#e7f3e7':'#fff'};cursor:pointer;font-size:12px;font-weight:700;font-family:inherit">
      ${m.icon} ${m.label}</button>`).join('')}
  </div>
  <div style="background:#f1f5f2;border-radius:12px;padding:14px;margin-bottom:14px" id="__payment-info">
    <p style="font-size:12px;font-weight:700;color:#083d22;margin-bottom:8px">${methods[0]?.icon} ${methods[0]?.label} (${methods[0]?.type})</p>
    <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
      <span style="font-size:22px;font-weight:700;color:#146b40;letter-spacing:2px">${methods[0]?.number}</span>
      <button id="__copy-num" class="btn btn-ghost btn-sm">📋 Copy</button>
    </div>
  </div>`:`
  <div style="background:#fde8e8;border-radius:10px;padding:12px;margin-bottom:14px;font-size:12px;color:#b83030;text-align:center">
    ⚠️ Admin এখনো payment number সেট করেননি।
  </div>`}
  <div style="background:#f1f5f2;border-radius:10px;padding:10px 14px;margin-bottom:14px;font-size:12px;color:#083d22">
    পরিমাণ: <strong id="__pay-amount">৳${planOptions[0]?.price||199}</strong> · Reference: <strong>${messId.slice(0,8).toUpperCase()}</strong>
  </div>
  <div class="field" style="margin-bottom:16px">
    <label class="lbl">Transaction ID *</label>
    <input id="__txn-inp" class="inp inp-sm" placeholder="যেমন: 8N6YJX8P4E" maxlength="30" style="font-family:monospace;letter-spacing:1px"/>
  </div>
  <div style="display:flex;gap:8px">
    <button id="__pay-cancel" class="btn btn-ghost" style="flex:1">বাতিল</button>
    <button id="__pay-submit" class="btn btn-p" style="flex:1">📤 Submit করুন</button>
  </div>
  <p style="font-size:10px;color:#8aaa90;text-align:center;margin-top:10px">Admin verify করার পর Plan activate হবে</p>
</div>`;
  document.body.appendChild(mo);

  let selPlan=planOptions[0]?.id||'pro10', selMethod=methods[0]?.id||'bkash';

  const _currentAmount = () => {
    if (selPlan === 'pro20plus') {
      const n = parseInt(mo.querySelector('#__pro20-members')?.value) || pro20BaseLimit;
      return _calcCustomPrice(Math.max(n, pro20BaseLimit+1));
    }
    return planOptions.find(x=>x.id===selPlan)?.price || 0;
  };
  const _refreshAmount = () => {
    const amtEl = mo.querySelector('#__pay-amount');
    if (amtEl) amtEl.textContent = '৳'+_currentAmount();
  };

  mo.querySelectorAll('.plan-opt-label').forEach(lbl=>{
    lbl.addEventListener('click',()=>{
      selPlan=lbl.dataset.plan;
      mo.querySelectorAll('.plan-opt-label').forEach(l=>l.style.borderColor=l.dataset.plan===selPlan?'#146b40':'#d1d5db');
      _refreshAmount();
    });
  });

  mo.querySelector('#__pro20-members')?.addEventListener('input', e=>{
    const n = Math.max(parseInt(e.target.value)||pro20BaseLimit+1, pro20BaseLimit+1);
    const priceEl = mo.querySelector('#__pro20-price');
    if (priceEl) priceEl.innerHTML = `৳${_calcCustomPrice(n)}<span style="font-size:10px;color:#4a7055">/মাস</span>`;
    if (selPlan === 'pro20plus') _refreshAmount();
  });

  mo.querySelectorAll('.__mtab').forEach(btn=>{
    btn.addEventListener('click',()=>{
      selMethod=btn.dataset.method;
      mo.querySelectorAll('.__mtab').forEach(b=>{
        b.style.borderColor=b.dataset.method===selMethod?'#146b40':'#d1d5db';
        b.style.background=b.dataset.method===selMethod?'#e7f3e7':'#fff';
      });
      const m=methods.find(x=>x.id===selMethod);
      const infoEl=mo.querySelector('#__payment-info');
      if(infoEl&&m) infoEl.innerHTML=`<p style="font-size:12px;font-weight:700;color:#083d22;margin-bottom:8px">${m.icon} ${m.label} (${m.type})</p>
<div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
<span style="font-size:22px;font-weight:700;color:#146b40;letter-spacing:2px">${m.number}</span>
<button id="__copy-num" class="btn btn-ghost btn-sm">📋 Copy</button></div>`;
      infoEl?.querySelector('#__copy-num')?.addEventListener('click',()=>navigator.clipboard?.writeText(m.number).then(()=>toast('Copied!','ok')));
    });
  });

  mo.querySelector('#__copy-num')?.addEventListener('click',()=>{
    const m=methods.find(x=>x.id===selMethod);
    if(m) navigator.clipboard?.writeText(m.number).then(()=>toast('Copied!','ok'));
  });

  const _close=()=>mo.remove();
  mo.querySelector('#__pay-close').addEventListener('click',_close);
  mo.querySelector('#__pay-cancel').addEventListener('click',_close);
  mo.addEventListener('click',e=>{if(e.target===mo)_close();});

  mo.querySelector('#__pay-submit').addEventListener('click',async()=>{
    const txnId=mo.querySelector('#__txn-inp')?.value.trim();
    if(!txnId||txnId.length<6){toast('সঠিক Transaction ID দিন','er');return;}
    const p=planOptions.find(x=>x.id===selPlan);
    const isCustom = selPlan === 'pro20plus';
    const requestedMemberCount = isCustom
      ? Math.max(parseInt(mo.querySelector('#__pro20-members')?.value)||pro20BaseLimit+1, pro20BaseLimit+1)
      : null;
    const amount = _currentAmount();
    const btn=mo.querySelector('#__pay-submit');
    if(btn){btn.disabled=true;btn.textContent='পাঠানো হচ্ছে…';}
    ld('Submit হচ্ছে…');
    try {
      await addDoc(collection(db,'paymentRequests'),{
        messId, requestedBy:profile.uid,
        requesterName:profile.name||profile.email||'',
        amount, plan:selPlan, planName:p?.name||selPlan,
        ...(isCustom ? { requestedMemberCount } : {}),
        paymentMethod:selMethod, txnId, status:'pending', createdAt:serverTimestamp(),
      });
      _close(); toast('Payment request পাঠানো হয়েছে!','ok');
    } catch(err){
      toast('Submit ব্যর্থ: '+err.message,'er');
      if(btn){btn.disabled=false;btn.textContent='📤 Submit করুন';}
    } finally{uld();}
  });
}

export function showUpgradeModal(messId, profile, messData) { requestPayment(messId, profile, messData); }
export function showAdBanner() {}

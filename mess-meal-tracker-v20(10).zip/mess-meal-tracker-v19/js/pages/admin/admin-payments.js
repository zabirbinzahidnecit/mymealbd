// admin-payments.js — bKash payment verify, plan upgrade

import { db } from '../../firebase.js';
import { toast, ld, uld, taka, formatDate } from '../../utils.js';
import { currentProfile } from '../../auth.js';
import { getPlanDueInfo } from '../../plan.js';
import {
  collection, getDocs, doc, updateDoc, getDoc,
  query, orderBy, serverTimestamp, writeBatch, limit, startAfter
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _all=[], _tab='pending', _lastDoc=null, _hasMore=true;

export async function render(root) {
  root.innerHTML = `
<div>
  <div class="adp-hd">
    <div>
      <h2 class="adp-h">💰 Payment Management</h2>
      <p class="adp-sub" id="pay-count">লোড হচ্ছে…</p>
    </div>
    <button class="btn btn-ghost btn-sm" id="pay-refresh">🔄 রিফ্রেশ</button>
  </div>
  <div class="adm-tabs">
    <button class="adm-tab active" data-tab="pending">⏳ Pending</button>
    <button class="adm-tab" data-tab="approved">✅ Approved</button>
    <button class="adm-tab" data-tab="rejected">❌ Rejected</button>
    <button class="adm-tab" data-tab="all">সব</button>
  </div>
  <div id="pay-list" style="display:flex;flex-direction:column;gap:10px">
    <div class="adm-loading">লোড হচ্ছে…</div>
  </div>
</div>

<style>
.pay-card{background:#fff;border:1px solid var(--line);border-radius:12px;
  padding:14px 16px;box-shadow:var(--sh)}
.pay-hd{display:flex;align-items:flex-start;justify-content:space-between;
  gap:10px;margin-bottom:10px}
.pay-hd h3{font-size:14px;font-weight:700;color:var(--ink);margin:0}
.pay-hd p{font-size:11px;color:var(--ink3);margin:3px 0 0}
.pay-info{font-size:12px;color:var(--ink3);line-height:1.8;margin-bottom:10px}
.pay-info strong{color:var(--ink)}
</style>`;

  root.querySelector('#pay-refresh').addEventListener('click', ()=> _load(root));
  root.querySelector('.adm-tabs').addEventListener('click', e=>{
    const b = e.target.closest('[data-tab]');
    if (!b) return;
    _tab = b.dataset.tab;
    root.querySelectorAll('.adm-tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===_tab));
    _render(root);
  });
  root.querySelector('#pay-list').addEventListener('click', e=>{
    const ap = e.target.closest('[data-approve]');
    const rj = e.target.closest('[data-reject]');
    if (ap) {
      const limitInput = root.querySelector(`#final-limit-${ap.dataset.approve}`);
      const customLimit = limitInput ? parseInt(limitInput.value)||null : null;
      _approve(root, ap.dataset.approve, ap.dataset.messid, ap.dataset.plan, customLimit);
    }
    if (rj) _reject(root, rj.dataset.reject);
  });

  await _load(root);
}

const PAGE_SIZE = 30;

async function _load(root, loadMore=false) {
  ld('Payment লোড হচ্ছে…');
  try {
    let q = query(collection(db,'paymentRequests'), orderBy('createdAt','desc'), limit(PAGE_SIZE));
    if (loadMore && _lastDoc) q = query(collection(db,'paymentRequests'), orderBy('createdAt','desc'), startAfter(_lastDoc), limit(PAGE_SIZE));

    const snap = await getDocs(q);
    const page = snap.docs.map(d=>({id:d.id,...d.data()}));
    _lastDoc = snap.docs[snap.docs.length-1] || _lastDoc;
    _hasMore = page.length === PAGE_SIZE;
    _all = loadMore ? [..._all, ...page] : page;

    const pending = _all.filter(p=>p.status==='pending').length;
    root.querySelector('#pay-count').textContent = `${pending}টি pending · মোট ${_all.length}টি${_hasMore?'+':''}`;
    _render(root);
  } catch(err) {
    root.querySelector('#pay-list').innerHTML =
      `<div class="adm-loading">⚠️ ${err.message}</div>`;
  } finally { uld(); }
}

function _render(root) {
  const list = root.querySelector('#pay-list');
  if (!list) return;
  const filtered = _tab==='all' ? _all : _all.filter(p=>p.status===_tab);
  if (!filtered.length) {
    list.innerHTML='<div class="adm-loading">কোনো payment নেই</div>';
    return;
  }

  const badge = {
    pending:  '<span class="badge b-amber">⏳ Pending</span>',
    approved: '<span class="badge b-green">✅ Approved</span>',
    rejected: '<span class="badge b-red">❌ Rejected</span>',
  };
  const planLabel = {
    free:'🆓 Free', pro10:'⭐ Pro 10', pro15:'⭐⭐ Pro 15', pro20plus:'⭐⭐⭐ Custom',
    monthly:'মাসিক (legacy)', yearly:'বার্ষিক (legacy)'
  };

  list.innerHTML = filtered.map(p=>`
<div class="pay-card">
  <div class="pay-hd">
    <div>
      <h3>💚 ${_e(p.requesterName||'—')}</h3>
      <p>${_e(p.messId||'—')} · ${p.createdAt?formatDate(p.createdAt):'—'}</p>
    </div>
    <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px">
      ${badge[p.status]||''}
      <span style="font-size:16px;font-weight:700;font-family:var(--mono);color:var(--g1)">
        ${taka(p.amount)}
      </span>
    </div>
  </div>
  <div class="pay-info">
    <div>📋 Plan: <strong>${planLabel[p.plan]||p.plan||'—'}</strong></div>
    <div>${_methodIcon(p.paymentMethod)} Method: <strong>${_e((p.paymentMethod||'bkash').toUpperCase())}</strong></div>
    <div>🔑 TxnID: <strong style="font-family:var(--mono);font-size:13px">${_e(p.txnId||'—')}</strong></div>
    <div>📧 From: <strong>${_e(p.requesterName||'—')}</strong></div>
    ${p.plan==='pro20plus' && p.requestedMemberCount ? `<div>👥 চাহিদা: <strong>${p.requestedMemberCount} জন সদস্য</strong></div>` : ''}
    ${p.reviewNote?`<div>💬 Note: ${_e(p.reviewNote)}</div>`:''}
  </div>
  ${p.status==='pending' && p.plan==='pro20plus' ? `
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;background:var(--paper);
    border-radius:8px;padding:8px 10px">
    <label class="lbl" style="margin:0;font-size:11px">চূড়ান্ত সদস্য সীমা:</label>
    <input class="inp inp-sm" type="number" id="final-limit-${p.id}" min="1"
      value="${p.requestedMemberCount||20}" style="width:70px"/>
  </div>` : ''}
  ${p.status==='pending'?`
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <button class="btn btn-p btn-sm"
      data-approve="${p.id}"
      data-messid="${p.messId}"
      data-plan="${p.plan}">
      ✓ Approve — Plan Activate
    </button>
    <button class="btn btn-danger btn-sm" data-reject="${p.id}">✗ Reject</button>
  </div>`:''}
</div>`).join('') + (_hasMore ? `
<div style="text-align:center;padding:14px">
  <button class="btn btn-ghost btn-sm" id="pay-load-more">আরও দেখুন ⬇️</button>
</div>` : '');

  root.querySelector('#pay-load-more')?.addEventListener('click', e => {
    e.target.disabled = true;
    e.target.textContent = 'লোড হচ্ছে…';
    _load(root, true);
  });
}

async function _approve(root, payId, messId, plan, customLimit=null) {
  // ✅ মেসের বর্তমান plan/expiry আগে দেখে নিই — renewal date এর হিসাব সঠিক করতে
  let dueInfo = { isExpired:false, monthsOverdue:0, dueAmount:0 };
  let oldExpiry = null;
  if (messId) {
    try {
      const messSnap = await getDoc(doc(db,'messes',messId));
      if (messSnap.exists()) {
        const messData = messSnap.data();
        oldExpiry = messData.planExpiry?.toDate ? messData.planExpiry.toDate() : (messData.planExpiry ? new Date(messData.planExpiry) : null);
        dueInfo = await getPlanDueInfo(messData);
      }
    } catch {}
  }

  let confirmMsg = `Payment approve করে "${plan}" plan activate করবেন?`;
  if (dueInfo.isExpired) {
    confirmMsg = `⚠️ এই মেসের Plan মেয়াদ ${dueInfo.monthsOverdue} মাস আগে শেষ হয়েছে — মোট বকেয়া ৳${dueInfo.dueAmount} (নতুন মাস সহ)।\n\nপেমেন্ট এই পুরো বকেয়া কভার করছে কিনা নিশ্চিত হয়ে "OK" চাপুন। Approve করলে মেয়াদ পুরনো expiry date থেকে ${dueInfo.monthsOverdue+1} মাস বাড়ানো হবে।`;
  }
  if (!window.confirm(confirmMsg)) return;

  ld('Plan activate হচ্ছে…');
  try {
    // ✅ ফিক্স: renewal date সবসময় "আজ থেকে ১ মাস" হতো, ফলে মেয়াদ শেষ হওয়ার
    // পর কয়েক মাস দেরি করে renew করলেও বকেয়া মাসগুলো এমনিতেই মাফ হয়ে যেত।
    // এখন থেকে:
    //  - মেয়াদ এখনো আছে (আগেভাগে renew) → পুরনো expiry থেকেই +১ মাস (কিছু হারাবে না)
    //  - মেয়াদ শেষ হয়ে গেছে → পুরনো expiry থেকে (বকেয়া মাস + নতুন ১ মাস) যোগ হবে
    //  - একদম নতুন plan (আগে কখনো ছিল না) → আজ থেকে ১ মাস
    const now = new Date();
    let baseDate = now;
    let monthsToAdd = 1;
    if (oldExpiry) {
      baseDate = oldExpiry;
      monthsToAdd = dueInfo.isExpired ? (dueInfo.monthsOverdue + 1) : 1;
    }
    const expiry = new Date(baseDate);
    expiry.setMonth(expiry.getMonth()+monthsToAdd);

    const batch = writeBatch(db);

    // Update mess plan — সঠিক plan type (pro10/pro15/pro20plus)
    if (messId) {
      const patch = {
        plan: plan || 'pro10',
        planExpiry: expiry,
        planActivatedAt: serverTimestamp(),
      };
      // ✅ Custom Plan — Admin এখানে যে সদস্য সীমা confirm করলেন সেটাই এই মেসের জন্য বসবে
      if (plan === 'pro20plus' && customLimit) patch.customMemberLimit = customLimit;
      batch.update(doc(db,'messes',messId), patch);
    }

    // Update payment request
    batch.update(doc(db,'paymentRequests',payId), {
      status:     'approved',
      reviewedBy: currentProfile?.uid||'',
      reviewedAt: serverTimestamp(),
    });

    await batch.commit();

    const p = _all.find(x=>x.id===payId);
    if (p) p.status='approved';
    _render(root);
    root.querySelector('#pay-count').textContent =
      `${_all.filter(p=>p.status==='pending').length}টি pending`;
    toast('Plan activate হয়েছে! ✓','ok');
  } catch(err) {
    toast('ব্যর্থ: '+err.message,'er');
    console.error(err);
  } finally { uld(); }
}

async function _reject(root, payId) {
  const note = window.prompt('Reject এর কারণ লিখুন (ঐচ্ছিক):');
  if (note === null) return; // cancelled

  try {
    await updateDoc(doc(db,'paymentRequests',payId), {
      status:     'rejected',
      reviewNote: note||'',
      reviewedBy: currentProfile?.uid||'',
      reviewedAt: serverTimestamp(),
    });
    const p = _all.find(x=>x.id===payId);
    if (p) { p.status='rejected'; p.reviewNote=note; }
    _render(root);
    toast('Payment reject হয়েছে','ok');
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
}

function _methodIcon(method) {
  if (method==='nagad')  return '🟠';
  if (method==='rocket') return '🟣';
  return '💚';
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

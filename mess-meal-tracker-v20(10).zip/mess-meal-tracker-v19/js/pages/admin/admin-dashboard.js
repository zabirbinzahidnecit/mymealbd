// admin-dashboard.js — v19: নতুন plan system সহ dashboard

import { db } from '../../firebase.js';
import { toast, ld, uld, taka } from '../../utils.js';
import {
  collection, getDocs, query, where
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

export async function render(root) {
  root.innerHTML = `
<div>
  <div class="adp-hd">
    <div>
      <h2 class="adp-h">📊 Dashboard</h2>
      <p class="adp-sub">Platform এর সার্বিক অবস্থা</p>
    </div>
    <button class="btn btn-ghost btn-sm" id="db-refresh">🔄 রিফ্রেশ</button>
  </div>

  <div class="g4" style="margin-bottom:14px">
    <div class="sc sg">
      <div class="sl">সক্রিয় মেস</div>
      <div class="sv" id="db-active-mess">—</div>
      <div class="ss" id="db-total-mess-sub">মোট: —</div>
    </div>
    <div class="sc sr">
      <div class="sl">Pending মেস অনুরোধ</div>
      <div class="sv" id="db-pending">—</div>
    </div>
    <div class="sc sc-blue">
      <div class="sl">Paid মেস</div>
      <div class="sv" id="db-paid-mess">—</div>
    </div>
    <div class="sc sr">
      <div class="sl">Expired Plan</div>
      <div class="sv" id="db-expired-count">—</div>
    </div>
  </div>

  <div id="db-load-more-wrap" style="margin-bottom:14px;text-align:center">
    <button class="btn btn-ghost btn-sm" id="db-load-more">👥 ইউজার ও Payment স্ট্যাটিস্টিক্স লোড করুন (আলাদাভাবে, দরকার হলে)</button>
  </div>
  <div class="g4" id="db-extra-stats" style="margin-bottom:14px;display:none">
    <div class="sc sa">
      <div class="sl">মোট ইউজার</div>
      <div class="sv" id="db-total-users">—</div>
    </div>
    <div class="sc sr">
      <div class="sl">মেসবিহীন ইউজার</div>
      <div class="sv" id="db-users-no-mess">—</div>
    </div>
    <div class="sc sa">
      <div class="sl">Pending Payment</div>
      <div class="sv" id="db-pending-pay">—</div>
    </div>
    <div class="sc sc-blue">
      <div class="sl">মোট Revenue</div>
      <div class="sv" id="db-revenue">—</div>
    </div>
  </div>

  <div class="card" style="margin-bottom:14px">
    <div class="ch"><h3>💳 Plan ভিত্তিক মেস</h3></div>
    <div class="cb">
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px"
        id="db-plan-breakdown">লোড হচ্ছে…</div>
    </div>
  </div>

  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:13px;margin-bottom:14px">
    <div class="card">
      <div class="ch"><h3>🏠 মেসের অবস্থা</h3></div>
      <div class="cb" style="display:flex;flex-direction:column;align-items:center;gap:10px">
        <canvas id="db-mess-chart" width="160" height="160"></canvas>
        <div id="db-mess-legend" style="display:flex;gap:12px;flex-wrap:wrap;justify-content:center"></div>
      </div>
    </div>
    <div class="card">
      <div class="ch"><h3>📊 Plan বিতরণ</h3></div>
      <div class="cb" style="display:flex;flex-direction:column;align-items:center;gap:10px">
        <canvas id="db-plan-chart" width="160" height="160"></canvas>
        <div id="db-plan-legend" style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center"></div>
      </div>
    </div>
    <div class="card">
      <div class="ch"><h3>💰 Payment Summary</h3></div>
      <div class="cb" id="db-payment-summary" style="padding:20px;text-align:center;color:var(--ink3);font-size:12px">
        উপরে "লোড করুন" বাটনে ক্লিক করুন
      </div>
    </div>
  </div>

  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:13px">
    <div class="card">
      <div class="ch">
        <h3>🆕 সাম্প্রতিক মেস</h3>
        <button class="btn btn-ghost btn-sm" id="db-go-messes">সব দেখুন</button>
      </div>
      <div id="db-recent-messes">লোড হচ্ছে…</div>
    </div>
    <div class="card">
      <div class="ch">
        <h3>⏳ Pending অনুরোধ</h3>
        <button class="btn btn-ghost btn-sm" id="db-go-requests">সব দেখুন</button>
      </div>
      <div id="db-pending-reqs">লোড হচ্ছে…</div>
    </div>
    <div class="card">
      <div class="ch">
        <h3>⚠️ Expired Plan</h3>
        <button class="btn btn-ghost btn-sm" id="db-go-expired">সব দেখুন</button>
      </div>
      <div id="db-expired-list">লোড হচ্ছে…</div>
    </div>
  </div>
</div>

<style>
.db-row{display:flex;align-items:center;gap:8px;padding:8px 14px;border-bottom:.5px solid var(--line);font-size:12px}
.db-row:last-child{border-bottom:none}
.db-row .name{font-weight:600;color:var(--ink);flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.db-row .meta{color:var(--ink3);font-size:11px;flex-shrink:0}
.plan-box{border-radius:10px;padding:12px;text-align:center;border:1px solid}
.plan-box .pb-num{font-size:24px;font-weight:700;margin:4px 0}
.plan-box .pb-lbl{font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.4px}
</style>`;

  root.querySelector('#db-refresh').addEventListener('click', () => _load(root));
  root.querySelector('#db-load-more')?.addEventListener('click', e => _loadExtraStats(root, e.target));
  root.querySelector('#db-go-requests').addEventListener('click', () =>
    window.dispatchEvent(new CustomEvent('adm:nav', { detail:'requests' })));
  root.querySelector('#db-go-messes').addEventListener('click', () =>
    window.dispatchEvent(new CustomEvent('adm:nav', { detail:'messes' })));
  root.querySelector('#db-go-expired').addEventListener('click', () =>
    window.dispatchEvent(new CustomEvent('adm:nav', { detail:'messes' })));

  await _load(root);
}

async function _loadExtraStats(root, btn) {
  btn.disabled = true;
  btn.textContent = 'লোড হচ্ছে…';
  try {
    const [userSnap, paySnap] = await Promise.all([
      getDocs(collection(db,'users')),
      getDocs(collection(db,'paymentRequests')),
    ]);
    const users    = userSnap.docs.map(d=>d.data());
    const payments = paySnap.docs.map(d=>d.data());

    const usersNoMess = users.filter(u=>!u.currentMessId).length;
    const pendingPay   = payments.filter(p=>p.status==='pending').length;
    const totalRev      = payments.filter(p=>p.status==='approved').reduce((s,p)=>s+(parseFloat(p.amount)||0),0);

    const _sv = (id,v) => { const el=root.querySelector('#'+id); if(el) el.textContent=v; };
    _sv('db-total-users',   users.length);
    _sv('db-users-no-mess', usersNoMess);
    _sv('db-pending-pay',   pendingPay);
    _sv('db-revenue',       taka(totalRev));

    const payEl = root.querySelector('#db-payment-summary');
    if (payEl) payEl.innerHTML = `
<div style="display:flex;flex-direction:column;gap:8px">
  <div style="display:flex;justify-content:space-between;align-items:center;background:var(--a4);border-radius:8px;padding:10px 12px">
    <span style="font-size:12px;color:var(--a0);font-weight:600">⏳ Pending Payment</span>
    <span style="font-size:20px;font-weight:700;color:var(--a0);font-family:var(--mono)">${pendingPay}</span>
  </div>
  <div style="display:flex;justify-content:space-between;align-items:center;background:var(--g7);border-radius:8px;padding:10px 12px">
    <span style="font-size:12px;color:var(--g1);font-weight:600">✅ মোট Revenue</span>
    <span style="font-size:20px;font-weight:700;color:var(--g1);font-family:var(--mono)">${taka(totalRev)}</span>
  </div>
</div>`;

    root.querySelector('#db-extra-stats').style.display = '';
    root.querySelector('#db-load-more-wrap').style.display = 'none';
  } catch(err) {
    toast('লোড ব্যর্থ: '+err.message,'er');
    btn.disabled = false;
    btn.textContent = '👥 ইউজার ও Payment স্ট্যাটিস্টিক্স লোড করুন (আলাদাভাবে, দরকার হলে)';
  }
}

async function _load(root) {
  ld('Dashboard লোড হচ্ছে…');
  try {
    // ✅ ডিফল্টভাবে শুধু মেস-সম্পর্কিত ডেটা লোড হয় — users/payments সম্পূর্ণ
    // collection টানা হয় না যতক্ষণ না admin স্পষ্টভাবে "লোড করুন" চাপেন।
    const [messSnap, reqSnap] = await Promise.all([
      getDocs(collection(db,'messes')),
      getDocs(query(collection(db,'messRequests'), where('status','==','pending'))),
    ]);

    const messes = messSnap.docs.map(d=>({id:d.id,...d.data()}));

    const now = new Date();
    const planCounts = { free:0, pro10:0, pro15:0, pro20plus:0, expired:0 };
    messes.forEach(m => {
      const plan = m.plan || 'free';
      if (plan === 'free') { planCounts.free++; return; }
      const exp = m.planExpiry?.toDate ? m.planExpiry.toDate() : new Date((m.planExpiry?.seconds||0)*1000);
      if (exp <= now) planCounts.expired++;
      else planCounts[plan] = (planCounts[plan]||0) + 1;
    });

    const active     = messes.filter(m=>m.status==='active').length;
    const inactive   = messes.filter(m=>m.status!=='active').length;
    const paidMess   = messes.filter(m=>m.plan&&m.plan!=='free').length;
    const expiredCnt = planCounts.expired;

    const _sv = (id,v) => { const el=root.querySelector('#'+id); if(el) el.textContent=v; };
    _sv('db-active-mess',    active);
    _sv('db-total-mess-sub', `মোট: ${messes.length}`);
    _sv('db-pending',        reqSnap.size);
    _sv('db-paid-mess',      paidMess);
    _sv('db-expired-count',  expiredCnt);

    const planEl = root.querySelector('#db-plan-breakdown');
    if (planEl) {
      planEl.innerHTML = [
        { key:'free',      label:'🆓 Free',      color:'#f0f7f2', border:'#cfe6d8', text:'#1a5c32' },
        { key:'pro10',     label:'⭐ Pro 10',    color:'#e7f0fe', border:'#b3cef8', text:'#1a3a8c' },
        { key:'pro15',     label:'⭐⭐ Pro 15',  color:'#f3e8ff', border:'#d8b4fe', text:'#5b21b6' },
        { key:'pro20plus', label:'⭐⭐⭐ Custom',color:'#fef3c7', border:'#fcd34d', text:'#92400e' },
        { key:'expired',   label:'⚠️ Expired',  color:'#fde8e8', border:'#fca5a5', text:'#b83030' },
      ].map(p=>`
<div class="plan-box" style="background:${p.color};border-color:${p.border}">
  <div class="pb-lbl" style="color:${p.text}">${p.label}</div>
  <div class="pb-num" style="color:${p.text}">${planCounts[p.key]||0}</div>
  <div style="font-size:10px;color:${p.text};opacity:.7">মেস</div>
</div>`).join('');
    }

    const planVals   = [planCounts.free, planCounts.pro10, planCounts.pro15, planCounts.pro20plus, planCounts.expired];
    const planColors = ['#4a78e8','#146b40','#7c3aed','#d98d2a','#b83030'];
    const planLabels = ['Free','Pro10','Pro15','Custom','Expired'];
    _drawPie('db-mess-chart', [active, inactive], ['#146b40','#b83030']);
    _drawPie('db-plan-chart', planVals, planColors);
    _legend('db-mess-legend', ['সক্রিয়','নিষ্ক্রিয়'], [active, inactive], ['#146b40','#b83030']);
    _legend('db-plan-legend', planLabels, planVals, planColors);

    const recentEl = root.querySelector('#db-recent-messes');
    if (recentEl) {
      const recent = [...messes].sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0)).slice(0,5);
      recentEl.innerHTML = recent.length
        ? recent.map(m=>{
          const plan = m.plan||'free';
          const badge = plan==='free'
            ? '<span class="badge b-member" style="font-size:9px">Free</span>'
            : `<span class="badge b-green" style="font-size:9px">${plan.replace('pro','Pro ').replace('plus','+')}</span>`;
          return `<div class="db-row">
<span class="name">🏠 ${_e(m.name||'অজানা')}</span>${badge}
<span class="badge ${m.status==='active'?'b-green':'b-red'}" style="font-size:9px;margin-left:4px">${m.status==='active'?'সক্রিয়':'নিষ্ক্রিয়'}</span>
</div>`;
        }).join('')
        : '<div style="padding:20px;text-align:center;color:var(--ink3)">কোনো মেস নেই</div>';
    }

    const reqEl = root.querySelector('#db-pending-reqs');
    if (reqEl) {
      const reqs = reqSnap.docs.map(d=>d.data()).slice(0,5);
      reqEl.innerHTML = reqs.length
        ? reqs.map(r=>`<div class="db-row"><span class="name">🏠 ${_e(r.messName||'—')}</span><span class="meta">${_e(r.requesterName||'—')}</span></div>`).join('')
        : '<div style="padding:20px;text-align:center;color:var(--ink3)">কোনো pending অনুরোধ নেই</div>';
    }

    const expEl = root.querySelector('#db-expired-list');
    if (expEl) {
      const expired = messes.filter(m=>{
        if (!m.plan||m.plan==='free') return false;
        const exp = m.planExpiry?.toDate ? m.planExpiry.toDate() : new Date((m.planExpiry?.seconds||0)*1000);
        return exp<=now;
      }).slice(0,5);
      expEl.innerHTML = expired.length
        ? expired.map(m=>`<div class="db-row"><span class="name" style="color:var(--r1)">⚠️ ${_e(m.name||'অজানা')}</span><span class="meta" style="color:var(--r1)">${m.plan||'—'}</span></div>`).join('')
        : '<div style="padding:20px;text-align:center;color:var(--ink3)">কোনো expired plan নেই ✅</div>';
    }

  } catch(err) {
    toast('Dashboard লোড ব্যর্থ: '+err.message,'er'); console.error(err);
  } finally { uld(); }
}

function _drawPie(canvasId, data, colors) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const cx=80, cy=80, r=70;
  const total = data.reduce((a,b)=>a+b,0);
  if (total===0) {
    ctx.fillStyle='#e0e0e0'; ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2); ctx.fill();
  } else {
    let start=-Math.PI/2;
    data.forEach((v,i)=>{
      if (!v) return;
      const slice=(v/total)*Math.PI*2;
      ctx.beginPath(); ctx.moveTo(cx,cy);
      ctx.arc(cx,cy,r,start,start+slice); ctx.closePath();
      ctx.fillStyle=colors[i]; ctx.fill();
      start+=slice;
    });
  }
  ctx.beginPath(); ctx.arc(cx,cy,38,0,Math.PI*2); ctx.fillStyle='#fff'; ctx.fill();
  ctx.fillStyle='#0a180e'; ctx.font='bold 16px Hind Siliguri';
  ctx.textAlign='center'; ctx.textBaseline='middle'; ctx.fillText(total,cx,cy);
}

function _legend(elId, labels, data, colors) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.innerHTML = labels.map((l,i)=>`
<div style="display:flex;align-items:center;gap:4px;font-size:11px">
  <span style="width:9px;height:9px;border-radius:2px;background:${colors[i]};flex-shrink:0"></span>
  <span style="color:var(--ink2)">${l}: <strong>${data[i]||0}</strong></span>
</div>`).join('');
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

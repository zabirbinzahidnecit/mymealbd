// admin-reports.js — v14: full rewrite, mess selector + full report

import { db } from '../../firebase.js';
import { taka, takaF, pad, moName, dim, monthDocIdRange, monthDateRange } from '../../utils.js';
import { exportPDF, exportExcel } from '../../report-export.js';
import {
  collection, getDocs, query, where, orderBy, documentId
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _messes=[], _vy=TODAY.getFullYear(), _vm=TODAY.getMonth();
let _members=[], _meals={}, _expenses=[], _deposits=[];

export async function render(root, { profile }) {
  root.innerHTML = `
<div>
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px">
    <h2 style="font-size:17px;font-weight:700;color:#0a180e;margin:0">📈 রিপোর্ট</h2>
    <button class="btn btn-ghost btn-sm" id="arep-refresh">🔄</button>
  </div>

  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <div class="field" style="margin:0;flex:1;min-width:180px">
      <label class="lbl">মেস নির্বাচন</label>
      <select class="inp inp-sm" id="arep-mess-sel"><option value="">— মেস নির্বাচন করুন —</option></select>
    </div>
    <div style="display:flex;align-items:center;gap:5px;margin-top:16px">
      <button class="btn btn-ghost btn-sm" id="arep-prev">◀</button>
      <span style="font-size:13px;font-weight:700;min-width:130px;text-align:center" id="arep-lbl"></span>
      <button class="btn btn-ghost btn-sm" id="arep-next">▶</button>
    </div>
    <div style="display:flex;gap:6px;margin-top:16px">
      <button class="btn btn-p btn-sm" id="arep-load">📊 লোড করুন</button>
      <button class="btn btn-ghost btn-sm" id="arep-excel" style="display:none">📥 Excel</button>
      <button class="btn btn-ghost btn-sm" id="arep-pdf" style="display:none">🖨️ PDF</button>
    </div>
  </div>

  <div id="arep-body">
    <div style="padding:40px;text-align:center;color:#4a7055;background:#f1f5f2;border-radius:12px">
      <div style="font-size:36px;margin-bottom:10px">📊</div>
      <p>একটি মেস নির্বাচন করুন</p>
    </div>
  </div>
</div>`;

  root.querySelector('#arep-lbl').textContent = `${moName(_vm)} ${_vy}`;
  root.querySelector('#arep-prev').addEventListener('click', ()=>{ _vm--; if(_vm<0){_vm=11;_vy--} root.querySelector('#arep-lbl').textContent=`${moName(_vm)} ${_vy}`; });
  root.querySelector('#arep-next').addEventListener('click', ()=>{ _vm++; if(_vm>11){_vm=0;_vy++} root.querySelector('#arep-lbl').textContent=`${moName(_vm)} ${_vy}`; });
  root.querySelector('#arep-load').addEventListener('click', ()=> _loadReport(root));
  root.querySelector('#arep-refresh').addEventListener('click', ()=> _init(root));
  root.querySelector('#arep-excel').addEventListener('click', ()=> _exportExcel());
  root.querySelector('#arep-pdf').addEventListener('click',   ()=> _exportPDF(root));

  await _init(root);
}

async function _init(root) {
  try {
    const snap = await getDocs(query(collection(db,'messes'), orderBy('createdAt','desc')));
    _messes    = snap.docs.map(d=>({id:d.id,...d.data()}));
    const sel  = root.querySelector('#arep-mess-sel');
    if (sel) {
      const prev = sel.value;
      sel.innerHTML = `<option value="">— মেস নির্বাচন করুন —</option>` +
        _messes.map(m=>`<option value="${m.id}">${_e(m.name||'অজানা')} ${m.plan==='paid'?'⭐':''}</option>`).join('');
      if (prev) sel.value = prev;
    }
  } catch(err) { console.error(err); }
}

async function _loadReport(root) {
  const messId = root.querySelector('#arep-mess-sel')?.value;
  if (!messId) { root.querySelector('#arep-body').innerHTML =
    '<div style="padding:20px;text-align:center;color:#b83030">মেস নির্বাচন করুন</div>'; return; }

  const mess       = _messes.find(m=>m.id===messId) || {};
  const monthStr   = `${_vy}-${pad(_vm+1)}`;
  const body       = root.querySelector('#arep-body');
  body.innerHTML   = '<div style="padding:30px;text-align:center;color:#4a7055">লোড হচ্ছে…</div>';

  try {
    const { start, end } = monthDocIdRange(_vy, _vm);
    const { start:dStart, end:dEnd } = monthDateRange(_vy, _vm);
    const [mSnap, allMeals, expSnap, depSnap] = await Promise.all([
      getDocs(collection(db,'messes',messId,'members')),
      getDocs(query(
        collection(db,'messes',messId,'meals'),
        where(documentId(), '>=', start),
        where(documentId(), '<', end)
      )),
      getDocs(query(collection(db,'messes',messId,'expenses'),
        where('status','==','approved'), where('date','>=',dStart), where('date','<',dEnd))),
      getDocs(query(collection(db,'messes',messId,'deposits'),
        where('status','==','approved'), where('date','>=',dStart), where('date','<',dEnd))),
    ]);

    _members  = mSnap.docs.map(d=>({uid:d.id,...d.data()}))
      .sort((a,b)=>(a.joinedAt?.seconds||0)-(b.joinedAt?.seconds||0));
    _meals    = {};
    allMeals.forEach(d=>{ _meals[d.id]=d.data(); });
    _expenses = expSnap.docs.map(d=>d.data()).filter(e=>e.date?.startsWith(monthStr));
    _deposits = depSnap.docs.map(d=>d.data()).filter(d=>d.date?.startsWith(monthStr));

    let grandMeals=0;
    const memberData = _members.map(m=>{
      let ml=0, gl=0;
      Object.entries(_meals).forEach(([key,data])=>{
        if(key.endsWith('_'+m.uid)){
          ml+=(data.slots||[]).filter(Boolean).length;
          gl+=(data.guestSlots||[]).filter(Boolean).length;
        }
      });
      const all=ml+gl; grandMeals+=all;
      const dep=_deposits.filter(d=>d.memberId===m.uid).reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
      return {...m,meals:ml,guest:gl,all,dep};
    });

    const totalBazar   = _expenses.reduce((s,e)=>s+(parseFloat(e.amount)||0),0);
    const totalDeposit = _deposits.reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
    const mealRate     = grandMeals>0 ? totalBazar/grandMeals : 0;
    memberData.forEach(m=>{ m.cost=m.all*mealRate; m.balance=m.dep-m.cost; });

    body.innerHTML = `
<div class="g4" style="margin-bottom:14px">
  <div class="sc sg"><div class="sl">মোট মিল</div><div class="sv">${grandMeals||'০'}</div></div>
  <div class="sc sa"><div class="sl">মিল রেট</div><div class="sv">${takaF(mealRate)}</div><div class="ss">প্রতি মিল</div></div>
  <div class="sc sc-blue"><div class="sl">মোট বাজার</div><div class="sv">${taka(totalBazar)}</div></div>
  <div class="sc sr"><div class="sl">মোট জমা</div><div class="sv">${taka(totalDeposit)}</div></div>
</div>

<div class="card" style="margin-bottom:14px">
  <div class="ch"><h3>👥 সদস্য ভিত্তিক হিসাব — ${_e(mess.name||'')} · ${moName(_vm)} ${_vy}</h3></div>
  <div style="overflow-x:auto">
    <table class="dt">
    <thead><tr>
      <th class="tl">সদস্য</th><th>মিল</th><th>Guest</th>
      <th>মোট মিল</th><th>মিল খরচ</th><th>জমা</th><th>ব্যালেন্স</th>
    </tr></thead>
    <tbody>
    ${memberData.map(m=>`<tr>
      <td class="tl" style="font-weight:700">${_e(m.name||m.email)}</td>
      <td>${m.meals}</td><td>${m.guest||'—'}</td><td style="font-weight:700">${m.all}</td>
      <td style="font-family:var(--mono)">${takaF(m.cost)}</td>
      <td style="font-family:var(--mono)">${taka(m.dep)}</td>
      <td style="font-weight:700;font-family:var(--mono);color:${m.balance>=0?'var(--g1)':'var(--r1)'}">
        ${takaF(m.balance)}
      </td>
    </tr>`).join('')}
    <tr class="tf">
      <td class="tl">মোট</td><td colspan="2"></td><td>${grandMeals}</td>
      <td>${takaF(totalBazar)}</td><td>${taka(totalDeposit)}</td>
      <td style="color:${totalDeposit-totalBazar>=0?'var(--g1)':'var(--r1)'}">
        ${takaF(totalDeposit-totalBazar)}
      </td>
    </tr>
    </tbody>
    </table>
  </div>
</div>

${_expenses.length ? `
<div class="card">
  <div class="ch"><h3>🛒 বাজারের তালিকা</h3><span style="font-weight:700;color:var(--g1)">${taka(totalBazar)}</span></div>
  <div style="overflow-x:auto">
    <table class="dt">
    <thead><tr><th class="tl">তারিখ</th><th class="tl">আইটেম</th><th class="tl">যোগ করেছেন</th><th>পরিমাণ</th></tr></thead>
    <tbody>
    ${_expenses.map(e=>`<tr>
      <td class="tl">${e.date||'—'}</td>
      <td class="tl">${_e(e.item||'')}${e.note?`<span style="color:var(--ink4)"> (${_e(e.note)})</span>`:''}</td>
      <td class="tl">${_e(e.addedByName||'—')}</td>
      <td style="font-family:var(--mono);font-weight:700">${taka(e.amount)}</td>
    </tr>`).join('')}
    </tbody>
    </table>
  </div>
</div>` : ''}`;

    // Store for export
    root._repData = { mess, memberData, mealRate, totalBazar, totalDeposit, grandMeals };
    root.querySelector('#arep-excel').style.display='';
    root.querySelector('#arep-pdf').style.display='';

  } catch(err) {
    body.innerHTML = `<div style="padding:20px;text-align:center;color:#b83030">⚠️ ${_e(err.message)}</div>`;
    console.error(err);
  }
}

function _exportExcel() {
  if(!window.XLSX) return;
  const d = document.querySelector('#arep-body')?._repData;
  // use module-level variables
  exportExcel({
    messName: _messes.find(m=>m.id===document.querySelector('#arep-mess-sel')?.value)?.name||'মেস',
    month: _vm, year: _vy,
    members: _members, meals: _meals,
    expenses: _expenses, deposits: _deposits,
    profile: { uid:'__admin__', name:'Admin' },
    isMessTab: true,
  });
}

function _exportPDF(root) {
  const messId = root.querySelector('#arep-mess-sel')?.value;
  const mess   = _messes.find(m=>m.id===messId)||{};
  exportPDF({
    messName:    mess.name||'মেস',
    messAddress: mess.address||'',
    month: _vm, year: _vy,
    members: _members, meals: _meals,
    expenses: _expenses, deposits: _deposits,
    slots: ['সকাল','দুপুর','রাত'],
    profile: { uid:'__admin__', name:'Admin' },
    isMessTab: true,
  });
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

// emailjs-config.js — EmailJS configuration
// Public Key, Service ID, Template ID

export const EMAILJS_PUBLIC_KEY  = 'YSq8vsmM5Hd00m6bY';
export const EMAILJS_SERVICE_ID  = 'service_cmt3p19';
export const EMAILJS_TEMPLATE_ID = 'template_g18m8tc';

// report-export.js — v16 final: CSS running header/footer, no empty pages

import { taka, takaF, pad, moName, dim } from './utils.js';
import { BRAND_LOGO_BASE64 } from './brand-logo.js';

const B = {
  name:    'Mess Meal Tracker',
  tagline: 'মেসের মিল, বাজার ও হিসাব সব এক জায়গায়',
  dev:     'Exit Excit',
  green:   '#2d8a4e',
  dark:    '#1a5c32',
  accent:  '#e8a838',
  light:   '#f0f7f2',
  border:  '#c8e0d0',
};

export function exportPDF({ messName, messAddress, month, year, members,
  meals, expenses, deposits, slots, profile, isMessTab }) {

  const moLabel   = `${moName(month)} ${year}`;
  const monthPfx  = `${year}_${pad(month+1)}`;
  const generated = new Date().toLocaleDateString('en-GB');
  const uid       = profile?.uid;

  // ── Calculate ──────────────────────────────────────────────────────────
  let grandMeals = 0;
  const memberData = members.map(m => {
    let ml=0, gl=0;
    Object.entries(meals).forEach(([key,data]) => {
      if (key.startsWith(monthPfx) && key.endsWith('_'+m.uid)) {
        ml += (data.slots||[]).filter(Boolean).length;
        gl += (data.guestSlots||[]).filter(Boolean).length;
      }
    });
    const all=ml+gl; grandMeals+=all;
    const dep=deposits.filter(d=>d.memberId===m.uid)
      .reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
    return {...m,meals:ml,guest:gl,all,dep};
  });
  const totalBazar   = expenses.reduce((s,e)=>s+(parseFloat(e.amount)||0),0);
  const totalDeposit = deposits.reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
  const mealRate     = grandMeals>0 ? totalBazar/grandMeals : 0;
  memberData.forEach(m=>{ m.cost=m.all*mealRate; m.balance=m.dep-m.cost; });

  const myData   = !isMessTab ? memberData.find(m=>m.uid===uid)||{} : null;
  const metaName = isMessTab ? (messName||'মেস') : (profile?.name||'—');
  const metaMem  = isMessTab ? `${members.length} জন` : '—';

  const bazarList = isMessTab ? expenses : expenses.filter(e=>e.addedBy===uid);
  const depList   = isMessTab ? deposits : deposits.filter(d=>d.memberId===uid);

  // ── CSS ────────────────────────────────────────────────────────────────
  const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700&family=Roboto:wght@400;700&display=swap');
*{box-sizing:border-box;margin:0;padding:0}

/* ── Page setup with running header & footer ── */
@page{
  size: A4;
  margin-top:    82px;   /* space for header */
  margin-bottom: 52px;   /* space for footer */
  margin-left:   18mm;
  margin-right:  18mm;

  @top-center{
    content: element(running-header);
  }
  @bottom-center{
    content: element(running-footer);
  }
}

html,body{
  font-family:'Hind Siliguri','Roboto',Arial,sans-serif;
  font-size:10.5px;color:#1a1a1a;background:#fff;
}

/* ── Running elements (Pagedjs / prince / chromium fallback) ── */
#r-header{
  position:running(running-header);
  width:100%;
}
#r-footer{
  position:running(running-footer);
  width:100%;
}

/* ── For Chromium (doesn't support CSS running): fixed position ── */
@media print{
  #r-header{
    position:fixed;top:0;left:0;right:0;
    background:#fff;
    padding:0;
    z-index:100;
  }
  #r-footer{
    position:fixed;bottom:0;left:0;right:0;
    z-index:100;
  }
  body{
    padding-top:86px;
    padding-bottom:52px;
  }
  tr{page-break-inside:avoid}
  thead{display:table-header-group}
  .sec{page-break-after:avoid}
}

/* ── HEADER ── */
.hdr-wrap{border-bottom:3px solid ${B.green};background:#fff}
.hdr{
  display:flex;align-items:center;
  padding:8px 18mm;
}
.hdr-logo{
  width:46px;height:46px;margin-right:10px;flex-shrink:0;
  background:${B.green};border-radius:9px;
  display:flex;align-items:center;justify-content:center;
  font-size:24px;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.hdr-mid{flex:1}
.hdr-title{font-size:18px;font-weight:700;color:${B.dark};line-height:1.1}
.hdr-sub{font-size:9.5px;color:#5a8a6a;margin-top:2px}
.hdr-right{text-align:right;flex-shrink:0}
.hdr-report{font-size:13px;font-weight:700;color:#1a1a1a}
.hdr-gen{font-size:9px;color:#888;margin-top:3px}
.accent{height:3px;background:${B.accent};-webkit-print-color-adjust:exact;print-color-adjust:exact}
.meta{
  display:grid;grid-template-columns:1fr 1fr 1fr;
  background:${B.light};
  border-bottom:1.5px solid ${B.border};
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.mc{padding:5px 18mm;border-right:1px solid ${B.border}}
.mc:last-child{border-right:none}
.ml{font-size:9px;font-weight:700;color:${B.green};text-transform:uppercase;letter-spacing:.5px;margin-bottom:1px}
.mv{font-size:12px;font-weight:700;color:${B.dark}}

/* ── FOOTER ── */
.ftr{
  background:${B.green};
  display:flex;align-items:center;justify-content:space-between;
  padding:6px 18mm;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.fl{font-size:11px;font-weight:700;color:#fff}
.fm{font-size:9px;color:rgba(255,255,255,.8);text-align:center}
.fr{display:flex;align-items:center;gap:7px}
.fd{font-size:9px;color:rgba(255,255,255,.8)}
.fd strong{color:${B.accent};font-weight:700}
.flogo{
  width:26px;height:26px;border-radius:5px;
  display:flex;align-items:center;justify-content:center;overflow:hidden;
  background:#fff;
}
.flogo img{ width:100%;height:100%;object-fit:contain; }
.pg{font-size:8px;color:${B.accent};text-align:right;padding:2px 18mm 0;
  -webkit-print-color-adjust:exact;print-color-adjust:exact}

/* ── BODY ── */
.body{padding:14px 0}

/* ── SUMMARY ── */
.sum{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:16px}
.sb2{
  border:1px solid ${B.border};border-radius:6px;
  padding:8px 10px;background:${B.light};
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.sl{font-size:9px;font-weight:700;color:#5a8a6a;text-transform:uppercase;letter-spacing:.3px}
.sv{font-size:17px;font-weight:700;color:${B.dark};margin-top:2px;font-family:'Roboto',sans-serif}
.ss{font-size:9px;margin-top:1px}
.pos{color:#1a6e3a;font-weight:700}
.neg{color:#b83030;font-weight:700}

/* ── SECTION TITLE ── */
.sec{
  font-size:11px;font-weight:700;color:${B.dark};
  border-bottom:2px solid ${B.green};
  padding-bottom:3px;margin:16px 0 8px;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}

/* ── TABLE ── */
table{width:100%;border-collapse:collapse;font-size:10px;margin-bottom:14px}
thead{display:table-header-group}
thead tr{background:${B.green};-webkit-print-color-adjust:exact;print-color-adjust:exact}
thead th{color:#fff;padding:5px 7px;text-align:left;font-weight:700;font-size:9.5px}
th.r,td.r{text-align:right}
th.c,td.c{text-align:center}
tbody tr:nth-child(even){background:#f6fbf8;-webkit-print-color-adjust:exact;print-color-adjust:exact}
tbody td{padding:4px 7px;border-bottom:1px solid #e0ede6;vertical-align:top}
tfoot tr{background:#daeee3;-webkit-print-color-adjust:exact;print-color-adjust:exact}
tfoot td{padding:5px 7px;font-weight:700;border-top:1.5px solid ${B.green}}
.don{
  display:inline-block;width:13px;height:13px;border-radius:50%;
  background:${B.green};color:#fff;font-size:8px;
  text-align:center;line-height:13px;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.doff{
  display:inline-block;width:13px;height:13px;border-radius:50%;
  background:#e8e8e8;border:1px solid #ccc;font-size:8px;
  text-align:center;line-height:13px;
}

/* ── SIGN ── */
.sign{
  display:grid;grid-template-columns:repeat(3,1fr);
  gap:30px;margin-top:24px;padding-top:10px;
  border-top:1px solid ${B.border};
}
.sign-box{text-align:center}
.sign-line{border-bottom:1px solid #555;height:26px;margin-bottom:3px}
.sign-lbl{font-size:9px;color:#4a7055}
`;

  // ── Build body HTML ──────────────────────────────────────────────────────
  let body = `<div class="body">`;

  // Summary cards
  body += `<div class="sum">
<div class="sb2"><div class="sl">মোট মিল</div>
  <div class="sv">${isMessTab?grandMeals:(myData?.all||0)}</div>
  <div class="ss">${isMessTab?'সকল সদস্য':'এই মাসে'}</div></div>
<div class="sb2"><div class="sl">মিল রেট</div>
  <div class="sv">${takaF(mealRate)}</div>
  <div class="ss">প্রতি মিল</div></div>
<div class="sb2"><div class="sl">${isMessTab?'মোট বাজার':'মিল খরচ'}</div>
  <div class="sv">${isMessTab?taka(totalBazar):takaF(myData?.cost||0)}</div></div>
<div class="sb2"><div class="sl">${isMessTab?'মোট জমা':'আমার জমা'}</div>
  <div class="sv">${isMessTab?taka(totalDeposit):taka(myData?.dep||0)}</div>
  ${myData?`<div class="ss ${(myData.balance||0)>=0?'pos':'neg'}">ব্যালেন্স: ${takaF(myData.balance||0)}</div>`:''}
</div></div>`;

  // Member table (mess report) OR Calendar (my report)
  if (isMessTab) {
    body += `<div class="sec">👥 সদস্য ভিত্তিক হিসাব</div>
<table>
<thead><tr>
  <th>সদস্য</th><th class="r">মিল</th><th class="r">Guest</th>
  <th class="r">মোট</th><th class="r">মিল খরচ (৳)</th>
  <th class="r">জমা (৳)</th><th class="r">ব্যালেন্স (৳)</th>
</tr></thead>
<tbody>
${memberData.map(m=>`<tr>
<td style="font-weight:600">${_e(m.name||m.email)}</td>
<td class="r">${m.meals}</td><td class="r">${m.guest||'—'}</td>
<td class="r" style="font-weight:700">${m.all}</td>
<td class="r">৳${m.cost.toFixed(2)}</td>
<td class="r">৳${m.dep.toFixed(2)}</td>
<td class="r ${m.balance>=0?'pos':'neg'}">৳${m.balance.toFixed(2)}</td>
</tr>`).join('')}
</tbody>
<tfoot><tr>
<td>মোট</td><td></td><td></td>
<td class="r">${grandMeals}</td>
<td class="r">৳${totalBazar.toFixed(2)}</td>
<td class="r">৳${totalDeposit.toFixed(2)}</td>
<td class="r ${totalDeposit>=totalBazar?'pos':'neg'}">৳${(totalDeposit-totalBazar).toFixed(2)}</td>
</tr></tfoot>
</table>`;
  } else {
    // My meal calendar
    const sl   = slots||['সকাল','দুপুর','রাত'];
    const days = dim(year, month);
    const pfx  = `${year}_${pad(month+1)}`;
    let total  = 0, rows = '';
    for (let d=1;d<=days;d++){
      const key  = `${pfx}_${pad(d)}_${uid}`;
      const data = meals[key]||{};
      const s    = data.slots||[];
      const g    = (data.guestSlots||[]).filter(Boolean).length;
      const t    = s.filter(Boolean).length+g; total+=t;
      rows+=`<tr>
<td>${d} ${moName(month)}</td>
${sl.map((_,i)=>`<td class="c"><span class="${s[i]?'don':'doff'}">${s[i]?'✓':''}</span></td>`).join('')}
<td class="r">${g||'—'}</td>
<td class="r" style="font-weight:${t?'700':'400'}">${t||'—'}</td>
</tr>`;
    }
    body += `<div class="sec">📅 মিল ক্যালেন্ডার — ${moLabel}</div>
<table>
<thead><tr>
<th>তারিখ</th>
${sl.map(s=>`<th class="c" style="font-size:9px">${_e(s)}</th>`).join('')}
<th class="r">Guest</th><th class="r">মোট</th>
</tr></thead>
<tbody>${rows}</tbody>
<tfoot><tr>
<td colspan="${sl.length+1}">মোট মিল</td>
<td></td><td class="r">${total}</td>
</tr></tfoot>
</table>`;
  }

  // Bazar list
  if (bazarList.length) {
    body += `<div class="sec">🛒 বাজারের তালিকা</div>
<table>
<thead><tr>
<th>তারিখ</th><th>বিভাগ</th><th>আইটেম</th><th>যোগ করেছেন</th><th class="r">পরিমাণ (৳)</th>
</tr></thead>
<tbody>
${bazarList.map(e=>`<tr>
<td>${e.date||'—'}</td>
<td>${_e(e.category||'')}</td>
<td>${_e(e.item||'')}${e.note?`<br><span style="color:#6a8a74;font-size:9px">${_e(e.note)}</span>`:''}</td>
<td>${_e(e.addedByName||'—')}</td>
<td class="r" style="font-weight:700">৳${parseFloat(e.amount||0).toFixed(2)}</td>
</tr>`).join('')}
</tbody>
<tfoot><tr>
<td colspan="4">মোট বাজার</td>
<td class="r">৳${bazarList.reduce((s,e)=>s+(parseFloat(e.amount)||0),0).toFixed(2)}</td>
</tr></tfoot>
</table>`;
  }

  // Deposit list
  if (depList.length) {
    body += `<div class="sec">💰 ডিপোজিট তালিকা</div>
<table>
<thead><tr>
<th>তারিখ</th><th>সদস্য</th><th>নোট</th><th class="r">পরিমাণ (৳)</th>
</tr></thead>
<tbody>
${depList.map(d=>`<tr>
<td>${d.date||'—'}</td>
<td>${_e(d.memberName||'—')}</td>
<td>${_e(d.note||'')}</td>
<td class="r" style="font-weight:700">৳${parseFloat(d.amount||0).toFixed(2)}</td>
</tr>`).join('')}
</tbody>
<tfoot><tr>
<td colspan="3">মোট জমা</td>
<td class="r">৳${depList.reduce((s,d)=>s+(parseFloat(d.amount)||0),0).toFixed(2)}</td>
</tr></tfoot>
</table>`;
  }

  // Signature
  body += `<div class="sign">
<div class="sign-box"><div class="sign-line"></div><div class="sign-lbl">Manager Signature</div></div>
<div class="sign-box"><div class="sign-line"></div><div class="sign-lbl">Member Representative</div></div>
<div class="sign-box"><div class="sign-line"></div><div class="sign-lbl">Date</div></div>
</div>`;

  body += `</div>`; // .body

  // ── Full HTML ─────────────────────────────────────────────────────────────
  const html = `<!DOCTYPE html>
<html lang="bn"><head>
<meta charset="UTF-8"/>
<title>${_e(metaName)} — ${moLabel}</title>
<style>${CSS}</style>
</head><body>

<!-- Running header — fixed on every printed page -->
<div id="r-header">
  <div class="hdr-wrap">
    <div class="hdr">
      <div class="hdr-logo">🍽️</div>
      <div class="hdr-mid">
        <div class="hdr-title">${_e(B.name)}</div>
        <div class="hdr-sub">${_e(B.tagline)}</div>
      </div>
      <div class="hdr-right">
        <div class="hdr-report">MONTHLY REPORT</div>
        <div class="hdr-gen">Generated: ${generated}</div>
      </div>
    </div>
    <div class="accent"></div>
    <div class="meta">
      <div class="mc">
        <div class="ml">Mess Name / Name:</div>
        <div class="mv">${_e(metaName)}</div>
        ${messAddress?`<div style="font-size:9px;color:#5a8a6a">${_e(messAddress)}</div>`:''}
      </div>
      <div class="mc">
        <div class="ml">Month / Year:</div>
        <div class="mv">${moLabel}</div>
      </div>
      <div class="mc">
        <div class="ml">Total Members:</div>
        <div class="mv">${metaMem}</div>
      </div>
    </div>
  </div>
</div>

<!-- Running footer — fixed on every printed page -->
<div id="r-footer">
  <div class="pg">Page <span class="pageNumber"></span></div>
  <div class="ftr">
    <div class="fl">${_e(B.name)}</div>
    <div class="fm">Smart Mess Management Solution</div>
    <div class="fr">
      <div class="fd">Developed by <strong>${_e(B.dev)}</strong></div>
      <div class="flogo"><img src="${BRAND_LOGO_BASE64}" alt="Exit Excit"/></div>
    </div>
  </div>
</div>

<!-- Main content -->
${body}

<script>
// Inject page numbers for Chromium print
window.addEventListener('beforeprint', () => {
  document.querySelectorAll('.pageNumber').forEach((el, i) => {
    el.textContent = i + 1;
  });
});
<\/script>
</body></html>`;

  const w = window.open('','_blank','width=960,height=820');
  if (!w) { alert('Popup blocked — allow করুন'); return; }
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(() => w.print(), 1000);
}

// ── Excel Export ──────────────────────────────────────────────────────────────
export function exportExcel({ messName, month, year, members, meals,
  expenses, deposits, profile, isMessTab }) {

  if (!window.XLSX) { alert('XLSX লোড হয়নি'); return; }

  const moLabel  = `${moName(month)} ${year}`;
  const monthPfx = `${year}_${pad(month+1)}`;
  const uid      = profile?.uid;

  let grandMeals = 0;
  const memberData = members.map(m => {
    let ml=0, gl=0;
    Object.entries(meals).forEach(([key,data]) => {
      if (key.startsWith(monthPfx) && key.endsWith('_'+m.uid)) {
        ml += (data.slots||[]).filter(Boolean).length;
        gl += (data.guestSlots||[]).filter(Boolean).length;
      }
    });
    const all=ml+gl; grandMeals+=all;
    const dep=deposits.filter(d=>d.memberId===m.uid)
      .reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
    return {...m,meals:ml,guest:gl,all,dep};
  });
  const totalBazar   = expenses.reduce((s,e)=>s+(parseFloat(e.amount)||0),0);
  const totalDeposit = deposits.reduce((s,d)=>s+(parseFloat(d.amount)||0),0);
  const mealRate     = grandMeals>0?totalBazar/grandMeals:0;
  memberData.forEach(m=>{ m.cost=m.all*mealRate; m.balance=m.dep-m.cost; });

  const wb = window.XLSX.utils.book_new();
  const br = [`${B.name} — ${isMessTab?'মেস রিপোর্ট':'আমার রিপোর্ট'} — ${moLabel}`,
              `Generated: ${new Date().toLocaleDateString('en-GB')} | Developed by ${B.dev}`,[]];

  // Sheet 1 — Summary
  const target = isMessTab ? memberData : [memberData.find(m=>m.uid===uid)||{}];
  const ws1 = window.XLSX.utils.aoa_to_sheet([
    ...br,
    ['সদস্য','মিল','Guest','মোট মিল','মিল খরচ (৳)','জমা (৳)','ব্যালেন্স (৳)'],
    ...target.map(m=>[m.name||m.email||'—',m.meals||0,m.guest||0,m.all||0,
      +((m.cost||0).toFixed(2)),m.dep||0,+((m.balance||0).toFixed(2))]),
    [],
    ['','','','মোট',+totalBazar.toFixed(2),+totalDeposit.toFixed(2),+(totalDeposit-totalBazar).toFixed(2)],
    [],
    [`মিল রেট: ৳${mealRate.toFixed(2)} / মিল | মোট মিল: ${grandMeals}`],
  ]);
  ws1['!cols']=[{wch:20},{wch:8},{wch:8},{wch:10},{wch:14},{wch:12},{wch:14}];
  window.XLSX.utils.book_append_sheet(wb,ws1,'সারসংক্ষেপ');

  // Sheet 2 — Bazar
  const bl = isMessTab?expenses:expenses.filter(e=>e.addedBy===uid);
  const ws2 = window.XLSX.utils.aoa_to_sheet([
    ...br,
    ['তারিখ','বিভাগ','আইটেম','নোট','যোগ করেছেন','পরিমাণ (৳)'],
    ...bl.map(e=>[e.date||'',e.category||'',e.item||'',e.note||'',e.addedByName||'',parseFloat(e.amount)||0]),
    [],['','','','','মোট',+bl.reduce((s,e)=>s+(parseFloat(e.amount)||0),0).toFixed(2)],
  ]);
  ws2['!cols']=[{wch:12},{wch:12},{wch:22},{wch:16},{wch:16},{wch:12}];
  window.XLSX.utils.book_append_sheet(wb,ws2,'বাজার');

  // Sheet 3 — Deposit
  const dl = isMessTab?deposits:deposits.filter(d=>d.memberId===uid);
  const ws3 = window.XLSX.utils.aoa_to_sheet([
    ...br,
    ['তারিখ','সদস্য','নোট','পরিমাণ (৳)'],
    ...dl.map(d=>[d.date||'',d.memberName||'',d.note||'',parseFloat(d.amount)||0]),
    [],['','','মোট',+dl.reduce((s,d)=>s+(parseFloat(d.amount)||0),0).toFixed(2)],
  ]);
  ws3['!cols']=[{wch:12},{wch:18},{wch:22},{wch:12}];
  window.XLSX.utils.book_append_sheet(wb,ws3,'ডিপোজিট');

  // Sheet 4 — Calendar (my report)
  if (!isMessTab) {
    const days=dim(year,month); const pfx=`${year}_${pad(month+1)}`;
    const sl=['সকাল','দুপুর','রাত'];
    const rows=[...br,['তারিখ',...sl,'Guest','মোট']];
    for(let d=1;d<=days;d++){
      const key=`${pfx}_${pad(d)}_${uid}`;
      const data=meals[key]||{};
      const s=data.slots||[]; const g=(data.guestSlots||[]).filter(Boolean).length;
      rows.push([`${d} ${moName(month)}`,...s.map(v=>v?'✓':''),g||0,s.filter(Boolean).length+g]);
    }
    const ws4=window.XLSX.utils.aoa_to_sheet(rows);
    ws4['!cols']=[{wch:14},...sl.map(()=>({wch:8})),{wch:8},{wch:8}];
    window.XLSX.utils.book_append_sheet(wb,ws4,'মিল ক্যালেন্ডার');
  }

  const fname=`${isMessTab?(messName||'mess'):(profile?.name||'user')}-${moName(month)}-${year}.xlsx`;
  window.XLSX.writeFile(wb, fname.replace(/\s+/g,'-'));
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

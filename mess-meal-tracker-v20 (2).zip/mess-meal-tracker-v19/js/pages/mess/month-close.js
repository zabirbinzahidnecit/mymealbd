// month-close.js — v11: data lock enforced, currentProfile import fixed

import { db } from '../../firebase.js';
import { toast, ld, uld, taka, takaF, pad, moName } from '../../utils.js';
import { getCachedMembers } from '../../members-cache.js';
import {
  collection, getDocs, doc, setDoc, getDoc,
  query, where, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _ctx={}, _vy=TODAY.getFullYear(), _vm=TODAY.getMonth();

export async function render(root, ctx) {
  _ctx = ctx;

  if (!['mess-admin','mess-co-admin'].includes(ctx.myMessRole)) {
    root.innerHTML = `
<div class="card">
  <div class="cb" style="text-align:center;padding:30px;color:var(--ink3)">
    <div style="font-size:32px;margin-bottom:8px">🔒</div>
    <p>এই পেজ শুধুমাত্র Mess Admin এর জন্য।</p>
  </div>
</div>`;
    return;
  }

  root.innerHTML = `
<div>
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <button class="btn btn-ghost btn-sm" id="mc-prev">◀</button>
    <span style="font-size:14px;font-weight:700;min-width:130px;text-align:center" id="mc-lbl"></span>
    <button class="btn btn-ghost btn-sm" id="mc-next">▶</button>
    <button class="btn btn-ghost btn-sm" id="mc-refresh" style="margin-left:auto">🔄</button>
  </div>

  <div id="mc-status-banner" style="margin-bottom:14px"></div>

  <div class="g4" style="margin-bottom:14px">
    <div class="sc sg"><div class="sl">মোট মিল</div><div class="sv" id="mc-total-meal">—</div></div>
    <div class="sc sa"><div class="sl">মিল রেট</div><div class="sv" id="mc-rate">—</div><div class="ss">প্রতি মিল</div></div>
    <div class="sc sc-blue"><div class="sl">মোট বাজার</div><div class="sv" id="mc-bazar">—</div></div>
    <div class="sc sr"><div class="sl">মোট জমা</div><div class="sv" id="mc-dep">—</div></div>
  </div>

  <div class="card" style="margin-bottom:14px">
    <div class="ch"><h3>💸 কে কাকে কত দেবে</h3></div>
    <div class="cb" id="mc-settlement">লোড হচ্ছে…</div>
  </div>

  <div class="card" style="margin-bottom:14px">
    <div class="ch">
      <h3>👥 সদস্যভিত্তিক হিসাব</h3>
      <button class="btn btn-p btn-sm" id="mc-export">📥 Excel</button>
    </div>
    <div style="overflow-x:auto" id="mc-table">লোড হচ্ছে…</div>
  </div>

  <div id="mc-close-area"></div>
</div>

<style>
.settle-row{display:flex;align-items:center;gap:10px;padding:10px;
  background:var(--r4);border:1px solid var(--r3);border-radius:10px;margin-bottom:8px;flex-wrap:wrap}
.settle-from{font-weight:700;color:var(--r1);font-size:13px}
.settle-to{font-weight:700;color:var(--g1);font-size:13px}
.settle-amt{font-family:var(--mono);font-weight:700;font-size:14px;color:var(--ink);margin-left:auto;flex-shrink:0}
</style>`;

  root.querySelector('#mc-prev').addEventListener('click', ()=>{ _vm--; if(_vm<0){_vm=11;_vy--} _load(root); });
  root.querySelector('#mc-next').addEventListener('click', ()=>{ _vm++; if(_vm>11){_vm=0;_vy++} _load(root); });
  root.querySelector('#mc-refresh').addEventListener('click', ()=> _load(root));
  root.querySelector('#mc-export').addEventListener('click', ()=> _export(root));

  root.querySelector('#mc-lbl').textContent = `${moName(_vm)} ${_vy}`;
  await _load(root);
}

async function _load(root) {
  root.querySelector('#mc-lbl').textContent = `${moName(_vm)} ${_vy}`;
  ld(`${moName(_vm)} ${_vy} এর হিসাব লোড হচ্ছে…`);

  try {
    const monthStr = `${_vy}-${pad(_vm+1)}`;
    const monthPfx = `${_vy}_${pad(_vm+1)}`;
    const closeKey = `${_vy}_${pad(_vm+1)}`;

    const closeSnap = await getDoc(doc(db,'messes',_ctx.messId,'monthClose',closeKey));
    const isClosed  = closeSnap.exists();

    // Banner
    const banner = root.querySelector('#mc-status-banner');
    if (banner) {
      banner.innerHTML = isClosed
        ? `<div style="background:var(--g7);border:1px solid var(--g5);border-radius:10px;
            padding:10px 14px;display:flex;align-items:center;gap:10px">
            <span style="font-size:20px">✅</span>
            <div>
              <p style="font-size:13px;font-weight:700;color:var(--g1)">${moName(_vm)} ${_vy} — বন্ধ করা হয়েছে</p>
              <p style="font-size:11px;color:var(--ink3)">বন্ধ করেছেন: ${_e(closeSnap.data().closedByName||'Admin')}</p>
              <p style="font-size:11px;color:var(--r1);margin-top:4px;font-weight:600">
                ⚠️ এই মাসের Meal, Bazar ও Deposit আর পরিবর্তন করা যাবে না।
              </p>
            </div>
          </div>`
        : `<div style="background:var(--a4);border:1px solid var(--a3);border-radius:10px;
            padding:10px 14px;font-size:12px;color:var(--a0)">
            ⚠️ এই মাস এখনো বন্ধ করা হয়নি।
            হিসাব চূড়ান্ত করতে "মাস বন্ধ করুন" বোতামে click করুন।
          </div>`;
    }

    // If closed, load from saved snapshot
    if (isClosed) {
      const saved = closeSnap.data();
      const _sv=(id,v)=>{ const el=root.querySelector('#'+id); if(el) el.textContent=v; };
      _sv('mc-total-meal', saved.grandMeals||0);
      _sv('mc-rate',  takaF(saved.mealRate||0));
      _sv('mc-bazar', taka(saved.totalBazar||0));
      _sv('mc-dep',   taka(saved.totalDep||0));

      const settleEl = root.querySelector('#mc-settlement');
      if (settleEl) {
        settleEl.innerHTML = (saved.settlements||[]).length
          ? saved.settlements.map(s=>`
<div class="settle-row">
  <span class="settle-from">😟 ${_e(s.from)}</span>
  <span style="color:var(--ink3)">→</span>
  <span class="settle-to">😊 ${_e(s.to)}</span>
  <span class="settle-amt">${takaF(s.amount)}</span>
</div>`).join('')
          : '<p style="color:var(--g1);font-weight:600">✅ সব সমান!</p>';
      }

      const tableEl = root.querySelector('#mc-table');
      if (tableEl) {
        tableEl.innerHTML = `
<table class="dt">
<thead><tr>
  <th class="tl">সদস্য</th><th>মোট মিল</th><th>মিল খরচ</th><th>জমা</th><th>ব্যালেন্স</th>
</tr></thead>
<tbody>
${(saved.memberSummary||[]).map(m=>`<tr>
  <td class="tl" style="font-weight:600">${_e(m.name||'')}</td>
  <td>${m.meals}</td>
  <td style="font-family:var(--mono)">${takaF(m.cost)}</td>
  <td style="font-family:var(--mono)">${taka(m.dep)}</td>
  <td style="font-weight:700;font-family:var(--mono);color:${m.balance>=0?'var(--g1)':'var(--r1)'}">
    ${takaF(m.balance)}
  </td>
</tr>`).join('')}
</tbody>
</table>`;
      }
      root._mcData = { ...saved, memberData: saved.memberSummary||[], settlements: saved.settlements||[] };
      root.querySelector('#mc-close-area').innerHTML = '';
      return;
    }

    // Not closed — load fresh
    const [members, mealSnap, expSnap, depSnap] = await Promise.all([
      getCachedMembers(_ctx.messId, { force:true }),
      getDocs(collection(db,'messes',_ctx.messId,'meals')),
      getDocs(query(collection(db,'messes',_ctx.messId,'expenses'), where('status','==','approved'))),
      getDocs(query(collection(db,'messes',_ctx.messId,'deposits'), where('status','==','approved'))),
    ]);

    const meals    = {};
    mealSnap.forEach(d=>{ if(d.id.startsWith(monthPfx)) meals[d.id]=d.data(); });

    let totalBazar=0, totalDep=0;
    expSnap.forEach(d=>{ if(d.data().date?.startsWith(monthStr)) totalBazar+=parseFloat(d.data().amount)||0; });
    depSnap.forEach(d=>{ if(d.data().date?.startsWith(monthStr)) totalDep+=parseFloat(d.data().amount)||0; });

    let grandMeals=0;
    const memberData = members.map(m=>{
      let ml=0, gl=0;
      Object.entries(meals).forEach(([key,data])=>{
        if(key.endsWith('_'+m.uid)){
          ml+=(data.slots||[]).filter(Boolean).length;
          gl+=(data.guestSlots||[]).filter(Boolean).length;
        }
      });
      const all=ml+gl; grandMeals+=all;
      const dep=depSnap.docs.filter(d=>d.data().memberId===m.uid&&d.data().date?.startsWith(monthStr))
        .reduce((s,d)=>s+(parseFloat(d.data().amount)||0),0);
      return {...m, meals:ml, guest:gl, all, dep};
    });

    const rate=grandMeals>0 ? totalBazar/grandMeals : 0;
    memberData.forEach(m=>{ m.cost=m.all*rate; m.balance=m.dep-m.cost; });

    const _sv=(id,v)=>{ const el=root.querySelector('#'+id); if(el) el.textContent=v; };
    _sv('mc-total-meal', grandMeals);
    _sv('mc-rate',  takaF(rate));
    _sv('mc-bazar', taka(totalBazar));
    _sv('mc-dep',   taka(totalDep));

    const settlements = _calcSettlements(memberData);
    const settleEl    = root.querySelector('#mc-settlement');
    if (settleEl) {
      settleEl.innerHTML = settlements.length
        ? settlements.map(s=>`
<div class="settle-row">
  <span class="settle-from">😟 ${_e(s.from)}</span>
  <span style="color:var(--ink3)">→ দেবে →</span>
  <span class="settle-to">😊 ${_e(s.to)}</span>
  <span class="settle-amt">${takaF(s.amount)}</span>
</div>`).join('')
        : '<p style="color:var(--g1);font-size:13px;font-weight:600">✅ সব হিসাব সমান!</p>';
    }

    const tableEl = root.querySelector('#mc-table');
    if (tableEl) {
      tableEl.innerHTML = `
<table class="dt">
<thead><tr>
  <th class="tl">সদস্য</th><th>মিল</th><th>Guest</th><th>মোট</th>
  <th>মিল খরচ</th><th>জমা</th><th>ব্যালেন্স</th>
</tr></thead>
<tbody>
${memberData.map(m=>`<tr>
  <td class="tl" style="font-weight:600">${_e(m.name||m.email)}</td>
  <td>${m.meals}</td><td>${m.guest||'—'}</td><td style="font-weight:700">${m.all}</td>
  <td style="font-family:var(--mono)">${takaF(m.cost)}</td>
  <td style="font-family:var(--mono)">${taka(m.dep)}</td>
  <td style="font-weight:700;font-family:var(--mono);color:${m.balance>=0?'var(--g1)':'var(--r1)'}">
    ${takaF(m.balance)}
  </td>
</tr>`).join('')}
<tr class="tf">
  <td class="tl">মোট</td><td colspan="2"></td><td>${grandMeals}</td>
  <td>${takaF(totalBazar)}</td><td>${taka(totalDep)}</td>
  <td style="color:${totalDep-totalBazar>=0?'var(--g1)':'var(--r1)'}">
    ${takaF(totalDep-totalBazar)}
  </td>
</tr>
</tbody>
</table>`;
    }

    root._mcData = { memberData, rate, totalBazar, totalDep, grandMeals, settlements };

    const closeArea = root.querySelector('#mc-close-area');
    if (closeArea) {
      closeArea.innerHTML = `
<div class="card" style="border-color:var(--r3)">
  <div class="ch"><h3 style="color:var(--r1)">🔒 মাস বন্ধ করুন</h3></div>
  <div class="cb">
    <p style="font-size:12px;color:var(--ink3);margin-bottom:12px;line-height:1.6">
      মাস বন্ধ করলে এই মাসের final হিসাব save হবে।
      <strong style="color:var(--r1)">পরে কেউ Meal, Bazar বা Deposit পরিবর্তন করতে পারবে না।</strong>
      নতুন মাস থেকে fresh start হবে।
    </p>
    <button class="btn btn-danger btn-sm" id="mc-close-btn">
      🔒 ${moName(_vm)} ${_vy} বন্ধ করুন
    </button>
  </div>
</div>`;
      root.querySelector('#mc-close-btn').addEventListener('click', ()=>
        _closeMonth(root, memberData, rate, totalBazar, totalDep, grandMeals, settlements)
      );
    }

  } catch(err) {
    toast('লোড ব্যর্থ: '+err.message,'er');
    console.error(err);
  } finally { uld(); }
}

function _calcSettlements(members) {
  const bal = members.map(m=>({name:m.name||m.email, bal:m.balance}));
  const debts = bal.filter(m=>m.bal<-0.01).sort((a,b)=>a.bal-b.bal);
  const creds = bal.filter(m=>m.bal>0.01).sort((a,b)=>b.bal-a.bal);
  const res=[]; let di=0,ci=0;
  while(di<debts.length&&ci<creds.length){
    const d=debts[di], c=creds[ci];
    const amt=Math.min(Math.abs(d.bal),c.bal);
    if(amt>0.01) res.push({from:d.name,to:c.name,amount:parseFloat(amt.toFixed(2))});
    d.bal+=amt; c.bal-=amt;
    if(Math.abs(d.bal)<0.01)di++;
    if(Math.abs(c.bal)<0.01)ci++;
  }
  return res;
}

async function _closeMonth(root, memberData, rate, totalBazar, totalDep, grandMeals, settlements) {
  if (!window.confirm(`${moName(_vm)} ${_vy} মাস বন্ধ করবেন?\nএই কাজ ফেরানো যাবে না।`)) return;
  ld('মাস বন্ধ হচ্ছে…');
  try {
    const closeKey = `${_vy}_${pad(_vm+1)}`;
    await setDoc(doc(db,'messes',_ctx.messId,'monthClose',closeKey), {
      year:_vy, month:_vm, grandMeals, totalBazar, totalDep, mealRate:rate,
      memberSummary: memberData.map(m=>({
        uid:m.uid, name:m.name||m.email,
        meals:m.all, cost:m.cost, dep:m.dep, balance:m.balance
      })),
      settlements,
      closedBy:     _ctx.profile.uid,
      closedByName: _ctx.profile.name||'Admin',
      closedAt:     serverTimestamp(),
    });
    toast(`${moName(_vm)} ${_vy} মাস বন্ধ করা হয়েছে ✓`,'ok');
    await _load(root);
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
  finally { uld(); }
}

function _export(root) {
  if (!window.XLSX) { toast('XLSX লোড হয়নি','er'); return; }
  const d = root._mcData;
  if (!d) { toast('আগে লোড করুন','er'); return; }
  const sheet = [
    [`${moName(_vm)} ${_vy} — মাসিক হিসাব`],
    [`মোট মিল: ${d.grandMeals} | মিল রেট: ${takaF(d.mealRate||d.rate)} | বাজার: ${taka(d.totalBazar)} | জমা: ${taka(d.totalDep)}`],
    [],
    ['সদস্য','মোট মিল','মিল খরচ','জমা','ব্যালেন্স'],
    ...(d.memberData||[]).map(m=>[m.name||m.email, m.meals||m.all, parseFloat((m.cost||0).toFixed(2)), m.dep||0, parseFloat((m.balance||0).toFixed(2))]),
    [],['--- Payment Settlement ---'],['থেকে','প্রাপক','পরিমাণ'],
    ...(d.settlements||[]).map(s=>[s.from,s.to,s.amount]),
  ];
  const wb=window.XLSX.utils.book_new();
  window.XLSX.utils.book_append_sheet(wb,window.XLSX.utils.aoa_to_sheet(sheet),`${moName(_vm)}-${_vy}`);
  window.XLSX.writeFile(wb,`month-close-${moName(_vm)}-${_vy}.xlsx`);
  toast('Excel download হচ্ছে…','ok');
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

// mess-shell.js — v11: fixed desktop layout (uses .sb/.main CSS classes), all bugs fixed

import { db } from '../../firebase.js';
import { logout, LOCAL_VERSION } from '../../auth.js';
import { toast, ld, uld, escapeHtml as _e } from '../../utils.js';
import { isPaid, isPlanExpired, showUpgradeModal } from '../../plan.js';
import {
  doc, getDoc, onSnapshot, collection, query, where
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

export let messId       = null;
export let messData     = null;
export let messSettings = { slots:['সকাল','দুপুর','রাত'], cutoffHour:10, maxMealsPerDay:3, rentEnabled:false, lang:'bn' };
export let myMessRole   = null;

export const isMessAdmin   = () => myMessRole === 'mess-admin';
export const isMessCoAdmin = () => ['mess-admin','mess-co-admin'].includes(myMessRole);

const NAV = [
  { id:'home',        ico:'🏠', lbl:'হোম' },
  { id:'meal',        ico:'🍚', lbl:'মিল এন্ট্রি' },
  { id:'bazar',       ico:'🛒', lbl:'বাজার হিসাব' },
  { id:'deposit',     ico:'💰', lbl:'ডিপোজিট' },
  { id:'report',      ico:'📊', lbl:'রিপোর্ট / আমার রিপোর্ট' },
  { id:'notice',      ico:'📢', lbl:'নোটিশ বোর্ড' },
  { id:'poll',        ico:'🗳️', lbl:'Meal Poll' },
  { id:'requests',    ico:'✅', lbl:'অনুমোদন', badge:true },
  { id:'members',     ico:'👥', lbl:'সদস্য' },
  { id:'rent',        ico:'🏡', lbl:'বাড়ি ভাড়া', rentOnly:true },
  { id:'month-close', ico:'🔒', lbl:'মাস বন্ধ', adminOnly:true },
  { id:'profile',     ico:'👤', lbl:'আমার প্রোফাইল' },
  { id:'billing',     ico:'💳', lbl:'বিলিং', adminOnly:true },
  { id:'contact',     ico:'📩', lbl:'Contact Us' },
  { id:'help',        ico:'❓', lbl:'Help / FAQ' },
  { id:'settings',    ico:'⚙️', lbl:'সেটিংস', adminOnly:true },
  { id:'bua-view',    ico:'🍚', lbl:'আজকের মিল' },
];

const FILE_MAP = {
  'home':'home','meal':'meal','bazar':'bazar','deposit':'deposit',
  'report':'report','notice':'notice','poll':'poll',
  'requests':'requests','members':'members','rent':'rent',
  'month-close':'month-close','profile':'profile','settings':'settings',
  'billing':'billing',
  'contact':'contact','help':'help','bua-view':'bua-view',
};

let _profile = null;

export async function render(root, { profile }) {
  _profile  = profile;
  messId    = profile.currentMessId;

  // ✅ boot-time prefetch — messId জানার সাথে সাথেই Home-এর ডেটা আনা শুরু,
  // mess context (settings/role) লোড হওয়ার জন্য অপেক্ষা না করেই সমান্তরালে।
  // পরে navigate('home') এ এই promise-টা home.js কে পাস করে দেওয়া হয়।
  const _homePreload = messId
    ? import('./home.js').then(m => m.preloadHomeData(messId, new Date().getFullYear(), new Date().getMonth())).catch(()=>null)
    : null;

  ld('মেস লোড হচ্ছে…');
  await _loadMessContext();
  uld();

  document.body.style.margin  = '0';
  document.body.style.padding = '0';
  root.style.cssText = 'display:block;width:100%';

  root.innerHTML = `
<!-- Sidebar uses global .sb class so CSS media queries work -->
<div class="sb" id="mess-sb" style="position:fixed;top:0;left:0;bottom:0;width:228px;background:#011a0e;display:flex;flex-direction:column;z-index:100;box-shadow:2px 0 16px rgba(0,0,0,.18)">
  <div class="sb-logo">
    <div class="ic">🍽</div>
    <div class="brand" style="min-width:0">
      <h2 id="sb-mess-name">${_e(messData?.name||'মেস')}${
      isPlanExpired(messData)
        ? '<span style="font-size:9px;background:#fef3c7;color:#92400e;border-radius:4px;padding:2px 6px;margin-left:6px;font-weight:700;display:inline-block">⚠️ Expired</span>'
        : ''
    }</h2>
      <p id="sb-mess-addr">${_e(messData?.address||'')}</p>
    </div>
  </div>
  <div class="sb-user">
    <div class="sb-av">
      ${profile.avatar?`<img src="${_e(profile.avatar)}" alt=""/>`:(profile.name||'?')[0].toUpperCase()}
    </div>
    <div class="sb-info" style="min-width:0">
      <div class="uname">${_e(profile.name||profile.email)}</div>
      <div class="ubadge">${_roleBadge(myMessRole)}</div>
    </div>
  </div>
  <nav class="sb-nav" id="mess-nav">
    ${_renderNav()}
  </nav>
  <div class="sb-foot">
    <button class="nl" id="btn-logout">
      <span class="ico">🚪</span><span>লগআউট</span>
    </button>
    <div class="sb-credits">
      মেস মিল ট্র্যাকার v${LOCAL_VERSION}
      ${isPlanExpired(messData)
        ? ' · <span style="color:#f59e0b;font-weight:700">⚠️ Plan Expired</span>'
        : isPaid(messData) ? '' : ' · <span style="color:#86efac">Free Trial</span>'}
    </div>
    ${isPlanExpired(messData) ? `
    <div style="margin-top:8px;padding:8px;background:#fef3c720;border:1px solid #f59e0b40;
      border-radius:8px;text-align:center">
      <p style="font-size:10px;color:#fbbf24;line-height:1.5;margin-bottom:5px">
        ⚠️ আপনার Plan এর মেয়াদ শেষ হয়েছে
      </p>
      <button class="sb-upgrade-btn" style="background:#f59e0b;border:none;color:#1a1a1a;
        font-size:10px;font-weight:700;padding:5px 14px;border-radius:14px;cursor:pointer;
        font-family:inherit">এখনই নবায়ন করুন</button>
    </div>` : !isPaid(messData) ? `
    <div style="margin-top:8px;padding:8px;background:#1f7a4520;border-radius:8px;
      text-align:center">
      <p style="font-size:10px;color:#86efac;line-height:1.5;margin-bottom:5px">
        🎯 Free Trial চলছে — ভালো লাগলে
      </p>
      <button class="sb-upgrade-btn" style="background:none;border:1px solid #4ade80;
        color:#4ade80;font-size:10px;font-weight:700;padding:5px 14px;border-radius:14px;
        cursor:pointer;font-family:inherit">Pro Plan নিন</button>
    </div>` : ''}
  </div>
</div>

<div class="sb-overlay" id="mess-overlay"></div>

<!-- Main uses global .main class so CSS media queries work -->
<div class="main" id="mess-main" style="margin-left:228px;width:calc(100% - 228px);min-height:100vh;display:flex;flex-direction:column">
  <div class="topbar" id="mess-topbar">
    <button class="hbtn" id="mess-hbtn">☰</button>
    <span class="tbtit" id="mess-title">হোম</span>
    <div id="mess-ctrl" style="display:flex;align-items:center;gap:5px;margin-left:auto"></div>
  </div>
  <div class="page" id="mess-page">
    <div style="padding:40px;text-align:center;color:#4a7055">লোড হচ্ছে…</div>
  </div>
</div>`;

  document.getElementById('btn-logout').addEventListener('click', ()=> logout());
  document.getElementById('mess-hbtn').addEventListener('click', ()=>{
    document.getElementById('mess-sb').classList.add('open');
    document.getElementById('mess-overlay').classList.add('on');
  });
  document.getElementById('mess-overlay').addEventListener('click', ()=>{
    document.getElementById('mess-sb').classList.remove('open');
    document.getElementById('mess-overlay').classList.remove('on');
  });
  document.getElementById('mess-nav').addEventListener('click', e=>{
    const btn = e.target.closest('[data-page]');
    if (btn) navigate(btn.dataset.page);
  });
  document.querySelector('.sb-foot')?.addEventListener('click', e=>{
    if (e.target.closest('.sb-upgrade-btn')) showUpgradeModal(messId, _profile, messData);
  });

  window.removeEventListener('mm:navigate', _onNav);
  window.addEventListener('mm:navigate', _onNav);
  window.removeEventListener('popstate', _onPopState);
  window.addEventListener('popstate', _onPopState);
  window.removeEventListener('hashchange', _onHashChange);
  window.addEventListener('hashchange', _onHashChange);

  await navigate(myMessRole === 'bua' ? 'bua-view' : 'home', { homePreload: _homePreload });
  _watchBadge();
  if (myMessRole !== 'bua') _prefetchLikelyPages();
}

// ✅ Next-page prefetch — home লোড হওয়ার পর idle সময়ে সবচেয়ে বেশি ব্যবহৃত
// পেজগুলোর JS module ব্যাকগ্রাউন্ডে ডাউনলোড করে রাখে (browser এর module cache এ),
// যাতে ইউজার ক্লিক করার সাথে সাথেই খুলে যায় — নতুন করে নেটওয়ার্ক রাউন্ড-ট্রিপ লাগে না।
function _prefetchLikelyPages() {
  const likely = ['meal','bazar','deposit','report'];
  const run = () => {
    likely.forEach(id => {
      const file = FILE_MAP[id] || id;
      import(`./${file}.js`).catch(()=>{});
    });
  };
  if ('requestIdleCallback' in window) window.requestIdleCallback(run, { timeout: 3000 });
  else setTimeout(run, 1500);
}

function _onNav(e) { navigate(e.detail.page, e.detail.params); }

// ✅ Android/browser Back বাটন হ্যান্ডলার — history-তে ফিরে যাওয়া state
// অনুযায়ী সেই পেজে navigate করে (নতুন history entry push না করে, তাই লুপ হবে না)
function _onPopState(e) {
  const page = e.state?.mmPage || location.hash.slice(1) || (myMessRole==='bua' ? 'bua-view' : 'home');
  navigate(page, {}, { fromPopState: true });
}

// ✅ কিছু WebView/browser এ popstate ঠিকমতো fire না করলেও hashchange নির্ভরযোগ্যভাবে
// fire করে — এটা একটা ব্যাকআপ হিসেবে রাখা হলো (একই পেজে দুইবার navigate হলেও ক্ষতি নেই)
function _onHashChange() {
  const page = location.hash.slice(1) || (myMessRole==='bua' ? 'bua-view' : 'home');
  navigate(page, {}, { fromPopState: true });
}

function _renderNav() {
  // ✅ বুয়া role — শুধু "আজকের মিল" দেখতে পারবে, বাকি সব sidebar আইটেম বাদ
  if (myMessRole === 'bua') {
    const n = NAV.find(x=>x.id==='bua-view');
    return `<button class="nl" data-page="bua-view" id="nl-bua-view">
  <span class="ico">${n.ico}</span><span>${n.lbl}</span>
</button><div class="sb-sep"></div>`;
  }

  const groups = [
    ['home','meal','bazar'],
    ['deposit','report'],
    ['notice','poll'],
    ['requests','members'],
    ['rent'],
    ['month-close','billing','profile','contact','help','settings'],
  ];

  return groups.map(group=>{
    const items = group.map(id=>{
      const n = NAV.find(x=>x.id===id);
      if (!n) return '';
      if (n.adminOnly && !isMessAdmin()) return '';
      if (n.rentOnly  && !messSettings.rentEnabled) return '';
      return `<button class="nl" data-page="${n.id}" id="nl-${n.id}">
  <span class="ico">${n.ico}</span><span>${n.lbl}</span>
  ${n.badge?'<span class="bdot" id="req-badge-dot"></span>':''}
</button>`;
    }).join('');
    return items ? items+'<div class="sb-sep"></div>' : '';
  }).join('');
}

let _lastPushedPage = null;

export async function navigate(pageId, params={}, opts={}) {
  // ✅ বুয়া role অন্য কোনো পেজে যেতে পারবে না — শুধু আজকের মিল ভিউ
  if (myMessRole === 'bua' && pageId !== 'bua-view') pageId = 'bua-view';

  // ✅ History API — Back বাটনে আগের পেজে ফিরে যাওয়া, Home এ থাকলে Back করলে অ্যাপ exit
  // (URL এ #pageId হ্যাশ যোগ করা হয় — এটা বেশিরভাগ WebView/browser এর back বাটন
  //  ইমপ্লিমেন্টেশনের সাথে সবচেয়ে বেশি compatible, আর ঠিকমতো কাজ করছে কিনা
  //  URL bar দেখে (থাকলে) verify করা যাবে)
  if (!opts.fromPopState) {
    const isRoot = pageId === 'home' || pageId === 'bua-view';
    const url = `${location.pathname}${location.search}#${pageId}`;
    if (isRoot) history.replaceState({ mmPage: pageId }, '', url);
    else if (pageId !== _lastPushedPage) history.pushState({ mmPage: pageId }, '', url);
  }
  _lastPushedPage = pageId;

  NAV.forEach(n=>document.getElementById(`nl-${n.id}`)?.classList.toggle('active', n.id===pageId));
  const nav   = NAV.find(n=>n.id===pageId);
  const title = document.getElementById('mess-title');
  if (title && nav) title.textContent = nav.lbl;

  document.getElementById('mess-sb')?.classList.remove('open');
  document.getElementById('mess-overlay')?.classList.remove('on');

  const ctrl = document.getElementById('mess-ctrl');
  if (ctrl) ctrl.innerHTML = '';

  const page = document.getElementById('mess-page');
  if (!page) return;
  page.innerHTML = '<div style="padding:40px;text-align:center;color:#4a7055">লোড হচ্ছে…</div>';

  try {
    const file = FILE_MAP[pageId] || pageId;
    const mod  = await import(`./${file}.js`);
    await mod.render(page, { messId, messData, messSettings, profile:_profile, myMessRole, params });
  } catch(err) {
    console.error('Page error:', pageId, err);
    page.innerHTML = `
<div style="padding:30px;text-align:center;color:#b83030">
  <div style="font-size:28px;margin-bottom:8px">⚠️</div>
  <p style="font-size:13px;margin-bottom:12px">${_e(err.message)}</p>
  <button id="__retry-btn"
    style="height:30px;padding:0 14px;background:#f1f5f2;border:1px solid #b0ceb8;
    border-radius:6px;font-size:12px;cursor:pointer">🔄 পুনরায় চেষ্টা</button>
</div>`;
    page.querySelector('#__retry-btn')?.addEventListener('click', ()=> navigate(pageId));
  }
}

async function _loadMessContext() {
  try {
    const [mSnap, sSnap, mbSnap] = await Promise.all([
      getDoc(doc(db,'messes',messId)),
      getDoc(doc(db,'messes',messId,'settings','main')),
      getDoc(doc(db,'messes',messId,'members',_profile.uid)),
    ]);
    if (!mSnap.exists()) {
      const { updateDoc, doc:fDoc } = await import('https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js');
      await updateDoc(fDoc(db,'users',_profile.uid), { currentMessId:null, status:'pending' });
      toast('এই মেস আর নেই','er');
      setTimeout(()=>location.reload(), 1500);
      return;
    }
    // ✅ Member document না থাকলে — Admin তাকে remove করে দিয়েছে
    if (!mbSnap.exists()) {
      const { updateDoc, doc:fDoc } = await import('https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js');
      await updateDoc(fDoc(db,'users',_profile.uid), { currentMessId:null, status:'pending' });
      toast('আপনাকে এই মেস থেকে বের করা হয়েছে','er');
      setTimeout(()=>location.reload(), 1500);
      return;
    }
    messData     = { id:mSnap.id, ...mSnap.data() };
    messSettings = sSnap.exists() ? sSnap.data() : messSettings;
    myMessRole   = mbSnap.data().role || 'member';
  } catch(err) {
    console.error('Context error:', err);
    toast('মেস তথ্য লোড ব্যর্থ','er');
  }
}

function _watchBadge() {
  if (!isMessCoAdmin()) return;
  try {
    onSnapshot(
      query(collection(db,'messes',messId,'expenses'), where('status','==','pending')),
      snap=>document.getElementById('req-badge-dot')?.classList.toggle('show', snap.size>0)
    );
  } catch(e) {}
}

function _roleBadge(role) {
  const s={
    'mess-admin':    'font-size:9px;background:rgba(31,168,96,.2);color:#3fcf85;padding:2px 7px;border-radius:10px;font-weight:700',
    'mess-co-admin': 'font-size:9px;background:rgba(74,120,232,.2);color:#4a78e8;padding:2px 7px;border-radius:10px;font-weight:700',
    'member':        'font-size:9px;background:rgba(255,255,255,.1);color:rgba(255,255,255,.5);padding:2px 7px;border-radius:10px;font-weight:700',
    'bua':           'font-size:9px;background:rgba(245,158,11,.2);color:#fbbf24;padding:2px 7px;border-radius:10px;font-weight:700',
  };
  const l={'mess-admin':'মেস অ্যাডমিন','mess-co-admin':'কো-অ্যাডমিন','member':'সদস্য','bua':'বুয়া'};
  return role&&s[role]?`<span style="${s[role]}">${l[role]}</span>`:'';
}


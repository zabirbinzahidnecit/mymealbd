// report-export.js — v16: branded PDF/Excel matching MessTracker_Report_Template

import { taka, takaF, pad, moName, dim } from './utils.js';

const B = {
  name:    'Mess Meal Tracker',
  tagline: 'মেসের মিল, বাজার ও হিসাব সব এক জায়গায়',
  dev:     'Exit Excit',
  green:   '#2d8a4e',
  darkGreen:'#1a5c32',
  accent:  '#e8a838',
  lightBg: '#f0f7f2',
  borderClr:'#c8e0d0',
};

// ─────────────────────────────────────────────────────────────────────────────
// PDF Export
// ─────────────────────────────────────────────────────────────────────────────
export function exportPDF({ messName, messAddress, month, year, members,
  meals, expenses, deposits, slots, profile, isMessTab }) {

  const moLabel   = `${moName(month)} ${year}`;
  const monthPfx  = `${year}_${pad(month+1)}`;
  const generated = new Date().toLocaleDateString('en-GB');

  // ── Calculate data ──
  let grandMeals = 0;
  const memberData = members.map(m => {
    let ml=0, gl=0;
    Object.entries(meals).forEach(([key,data]) => {
      if (key.startsWith(monthPfx) && key.endsWith('_'+m.uid)) {
        ml += (data.slots||[]).filter(Boolean).length;
        gl += (data.guestSlots||[]).filter(Boolean).length;
      }
    });
    const all = ml+gl; grandMeals += all;
    const dep = deposits.filter(d=>d.memberId===m.uid)
      .reduce((s,d)=>s+(parseFloat(d.amount)||0), 0);
    return {...m, meals:ml, guest:gl, all, dep};
  });
  const totalBazar   = expenses.reduce((s,e)=>s+(parseFloat(e.amount)||0), 0);
  const totalDeposit = deposits.reduce((s,d)=>s+(parseFloat(d.amount)||0), 0);
  const mealRate     = grandMeals>0 ? totalBazar/grandMeals : 0;
  memberData.forEach(m => { m.cost=m.all*mealRate; m.balance=m.dep-m.cost; });

  const uid     = profile?.uid;
  const myData  = !isMessTab ? memberData.find(m=>m.uid===uid)||{} : null;
  const metaName= isMessTab ? (messName||'মেস') : (profile?.name||'—');
  const metaMem = isMessTab ? members.length : '—';

  // ── Shared CSS (injected once, repeated header/footer via @page) ──
  const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700&family=Roboto:wght@400;700&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
@page{
  size:A4;
  margin:0;
}
html,body{width:210mm;background:#fff}
body{font-family:'Hind Siliguri','Roboto',Arial,sans-serif;font-size:10.5px;color:#1a1a1a}

/* ── PAGE WRAPPER ── */
.page{
  width:210mm;min-height:297mm;
  display:flex;flex-direction:column;
  page-break-after:always;
}
.page:last-child{page-break-after:auto}

/* ── HEADER ── */
.hdr{
  display:flex;align-items:center;
  padding:10px 18px;
  border-bottom:3px solid ${B.green};
  background:#fff;
}
.hdr-logo{
  width:52px;height:52px;margin-right:12px;flex-shrink:0;
  background:${B.green};border-radius:10px;
  display:flex;align-items:center;justify-content:center;
  font-size:28px;color:#fff;
}
.hdr-mid{flex:1}
.hdr-title{font-size:22px;font-weight:700;color:${B.darkGreen};line-height:1.1}
.hdr-sub{font-size:10px;color:#5a8a6a;margin-top:3px}
.hdr-right{text-align:right;flex-shrink:0}
.hdr-report{font-size:14px;font-weight:700;color:#1a1a1a;letter-spacing:.5px}
.hdr-gen{font-size:10px;color:#666;margin-top:4px}

/* ── ACCENT BAR ── */
.accent{height:3px;background:${B.accent}}

/* ── META ROW ── */
.meta{
  display:grid;grid-template-columns:1fr 1fr 1fr;
  background:${B.lightBg};
  border-bottom:1.5px solid ${B.borderClr};
  padding:6px 0;
}
.meta-cell{padding:5px 18px;border-right:1px solid ${B.borderClr}}
.meta-cell:last-child{border-right:none}
.meta-lbl{font-size:10px;font-weight:700;color:${B.green};text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px}
.meta-val{font-size:13px;font-weight:700;color:${B.darkGreen}}
.meta-sub{font-size:9.5px;color:#5a8a6a;margin-top:1px}

/* ── CONTENT ── */
.content{flex:1;padding:12px 18px}

/* ── SUMMARY GRID ── */
.sum{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:14px}
.sum-box{border:1px solid ${B.borderClr};border-radius:6px;padding:8px 10px;background:${B.lightBg}}
.sum-lbl{font-size:9px;font-weight:700;color:#5a8a6a;text-transform:uppercase;letter-spacing:.3px}
.sum-val{font-size:17px;font-weight:700;color:${B.darkGreen};margin-top:2px;font-family:'Roboto',sans-serif}
.sum-sub{font-size:9px;color:#8aaa90;margin-top:1px}

/* ── SECTION HEADING ── */
.sec{
  font-size:11.5px;font-weight:700;color:${B.darkGreen};
  border-bottom:2px solid ${B.green};
  padding-bottom:4px;margin:14px 0 8px;
  display:flex;align-items:center;gap:6px;
}

/* ── TABLE ── */
table{width:100%;border-collapse:collapse;font-size:10px;margin-bottom:4px;page-break-inside:auto}
thead{display:table-header-group}
thead tr{background:${B.green};-webkit-print-color-adjust:exact;print-color-adjust:exact}
thead th{color:#fff;padding:5px 8px;text-align:left;font-weight:700;font-size:9.5px}
th.r,td.r{text-align:right}
th.c,td.c{text-align:center}
tbody tr{page-break-inside:avoid}
tbody tr:nth-child(even){background:#f6fbf8;-webkit-print-color-adjust:exact;print-color-adjust:exact}
tbody td{padding:4.5px 8px;border-bottom:1px solid #e0ede6;vertical-align:top}
tfoot tr{background:#daeee3;-webkit-print-color-adjust:exact;print-color-adjust:exact}
tfoot td{padding:5px 8px;font-weight:700;border-top:1.5px solid ${B.green}}
.bal-pos{color:#1a6e3a;font-weight:700}
.bal-neg{color:#b83030;font-weight:700}
.dot-on{
  display:inline-block;width:14px;height:14px;border-radius:50%;
  background:${B.green};color:#fff;font-size:8px;
  text-align:center;line-height:14px;
  -webkit-print-color-adjust:exact;print-color-adjust:exact
}
.dot-off{
  display:inline-block;width:14px;height:14px;border-radius:50%;
  background:#e8e8e8;color:#999;font-size:8px;
  text-align:center;line-height:14px;border:1px solid #ccc;
  -webkit-print-color-adjust:exact;print-color-adjust:exact
}

/* ── SIGNATURE ── */
.sign{display:grid;grid-template-columns:repeat(3,1fr);gap:30px;margin-top:20px;padding-top:10px;border-top:1px solid ${B.borderClr}}
.sign-box{text-align:center}
.sign-line{border-bottom:1px solid #555;height:28px;margin-bottom:4px}
.sign-lbl{font-size:9.5px;color:#4a7055}

/* ── FOOTER ── */
.ftr{
  background:${B.green};
  display:flex;align-items:center;justify-content:space-between;
  padding:7px 18px;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.ftr-left{font-size:11px;font-weight:700;color:#fff}
.ftr-mid{font-size:9.5px;color:rgba(255,255,255,.8);text-align:center}
.ftr-right{display:flex;align-items:center;gap:8px}
.ftr-dev{font-size:9.5px;color:rgba(255,255,255,.8)}
.ftr-dev strong{color:${B.accent};font-weight:700}
.ftr-logo{width:28px;height:28px;background:rgba(255,255,255,.15);border-radius:5px;
  display:flex;align-items:center;justify-content:center;font-size:15px}
.pgnum{font-size:9px;color:${B.accent};margin-top:3px;text-align:right}

@media print{
  .page{page-break-after:always}
  .page:last-child{page-break-after:auto}
  thead{display:table-header-group}
}`;

  // ── Header HTML (reused on every page) ──
  function hdr() { return `
<div class="hdr">
  <div class="hdr-logo">🍽️</div>
  <div class="hdr-mid">
    <div class="hdr-title">${B.name}</div>
    <div class="hdr-sub">${B.tagline}</div>
  </div>
  <div class="hdr-right">
    <div class="hdr-report">MONTHLY REPORT</div>
    <div class="hdr-gen">Generated: ${generated}</div>
  </div>
</div>
<div class="accent"></div>
<div class="meta">
  <div class="meta-cell">
    <div class="meta-lbl">Mess Name / Name:</div>
    <div class="meta-val">${_e(metaName)}</div>
    ${messAddress?`<div class="meta-sub">${_e(messAddress)}</div>`:''}
  </div>
  <div class="meta-cell">
    <div class="meta-lbl">Month / Year:</div>
    <div class="meta-val">${moLabel}</div>
  </div>
  <div class="meta-cell">
    <div class="meta-lbl">Total Members:</div>
    <div class="meta-val">${metaMem}</div>
  </div>
</div>`; }

  // ── Footer HTML ──
  function ftr(pg, total) { return `
<div style="padding:0 18px 4px;text-align:right">
  <span style="font-size:9px;color:${B.accent}">Page ${pg} of ${total}</span>
</div>
<div class="ftr">
  <div class="ftr-left">${B.name}</div>
  <div class="ftr-mid">Smart Mess Management Solution</div>
  <div class="ftr-right">
    <div class="ftr-dev">Developed by <strong>${B.dev}</strong></div>
    <div class="ftr-logo">🍽️</div>
  </div>
</div>`; }

  // ── Build pages ──
  const pages = [];

  // PAGE 1 — Summary + Member table
  let p1 = `<div class="content">`;

  // Summary boxes
  const s1v = isMessTab ? grandMeals : (myData?.all||0);
  const s2v = takaF(mealRate);
  const s3v = isMessTab ? taka(totalBazar) : taka(myData?.cost||0);
  const s4v = isMessTab ? taka(totalDeposit) : taka(myData?.dep||0);
  p1 += `
<div class="sum">
  <div class="sum-box">
    <div class="sum-lbl">মোট মিল</div>
    <div class="sum-val">${s1v}</div>
    <div class="sum-sub">${isMessTab?'সকল সদস্য':'এই মাসে'}</div>
  </div>
  <div class="sum-box">
    <div class="sum-lbl">মিল রেট</div>
    <div class="sum-val">${s2v}</div>
    <div class="sum-sub">প্রতি মিল</div>
  </div>
  <div class="sum-box">
    <div class="sum-lbl">${isMessTab?'মোট বাজার':'মিল খরচ'}</div>
    <div class="sum-val">${s3v}</div>
  </div>
  <div class="sum-box">
    <div class="sum-lbl">${isMessTab?'মোট জমা':'আমার জমা'}</div>
    <div class="sum-val">${s4v}</div>
    ${!isMessTab&&myData?`<div class="sum-sub ${(myData.balance||0)>=0?'bal-pos':'bal-neg'}">
      ব্যালেন্স: ${takaF(myData.balance||0)}</div>`:''}
  </div>
</div>`;

  if (isMessTab) {
    p1 += `<div class="sec">👥 সদস্য ভিত্তিক হিসাব</div>
<table>
<thead><tr>
  <th>সদস্য</th><th class="r">মিল</th><th class="r">Guest</th>
  <th class="r">মোট মিল</th><th class="r">মিল খরচ (৳)</th>
  <th class="r">জমা (৳)</th><th class="r">ব্যালেন্স (৳)</th>
</tr></thead>
<tbody>
${memberData.map(m=>`<tr>
  <td style="font-weight:600">${_e(m.name||m.email)}</td>
  <td class="r">${m.meals}</td><td class="r">${m.guest||'—'}</td>
  <td class="r" style="font-weight:700">${m.all}</td>
  <td class="r">৳${m.cost.toFixed(2)}</td>
  <td class="r">৳${m.dep.toFixed(2)}</td>
  <td class="r ${m.balance>=0?'bal-pos':'bal-neg'}">৳${m.balance.toFixed(2)}</td>
</tr>`).join('')}
</tbody>
<tfoot><tr>
  <td style="font-weight:700">মোট</td>
  <td></td><td></td>
  <td class="r">${grandMeals}</td>
  <td class="r">৳${totalBazar.toFixed(2)}</td>
  <td class="r">৳${totalDeposit.toFixed(2)}</td>
  <td class="r ${totalDeposit>=totalBazar?'bal-pos':'bal-neg'}">৳${(totalDeposit-totalBazar).toFixed(2)}</td>
</tr></tfoot>
</table>`;
  } else {
    // My report — calendar on page 1
    p1 += _calendarHTML(uid, meals, month, year, slots||['সকাল','দুপুর','রাত'], moLabel);
  }

  // Signature on page 1
  p1 += `
<div class="sign">
  <div class="sign-box"><div class="sign-line"></div><div class="sign-lbl">Manager Signature</div></div>
  <div class="sign-box"><div class="sign-line"></div><div class="sign-lbl">Member Representative</div></div>
  <div class="sign-box"><div class="sign-line"></div><div class="sign-lbl">Date</div></div>
</div>`;
  p1 += `</div>`;
  pages.push(p1);

  // PAGE 2 — Bazar list
  if (expenses.length) {
    const bazarList = isMessTab ? expenses : expenses.filter(e=>e.addedBy===uid);
    if (bazarList.length) {
      let p2 = `<div class="content">
<div class="sec">🛒 বাজারের তালিকা</div>
<table>
<thead><tr>
  <th>তারিখ</th><th>বিভাগ</th><th>আইটেম</th><th>যোগ করেছেন</th><th class="r">পরিমাণ (৳)</th>
</tr></thead>
<tbody>
${bazarList.map(e=>`<tr>
  <td>${e.date||'—'}</td>
  <td>${_e(e.category||'')}</td>
  <td>${_e(e.item||'')}${e.note?`<br><span style="color:#6a8a74;font-size:9px">${_e(e.note)}</span>`:''}</td>
  <td>${_e(e.addedByName||'—')}</td>
  <td class="r" style="font-weight:700">৳${parseFloat(e.amount||0).toFixed(2)}</td>
</tr>`).join('')}
</tbody>
<tfoot><tr>
  <td colspan="4" style="font-weight:700">মোট বাজার</td>
  <td class="r">৳${bazarList.reduce((s,e)=>s+(parseFloat(e.amount)||0),0).toFixed(2)}</td>
</tr></tfoot>
</table></div>`;
      pages.push(p2);
    }
  }

  // PAGE 3 — Deposit list
  if (deposits.length) {
    const depList = isMessTab ? deposits : deposits.filter(d=>d.memberId===uid);
    if (depList.length) {
      let p3 = `<div class="content">
<div class="sec">💰 ডিপোজিট তালিকা</div>
<table>
<thead><tr>
  <th>তারিখ</th><th>সদস্য</th><th>নোট</th><th class="r">পরিমাণ (৳)</th>
</tr></thead>
<tbody>
${depList.map(d=>`<tr>
  <td>${d.date||'—'}</td>
  <td>${_e(d.memberName||'—')}</td>
  <td>${_e(d.note||'')}</td>
  <td class="r" style="font-weight:700">৳${parseFloat(d.amount||0).toFixed(2)}</td>
</tr>`).join('')}
</tbody>
<tfoot><tr>
  <td colspan="3" style="font-weight:700">মোট জমা</td>
  <td class="r">৳${depList.reduce((s,d)=>s+(parseFloat(d.amount)||0),0).toFixed(2)}</td>
</tr></tfoot>
</table></div>`;
      pages.push(p3);
    }
  }

  const total = pages.length;
  const html  = `<!DOCTYPE html>
<html lang="bn"><head>
<meta charset="UTF-8"/>
<title>${_e(metaName)} — ${moLabel} Report</title>
<style>${CSS}</style>
</head><body>
${pages.map((content, i) => `
<div class="page">
  ${hdr()}
  ${content}
  ${ftr(i+1, total)}
</div>`).join('')}
</body></html>`;

  const w = window.open('','_blank','width=950,height=800');
  if (!w) { alert('Popup blocked — browser এ allow করুন'); return; }
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(() => w.print(), 900);
}

// ── Calendar table helper ────────────────────────────────────────────────────
function _calendarHTML(uid, meals, month, year, slots, moLabel) {
  const days  = dim(year, month);
  const pfx   = `${year}_${pad(month+1)}`;
  let total   = 0, rows = '';
  for (let d=1; d<=days; d++) {
    const key  = `${pfx}_${pad(d)}_${uid}`;
    const data = meals[key]||{};
    const s    = data.slots||[];
    const g    = (data.guestSlots||[]).filter(Boolean).length;
    const t    = s.filter(Boolean).length+g;
    total += t;
    rows += `<tr>
  <td>${d} ${moLabel.split(' ')[0]}</td>
  ${slots.map((_,i)=>`<td class="c"><span class="${s[i]?'dot-on':'dot-off'}">${s[i]?'✓':''}</span></td>`).join('')}
  <td class="r">${g||'—'}</td>
  <td class="r" style="font-weight:${t?'700':'400'}">${t||'—'}</td>
</tr>`;
  }
  return `<div class="sec">📅 মিল ক্যালেন্ডার</div>
<table>
<thead><tr>
  <th>তারিখ</th>
  ${slots.map(s=>`<th class="c" style="font-size:9px">${_e(s)}</th>`).join('')}
  <th class="r">Guest</th><th class="r">মোট</th>
</tr></thead>
<tbody>${rows}</tbody>
<tfoot><tr>
  <td colspan="${slots.length+1}" style="font-weight:700">মোট মিল</td>
  <td></td><td class="r">${total}</td>
</tr></tfoot>
</table>`;
}

// ── Excel Export ─────────────────────────────────────────────────────────────
export function exportExcel({ messName, month, year, members, meals,
  expenses, deposits, profile, isMessTab }) {

  if (!window.XLSX) { alert('XLSX library লোড হয়নি'); return; }

  const moLabel  = `${moName(month)} ${year}`;
  const monthPfx = `${year}_${pad(month+1)}`;
  const uid      = profile?.uid;

  let grandMeals = 0;
  const memberData = members.map(m => {
    let ml=0, gl=0;
    Object.entries(meals).forEach(([key,data]) => {
      if (key.startsWith(monthPfx) && key.endsWith('_'+m.uid)) {
        ml += (data.slots||[]).filter(Boolean).length;
        gl += (data.guestSlots||[]).filter(Boolean).length;
      }
    });
    const all = ml+gl; grandMeals += all;
    const dep = deposits.filter(d=>d.memberId===m.uid)
      .reduce((s,d)=>s+(parseFloat(d.amount)||0), 0);
    return {...m, meals:ml, guest:gl, all, dep};
  });
  const totalBazar   = expenses.reduce((s,e)=>s+(parseFloat(e.amount)||0), 0);
  const totalDeposit = deposits.reduce((s,d)=>s+(parseFloat(d.amount)||0), 0);
  const mealRate     = grandMeals>0 ? totalBazar/grandMeals : 0;
  memberData.forEach(m => { m.cost=m.all*mealRate; m.balance=m.dep-m.cost; });

  const wb = window.XLSX.utils.book_new();

  // Sheet 1 — Summary
  const sheetData = [
    [`${B.name} — ${isMessTab?'মেস রিপোর্ট':'আমার রিপোর্ট'}`],
    [`${isMessTab?(messName||'মেস'):(profile?.name||'—')} | ${moLabel}`],
    [`Generated: ${new Date().toLocaleDateString('en-GB')}`],
    [`Developed by ${B.dev}`],
    [],
    ['সদস্য','মিল','Guest','মোট মিল','মিল খরচ (৳)','জমা (৳)','ব্যালেন্স (৳)'],
    ...(isMessTab ? memberData : [memberData.find(m=>m.uid===uid)||{}]).map(m=>[
      m.name||m.email||'—', m.meals||0, m.guest||0, m.all||0,
      +((m.cost||0).toFixed(2)), m.dep||0, +((m.balance||0).toFixed(2))
    ]),
    [],
    ['','','','মোট', +totalBazar.toFixed(2), +totalDeposit.toFixed(2),
      +(totalDeposit-totalBazar).toFixed(2)],
    [],
    [`মিল রেট: ৳${mealRate.toFixed(2)} / মিল`],
  ];
  const ws1 = window.XLSX.utils.aoa_to_sheet(sheetData);
  ws1['!cols'] = [{wch:20},{wch:8},{wch:8},{wch:10},{wch:14},{wch:12},{wch:14}];
  window.XLSX.utils.book_append_sheet(wb, ws1, 'সারসংক্ষেপ');

  // Sheet 2 — Bazar
  const bazarList = isMessTab ? expenses : expenses.filter(e=>e.addedBy===uid);
  const ws2 = window.XLSX.utils.aoa_to_sheet([
    [`${B.name} — বাজারের তালিকা — ${moLabel}`],[],
    ['তারিখ','বিভাগ','আইটেম','নোট','যোগ করেছেন','পরিমাণ (৳)'],
    ...bazarList.map(e=>[e.date||'',e.category||'',e.item||'',e.note||'',e.addedByName||'',parseFloat(e.amount)||0]),
    [],['','','','','মোট',+bazarList.reduce((s,e)=>s+(parseFloat(e.amount)||0),0).toFixed(2)],
  ]);
  ws2['!cols'] = [{wch:12},{wch:12},{wch:20},{wch:16},{wch:16},{wch:12}];
  window.XLSX.utils.book_append_sheet(wb, ws2, 'বাজার');

  // Sheet 3 — Deposit
  const depList = isMessTab ? deposits : deposits.filter(d=>d.memberId===uid);
  const ws3 = window.XLSX.utils.aoa_to_sheet([
    [`${B.name} — ডিপোজিট তালিকা — ${moLabel}`],[],
    ['তারিখ','সদস্য','নোট','পরিমাণ (৳)'],
    ...depList.map(d=>[d.date||'',d.memberName||'',d.note||'',parseFloat(d.amount)||0]),
    [],['','','মোট',+depList.reduce((s,d)=>s+(parseFloat(d.amount)||0),0).toFixed(2)],
  ]);
  ws3['!cols'] = [{wch:12},{wch:18},{wch:20},{wch:12}];
  window.XLSX.utils.book_append_sheet(wb, ws3, 'ডিপোজিট');

  // Sheet 4 — Calendar (my report)
  if (!isMessTab) {
    const days = dim(year, month);
    const pfx  = `${year}_${pad(month+1)}`;
    const slotsArr = ['সকাল','দুপুর','রাত'];
    const calRows  = [
      [`${B.name} — মিল ক্যালেন্ডার — ${moLabel}`],[],
      ['তারিখ',...slotsArr,'Guest','মোট'],
    ];
    for (let d=1; d<=days; d++) {
      const key  = `${pfx}_${pad(d)}_${uid}`;
      const data = meals[key]||{};
      const s    = data.slots||[];
      const g    = (data.guestSlots||[]).filter(Boolean).length;
      calRows.push([`${d} ${moName(month)}`,...s.map(v=>v?'✓':''), g||0, s.filter(Boolean).length+g]);
    }
    const ws4 = window.XLSX.utils.aoa_to_sheet(calRows);
    ws4['!cols'] = [{wch:14},...slotsArr.map(()=>({wch:8})),{wch:8},{wch:8}];
    window.XLSX.utils.book_append_sheet(wb, ws4, 'মিল ক্যালেন্ডার');
  }

  const fname = `${isMessTab?(messName||'mess'):(profile?.name||'user')}-${moName(month)}-${year}.xlsx`;
  window.XLSX.writeFile(wb, fname.replace(/\s+/g,'-'));
}

const _e = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

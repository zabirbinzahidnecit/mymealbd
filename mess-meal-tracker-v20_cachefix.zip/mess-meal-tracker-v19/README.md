# Mess Meal Tracker

মেস/শেয়ারড-হাউজিং-এর জন্য মিল, বাজার-খরচ, জমা, ভাড়া, বিলিং হিসাবের PWA।
Firebase (Auth + Firestore + Hosting) দিয়ে বানানো, plain JS (ES Modules) —
কোনো framework/bundler-lock-in নেই (esbuild শুধু minify করার জন্য ব্যবহৃত হয়)।

## Tech Stack

- **Frontend:** Vanilla JS (ES Modules), no framework
- **Backend:** Firebase Auth + Cloud Firestore + Firebase Hosting
- **Build:** esbuild (শুধু minify, bundling নয় — `bundle:false`, code-splitting/lazy-load বজায় রাখতে)
- **Email:** EmailJS (মেম্বার ইনভাইট ইমেইল পাঠাতে)
- **PWA:** Service Worker (`sw.js`) + Web App Manifest

## প্রি-রিকুইজিট

- Node.js 18+ (`node --version` দিয়ে চেক করো)
- একটা Firebase প্রজেক্ট (Firestore + Auth + Hosting চালু করা)
- Firebase CLI: `npm install -g firebase-tools`

## লোকাল সেটআপ

```bash
git clone <this-repo>
cd mess-meal-tracker-v19
npm install
```

### Firebase কনফিগারেশন

`js/firebase.js`-এ তোমার নিজের Firebase প্রজেক্টের config বসাও (Firebase
Console → Project Settings → General → Your apps → SDK config)। এই ফাইলের
`apiKey`, `projectId` ইত্যাদি client-side এ পাবলিক থাকা স্বাভাবিক — আসল
সিকিউরিটি নিশ্চিত হয় `firestore.rules` দিয়ে, key দিয়ে না।

`.firebaserc`-এ তোমার প্রজেক্ট আইডি বসাও:
```json
{ "projects": { "default": "your-firebase-project-id" } }
```

### EmailJS কনফিগারেশন (ইনভাইট ইমেইলের জন্য)

`js/emailjs-config.js`-এ তোমার নিজের EmailJS public key/service id/template
id বসাও ([emailjs.com](https://www.emailjs.com/) থেকে ফ্রি অ্যাকাউন্ট)।

## ডেভেলপমেন্ট (লোকালি চালানো)

কোনো dev-server bundling দরকার নেই — এটা plain ES modules, তাই যেকোনো
static file server দিয়ে চালানো যায়:

```bash
npx serve .
# অথবা
python3 -m http.server 8000
```

তারপর ব্রাউজারে `http://localhost:8000` খোলো। (module import করার জন্য
`file://` দিয়ে সরাসরি খোলা যাবে না — একটা server লাগবেই)।

## Build (প্রোডাকশনের জন্য)

```bash
npm run build
```

এটা সব `.js`/`.css` ফাইল minify করে `dist/`-এ রাখে (`build.js` দেখো)। এখানে
**bundling করা হয় না** ইচ্ছাকৃতভাবে — প্রতিটা page/role আলাদা ফাইলে
lazy-load (`dynamic import()`) হয়, একজন সাধারণ member লগইন করলে admin-এর
কোনো কোডই ডাউনলোড হয় না। এটা ভেঙো না, নাহলে lazy-loading-এর পারফরম্যান্স
সুবিধা চলে যাবে।

## Deploy

✅ **এই zip-এ আগে থেকেই বানানো `dist/` ফোল্ডার আছে** — তাই এখনই সরাসরি
deploy করা যাবে, আলাদা কোনো build কমান্ড লাগবে না:

```bash
firebase login
firebase deploy --only hosting,firestore
```

এই `dist/`-টা esbuild দিয়ে minify করা না (raw কপি) — কারণটা নিচে লেখা
আছে। ফাংশনালিটিতে কোনো পার্থক্য নেই, ফাইল সাইজ একটু বড় শুধু।

⚠️ **`firebase.json`-এ ইচ্ছাকৃতভাবে কোনো `predeploy` hook নেই।** কিছু
Windows সেটআপে firebase-tools-এর নিজস্ব subprocess spawning
(`npm install`/`npm run build` কে predeploy hook হিসেবে অটো-চালানো)
`ENOENT`/`cross-spawn` এরর দেয় — command স্ট্রিং যেভাবেই ফরম্যাট করা হোক,
কোনোটাতেই লাভ হয় না। তাই deploy একদম raw `dist/` ফোল্ডার আপলোড করে, কোনো
subprocess spawn ছাড়াই — এই এররটা আর হওয়ার কথা না।

### ভবিষ্যতে `js/`, `style.css` ইত্যাদি সোর্স ফাইল বদলালে

`dist/` আবার regenerate করতে হবে (deploy সবসময় `dist/`-এর কন্টেন্ট
আপলোড করে, সোর্স ফাইল সরাসরি না)। দুইটা উপায়:

**সহজ (network/esbuild ছাড়াই, minify হয় না):**
```bash
node -e "
const fs=require('fs');
fs.rmSync('dist',{recursive:true,force:true});
fs.mkdirSync('dist',{recursive:true});
fs.cpSync('js','dist/js',{recursive:true});
fs.cpSync('style.css','dist/style.css');
['index.html','manifest.json','sw.js','firestore.rules','storage.rules'].forEach(f=>{
  if (fs.existsSync(f)) fs.cpSync(f,'dist/'+f);
});
if (fs.existsSync('icons')) fs.cpSync('icons','dist/icons',{recursive:true});
console.log('dist/ রেডি — raw কপি, minify হয়নি');
"
```

**Minify সহ (esbuild লাগবে, তাই internet + `npm install` লাগবে):**
```bash
npm install
npm run build
```

দুটোর যেকোনো একটা চালানোর পর সরাসরি `firebase deploy --only
hosting,firestore` চালাও — কোনো predeploy hook নেই বলে এটাই একমাত্র
manual step।

⚠️ **`dist/` regenerate না করে deploy করলে পুরনো কন্টেন্টই আবার deploy
হয়ে যাবে** — কোনো error দেখাবে না, কিন্তু নতুন পরিবর্তন লাইভে দেখা যাবে
না।

⚠️ **`firestore.rules` বদলানোর পর অবশ্যই `firebase deploy --only
firestore:rules` চালাতে হবে** — শুধু `git push`/hosting deploy করলে rules
আপডেট হয় না, কারণ rules আলাদাভাবে deploy হয়।

⚠️ **যেকোনো `.js`/`.css` ফাইল বদলানোর পর `sw.js`-এ `CACHE_VERSION`
বাড়িয়ে দাও** (যেমন `mm-v3.20.0` → `mm-v3.21.0`)। এটা Service Worker-এর
নিজস্ব cache পরিষ্কার করে।

**`.js`/`.css`-এর জন্য `firebase.json`-এ `Cache-Control: no-cache`** সেট করা
আছে (আগে `max-age=3600` ছিল, যেটা একটা real bug-এর কারণ হয়েছিল — ব্রাউজারের
নিজস্ব HTTP cache Service Worker-এর cache থেকে সম্পূর্ণ আলাদা একটা স্তর;
Service Worker/Cache Storage মুছে reload করলেও ব্রাউজার তখনো নিজের ১-ঘণ্টার
HTTP cache থেকে পুরনো ফাইল দিয়ে দিতে পারত, কোনো নেটওয়ার্ক রিকোয়েস্টই ছাড়া)।
`no-cache` মানে ব্রাউজার প্রতিবার লোডেই সার্ভারের সাথে যাচাই করবে (ETag দিয়ে
conditional request — না বদলালে দ্রুত 304 পাবে), তাই নতুন deploy সবসময়
স্বয়ংক্রিয়ভাবেই ধরা পড়বে, `CACHE_VERSION` বাড়ানো বা ম্যানুয়াল cache-clear
আর কড়াকড়িভাবে জরুরি না — তবু habit হিসেবে `CACHE_VERSION` বাড়ানো ভালো
(offline-এ Service Worker যে precached ফাইল সার্ভ করে সেটার জন্য এখনও এটাই
একমাত্র উপায় নতুন ভার্সন পাওয়ার)।

## Firestore Rules টেস্ট করা (emulator দিয়ে)

`test/firestore.rules.test.js`-এ security rules-এর জন্য emulator টেস্ট আছে
— বিশেষ করে যেসব permission-gap আগে ফিক্স করা হয়েছিল সেগুলো (member যেন
অন্যের মিল এডিট করতে না পারে, expenses/deposits approval bypass করতে না
পারে, ইত্যাদি) — যাতে ভবিষ্যতে কেউ ভুলে rule আলগা করে দিলে টেস্ট ফেল করে
সেটা ধরিয়ে দেয়।

```bash
npm run test:rules
```

এটা `firebase emulators:exec` দিয়ে চলে — সম্পূর্ণ লোকাল emulator-এ, তোমার
আসল Firebase প্রজেক্টে কোনো প্রভাব ফেলে না। প্রথমবার চালানোর আগে Firebase
CLI-এর সাথে Java লাগবে (emulator Java-ভিত্তিক); না থাকলে CLI নিজেই ইনস্টল
করতে বলবে অথবা `sudo apt install default-jre` (Linux) দিয়ে ইনস্টল করে নাও।

নতুন কোনো collection বা rule যোগ করলে `test/firestore.rules.test.js`-এ
সেটার জন্যও কেস যোগ করে দিও — বিশেষ করে `create`/`update`/`delete` rule
যেখানেই কোনো ownership/role check আছে।

## প্রজেক্ট স্ট্রাকচার

```
js/
  firebase.js, auth.js, router.js       — কোর ইনফ্রাস্ট্রাকচার
  plan.js, billing.js                   — প্ল্যান/বিলিং লজিক (carry-over হিসাব সহ)
  app-config-cache.js                   — appConfig-এর শেয়ার্ড ক্যাশ
  members-cache.js                      — মেস-মেম্বারদের শেয়ার্ড ক্যাশ
  utils.js                              — কমন হেল্পার (escapeHtml, taka, pad, ...)
  pages/admin/                          — প্ল্যাটফর্ম-অ্যাডমিন পেজ (lazy-loaded)
  pages/mess/                           — মেস-লেভেল পেজ: member/mess-admin/bua (lazy-loaded)
firestore.rules                         — Firestore সিকিউরিটি রুলস
firestore.indexes.json                  — কম্পোজিট ইনডেক্স
test/firestore.rules.test.js            — rules emulator টেস্ট
build.js                                — esbuild দিয়ে minify (no bundling)
```

## রোল সিস্টেম ও Permission টেবিল

দুই স্তরের রোল আছে — **প্ল্যাটফর্ম রোল** (পুরো অ্যাপের মালিক/অ্যাডমিন) আর
**মেস রোল** (একটা নির্দিষ্ট মেসের মধ্যে)। একজন ইউজারের দুটোই থাকতে পারে,
আলাদা আলাদা (যেমন কেউ প্ল্যাটফর্ম co-admin হতে পারে, আবার নিজের মেসে
সাধারণ member-ও হতে পারে)।

### প্ল্যাটফর্ম রোল (`users/{uid}.platformRole`)

| ক্ষমতা | Admin | Co-admin |
|---|---|---|
| মেস তৈরির অনুরোধ Approve/Reject | ✅ | ✅ |
| Payment request Approve/Reject/মওকুফ | ✅ | ✅ |
| যেকোনো মেসের plan/মেয়াদ সরাসরি এডিট | ✅ | ✅ |
| মেস active/deactive টগল | ✅ | ✅ |
| **মেস সম্পূর্ণ ডিলিট** | ✅ | ❌ |
| **যেকোনো ইউজার ডিলিট** | ✅ | ❌ |
| প্ল্যাটফর্ম সেটিংস (payment number, দাম, ট্রায়াল/গ্রেস-পিরিয়ড দিন, maintenance mode) | ✅ | ✅ |
| Contact message দেখা/reply | ✅ | ✅ |

`isPlatAdmin()` (শুধু `admin`) বনাম `isPlatCoAdmin()` (`admin` অথবা
`co-admin`) — `firestore.rules`-এ এই দুটো হেল্পার দিয়েই মূল পার্থক্য।
Delete-জাতীয় অপরিবর্তনযোগ্য অ্যাকশন সবসময় `isPlatAdmin()`-only।

### মেস রোল (`messes/{id}/members/{uid}.role`)

| ক্ষমতা | mess-admin | mess-co-admin | member | bua |
|---|---|---|---|---|
| নিজের মিল এন্ট্রি দেওয়া | ✅ | ✅ | ✅ | ❌ (শুধু দেখতে পারে) |
| **অন্য সদস্যের মিল এডিট করা** | ✅ | ✅ | ❌ (শুধু নিজেরটা) | ❌ |
| বাজার খরচ/ডিপোজিট **যোগ করা** (pending অবস্থায়) | ✅ | ✅ | ✅ | ❌ |
| বাজার খরচ/ডিপোজিট **Approve করা** | ✅ | ✅ | ❌ | ❌ |
| নোটিশ/পোল **তৈরি করা** | ✅ | ✅ | ❌ | ❌ |
| পোলে ভোট দেওয়া | ✅ | ✅ | ✅ | ❌ |
| নোটিশ/পোল **ডিলিট করা** | ✅ | ❌ (নিজে তৈরি করা নোটিশ ছাড়া) | ❌ | ❌ |
| **সদস্য যোগ/রিমুভ/রোল পরিবর্তন** | ✅ | ❌ | ❌ | ❌ |
| **মাস বন্ধ করা (month-close)** | ✅ | ❌ | ❌ | ❌ |
| **Billing/Plan renew/change** | ✅ | ❌ | ❌ | ❌ |
| **মেস Settings এডিট** (meal slot, cutoff time, ইত্যাদি) | ✅ | ❌ | ❌ | ❌ |
| Join code/Invite তৈরি | ✅ | ✅ | ❌ | ❌ |
| রিপোর্ট দেখা (নিজের/পুরো মেসের) | ✅ | ✅ | ✅ | ❌ |
| মেস ছাড়া (Leave) | ⚠️ শুধু আরেকজন mess-admin থাকলে | ✅ | ✅ | ✅ |

**গুরুত্বপূর্ণ:** mess-co-admin বাজার/ডিপোজিট **approve** করতে পারে এবং
যেকোনো সদস্যের মিল এডিট করতে পারে, কিন্তু billing/settings/month-close/সদস্য-ব্যবস্থাপনার
মতো "মেসের কাঠামো" বদলানোর ক্ষমতা তার নেই — এই কাজগুলো শুধু **mess-admin**-এর
(`isAdmin(messId)` — role literally `'mess-admin'` হতে হবে, `isCoAdmin()` না)।
এটা UI (`NAV` array-এর `adminOnly` ফ্ল্যাগ) আর Firestore rules — দুই জায়গাতেই
সমানভাবে enforce করা, শুধু UI-তে লুকানো না (তাই সরাসরি API কল করেও bypass করা যাবে না)।

**Sole-admin leave restriction:** কোনো মেসে যদি একজনই `mess-admin` থাকে,
সে "মেস ছাড়ুন" করতে পারবে না যতক্ষণ না আরেকজনকে আগে mess-admin বানানো হয়
(loophole-প্রতিরোধ — নাহলে trial/plan শেষ হওয়া মেস ছেড়ে নতুন মেস বানিয়ে
বারবার ফ্রি ট্রায়াল নেওয়া যেত)।

**বুয়া (bua):** সম্পূর্ণ read-only, শুধু "আজকের মিল" ভিউ দেখতে পারে — কোনো
write অনুমতি নেই কোথাও।

`firestore.rules`-এর হেল্পার ফাংশনগুলো (`isAdmin`, `isCoAdmin`, `isBua`,
`isPlatAdmin`, `isPlatCoAdmin`) এই রোলগুলোর উপর ভিত্তি করে অ্যাক্সেস
নিয়ন্ত্রণ করে — নতুন কোনো rule লেখার সময় client-side check-এর উপর ভরসা না
করে সবসময় rule-লেভেলেও enforce করা উচিত (client check শুধু UX-এর জন্য,
নিরাপত্তার জন্য না)।

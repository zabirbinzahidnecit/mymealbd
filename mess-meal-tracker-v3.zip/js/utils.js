// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/utils.js
//  Common utilities: toast, loader, taka, t, formatDate, lang
//  import { toast, ld, uld, taka, t, formatDate, ini, moName, dayName } from './utils.js';
// ══════════════════════════════════════════════════════════

// ── Language Store ───────────────────────────────────────
export let LANG = localStorage.getItem('mm_lang') || 'bn';

export function setLang(l) {
  LANG = l;
  localStorage.setItem('mm_lang', l);
  document.getElementById('html-root')?.setAttribute('lang', l);
  document.body?.classList.toggle('en', l === 'en');
}

// ── Translation Table ────────────────────────────────────
const TR = {
  bn: {
    loading: 'লোড হচ্ছে…', saving: 'সেভ হচ্ছে…',
    success: 'সফল!', error: 'ত্রুটি হয়েছে',
    confirm_delete: 'মুছে ফেলবেন?',
    approve: '✓ অনুমোদন', reject: '✗ বাতিল',
    pending: 'অপেক্ষামাণ', approved: 'অনুমোদিত', rejected: 'বাতিল',
    today: 'আজ',
    nav_home: 'হোম', nav_meal: 'মিল এন্ট্রি',
    nav_bazar: 'বাজার হিসাব', nav_deposit: 'ডিপোজিট',
    nav_rent: 'বাড়ি ভাড়া', nav_report: 'রিপোর্ট',
    nav_notice: 'নোটিশ বোর্ড', nav_requests: 'অনুমোদন',
    nav_members: 'সদস্য', nav_profile: 'আমার প্রোফাইল',
    nav_settings: 'সেটিংস',
    role_mess_admin: 'মেস অ্যাডমিন', role_mess_coadmin: 'মেস কো-অ্যাডমিন',
    role_member: 'সদস্য', role_admin: 'প্ল্যাটফর্ম অ্যাডমিন',
    role_coadmin: 'কো-অ্যাডমিন',
    months: ['জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন',
             'জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'],
    days_short: ['রোব','সোম','মঙ্গল','বুধ','বৃহ','শুক্র','শনি'],
  },
  en: {
    loading: 'Loading…', saving: 'Saving…',
    success: 'Success!', error: 'Something went wrong',
    confirm_delete: 'Delete this?',
    approve: '✓ Approve', reject: '✗ Reject',
    pending: 'Pending', approved: 'Approved', rejected: 'Rejected',
    today: 'Today',
    nav_home: 'Home', nav_meal: 'Meal Entry',
    nav_bazar: 'Grocery', nav_deposit: 'Deposits',
    nav_rent: 'House Rent', nav_report: 'Report',
    nav_notice: 'Notice Board', nav_requests: 'Approvals',
    nav_members: 'Members', nav_profile: 'My Profile',
    nav_settings: 'Settings',
    role_mess_admin: 'Mess Admin', role_mess_coadmin: 'Mess Co-Admin',
    role_member: 'Member', role_admin: 'Platform Admin',
    role_coadmin: 'Co-Admin',
    months: ['January','February','March','April','May','June',
             'July','August','September','October','November','December'],
    days_short: ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],
  }
};

/** Translate key */
export function t(key) {
  return TR[LANG]?.[key] ?? TR.bn[key] ?? key;
}

// ── Month / Day helpers ──────────────────────────────────
export function moName(m) { return t('months')[m] ?? ''; }
export function dayName(d) { return t('days_short')[d] ?? ''; }

// ── Number / Money helpers ───────────────────────────────
export const taka  = n => `৳${(parseFloat(n) || 0).toFixed(0)}`;
export const takaF = n => `৳${(parseFloat(n) || 0).toFixed(2)}`;
export const pad   = n => String(n).padStart(2, '0');
export const ini   = n =>
  (n || '').split(' ').map(w => w[0] || '').join('').slice(0, 2).toUpperCase() || '?';

// Avatar color classes (10 variants)
export const avColor = name =>
  'av' + ((name?.charCodeAt(0) || 0) % 10);

// ── Date helpers ─────────────────────────────────────────
export function formatDate(d) {
  if (!d) return '';
  const dt = d?.toDate ? d.toDate() : new Date(d);
  return `${dt.getDate()} ${moName(dt.getMonth())} ${dt.getFullYear()}`;
}

export function dateKey(date = new Date()) {
  return `${date.getFullYear()}_${pad(date.getMonth() + 1)}_${pad(date.getDate())}`;
}

export function mealKey(uid, date = new Date()) {
  return `${dateKey(date)}_${uid}`;
}

export function dim(y, m) { return new Date(y, m + 1, 0).getDate(); }

// ── Toast ─────────────────────────────────────────────────
let _toastTimer = null;
/**
 * @param {string} msg
 * @param {'ok'|'er'|'info'} [type='ok']
 * @param {number} [ms=2600]
 */
export function toast(msg, type = 'ok', ms = 2600) {
  let el = document.getElementById('toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'toast';
    document.body.appendChild(el);
  }
  el.className = `toast ${type}`;
  el.textContent = msg;
  requestAnimationFrame(() => el.classList.add('on'));
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => el.classList.remove('on'), ms);
}

// ── Loading overlay ──────────────────────────────────────
// counter বাদ — সরাসরি show/hide, stuck spinner হবে না
export function ld(msg) {
  const el = document.getElementById('lov');
  if (!el) return;
  el.classList.add('on');
  const p = el.querySelector('p');
  if (p) p.textContent = msg || t('loading');
}

export function uld() {
  document.getElementById('lov')?.classList.remove('on');
}

// Timeout safety — ৮ সেকেন্ড পরেও spinner থাকলে জোর করে বন্ধ
export function ldWithTimeout(msg, ms = 8000) {
  ld(msg);
  return setTimeout(() => uld(), ms);
}

// ── Confirm dialog ───────────────────────────────────────
export function confirm(msg) {
  return window.confirm(msg || t('confirm_delete'));
}

// ── Role label ───────────────────────────────────────────
export function roleLabel(role) {
  const map = {
    'mess-admin':    t('role_mess_admin'),
    'mess-co-admin': t('role_mess_coadmin'),
    'member':        t('role_member'),
    'admin':         t('role_admin'),
    'co-admin':      t('role_coadmin'),
  };
  return map[role] || role;
}

// ── Expense categories ───────────────────────────────────
export const CATS = ['বাজার','রান্না','গ্যাস','বিদ্যুৎ','পানি','পরিষ্কার','অন্যান্য'];
export const CICO = {
  বাজার:'🛒', রান্না:'🍳', গ্যাস:'🔥',
  বিদ্যুৎ:'💡', পানি:'💧', পরিষ্কার:'🧹', অন্যান্য:'📦'
};

// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/pages/admin/admin-messes.js
//  সব মেসের list, active/deactive/delete
//  import { render } from './admin-messes.js';
// ══════════════════════════════════════════════════════════

import { db } from '../../firebase.js';
import { toast, ld, uld, taka, formatDate } from '../../utils.js';
import {
  collection, getDocs, doc, updateDoc, deleteDoc,
  query, orderBy, writeBatch, getDoc
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

export async function render(root) {
  root.innerHTML = `
<div>
  <div class="adp-hd">
    <div>
      <h2 class="adp-h">সব মেস</h2>
      <p class="adp-sub" id="mess-count">লোড হচ্ছে…</p>
    </div>
    <button class="btn btn-ghost btn-sm" onclick="window.__admRefreshMesses()">🔄 রিফ্রেশ</button>
  </div>

  <!-- Filter tabs -->
  <div class="adm-tabs">
    <button class="adm-tab active" id="mtab-all"      onclick="window.__admMessTab('all')">সব</button>
    <button class="adm-tab"        id="mtab-active"   onclick="window.__admMessTab('active')">সক্রিয়</button>
    <button class="adm-tab"        id="mtab-deactive" onclick="window.__admMessTab('deactive')">নিষ্ক্রিয়</button>
  </div>

  <div id="mess-list" class="mess-grid">
    <div class="adm-loading">লোড হচ্ছে…</div>
  </div>
</div>

<style>
.adp-hd{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:14px;flex-wrap:wrap}
.adp-h{font-size:17px;font-weight:700;color:var(--ink);margin:0}
.adp-sub{font-size:12px;color:var(--ink3);margin:3px 0 0}

.adm-tabs{display:flex;gap:6px;margin-bottom:14px;flex-wrap:wrap}
.adm-tab{
  height:30px;padding:0 12px;border-radius:20px;font-size:12px;font-weight:600;
  border:1.5px solid var(--line2);background:var(--paper);color:var(--ink3);cursor:pointer;
  font-family:var(--fn);transition:.12s;
}
.adm-tab:hover{background:var(--g7);border-color:var(--g4);color:var(--g1)}
.adm-tab.active{background:var(--g2);color:#fff;border-color:var(--g2)}

.mess-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px}

.mess-card{
  background:#fff;border:1px solid var(--line);border-radius:12px;
  box-shadow:var(--sh);overflow:hidden;
}
.mess-card-hd{padding:12px 14px;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:10px}
.mess-ic{font-size:20px;width:38px;height:38px;background:var(--g7);
  border-radius:9px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.mess-card-hd h3{font-size:13px;font-weight:700;color:var(--ink);margin:0;flex:1;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mess-card-hd p{font-size:11px;color:var(--ink3);margin:2px 0 0;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mess-card-bd{padding:12px 14px}
.mess-meta{font-size:11px;color:var(--ink3);margin-bottom:10px}
.mess-meta span{display:inline-block;margin-right:10px}
.mess-actions{display:flex;gap:6px;flex-wrap:wrap}

.badge-active  {background:var(--g7);color:var(--g1)}
.badge-deactive{background:var(--r3);color:var(--r1)}
.badge-pending {background:var(--a3);color:var(--a0)}

.adm-empty{
  grid-column:1/-1;text-align:center;padding:40px;
  color:var(--ink3);font-size:13px;
}
</style>`;

  window.__admRefreshMesses = () => _load(root);
  window.__admMessTab = (tab) => _filterTab(tab);
  window.__admToggleActive  = (id, cur) => _toggleActive(id, cur);
  window.__admDeleteMess    = (id, name) => _deleteMess(id, name);

  await _load(root);
}

let _allMesses = [];
let _curTab = 'all';

async function _load(root) {
  try {
    const snap = await getDocs(query(collection(db, 'messes'), orderBy('createdAt', 'desc')));
    _allMesses = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    document.getElementById('mess-count').textContent = `মোট ${_allMesses.length}টি মেস`;
    _renderList();
  } catch (err) {
    document.getElementById('mess-list').innerHTML =
      `<div class="adm-empty">⚠️ লোড ব্যর্থ: ${err.message}</div>`;
  }
}

function _filterTab(tab) {
  _curTab = tab;
  ['all','active','deactive'].forEach(t => {
    document.getElementById(`mtab-${t}`)?.classList.toggle('active', t === tab);
  });
  _renderList();
}

function _renderList() {
  const list = document.getElementById('mess-list');
  if (!list) return;

  const filtered = _curTab === 'all'
    ? _allMesses
    : _allMesses.filter(m => m.status === _curTab);

  if (!filtered.length) {
    list.innerHTML = `<div class="adm-empty">কোনো মেস নেই</div>`;
    return;
  }

  list.innerHTML = filtered.map(m => `
<div class="mess-card">
  <div class="mess-card-hd">
    <div class="mess-ic">🏠</div>
    <div style="flex:1;min-width:0">
      <h3>${_esc(m.name || 'অজানা মেস')}</h3>
      <p>${_esc(m.address || '—')}</p>
    </div>
    <span class="badge ${m.status === 'active' ? 'badge-active' : 'badge-deactive'}" style="font-size:10px;padding:3px 8px;border-radius:20px;font-weight:700;flex-shrink:0">
      ${m.status === 'active' ? '● সক্রিয়' : '○ নিষ্ক্রিয়'}
    </span>
  </div>
  <div class="mess-card-bd">
    <div class="mess-meta">
      <span>🆔 ${m.id.slice(0,8)}…</span>
      <span>📅 ${m.createdAt ? formatDate(m.createdAt) : '—'}</span>
    </div>
    <div class="mess-actions">
      <button class="btn btn-sm ${m.status === 'active' ? 'btn-amber' : 'btn-ghost'}"
        onclick="window.__admToggleActive('${m.id}','${m.status}')">
        ${m.status === 'active' ? '⏸ নিষ্ক্রিয় করুন' : '▶ সক্রিয় করুন'}
      </button>
      <button class="btn btn-sm btn-danger"
        onclick="window.__admDeleteMess('${m.id}','${_esc(m.name)}')">
        🗑 মুছুন
      </button>
    </div>
  </div>
</div>`).join('');
}

async function _toggleActive(id, cur) {
  const next = cur === 'active' ? 'deactive' : 'active';
  try {
    await updateDoc(doc(db, 'messes', id), { status: next });
    const m = _allMesses.find(x => x.id === id);
    if (m) m.status = next;
    _renderList();
    toast(`মেস ${next === 'active' ? 'সক্রিয়' : 'নিষ্ক্রিয়'} করা হয়েছে`, 'ok');
  } catch (err) {
    toast('আপডেট ব্যর্থ: ' + err.message, 'er');
  }
}

async function _deleteMess(id, name) {
  if (!window.confirm(`"${name}" মেসটি সম্পূর্ণ মুছে ফেলবেন?\nএই কাজ ফেরানো যাবে না।`)) return;
  ld('মুছে ফেলা হচ্ছে…');
  try {
    // Delete main mess doc (sub-collections must be deleted via Cloud Functions in production)
    await deleteDoc(doc(db, 'messes', id));
    _allMesses = _allMesses.filter(m => m.id !== id);
    _renderList();
    document.getElementById('mess-count').textContent = `মোট ${_allMesses.length}টি মেস`;
    toast('মেস মুছে ফেলা হয়েছে', 'ok');
  } catch (err) {
    toast('মুছতে ব্যর্থ: ' + err.message, 'er');
  } finally {
    uld();
  }
}

const _esc = s => String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

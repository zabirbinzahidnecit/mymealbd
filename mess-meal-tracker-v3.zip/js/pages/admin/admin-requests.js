// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/pages/admin/admin-requests.js
//  Mess Create Request approve/reject
//  import { render } from './admin-requests.js';
// ══════════════════════════════════════════════════════════

import { db } from '../../firebase.js';
import { currentProfile } from '../../auth.js';
import { toast, ld, uld, formatDate } from '../../utils.js';
import {
  collection, getDocs, doc, updateDoc, setDoc, getDoc,
  query, orderBy, serverTimestamp, writeBatch
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

export async function render(root) {
  root.innerHTML = `
<div>
  <div class="adp-hd">
    <div>
      <h2 class="adp-h">মেস তৈরির অনুরোধ</h2>
      <p class="adp-sub" id="req-count">লোড হচ্ছে…</p>
    </div>
    <button class="btn btn-ghost btn-sm" onclick="window.__admRefreshReqs()">🔄 রিফ্রেশ</button>
  </div>

  <div class="adm-tabs">
    <button class="adm-tab active" id="rtab-pending"  onclick="window.__admReqTab('pending')">অপেক্ষামাণ</button>
    <button class="adm-tab"        id="rtab-approved" onclick="window.__admReqTab('approved')">অনুমোদিত</button>
    <button class="adm-tab"        id="rtab-rejected" onclick="window.__admReqTab('rejected')">বাতিল</button>
    <button class="adm-tab"        id="rtab-all"      onclick="window.__admReqTab('all')">সব</button>
  </div>

  <div id="req-list" style="display:flex;flex-direction:column;gap:10px">
    <div class="adm-loading">লোড হচ্ছে…</div>
  </div>
</div>

<!-- Reject modal -->
<div class="adm-mo" id="reject-mo" style="display:none">
  <div class="adm-mbox">
    <h3 style="font-size:15px;font-weight:700;color:var(--ink);margin-bottom:10px">❌ অনুরোধ বাতিল</h3>
    <p style="font-size:12px;color:var(--ink3);margin-bottom:12px">কারণ লিখুন (ঐচ্ছিক):</p>
    <textarea id="reject-note" rows="3"
      style="width:100%;border:1.5px solid var(--line2);border-radius:8px;padding:9px 11px;
        font-size:13px;font-family:var(--fn);resize:vertical;outline:none;color:var(--ink)"
      placeholder="বাতিলের কারণ…"></textarea>
    <div style="display:flex;gap:8px;margin-top:12px">
      <button class="btn btn-ghost btn-sm" onclick="window.__admCloseReject()">বাতিল</button>
      <button class="btn btn-danger btn-sm" onclick="window.__admDoReject()">✗ বাতিল করুন</button>
    </div>
  </div>
</div>

<style>
.adm-mo{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:300;
  display:flex;align-items:center;justify-content:center;padding:20px}
.adm-mbox{background:#fff;border-radius:14px;padding:22px;width:100%;max-width:400px;
  box-shadow:0 16px 48px rgba(0,0,0,.18)}

.req-card{background:#fff;border:1px solid var(--line);border-radius:12px;
  box-shadow:var(--sh);padding:14px 16px}
.req-card-hd{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:10px}
.req-card-hd h3{font-size:14px;font-weight:700;color:var(--ink);margin:0}
.req-card-hd p{font-size:11px;color:var(--ink3);margin:3px 0 0}
.req-info{font-size:12px;color:var(--ink3);margin-bottom:12px;line-height:1.7}
.req-info span{font-weight:600;color:var(--ink)}
.req-actions{display:flex;gap:8px;flex-wrap:wrap}
.req-note{
  background:var(--a4);border:1px solid var(--a3);border-radius:8px;
  padding:8px 11px;font-size:12px;color:var(--a0);margin-top:10px;
}
</style>`;

  let _rejectId = null;

  window.__admRefreshReqs = () => _load();
  window.__admReqTab      = (tab) => _filterTab(tab);
  window.__admApprove     = (id) => _approve(id);
  window.__admReject      = (id) => { _rejectId = id; document.getElementById('reject-mo').style.display='flex'; };
  window.__admCloseReject = () => { _rejectId=null; document.getElementById('reject-mo').style.display='none'; };
  window.__admDoReject    = () => _reject(_rejectId);

  await _load();
}

let _allReqs = [];
let _curTab  = 'pending';

async function _load() {
  try {
    const snap = await getDocs(query(collection(db, 'messRequests'), orderBy('createdAt','desc')));
    _allReqs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    const pending = _allReqs.filter(r => r.status === 'pending').length;
    document.getElementById('req-count').textContent = `${pending}টি অপেক্ষামাণ`;
    _renderList();
  } catch (err) {
    document.getElementById('req-list').innerHTML =
      `<div class="adm-loading">⚠️ ${err.message}</div>`;
  }
}

function _filterTab(tab) {
  _curTab = tab;
  ['pending','approved','rejected','all'].forEach(t =>
    document.getElementById(`rtab-${t}`)?.classList.toggle('active', t === tab)
  );
  _renderList();
}

function _renderList() {
  const list = document.getElementById('req-list');
  if (!list) return;

  const filtered = _curTab === 'all'
    ? _allReqs
    : _allReqs.filter(r => r.status === _curTab);

  if (!filtered.length) {
    list.innerHTML = `<div class="adm-loading">কোনো অনুরোধ নেই</div>`;
    return;
  }

  const badge = {
    pending:  '<span class="badge b-amber">⏳ অপেক্ষামাণ</span>',
    approved: '<span class="badge b-green">✅ অনুমোদিত</span>',
    rejected: '<span class="badge b-red">❌ বাতিল</span>',
  };

  list.innerHTML = filtered.map(r => `
<div class="req-card">
  <div class="req-card-hd">
    <div>
      <h3>🏠 ${_esc(r.messName)}</h3>
      <p>${_esc(r.requesterName)} (${_esc(r.requesterEmail)})</p>
    </div>
    ${badge[r.status] || ''}
  </div>
  <div class="req-info">
    ${r.address ? `<div>📍 <span>${_esc(r.address)}</span></div>` : ''}
    ${r.description ? `<div>📝 ${_esc(r.description)}</div>` : ''}
    <div>📅 ${r.createdAt ? formatDate(r.createdAt) : '—'}</div>
  </div>
  ${r.reviewNote ? `<div class="req-note">💬 ${_esc(r.reviewNote)}</div>` : ''}
  ${r.status === 'pending' ? `
  <div class="req-actions">
    <button class="btn btn-sm btn-p" onclick="window.__admApprove('${r.id}')">✓ অনুমোদন</button>
    <button class="btn btn-sm btn-danger" onclick="window.__admReject('${r.id}')">✗ বাতিল</button>
  </div>` : ''}
</div>`).join('');
}

async function _approve(reqId) {
  const req = _allReqs.find(r => r.id === reqId);
  if (!req) return;

  ld('মেস তৈরি হচ্ছে…');
  try {
    const batch = writeBatch(db);
    const messRef = doc(collection(db, 'messes'));

    // Create mess
    batch.set(messRef, {
      name:      req.messName,
      address:   req.address || '',
      status:    'active',
      createdAt: serverTimestamp(),
      createdBy: req.requestedBy,
    });

    // Create default settings
    batch.set(doc(db, 'messes', messRef.id, 'settings', 'main'), {
      slots:          ['সকাল','দুপুর','রাত'],
      cutoffHour:     10,
      maxMealsPerDay: 3,
      rentEnabled:    false,
      rentGas:        0, rentElectric: 0, rentWater: 0, rentBua: 0,
      lang:           'bn',
    });

    // Add requester as mess-admin member
    batch.set(doc(db, 'messes', messRef.id, 'members', req.requestedBy), {
      name:     req.requesterName,
      email:    req.requesterEmail,
      avatar:   null,
      role:     'mess-admin',
      joinedAt: serverTimestamp(),
    });

    // Update user currentMessId
    batch.update(doc(db, 'users', req.requestedBy), {
      currentMessId: messRef.id,
      status: 'active',
    });

    // Mark request approved
    batch.update(doc(db, 'messRequests', reqId), {
      status:     'approved',
      reviewedBy: currentProfile?.uid || '',
      reviewNote: '',
    });

    await batch.commit();

    req.status = 'approved';
    _renderList();
    toast('মেস তৈরি হয়েছে এবং অনুমোদন দেওয়া হয়েছে!', 'ok');
  } catch (err) {
    toast('অনুমোদন ব্যর্থ: ' + err.message, 'er');
  } finally {
    uld();
  }
}

async function _reject(reqId) {
  const note = document.getElementById('reject-note')?.value.trim() || '';
  const req  = _allReqs.find(r => r.id === reqId);
  if (!req) return;

  try {
    await updateDoc(doc(db, 'messRequests', reqId), {
      status:     'rejected',
      reviewedBy: currentProfile?.uid || '',
      reviewNote: note,
    });
    req.status = 'rejected';
    req.reviewNote = note;
    _renderList();
    toast('অনুরোধ বাতিল করা হয়েছে', 'ok');
  } catch (err) {
    toast('বাতিল ব্যর্থ: ' + err.message, 'er');
  }

  document.getElementById('reject-mo').style.display = 'none';
  document.getElementById('reject-note').value = '';
}

const _esc = s => String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

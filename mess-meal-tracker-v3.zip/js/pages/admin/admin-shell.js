// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/pages/admin/admin-shell.js
//  Admin layout + nav + sub-page routing
//  import { render } from './admin-shell.js';
// ══════════════════════════════════════════════════════════

import { logout } from '../../auth.js';
import { t, LANG } from '../../utils.js';

const ADMIN_PAGES = [
  { id: 'messes',   label: 'সব মেস',         ico: '🏠' },
  { id: 'requests', label: 'মেস অনুরোধ',     ico: '📋' },
  { id: 'users',    label: 'ব্যবহারকারী',     ico: '👥' },
];

let _currentSub = 'messes';
let _profile = null;

export async function render(root, { profile }) {
  _profile = profile;
  root.innerHTML = `
<div class="adm-wrap">
  <!-- Sidebar -->
  <aside class="adm-sb" id="adm-sb">
    <div class="adm-logo">
      <div class="adm-logo-ic">🍽</div>
      <div>
        <h2 class="adm-logo-h">মেস মিল ট্র্যাকার</h2>
        <p class="adm-logo-s">Admin Panel</p>
      </div>
    </div>

    <div class="adm-user">
      ${profile.avatar
        ? `<img src="${profile.avatar}" class="adm-av-img" alt=""/>`
        : `<div class="adm-av-txt">${(profile.name||'A')[0].toUpperCase()}</div>`
      }
      <div class="adm-uinfo">
        <div class="adm-uname">${profile.name || profile.email}</div>
        <div class="adm-ubadge">${profile.platformRole === 'admin' ? '🔑 Admin' : '🛡 Co-Admin'}</div>
      </div>
    </div>

    <nav class="adm-nav">
      ${ADMIN_PAGES.map(p => `
        <button class="adm-nl ${_currentSub === p.id ? 'active' : ''}"
          id="adm-nav-${p.id}"
          onclick="window.__admNav('${p.id}')">
          <span class="adm-nl-ic">${p.ico}</span>
          <span>${p.label}</span>
          ${p.id === 'requests' ? '<span class="adm-badge-dot" id="req-badge"></span>' : ''}
        </button>`).join('')}
    </nav>

    <div class="adm-foot">
      <button class="adm-nl" onclick="window.__admLogout()">
        <span class="adm-nl-ic">🚪</span>
        <span>লগআউট</span>
      </button>
    </div>
  </aside>

  <!-- Overlay (mobile) -->
  <div class="adm-overlay" id="adm-ov" onclick="window.__admCloseSb()"></div>

  <!-- Main -->
  <div class="adm-main" id="adm-main">
    <div class="adm-topbar">
      <button class="adm-hbtn" id="adm-hbtn" onclick="window.__admOpenSb()">☰</button>
      <span class="adm-tbtit" id="adm-tbtit">সব মেস</span>
    </div>
    <div class="adm-page" id="adm-content">
      <div class="adm-loading">লোড হচ্ছে…</div>
    </div>
  </div>
</div>

<style>
.adm-wrap{display:flex;min-height:100vh;background:var(--paper)}

/* Sidebar */
.adm-sb{
  width:228px;flex-shrink:0;background:var(--g0);
  display:flex;flex-direction:column;
  position:fixed;top:0;left:0;bottom:0;z-index:100;
  box-shadow:2px 0 16px rgba(0,0,0,.18);
}
.adm-logo{
  padding:15px 13px 12px;border-bottom:1px solid rgba(255,255,255,.07);
  display:flex;align-items:center;gap:10px;
}
.adm-logo-ic{
  width:38px;height:38px;border-radius:11px;background:var(--g2);
  display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;
}
.adm-logo-h{color:var(--g6);font-size:13px;font-weight:700;margin:0}
.adm-logo-s{color:var(--g4);font-size:10px;margin:2px 0 0}

.adm-user{
  margin:10px 10px 0;background:rgba(255,255,255,.07);
  border-radius:8px;padding:9px 12px;display:flex;align-items:center;gap:9px;
}
.adm-av-img{width:36px;height:36px;border-radius:50%;object-fit:cover;flex-shrink:0;border:2px solid rgba(255,255,255,.2)}
.adm-av-txt{
  width:36px;height:36px;border-radius:50%;flex-shrink:0;
  background:var(--g2);color:#fff;font-size:15px;font-weight:700;
  display:flex;align-items:center;justify-content:center;
}
.adm-uname{color:#dff5ec;font-size:13px;font-weight:600;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.adm-ubadge{color:var(--g4);font-size:10px;margin-top:3px}

.adm-nav{flex:1;padding:8px 0;overflow-y:auto}
.adm-nl{
  display:flex;align-items:center;gap:10px;padding:9px 14px;
  font-size:13px;color:var(--g5);border:none;background:none;
  width:100%;text-align:left;cursor:pointer;border-left:3px solid transparent;
  transition:.12s;position:relative;font-family:var(--fn);
}
.adm-nl:hover{background:rgba(255,255,255,.06);color:#fff}
.adm-nl.active{background:rgba(31,168,96,.2);color:var(--g4);border-left-color:var(--g3)}
.adm-nl-ic{font-size:15px;width:22px;text-align:center;flex-shrink:0}
.adm-badge-dot{
  position:absolute;right:12px;width:8px;height:8px;border-radius:50%;
  background:var(--r1);border:1.5px solid var(--g0);display:none;
}
.adm-badge-dot.show{display:block}

.adm-foot{padding:11px;border-top:1px solid rgba(255,255,255,.07)}

/* Overlay */
.adm-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99}
.adm-overlay.on{display:block}

/* Main */
.adm-main{margin-left:228px;min-height:100vh;display:flex;flex-direction:column}
.adm-topbar{
  height:52px;background:#fff;border-bottom:1px solid var(--line);
  display:flex;align-items:center;padding:0 16px;gap:10px;
  position:sticky;top:0;z-index:50;box-shadow:var(--sh);
}
.adm-hbtn{display:none;width:34px;height:34px;align-items:center;justify-content:center;
  font-size:22px;color:var(--ink2);border-radius:8px;background:none;border:none;cursor:pointer}
.adm-hbtn:hover{background:var(--paper)}
.adm-tbtit{font-size:15px;font-weight:700;color:var(--ink);flex:1}
.adm-page{padding:16px;flex:1;max-width:1100px}
.adm-loading{padding:40px;text-align:center;color:var(--ink3)}

/* Mobile */
@media(max-width:760px){
  .adm-sb{transform:translateX(-228px);transition:transform .26s cubic-bezier(.4,0,.2,1)}
  .adm-sb.open{transform:translateX(0)}
  .adm-main{margin-left:0}
  .adm-hbtn{display:flex}
}
</style>`;

  // Wire up navigation
  window.__admNav      = (p) => _navigateTo(p);
  window.__admLogout   = () => logout();
  window.__admOpenSb   = () => {
    document.getElementById('adm-sb')?.classList.add('open');
    document.getElementById('adm-ov')?.classList.add('on');
  };
  window.__admCloseSb  = () => {
    document.getElementById('adm-sb')?.classList.remove('open');
    document.getElementById('adm-ov')?.classList.remove('on');
  };

  // Load default sub-page
  await _navigateTo('messes');

  // Load pending badge count
  _loadBadge();
}

async function _navigateTo(pageId) {
  _currentSub = pageId;

  // Update nav active state
  ADMIN_PAGES.forEach(p => {
    document.getElementById(`adm-nav-${p.id}`)?.classList.toggle('active', p.id === pageId);
  });

  // Update topbar title
  const title = ADMIN_PAGES.find(p => p.id === pageId)?.label || '';
  const tbtit = document.getElementById('adm-tbtit');
  if (tbtit) tbtit.textContent = title;

  // Close mobile sidebar
  document.getElementById('adm-sb')?.classList.remove('open');
  document.getElementById('adm-ov')?.classList.remove('on');

  // Load sub-page
  const content = document.getElementById('adm-content');
  if (!content) return;
  content.innerHTML = '<div class="adm-loading">লোড হচ্ছে…</div>';

  try {
    const mod = await import(`./${pageId === 'messes' ? 'admin-messes'
      : pageId === 'requests' ? 'admin-requests'
      : 'admin-users'}.js`);
    await mod.render(content, { profile: _profile });
  } catch (err) {
    content.innerHTML = `<div class="adm-loading" style="color:var(--r1)">⚠️ ${err.message}</div>`;
  }
}

async function _loadBadge() {
  try {
    const { getDocs, collection, query, where } = await import('https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js');
    const { db } = await import('../../firebase.js');
    const q = query(collection(db, 'messRequests'), where('status','==','pending'));
    const snap = await getDocs(q);
    const dot = document.getElementById('req-badge');
    if (dot && snap.size > 0) dot.classList.add('show');
  } catch (e) { /* ignore */ }
}

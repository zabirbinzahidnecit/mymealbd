// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/pages/admin/admin-users.js
//  Pending user list, co-admin assign
//  import { render } from './admin-users.js';
// ══════════════════════════════════════════════════════════

import { db } from '../../firebase.js';
import { currentProfile } from '../../auth.js';
import { toast, ld, uld, formatDate, ini, avColor } from '../../utils.js';
import {
  collection, getDocs, doc, updateDoc,
  query, where, orderBy
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

export async function render(root) {
  root.innerHTML = `
<div>
  <div class="adp-hd">
    <div>
      <h2 class="adp-h">ব্যবহারকারী ব্যবস্থাপনা</h2>
      <p class="adp-sub" id="usr-count">লোড হচ্ছে…</p>
    </div>
    <button class="btn btn-ghost btn-sm" onclick="window.__admRefreshUsers()">🔄 রিফ্রেশ</button>
  </div>

  <div class="adm-tabs">
    <button class="adm-tab active" id="utab-pending"  onclick="window.__admUsrTab('pending')">অপেক্ষামাণ</button>
    <button class="adm-tab"        id="utab-active"   onclick="window.__admUsrTab('active')">সক্রিয়</button>
    <button class="adm-tab"        id="utab-all"      onclick="window.__admUsrTab('all')">সব</button>
  </div>

  <div id="usr-list" style="display:flex;flex-direction:column;gap:8px">
    <div class="adm-loading">লোড হচ্ছে…</div>
  </div>
</div>

<style>
.usr-card{
  background:#fff;border:1px solid var(--line);border-radius:12px;
  padding:12px 14px;display:flex;align-items:center;gap:12px;
  box-shadow:var(--sh);flex-wrap:wrap;
}
.usr-av{
  width:42px;height:42px;border-radius:50%;flex-shrink:0;overflow:hidden;
  display:flex;align-items:center;justify-content:center;
  font-size:16px;font-weight:700;
}
.usr-av img{width:100%;height:100%;object-fit:cover}
.usr-info{flex:1;min-width:0}
.usr-info h3{font-size:13px;font-weight:700;color:var(--ink);margin:0;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.usr-info p{font-size:11px;color:var(--ink3);margin:2px 0 0}
.usr-actions{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
</style>`;

  window.__admRefreshUsers = () => _load();
  window.__admUsrTab       = (tab) => _filterTab(tab);
  window.__admAssignCoAdmin = (uid) => _assignCoAdmin(uid);
  window.__admRemoveCoAdmin = (uid) => _removeCoAdmin(uid);

  await _load();
}

let _allUsers = [];
let _curTab   = 'pending';

async function _load() {
  try {
    const snap = await getDocs(query(collection(db, 'users'), orderBy('createdAt', 'desc')));
    _allUsers = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    const pending = _allUsers.filter(u => u.status === 'pending').length;
    document.getElementById('usr-count').textContent = `${pending}জন অপেক্ষামাণ`;
    _renderList();
  } catch (err) {
    document.getElementById('usr-list').innerHTML = `<div class="adm-loading">⚠️ ${err.message}</div>`;
  }
}

function _filterTab(tab) {
  _curTab = tab;
  ['pending','active','all'].forEach(t =>
    document.getElementById(`utab-${t}`)?.classList.toggle('active', t === tab)
  );
  _renderList();
}

function _renderList() {
  const list = document.getElementById('usr-list');
  if (!list) return;

  const filtered = _curTab === 'all'
    ? _allUsers
    : _allUsers.filter(u => u.status === _curTab);

  if (!filtered.length) {
    list.innerHTML = `<div class="adm-loading">কোনো ব্যবহারকারী নেই</div>`;
    return;
  }

  list.innerHTML = filtered.map(u => {
    const av = u.avatar
      ? `<img src="${_esc(u.avatar)}" alt=""/>`
      : `<span>${ini(u.name || u.email)}</span>`;
    const avCls = u.avatar ? '' : avColor(u.name || u.email);

    const roleBadge = u.platformRole === 'admin'
      ? '<span class="badge b-green">🔑 Admin</span>'
      : u.platformRole === 'co-admin'
      ? '<span class="badge b-blue">🛡 Co-Admin</span>'
      : u.currentMessId
      ? '<span class="badge b-muted">🏠 মেসে আছে</span>'
      : '<span class="badge b-amber">⏳ অপেক্ষামাণ</span>';

    const isMe = u.id === currentProfile?.uid;
    const isPlatAdmin = u.platformRole === 'admin';

    return `
<div class="usr-card">
  <div class="usr-av ${avCls}">${av}</div>
  <div class="usr-info">
    <h3>${_esc(u.name || '—')} ${isMe ? '(আপনি)' : ''}</h3>
    <p>${_esc(u.email || '—')}</p>
    <p style="margin-top:3px">📅 ${u.createdAt ? formatDate(u.createdAt) : '—'}</p>
  </div>
  <div class="usr-actions">
    ${roleBadge}
    ${!isMe && !isPlatAdmin ? (
      u.platformRole === 'co-admin'
        ? `<button class="btn btn-sm btn-danger" onclick="window.__admRemoveCoAdmin('${u.id}')">🛡 Co-Admin সরান</button>`
        : `<button class="btn btn-sm btn-blue" onclick="window.__admAssignCoAdmin('${u.id}')">+ Co-Admin করুন</button>`
    ) : ''}
  </div>
</div>`;
  }).join('');
}

async function _assignCoAdmin(uid) {
  if (!window.confirm('এই ব্যবহারকারীকে Platform Co-Admin করবেন?')) return;
  try {
    await updateDoc(doc(db, 'users', uid), { platformRole: 'co-admin' });
    const u = _allUsers.find(x => x.id === uid);
    if (u) u.platformRole = 'co-admin';
    _renderList();
    toast('Co-Admin করা হয়েছে', 'ok');
  } catch (err) {
    toast('ব্যর্থ: ' + err.message, 'er');
  }
}

async function _removeCoAdmin(uid) {
  if (!window.confirm('Co-Admin role সরাবেন?')) return;
  try {
    await updateDoc(doc(db, 'users', uid), { platformRole: null });
    const u = _allUsers.find(x => x.id === uid);
    if (u) u.platformRole = null;
    _renderList();
    toast('Co-Admin role সরানো হয়েছে', 'ok');
  } catch (err) {
    toast('ব্যর্থ: ' + err.message, 'er');
  }
}

const _esc = s => String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

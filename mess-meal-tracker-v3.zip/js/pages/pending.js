// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/pages/pending.js
//  Pending user page — Mess Create Request form
//  import { render } from './pending.js';
// ══════════════════════════════════════════════════════════

import { db } from '../firebase.js';
import { currentUser, currentProfile, logout } from '../auth.js';
import { toast, ld, uld, t, LANG, setLang } from '../utils.js';
import {
  doc, collection, addDoc, query, where, getDocs,
  serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

export async function render(root, { profile }) {
  // Check if user already has a pending request
  let existingRequest = null;
  try {
    const q = query(
      collection(db, 'messRequests'),
      where('requestedBy', '==', profile.uid),
      where('status', '==', 'pending')
    );
    const snap = await getDocs(q);
    if (!snap.empty) existingRequest = { id: snap.docs[0].id, ...snap.docs[0].data() };
  } catch (e) { /* ignore */ }

  root.innerHTML = `
<div class="pend-wrap">
  <div class="pend-bg-orb"></div>

  <!-- Topbar -->
  <div class="pend-topbar">
    <div class="pend-logo">
      <div class="pend-logo-ic">🍽</div>
      <span class="pend-logo-name">মেস মিল ট্র্যাকার</span>
    </div>
    <div class="pend-user">
      ${profile.avatar
        ? `<img src="${profile.avatar}" class="pend-av-img" alt=""/>`
        : `<div class="pend-av-txt">${(profile.name||'?')[0].toUpperCase()}</div>`
      }
      <span class="pend-uname">${profile.name || profile.email}</span>
      <button class="btn btn-ghost btn-sm" onclick="window.__mmLogout()">লগআউট</button>
    </div>
  </div>

  <div class="pend-body">
    <!-- Status card -->
    <div class="pend-status-card">
      <div class="pend-status-ic">👤</div>
      <h2 class="pend-status-h">আপনি কোনো মেসে নেই</h2>
      <p class="pend-status-p">
        আপনি এখনো কোনো মেসের সদস্য নন। নিচের যেকোনো একটি করুন:
      </p>
      <div class="pend-options">
        <div class="pend-opt">
          <div class="pend-opt-ic">📨</div>
          <div>
            <p class="pend-opt-t">মেস Admin-এর invite পান</p>
            <p class="pend-opt-s">আপনার Gmail-এ invite লিংক পাঠাতে বলুন</p>
          </div>
        </div>
        <div class="pend-or">অথবা</div>
        <div class="pend-opt">
          <div class="pend-opt-ic">🏠</div>
          <div>
            <p class="pend-opt-t">নতুন মেস তৈরির request পাঠান</p>
            <p class="pend-opt-s">Admin approve করলে আপনি মেস Admin হবেন</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Request form or existing request status -->
    <div class="pend-form-card" id="pend-form-area">
      ${existingRequest ? _renderExisting(existingRequest) : _renderForm()}
    </div>
  </div>
</div>

<style>
.pend-wrap{min-height:100vh;background:var(--g0);position:relative;overflow:hidden}
.pend-bg-orb{
  position:absolute;width:500px;height:500px;border-radius:50%;
  background:rgba(20,107,64,.15);filter:blur(100px);
  top:-100px;right:-100px;pointer-events:none;
}

/* Topbar */
.pend-topbar{
  display:flex;align-items:center;gap:12px;padding:12px 20px;
  background:rgba(0,0,0,.2);border-bottom:1px solid rgba(255,255,255,.07);
  position:sticky;top:0;z-index:50;backdrop-filter:blur(8px);
}
.pend-logo{display:flex;align-items:center;gap:8px;flex:1}
.pend-logo-ic{
  width:32px;height:32px;border-radius:9px;background:var(--g2);
  display:flex;align-items:center;justify-content:center;font-size:17px;
}
.pend-logo-name{color:var(--g6);font-size:13px;font-weight:700}
.pend-user{display:flex;align-items:center;gap:8px}
.pend-av-img,.pend-av-txt{
  width:30px;height:30px;border-radius:50%;flex-shrink:0;overflow:hidden;
}
.pend-av-img{object-fit:cover}
.pend-av-txt{
  background:var(--g2);color:#fff;font-size:13px;font-weight:700;
  display:flex;align-items:center;justify-content:center;
}
.pend-uname{color:#dff5ec;font-size:13px;font-weight:600;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:140px}

/* Body */
.pend-body{max-width:560px;margin:0 auto;padding:24px 16px;display:flex;flex-direction:column;gap:16px}

/* Status card */
.pend-status-card{
  background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);
  border-radius:18px;padding:24px;text-align:center;
}
.pend-status-ic{font-size:36px;margin-bottom:10px}
.pend-status-h{color:var(--g6);font-size:17px;font-weight:700;margin-bottom:8px}
.pend-status-p{color:var(--g5);font-size:13px;margin-bottom:18px;line-height:1.6}

.pend-options{text-align:left;display:flex;flex-direction:column;gap:10px}
.pend-opt{
  display:flex;align-items:flex-start;gap:12px;
  background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);
  border-radius:12px;padding:12px;
}
.pend-opt-ic{font-size:22px;flex-shrink:0}
.pend-opt-t{color:var(--g6);font-size:13px;font-weight:600;margin-bottom:2px}
.pend-opt-s{color:var(--g5);font-size:11px;line-height:1.5}
.pend-or{
  text-align:center;color:var(--g4);font-size:12px;font-weight:700;
  letter-spacing:.5px;padding:4px 0;
}

/* Form card */
.pend-form-card{
  background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);
  border-radius:18px;padding:24px;
}
.pend-form-card h3{color:var(--g6);font-size:15px;font-weight:700;margin-bottom:4px}
.pend-form-card .sub{color:var(--g5);font-size:12px;margin-bottom:18px;line-height:1.5}

.pend-field{margin-bottom:13px}
.pend-field label{
  display:block;font-size:10px;font-weight:700;color:var(--g5);
  text-transform:uppercase;letter-spacing:.6px;margin-bottom:5px;
}
.pend-field input,.pend-field textarea{
  width:100%;background:rgba(255,255,255,.07);border:1.5px solid rgba(255,255,255,.1);
  border-radius:9px;padding:10px 12px;font-size:13px;color:var(--g6);outline:none;
  font-family:var(--fn);resize:vertical;transition:.15s;
}
.pend-field input::placeholder,.pend-field textarea::placeholder{color:rgba(255,255,255,.2)}
.pend-field input:focus,.pend-field textarea:focus{
  border-color:var(--g3);background:rgba(255,255,255,.1);
}

.pend-submit{
  width:100%;height:42px;background:var(--g2);color:#fff;border:none;
  border-radius:10px;font-size:14px;font-weight:600;cursor:pointer;
  font-family:var(--fn);transition:.15s;
}
.pend-submit:hover{background:var(--g1)}
.pend-submit:disabled{opacity:.5;cursor:not-allowed}

/* Existing request */
.exist-req{text-align:center;padding:8px 0}
.exist-req-ic{font-size:32px;margin-bottom:10px}
.exist-req h3{color:var(--g6);font-size:15px;font-weight:700;margin-bottom:8px}
.exist-req p{color:var(--g5);font-size:13px;margin-bottom:6px;line-height:1.6}
.req-badge{
  display:inline-flex;align-items:center;gap:6px;
  padding:5px 14px;border-radius:20px;font-size:12px;font-weight:700;
  background:rgba(245,224,176,.15);color:#f5e0b0;border:1px solid rgba(245,224,176,.2);
  margin-bottom:14px;
}
.exist-req .note{font-size:11px;color:rgba(255,255,255,.3);margin-top:10px}
</style>`;

  window.__mmLogout = () => logout();
}

function _renderForm() {
  return `
<h3>🏠 নতুন মেস তৈরির অনুরোধ</h3>
<p class="sub">
  Admin approve করলে আপনার মেস active হবে এবং আপনি Mess Admin হবেন।
</p>
<div class="pend-field">
  <label>মেসের নাম *</label>
  <input id="req-name" placeholder="যেমন: মিয়া বাড়ি মেস" maxlength="80"/>
</div>
<div class="pend-field">
  <label>ঠিকানা</label>
  <input id="req-addr" placeholder="রোড, এলাকা, শহর" maxlength="120"/>
</div>
<div class="pend-field">
  <label>বিবরণ (ঐচ্ছিক)</label>
  <textarea id="req-desc" rows="3" placeholder="মেস সম্পর্কে সংক্ষিপ্ত বিবরণ…" maxlength="300"></textarea>
</div>
<button class="pend-submit" id="req-submit" onclick="window.__mmSubmitReq()">
  📤 অনুরোধ পাঠান
</button>`;
}

function _renderExisting(req) {
  const statusMap = {
    pending:  { label: '⏳ অপেক্ষামাণ', cls: '' },
    approved: { label: '✅ অনুমোদিত',   cls: 'b-green' },
    rejected: { label: '❌ বাতিল',       cls: 'b-red' },
  };
  const s = statusMap[req.status] || statusMap.pending;
  return `
<div class="exist-req">
  <div class="exist-req-ic">📋</div>
  <h3>আপনার অনুরোধ পাঠানো হয়েছে</h3>
  <div class="req-badge">${s.label}</div>
  <p><strong>${req.messName}</strong></p>
  ${req.address ? `<p style="font-size:11px;color:rgba(255,255,255,.4)">${req.address}</p>` : ''}
  ${req.reviewNote ? `<p style="color:#f5e0b0;font-size:12px;margin-top:8px">📝 ${req.reviewNote}</p>` : ''}
  <p class="note">Admin review করলে আপনাকে জানানো হবে। পেজ refresh করে status দেখুন।</p>
  ${req.status === 'rejected'
    ? `<button class="pend-submit" style="margin-top:12px" onclick="window.__mmNewReq()">নতুন অনুরোধ পাঠান</button>`
    : ''
  }
</div>`;
}

// Expose submit handler
window.__mmSubmitReq = async () => {
  const name = document.getElementById('req-name')?.value.trim();
  const addr = document.getElementById('req-addr')?.value.trim();
  const desc = document.getElementById('req-desc')?.value.trim();

  if (!name) { toast('মেসের নাম দিন', 'er'); return; }

  const btn = document.getElementById('req-submit');
  if (btn) { btn.disabled = true; btn.textContent = 'পাঠানো হচ্ছে…'; }

  try {
    await addDoc(collection(db, 'messRequests'), {
      requestedBy:   currentProfile.uid,
      requesterEmail: currentProfile.email,
      requesterName:  currentProfile.name,
      messName:  name,
      address:   addr || '',
      description: desc || '',
      status:    'pending',
      reviewedBy: null,
      reviewNote: '',
      createdAt: serverTimestamp()
    });
    toast('অনুরোধ পাঠানো হয়েছে! Admin review করবেন।', 'ok');

    // Re-render with existing status
    document.getElementById('pend-form-area').innerHTML = _renderExisting({
      messName: name, address: addr, status: 'pending'
    });
  } catch (err) {
    toast('পাঠানো যায়নি: ' + err.message, 'er');
    if (btn) { btn.disabled = false; btn.textContent = '📤 অনুরোধ পাঠান'; }
  }
};

window.__mmNewReq = () => {
  document.getElementById('pend-form-area').innerHTML = _renderForm();
};

// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/pages/mess/mess-shell.js
//  Mess layout + sidebar + bottom nav + sub-page routing
//  import { render } from './mess-shell.js';
// ══════════════════════════════════════════════════════════

import { db } from '../../firebase.js';
import { logout, currentProfile } from '../../auth.js';
import { toast, t, LANG, setLang } from '../../utils.js';
import {
  doc, getDoc, onSnapshot, collection, query, where, getDocs
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

// ── Mess context (shared across pages) ─────────────────
export let messId      = null;
export let messData    = null;
export let messSettings = { slots:['সকাল','দুপুর','রাত'], cutoffHour:10, maxMealsPerDay:3, rentEnabled:false, lang:'bn' };
export let myMessRole  = null; // 'mess-admin' | 'mess-co-admin' | 'member'

export const isMessAdmin   = () => myMessRole === 'mess-admin';
export const isMessCoAdmin = () => ['mess-admin','mess-co-admin'].includes(myMessRole);

// ── Nav items ───────────────────────────────────────────
const NAV = [
  { id:'home',     ico:'🏠', lbl:'হোম' },
  { id:'meal',     ico:'🍚', lbl:'মিল' },
  { id:'bazar',    ico:'🛒', lbl:'বাজার' },
  { id:'deposit',  ico:'💰', lbl:'ডিপোজিট' },
  { id:'report',   ico:'📊', lbl:'রিপোর্ট' },
  { id:'notice',   ico:'📢', lbl:'নোটিশ' },
  { id:'requests', ico:'✅', lbl:'অনুমোদন', badge:true },
  { id:'members',  ico:'👥', lbl:'সদস্য' },
  { id:'profile',  ico:'👤', lbl:'প্রোফাইল' },
  { id:'settings', ico:'⚙️', lbl:'সেটিংস' },
];

let _curSub = 'home';
let _profile = null;
let _messName = '';

export async function render(root, { profile }) {
  _profile = profile;
  messId = profile.currentMessId;

  // Load mess data & role
  await _loadMessContext();

  root.innerHTML = `
<div class="app-wrap" id="app-wrap">
  <!-- Sidebar -->
  <aside class="sb" id="app-sb">
    <div class="sb-logo">
      <div class="ic">🍽</div>
      <div class="brand">
        <h2 id="sb-mess-name">${_esc(messData?.name || 'মেস')}</h2>
        <p id="sb-mess-addr">${_esc(messData?.address || '')}</p>
      </div>
    </div>

    <div class="sb-user">
      ${_profile.avatar
        ? `<img src="${_esc(_profile.avatar)}" class="sb-av" style="width:36px;height:36px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.2)" alt=""/>`
        : `<div class="sb-av">${(_profile.name||'?')[0].toUpperCase()}</div>`
      }
      <div class="sb-info">
        <div class="uname">${_esc(_profile.name || _profile.email)}</div>
        <div class="ubadge">${_roleBadge(myMessRole)}</div>
      </div>
    </div>

    <nav class="sb-nav" id="sb-nav">
      ${_renderNavItems()}
    </nav>

    <div class="sb-foot">
      <button class="nl" onclick="window.__messLogout()">
        <span class="ico">🚪</span>লগআউট
      </button>
      <div class="sb-credits">মেস মিল ট্র্যাকার v3.0</div>
    </div>
  </aside>

  <!-- Overlay -->
  <div id="sb-overlay" onclick="window.__messCloseSb()"></div>

  <!-- Main -->
  <div class="main" id="app-main-col">
    <div class="topbar">
      <button class="hbtn" id="mob-toggle" onclick="window.__messOpenSb()">☰</button>
      <span class="tbtit" id="topbar-title">হোম</span>
      <div class="mc" id="topbar-controls"></div>
    </div>
    <div class="page" id="mess-page-content">
      <div style="padding:40px;text-align:center;color:var(--ink3)">লোড হচ্ছে…</div>
    </div>
  </div>
</div>`;

  // Wire handlers
  window.__messLogout  = () => logout();
  window.__messOpenSb  = () => { document.getElementById('app-sb')?.classList.add('open'); document.getElementById('sb-overlay')?.classList.add('on'); };
  window.__messCloseSb = () => { document.getElementById('app-sb')?.classList.remove('open'); document.getElementById('sb-overlay')?.classList.remove('on'); };
  window.__messNav     = (p) => navigate(p);

  // Listen for navigate events from sub-pages
  window.addEventListener('mm:navigate', e => navigate(e.detail.page, e.detail.params));

  // Load default page
  await navigate('home');

  // Listen for pending requests badge
  _watchRequestsBadge();
}

function _renderNavItems() {
  return NAV.map(n => {
    // Hide settings if not mess-admin
    if (n.id === 'settings' && !isMessAdmin()) return '';
    // Hide rent if not enabled
    if (n.id === 'rent' && !messSettings.rentEnabled) return '';
    return `
<button class="nl ${_curSub === n.id ? 'active' : ''}" id="nl-${n.id}"
  onclick="window.__messNav('${n.id}')">
  <span class="ico">${n.ico}</span>
  <span>${n.lbl}</span>
  ${n.badge ? '<span class="badge-dot" id="req-badge-dot"></span>' : ''}
</button>`;
  }).join('');
}

export async function navigate(pageId, params = {}) {
  _curSub = pageId;

  // Update nav
  NAV.forEach(n => document.getElementById(`nl-${n.id}`)?.classList.toggle('active', n.id === pageId));

  // Update topbar title
  const nav = NAV.find(n => n.id === pageId);
  const title = document.getElementById('topbar-title');
  if (title && nav) title.textContent = nav.lbl;

  // Close mobile sidebar
  window.__messCloseSb();

  // Clear topbar controls
  const ctrl = document.getElementById('topbar-controls');
  if (ctrl) ctrl.innerHTML = '';

  const content = document.getElementById('mess-page-content');
  if (!content) return;
  content.innerHTML = '<div style="padding:40px;text-align:center;color:var(--ink3)">লোড হচ্ছে…</div>';

  const PAGE_MAP = {
    home:     'home', meal:    'meal',
    bazar:    'bazar', deposit: 'deposit',
    report:   'report', notice:  'notice',
    requests: 'requests', members: 'members',
    profile:  'profile', settings:'settings',
  };

  const file = PAGE_MAP[pageId];
  if (!file) return;

  try {
    const mod = await import(`./${file}.js`);
    await mod.render(content, { messId, messData, messSettings, profile: _profile, myMessRole, params });
  } catch (err) {
    console.error(`Failed to load mess page: ${pageId}`, err);
    content.innerHTML = `<div style="padding:40px;text-align:center;color:var(--r1)">⚠️ ${err.message}</div>`;
  }
}

async function _loadMessContext() {
  try {
    const [messSnap, settingsSnap, memberSnap] = await Promise.all([
      getDoc(doc(db, 'messes', messId)),
      getDoc(doc(db, 'messes', messId, 'settings', 'main')),
      getDoc(doc(db, 'messes', messId, 'members', _profile.uid)),
    ]);

    messData     = messSnap.exists() ? { id: messSnap.id, ...messSnap.data() } : null;
    messSettings = settingsSnap.exists() ? settingsSnap.data() : messSettings;
    myMessRole   = memberSnap.exists() ? memberSnap.data().role : 'member';

    // Apply mess language setting
    if (messSettings.lang && messSettings.lang !== LANG) {
      setLang(messSettings.lang);
    }
  } catch (err) {
    console.error('Mess context load error:', err);
    toast('মেস তথ্য লোড ব্যর্থ', 'er');
  }
}

function _watchRequestsBadge() {
  if (!isMessCoAdmin()) return;
  try {
    const q = query(
      collection(db, 'messes', messId, 'expenses'),
      where('status','==','pending')
    );
    onSnapshot(q, snap => {
      const dot = document.getElementById('req-badge-dot');
      if (dot) dot.classList.toggle('show', snap.size > 0);
    });
  } catch (e) {}
}

function _roleBadge(role) {
  const map = {
    'mess-admin':    '<span style="font-size:9px;background:rgba(31,168,96,.2);color:#3fcf85;padding:2px 7px;border-radius:10px;font-weight:700">মেস অ্যাডমিন</span>',
    'mess-co-admin': '<span style="font-size:9px;background:rgba(74,120,232,.2);color:#4a78e8;padding:2px 7px;border-radius:10px;font-weight:700">কো-অ্যাডমিন</span>',
    'member':        '<span style="font-size:9px;background:rgba(255,255,255,.1);color:rgba(255,255,255,.5);padding:2px 7px;border-radius:10px;font-weight:700">সদস্য</span>',
  };
  return map[role] || '';
}

const _esc = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

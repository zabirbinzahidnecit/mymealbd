// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/pages/mess/profile.js
//  প্রোফাইল: নাম update, ছবি upload, মাসিক summary, leave mess
// ══════════════════════════════════════════════════════════

import { db, storage } from '../../firebase.js';
import { toast, ld, uld, taka, pad, moName, ini, avColor, LANG, setLang } from '../../utils.js';
import {
  doc, getDoc, updateDoc, collection, getDocs,
  query, where, writeBatch, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';
import {
  ref as storageRef, uploadBytes, getDownloadURL
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js';

const TODAY = new Date();
let _ctx = {};

export async function render(root, ctx) {
  _ctx = ctx;
  const { profile } = ctx;

  root.innerHTML = `
<div>
  <h2 style="font-size:17px;font-weight:700;color:var(--ink);margin-bottom:14px">👤 আমার প্রোফাইল</h2>

  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:13px">

    <!-- Avatar card -->
    <div class="card">
      <div class="ch"><h3>🖼 প্রোফাইল ছবি</h3></div>
      <div class="cb" style="display:flex;flex-direction:column;align-items:center;gap:10px">
        <div id="prof-av-display"
          style="width:80px;height:80px;border-radius:50%;border:3px solid var(--g4);
            overflow:hidden;cursor:pointer;display:flex;align-items:center;justify-content:center;
            font-size:28px;font-weight:700;flex-shrink:0"
          onclick="document.getElementById('prof-pic-inp').click()">
          ${profile.avatar
            ? `<img src="${_esc(profile.avatar)}" style="width:100%;height:100%;object-fit:cover" alt=""/>`
            : `<span class="${avColor(profile.name)}">${ini(profile.name || profile.email)}</span>`
          }
        </div>
        <input type="file" id="prof-pic-inp" accept="image/*" style="display:none"
          onchange="window.__profUploadPic(this)"/>
        <p style="font-size:11px;color:var(--ink3);text-align:center">ছবিতে ক্লিক করে পরিবর্তন করুন</p>
        <p style="font-size:10px;color:var(--ink4);text-align:center">সর্বোচ্চ ২MB, যেকোনো image format</p>
      </div>
    </div>

    <!-- Info card -->
    <div class="card">
      <div class="ch"><h3>📝 মূল তথ্য</h3></div>
      <div class="cb">
        <div class="field">
          <label class="lbl">নাম</label>
          <input class="inp inp-sm" id="prof-name" value="${_esc(profile.name || '')}" placeholder="আপনার নাম"/>
        </div>
        <div class="field">
          <label class="lbl">Email</label>
          <input class="inp inp-sm" value="${_esc(profile.email || '')}" disabled style="opacity:.6"/>
        </div>
        <div class="field">
          <label class="lbl">ভাষা</label>
          <select class="inp inp-sm" id="prof-lang">
            <option value="bn" ${LANG === 'bn' ? 'selected' : ''}>বাংলা</option>
            <option value="en" ${LANG === 'en' ? 'selected' : ''}>English</option>
          </select>
        </div>
        <button class="btn btn-p btn-sm" onclick="window.__profSave()">✓ আপডেট করুন</button>
        <div id="prof-msg" style="margin-top:8px;font-size:12px"></div>
      </div>
    </div>

    <!-- Monthly summary -->
    <div class="card">
      <div class="ch">
        <h3>📊 এই মাসের হিসাব</h3>
        <span style="font-size:11px;color:var(--ink3)">${moName(TODAY.getMonth())} ${TODAY.getFullYear()}</span>
      </div>
      <div class="cb" id="prof-summary">লোড হচ্ছে…</div>
    </div>

    <!-- Leave mess -->
    <div class="card" style="border-color:var(--r3)">
      <div class="ch"><h3 style="color:var(--r1)">🚪 মেস ছাড়ুন</h3></div>
      <div class="cb">
        <p style="font-size:12px;color:var(--ink3);margin-bottom:12px;line-height:1.6">
          মেস ছাড়লে আপনার সব মিল ও তথ্য থাকবে, কিন্তু আপনি আর এই মেসে প্রবেশ করতে পারবেন না।
          নতুন Invite ছাড়া বা নতুন মেস তৈরি না করা পর্যন্ত মেস access থাকবে না।
        </p>
        <button class="btn btn-danger btn-sm" onclick="window.__profLeaveMess()">মেস ছাড়ুন</button>
      </div>
    </div>
  </div>
</div>`;

  window.__profSave       = () => _save();
  window.__profUploadPic  = el => _uploadPic(el);
  window.__profLeaveMess  = () => _leaveMess();

  await _loadSummary();
}

async function _save() {
  const name = document.getElementById('prof-name')?.value.trim();
  const lang = document.getElementById('prof-lang')?.value || 'bn';
  if (!name) { toast('নাম দিন', 'er'); return; }

  const btn = document.querySelector('[onclick="window.__profSave()"]');
  if (btn) { btn.disabled = true; btn.textContent = 'সেভ হচ্ছে…'; }

  try {
    // Update user doc
    await updateDoc(doc(db,'users',_ctx.profile.uid), { name });
    // Update member doc
    await updateDoc(doc(db,'messes',_ctx.messId,'members',_ctx.profile.uid), { name });
    // Update mess settings lang
    await updateDoc(doc(db,'messes',_ctx.messId,'settings','main'), { lang });

    // Update local profile
    _ctx.profile.name = name;
    setLang(lang);

    const msgEl = document.getElementById('prof-msg');
    if (msgEl) { msgEl.textContent = '✓ প্রোফাইল আপডেট হয়েছে'; msgEl.style.color = 'var(--g1)'; }
    toast('প্রোফাইল আপডেট হয়েছে', 'ok');
  } catch (err) {
    toast('আপডেট ব্যর্থ: ' + err.message, 'er');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '✓ আপডেট করুন'; }
  }
}

async function _uploadPic(input) {
  const file = input.files?.[0];
  if (!file) return;
  if (file.size > 2 * 1024 * 1024) { toast('ছবি ২MB এর কম হতে হবে', 'er'); return; }
  if (!file.type.startsWith('image/')) { toast('শুধু image file দিন', 'er'); return; }

  ld('ছবি আপলোড হচ্ছে…');
  try {
    const path  = `avatars/${_ctx.profile.uid}/${Date.now()}_${file.name}`;
    const sRef  = storageRef(storage, path);
    await uploadBytes(sRef, file);
    const url   = await getDownloadURL(sRef);

    // Update both user and member docs
    await Promise.all([
      updateDoc(doc(db,'users',_ctx.profile.uid), { avatar: url }),
      updateDoc(doc(db,'messes',_ctx.messId,'members',_ctx.profile.uid), { avatar: url })
    ]);

    // Update display
    const avEl = document.getElementById('prof-av-display');
    if (avEl) avEl.innerHTML = `<img src="${url}" style="width:100%;height:100%;object-fit:cover" alt=""/>`;
    _ctx.profile.avatar = url;
    toast('ছবি আপলোড হয়েছে', 'ok');
  } catch (err) {
    toast('আপলোড ব্যর্থ: ' + err.message, 'er');
  } finally {
    uld();
  }
}

async function _loadSummary() {
  const el = document.getElementById('prof-summary');
  if (!el) return;

  const monthStr    = `${TODAY.getFullYear()}-${pad(TODAY.getMonth()+1)}`;
  const monthPrefix = `${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}`;

  try {
    // Meals
    const mealSnap = await getDocs(collection(db,'messes',_ctx.messId,'meals'));
    let myMeals = 0;
    mealSnap.forEach(d => {
      if (d.id.startsWith(monthPrefix) && d.id.endsWith('_' + _ctx.profile.uid)) {
        myMeals += (d.data().slots || []).filter(Boolean).length;
        myMeals += (d.data().guestSlots || []).filter(Boolean).length;
      }
    });

    // Deposits
    const depSnap = await getDocs(query(
      collection(db,'messes',_ctx.messId,'deposits'),
      where('memberId','==',_ctx.profile.uid),
      where('status','==','approved')
    ));
    let myDeposit = 0;
    depSnap.forEach(d => {
      if (d.data().date?.startsWith(monthStr)) myDeposit += parseFloat(d.data().amount) || 0;
    });

    el.innerHTML = `
<div class="g2" style="gap:8px">
  <div class="sc sg"><div class="sl">আমার মিল</div><div class="sv" style="font-size:20px">${myMeals}</div><div class="ss">এই মাসে</div></div>
  <div class="sc sb"><div class="sl">আমার জমা</div><div class="sv" style="font-size:20px">${taka(myDeposit)}</div><div class="ss">এই মাসে</div></div>
</div>`;
  } catch (err) {
    el.innerHTML = '<p style="font-size:12px;color:var(--r1)">লোড ব্যর্থ</p>';
  }
}

async function _leaveMess() {
  if (!window.confirm('আপনি কি সত্যিই এই মেস ছাড়তে চান?\nএই কাজ ফেরানো যাবে না।')) return;

  ld('মেস ছাড়া হচ্ছে…');
  try {
    const batch = writeBatch(db);
    batch.delete(doc(db,'messes',_ctx.messId,'members',_ctx.profile.uid));
    batch.update(doc(db,'users',_ctx.profile.uid), { currentMessId: null, status: 'pending' });
    await batch.commit();
    toast('আপনি মেস ছেড়েছেন', 'ok');
    // Reload the app — router will redirect to pending page
    setTimeout(() => window.location.reload(), 800);
  } catch (err) {
    toast('ব্যর্থ: ' + err.message, 'er');
    uld();
  }
}

const _esc = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

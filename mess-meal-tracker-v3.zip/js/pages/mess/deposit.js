// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/pages/mess/deposit.js
//  ডিপোজিট: member-ভিত্তিক টাকা জমা, approval system
// ══════════════════════════════════════════════════════════

import { db } from '../../firebase.js';
import { toast, taka, pad, moName, formatDate } from '../../utils.js';
import {
  collection, getDocs, addDoc, updateDoc, deleteDoc,
  doc, query, orderBy, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _ctx = {}, _vy = TODAY.getFullYear(), _vm = TODAY.getMonth();
let _deposits = [], _members = [];

export async function render(root, ctx) {
  _ctx = ctx;
  const canApprove = ['mess-admin','mess-co-admin'].includes(ctx.myMessRole);
  const isAdmin    = ctx.myMessRole === 'mess-admin';

  root.innerHTML = `
<div>
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <button class="btn btn-ghost btn-sm" onclick="window.__depMNav(-1)">◀</button>
    <span style="font-size:14px;font-weight:700;min-width:130px;text-align:center" id="dep-month-lbl"></span>
    <button class="btn btn-ghost btn-sm" onclick="window.__depMNav(1)">▶</button>
    <button class="btn btn-ghost btn-sm" style="margin-left:auto" onclick="window.__depRefresh()">🔄</button>
  </div>

  <!-- Add form -->
  <div class="card" style="margin-bottom:14px">
    <div class="ch"><h3>💰 নতুন ডিপোজিট যোগ করুন</h3></div>
    <div class="cb">
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px">
        <div class="field">
          <label class="lbl">সদস্য</label>
          <select class="inp inp-sm" id="dep-member-sel">
            <option value="">সদস্য নির্বাচন করুন</option>
          </select>
        </div>
        <div class="field">
          <label class="lbl">তারিখ</label>
          <input class="inp inp-sm" type="date" id="dep-date"
            value="${TODAY.getFullYear()}-${pad(TODAY.getMonth()+1)}-${pad(TODAY.getDate())}"/>
        </div>
        <div class="field">
          <label class="lbl">পরিমাণ (৳)</label>
          <input class="inp inp-sm" id="dep-amount" type="number" min="0" placeholder="0"/>
        </div>
        <div class="field" style="grid-column:1/-1">
          <label class="lbl">নোট (ঐচ্ছিক)</label>
          <input class="inp inp-sm" id="dep-note" placeholder="বিস্তারিত…"/>
        </div>
      </div>
      <button class="btn btn-p btn-sm" style="margin-top:8px" onclick="window.__depAdd()">+ যোগ করুন</button>
    </div>
  </div>

  <!-- Summary cards -->
  <div class="gA" id="dep-summary" style="margin-bottom:14px"></div>

  <!-- Table -->
  <div class="card">
    <div class="ch">
      <h3>💳 ডিপোজিট তালিকা</h3>
      <span style="font-size:12px;font-weight:700;color:var(--g1)" id="dep-total-lbl">৳০</span>
    </div>
    <div style="overflow-x:auto" id="dep-content">লোড হচ্ছে…</div>
  </div>
</div>`;

  window.__depMNav    = d => { _vm+=d; if(_vm>11){_vm=0;_vy++} if(_vm<0){_vm=11;_vy--} _load(); };
  window.__depRefresh = () => _load();
  window.__depAdd     = () => _add();
  window.__depApprove = id => _approve(id);
  window.__depReject  = id => _reject(id);
  window.__depDelete  = id => _delete(id);

  document.getElementById('dep-month-lbl').textContent = `${moName(_vm)} ${_vy}`;
  await _load();
}

async function _load() {
  document.getElementById('dep-month-lbl').textContent = `${moName(_vm)} ${_vy}`;
  const monthStr = `${_vy}-${pad(_vm+1)}`;

  try {
    // Load members for select
    const mSnap = await getDocs(query(collection(db,'messes',_ctx.messId,'members'), orderBy('joinedAt')));
    _members = mSnap.docs.map(d => ({ uid: d.id, ...d.data() }));

    const sel = document.getElementById('dep-member-sel');
    if (sel) {
      sel.innerHTML = '<option value="">সদস্য নির্বাচন করুন</option>' +
        _members.map(m =>
          `<option value="${m.uid}" data-name="${_esc(m.name||m.email)}">${_esc(m.name||m.email)}</option>`
        ).join('');
      // Default to self
      sel.value = _ctx.profile.uid;
    }

    // Load deposits for month
    const dSnap = await getDocs(query(collection(db,'messes',_ctx.messId,'deposits'), orderBy('date','desc')));
    _deposits = dSnap.docs.map(d => ({ id: d.id, ...d.data() })).filter(d => d.date?.startsWith(monthStr));

    _render();
  } catch (err) {
    toast('লোড ব্যর্থ: ' + err.message, 'er');
  }
}

function _render() {
  const canApprove = ['mess-admin','mess-co-admin'].includes(_ctx.myMessRole);
  const isAdmin    = _ctx.myMessRole === 'mess-admin';

  // Per-member summary
  const memberTotals = {};
  _deposits.filter(d => d.status === 'approved').forEach(d => {
    memberTotals[d.memberId] = (memberTotals[d.memberId] || 0) + (parseFloat(d.amount) || 0);
  });
  const grandTotal = Object.values(memberTotals).reduce((a,b) => a+b, 0);
  document.getElementById('dep-total-lbl').textContent = taka(grandTotal);

  // Summary cards
  const summaryEl = document.getElementById('dep-summary');
  if (summaryEl) {
    if (_members.length) {
      summaryEl.innerHTML = _members.map(m => `
<div class="sc sg">
  <div class="sl">${_esc(m.name || m.email)}</div>
  <div class="sv">${taka(memberTotals[m.uid] || 0)}</div>
  <div class="ss">মোট জমা</div>
</div>`).join('');
    } else {
      summaryEl.innerHTML = '';
    }
  }

  const content = document.getElementById('dep-content');
  if (!content) return;

  if (!_deposits.length) {
    content.innerHTML = '<div style="padding:20px;text-align:center;color:var(--ink3)">এই মাসে কোনো ডিপোজিট নেই</div>';
    return;
  }

  content.innerHTML = `
<table class="dt">
<thead><tr>
  <th class="tl">সদস্য</th>
  <th>তারিখ</th>
  <th>পরিমাণ</th>
  <th>অবস্থা</th>
  <th>নোট</th>
  ${canApprove ? '<th>অ্যাকশন</th>' : ''}
</tr></thead>
<tbody>
${_deposits.map(d => `<tr>
  <td class="tl" style="font-weight:600">${_esc(d.memberName || '—')}</td>
  <td>${d.date || '—'}</td>
  <td style="font-weight:700;font-family:var(--mono)">${taka(d.amount)}</td>
  <td>${_statusBadge(d.status)}</td>
  <td style="font-size:11px;color:var(--ink3)">${_esc(d.note || '—')}</td>
  ${canApprove ? `<td>
    <div style="display:flex;gap:4px">
      ${d.status === 'pending'
        ? `<button class="btn btn-xs btn-p" onclick="window.__depApprove('${d.id}')">✓</button>
           <button class="btn btn-xs btn-danger" onclick="window.__depReject('${d.id}')">✗</button>`
        : ''}
      ${isAdmin ? `<button class="btn btn-xs btn-ghost" onclick="window.__depDelete('${d.id}')">🗑</button>` : ''}
    </div>
  </td>` : ''}
</tr>`).join('')}
</tbody>
</table>`;
}

function _statusBadge(s) {
  if (s === 'approved') return '<span class="badge b-green" style="font-size:9px">✓ অনুমোদিত</span>';
  if (s === 'rejected') return '<span class="badge b-red" style="font-size:9px">✗ বাতিল</span>';
  return '<span class="badge b-amber" style="font-size:9px">⏳ অপেক্ষামাণ</span>';
}

async function _add() {
  const selEl    = document.getElementById('dep-member-sel');
  const memberId = selEl?.value;
  const memberName = selEl?.options[selEl.selectedIndex]?.dataset?.name || '';
  const date     = document.getElementById('dep-date')?.value;
  const amount   = parseFloat(document.getElementById('dep-amount')?.value) || 0;
  const note     = document.getElementById('dep-note')?.value.trim();

  if (!memberId) { toast('সদস্য নির্বাচন করুন', 'er'); return; }
  if (!date)     { toast('তারিখ দিন', 'er'); return; }
  if (!amount)   { toast('পরিমাণ দিন', 'er'); return; }

  const isCoAdmin = ['mess-admin','mess-co-admin'].includes(_ctx.myMessRole);

  await addDoc(collection(db,'messes',_ctx.messId,'deposits'), {
    memberId, memberName,
    date, amount, note: note || '',
    addedBy: _ctx.profile.uid,
    status: isCoAdmin ? 'approved' : 'pending',
    approvedBy: null, approvedAt: null,
    createdAt: serverTimestamp()
  });

  toast('ডিপোজিট যোগ হয়েছে', 'ok');
  document.getElementById('dep-amount').value = '';
  document.getElementById('dep-note').value   = '';
  await _load();
}

async function _approve(id) {
  await updateDoc(doc(db,'messes',_ctx.messId,'deposits',id), {
    status: 'approved', approvedBy: _ctx.profile.uid, approvedAt: serverTimestamp()
  });
  toast('অনুমোদন দেওয়া হয়েছে', 'ok');
  await _load();
}

async function _reject(id) {
  await updateDoc(doc(db,'messes',_ctx.messId,'deposits',id), { status: 'rejected' });
  toast('বাতিল করা হয়েছে', 'ok');
  await _load();
}

async function _delete(id) {
  if (!window.confirm('ডিপোজিট মুছে ফেলবেন?')) return;
  await deleteDoc(doc(db,'messes',_ctx.messId,'deposits',id));
  toast('মুছে ফেলা হয়েছে', 'ok');
  await _load();
}

const _esc = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

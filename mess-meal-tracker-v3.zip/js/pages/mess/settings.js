// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/pages/mess/settings.js
//  Settings: মেস info, meal slots, cutoff, rent, language
//  Only accessible by mess-admin
// ══════════════════════════════════════════════════════════

import { db } from '../../firebase.js';
import { toast, ld, uld, setLang } from '../../utils.js';
import {
  doc, updateDoc, getDoc
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _ctx = {}, _settings = {};

export async function render(root, ctx) {
  _ctx = ctx;

  if (ctx.myMessRole !== 'mess-admin') {
    root.innerHTML = `
<div class="card">
  <div class="cb" style="text-align:center;padding:30px;color:var(--ink3)">
    <div style="font-size:32px;margin-bottom:8px">🔒</div>
    <p style="font-size:13px">Settings শুধুমাত্র Mess Admin পরিবর্তন করতে পারবেন।</p>
  </div>
</div>`;
    return;
  }

  _settings = { ...ctx.messSettings };

  root.innerHTML = `
<div>
  <h2 style="font-size:17px;font-weight:700;color:var(--ink);margin-bottom:14px">⚙️ সেটিংস</h2>

  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:13px">

    <!-- Mess info -->
    <div class="card">
      <div class="ch"><h3>🏠 মেসের তথ্য</h3></div>
      <div class="cb">
        <div class="field"><label class="lbl">মেসের নাম</label>
          <input class="inp inp-sm" id="set-name" value="${_esc(ctx.messData?.name||'')}" placeholder="মেসের নাম"/>
        </div>
        <div class="field"><label class="lbl">ঠিকানা</label>
          <input class="inp inp-sm" id="set-addr" value="${_esc(ctx.messData?.address||'')}" placeholder="ঠিকানা"/>
        </div>
        <button class="btn btn-p btn-sm" onclick="window.__setName()">✓ সংরক্ষণ</button>
        <div id="name-msg" style="font-size:11px;margin-top:6px"></div>
      </div>
    </div>

    <!-- Meal slots -->
    <div class="card">
      <div class="ch"><h3>🍽 খাবারের বেলা</h3></div>
      <div class="cb">
        <p style="font-size:11px;color:var(--ink3);margin-bottom:10px">সর্বোচ্চ ৫টি বেলা নির্ধারণ করা যাবে</p>
        <div id="slot-list" style="display:flex;flex-direction:column;gap:6px;margin-bottom:10px"></div>
        <button class="btn btn-ghost btn-sm btn-full" onclick="window.__setAddSlot()" id="btn-add-slot">+ নতুন বেলা</button>
        <hr style="margin:12px 0;border-color:var(--line)"/>
        <div class="field">
          <label class="lbl">মিল বন্ধের সময় (ঘণ্টা, ০-২৩)</label>
          <input class="inp inp-sm" id="set-cutoff" type="number" min="0" max="23" value="${_settings.cutoffHour ?? 10}"/>
        </div>
        <div class="field">
          <label class="lbl">দিনে সর্বোচ্চ মিল সংখ্যা</label>
          <input class="inp inp-sm" id="set-maxmeals" type="number" min="1" max="10" value="${_settings.maxMealsPerDay ?? 3}"/>
        </div>
        <button class="btn btn-p btn-sm" onclick="window.__setSlots()">✓ সংরক্ষণ</button>
        <div id="slot-msg" style="font-size:11px;margin-top:6px"></div>
      </div>
    </div>

    <!-- House rent -->
    <div class="card">
      <div class="ch"><h3>🏡 বাড়ি ভাড়া</h3></div>
      <div class="cb">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid var(--line)">
          <span style="font-size:13px;font-weight:600">বাড়ি ভাড়া চালু করুন</span>
          <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
            <input type="checkbox" id="rent-toggle" style="accent-color:var(--g2);width:16px;height:16px"
              ${_settings.rentEnabled ? 'checked' : ''}
              onchange="window.__setRentToggle(this.checked)"/>
            <span id="rent-toggle-lbl" style="font-size:12px;color:var(--ink3)">${_settings.rentEnabled ? 'চালু' : 'বন্ধ'}</span>
          </label>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
          <div><label class="lbl">🔥 গ্যাস (৳)</label><input class="inp inp-sm" id="set-gas" type="number" value="${_settings.rentGas||0}"/></div>
          <div><label class="lbl">💡 বিদ্যুৎ (৳)</label><input class="inp inp-sm" id="set-elec" type="number" value="${_settings.rentElectric||0}"/></div>
          <div><label class="lbl">💧 পানি (৳)</label><input class="inp inp-sm" id="set-water" type="number" value="${_settings.rentWater||0}"/></div>
          <div><label class="lbl">🧹 বুয়া (৳)</label><input class="inp inp-sm" id="set-bua" type="number" value="${_settings.rentBua||0}"/></div>
        </div>
        <button class="btn btn-p btn-sm" onclick="window.__setRent()">✓ সংরক্ষণ</button>
        <div id="rent-msg" style="font-size:11px;margin-top:6px"></div>
      </div>
    </div>

    <!-- Language -->
    <div class="card">
      <div class="ch"><h3>🌐 ভাষা</h3></div>
      <div class="cb">
        <div class="field">
          <label class="lbl">অ্যাপের ভাষা</label>
          <select class="inp inp-sm" id="set-lang">
            <option value="bn" ${(_settings.lang||'bn') === 'bn' ? 'selected' : ''}>বাংলা</option>
            <option value="en" ${(_settings.lang||'bn') === 'en' ? 'selected' : ''}>English</option>
          </select>
        </div>
        <button class="btn btn-p btn-sm" onclick="window.__setLang()">✓ সংরক্ষণ</button>
      </div>
    </div>
  </div>
</div>`;

  window.__setName      = () => _saveName();
  window.__setSlots     = () => _saveSlots();
  window.__setAddSlot   = () => _addSlot();
  window.__setRent      = () => _saveRent();
  window.__setRentToggle = v => {
    const lbl = document.getElementById('rent-toggle-lbl');
    if (lbl) lbl.textContent = v ? 'চালু' : 'বন্ধ';
  };
  window.__setLang      = () => _saveLang();
  window.__setDelSlot   = i => _delSlot(i);

  _renderSlots();
}

function _renderSlots() {
  const slots   = _settings.slots || ['সকাল','দুপুর','রাত'];
  const listEl  = document.getElementById('slot-list');
  if (!listEl) return;

  listEl.innerHTML = slots.map((s, i) => `
<div style="display:flex;gap:6px;align-items:center">
  <input class="inp inp-sm" style="flex:1" id="slot-inp-${i}" value="${_esc(s)}" placeholder="বেলার নাম"/>
  <button class="btn btn-xs btn-danger" onclick="window.__setDelSlot(${i})">✕</button>
</div>`).join('');

  const addBtn = document.getElementById('btn-add-slot');
  if (addBtn) addBtn.style.display = slots.length >= 5 ? 'none' : '';
}

function _addSlot() {
  const slots = _settings.slots || [];
  if (slots.length >= 5) { toast('সর্বোচ্চ ৫টি বেলা', 'er'); return; }
  slots.push('নতুন বেলা');
  _settings.slots = slots;
  _renderSlots();
}

function _delSlot(i) {
  const slots = _settings.slots || [];
  if (slots.length <= 1) { toast('কমপক্ষে ১টি বেলা রাখুন', 'er'); return; }
  slots.splice(i, 1);
  _settings.slots = slots;
  _renderSlots();
}

async function _saveName() {
  const name = document.getElementById('set-name')?.value.trim();
  const addr = document.getElementById('set-addr')?.value.trim();
  if (!name) { toast('মেসের নাম দিন', 'er'); return; }
  try {
    await updateDoc(doc(db,'messes',_ctx.messId), { name, address: addr || '' });
    _ctx.messData.name = name;
    _ctx.messData.address = addr;
    const msgEl = document.getElementById('name-msg');
    if (msgEl) { msgEl.textContent = '✓ সংরক্ষণ হয়েছে'; msgEl.style.color = 'var(--g1)'; }
    toast('মেসের তথ্য আপডেট হয়েছে', 'ok');

    // Update sidebar name
    const sbName = document.getElementById('sb-mess-name');
    if (sbName) sbName.textContent = name;
  } catch (err) { toast('ব্যর্থ: ' + err.message, 'er'); }
}

async function _saveSlots() {
  const inputs = document.querySelectorAll('[id^="slot-inp-"]');
  const slots  = [...inputs].map(inp => inp.value.trim()).filter(Boolean);
  if (!slots.length) { toast('কমপক্ষে ১টি বেলা দিন', 'er'); return; }

  const cutoff   = parseInt(document.getElementById('set-cutoff')?.value) || 10;
  const maxMeals = parseInt(document.getElementById('set-maxmeals')?.value) || 3;

  try {
    await updateDoc(doc(db,'messes',_ctx.messId,'settings','main'), {
      slots, cutoffHour: cutoff, maxMealsPerDay: maxMeals
    });
    _settings.slots          = slots;
    _settings.cutoffHour     = cutoff;
    _settings.maxMealsPerDay = maxMeals;
    _ctx.messSettings.slots          = slots;
    _ctx.messSettings.cutoffHour     = cutoff;
    _ctx.messSettings.maxMealsPerDay = maxMeals;
    const msgEl = document.getElementById('slot-msg');
    if (msgEl) { msgEl.textContent = '✓ সংরক্ষণ হয়েছে'; msgEl.style.color = 'var(--g1)'; }
    toast('বেলা সেটিংস সেভ হয়েছে', 'ok');
  } catch (err) { toast('ব্যর্থ: ' + err.message, 'er'); }
}

async function _saveRent() {
  const enabled  = document.getElementById('rent-toggle')?.checked || false;
  const gas      = parseFloat(document.getElementById('set-gas')?.value) || 0;
  const electric = parseFloat(document.getElementById('set-elec')?.value) || 0;
  const water    = parseFloat(document.getElementById('set-water')?.value) || 0;
  const bua      = parseFloat(document.getElementById('set-bua')?.value) || 0;

  try {
    await updateDoc(doc(db,'messes',_ctx.messId,'settings','main'), {
      rentEnabled: enabled, rentGas: gas, rentElectric: electric, rentWater: water, rentBua: bua
    });
    Object.assign(_settings, { rentEnabled: enabled, rentGas: gas, rentElectric: electric, rentWater: water, rentBua: bua });
    Object.assign(_ctx.messSettings, { rentEnabled: enabled });
    const msgEl = document.getElementById('rent-msg');
    if (msgEl) { msgEl.textContent = '✓ সংরক্ষণ হয়েছে'; msgEl.style.color = 'var(--g1)'; }
    toast('ভাড়া সেটিংস সেভ হয়েছে', 'ok');
  } catch (err) { toast('ব্যর্থ: ' + err.message, 'er'); }
}

async function _saveLang() {
  const lang = document.getElementById('set-lang')?.value || 'bn';
  try {
    await updateDoc(doc(db,'messes',_ctx.messId,'settings','main'), { lang });
    _settings.lang = lang;
    _ctx.messSettings.lang = lang;
    setLang(lang);
    toast('ভাষা পরিবর্তন হয়েছে', 'ok');
  } catch (err) { toast('ব্যর্থ: ' + err.message, 'er'); }
}

const _esc = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

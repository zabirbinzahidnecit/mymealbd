// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/pages/mess/members.js
//  সদস্য ব্যবস্থাপনা: list, invite (Gmail), pending invites, remove
// ══════════════════════════════════════════════════════════

import { db } from '../../firebase.js';
import { toast, ld, uld, formatDate, ini, avColor, roleLabel } from '../../utils.js';
import {
  collection, getDocs, addDoc, deleteDoc,
  doc, query, orderBy, setDoc, updateDoc,
  where, writeBatch, serverTimestamp, getDoc
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _ctx = {}, _members = [], _invites = [];

export async function render(root, ctx) {
  _ctx = ctx;
  const isAdmin = ctx.myMessRole === 'mess-admin';

  root.innerHTML = `
<div>
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px">
    <div>
      <h2 style="font-size:17px;font-weight:700;color:var(--ink);margin:0">👥 সদস্য ব্যবস্থাপনা</h2>
      <p style="font-size:12px;color:var(--ink3);margin:3px 0 0" id="mem-count">লোড হচ্ছে…</p>
    </div>
    <button class="btn btn-ghost btn-sm" onclick="window.__memRefresh()">🔄 রিফ্রেশ</button>
  </div>

  ${isAdmin ? `
  <!-- Invite form -->
  <div class="card" style="margin-bottom:14px">
    <div class="ch"><h3>📨 নতুন সদস্য Invite করুন</h3></div>
    <div class="cb">
      <div style="display:grid;grid-template-columns:1fr auto auto;gap:8px;align-items:end">
        <div class="field" style="margin:0">
          <label class="lbl">Gmail ঠিকানা</label>
          <input class="inp inp-sm" id="inv-email" type="email" placeholder="example@gmail.com"/>
        </div>
        <div class="field" style="margin:0">
          <label class="lbl">ভূমিকা</label>
          <select class="inp inp-sm" id="inv-role">
            <option value="member">সদস্য (Member)</option>
            <option value="mess-co-admin">কো-অ্যাডমিন</option>
          </select>
        </div>
        <button class="btn btn-p btn-sm" onclick="window.__memInvite()">📤 Invite পাঠান</button>
      </div>
      <p style="font-size:11px;color:var(--ink4);margin-top:8px">⏱ Invite ২৪ ঘণ্টা valid থাকবে</p>
    </div>
  </div>

  <!-- Pending invites -->
  <div class="card" style="margin-bottom:14px">
    <div class="ch">
      <h3>⏳ Pending Invites</h3>
      <button class="btn btn-ghost btn-sm" onclick="window.__memRefreshInvites()">রিফ্রেশ</button>
    </div>
    <div id="inv-list" class="cb">লোড হচ্ছে…</div>
  </div>` : ''}

  <!-- Member list -->
  <div class="card">
    <div class="ch"><h3>👥 সকল সদস্য</h3></div>
    <div id="mem-list" style="padding:4px 0">লোড হচ্ছে…</div>
  </div>
</div>

<style>
.mem-row{
  display:flex;align-items:center;gap:12px;padding:10px 14px;
  border-bottom:.5px solid var(--line);
}
.mem-row:last-child{border-bottom:none}
.mem-av{
  width:40px;height:40px;border-radius:50%;flex-shrink:0;overflow:hidden;
  display:flex;align-items:center;justify-content:center;font-size:15px;font-weight:700;
}
.mem-av img{width:100%;height:100%;object-fit:cover}
.mem-info{flex:1;min-width:0}
.mem-info h3{font-size:13px;font-weight:600;color:var(--ink);margin:0;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mem-info p{font-size:11px;color:var(--ink3);margin:2px 0 0}
.inv-row{
  display:flex;align-items:center;justify-content:space-between;gap:8px;
  padding:8px 0;border-bottom:.5px solid var(--line);flex-wrap:wrap;
}
.inv-row:last-child{border-bottom:none}
</style>`;

  window.__memRefresh        = () => _load();
  window.__memRefreshInvites = () => _loadInvites();
  window.__memInvite         = () => _invite();
  window.__memRemove         = uid => _remove(uid);
  window.__memDeleteInvite   = token => _deleteInvite(token);

  await _load();
  if (isAdmin) await _loadInvites();
}

async function _load() {
  try {
    const snap = await getDocs(query(collection(db,'messes',_ctx.messId,'members'), orderBy('joinedAt')));
    _members = snap.docs.map(d => ({ uid: d.id, ...d.data() }));

    const countEl = document.getElementById('mem-count');
    if (countEl) countEl.textContent = `মোট ${_members.length}জন সদস্য`;

    const isAdmin = _ctx.myMessRole === 'mess-admin';
    const list = document.getElementById('mem-list');
    if (!list) return;

    list.innerHTML = _members.map(m => {
      const av = m.avatar
        ? `<img src="${_esc(m.avatar)}" alt=""/>`
        : `<span>${ini(m.name || m.email)}</span>`;
      const avCls = m.avatar ? '' : avColor(m.name || m.email);
      const isMe  = m.uid === _ctx.profile.uid;
      const roleBadge = {
        'mess-admin':    '<span class="badge b-green">🔑 অ্যাডমিন</span>',
        'mess-co-admin': '<span class="badge b-blue">🛡 কো-অ্যাডমিন</span>',
        'member':        '<span class="badge b-muted">👤 সদস্য</span>',
      }[m.role] || '';

      return `
<div class="mem-row">
  <div class="mem-av ${avCls}">${av}</div>
  <div class="mem-info">
    <h3>${_esc(m.name || '—')} ${isMe ? '<span style="font-size:10px;color:var(--ink4)">(আপনি)</span>' : ''}</h3>
    <p>${_esc(m.email || '—')}</p>
  </div>
  ${roleBadge}
  ${isAdmin && !isMe
    ? `<button class="btn btn-xs btn-danger" onclick="window.__memRemove('${m.uid}')">বের করুন</button>`
    : ''}
</div>`;
    }).join('');
  } catch (err) {
    toast('লোড ব্যর্থ: ' + err.message, 'er');
  }
}

async function _loadInvites() {
  const list = document.getElementById('inv-list');
  if (!list) return;

  try {
    const snap = await getDocs(query(collection(db,'messes',_ctx.messId,'invites'), where('used','==',false)));
    _invites = snap.docs.map(d => ({ id: d.id, ...d.data() }));

    if (!_invites.length) {
      list.innerHTML = '<p style="font-size:12px;color:var(--ink3)">কোনো pending invite নেই</p>';
      return;
    }

    list.innerHTML = _invites.map(inv => {
      const expired = inv.expiresAt?.toDate() < new Date();
      return `
<div class="inv-row">
  <div>
    <p style="font-size:13px;font-weight:600;color:var(--ink)">${_esc(inv.email)}</p>
    <p style="font-size:11px;color:var(--ink3)">${roleLabel(inv.role)} · ${expired ? '<span style="color:var(--r1)">মেয়াদ শেষ</span>' : 'সক্রিয়'}</p>
  </div>
  <button class="btn btn-xs btn-danger" onclick="window.__memDeleteInvite('${inv.id}')">বাতিল</button>
</div>`;
    }).join('');
  } catch (err) {
    list.innerHTML = '<p style="font-size:12px;color:var(--r1)">লোড ব্যর্থ</p>';
  }
}

async function _invite() {
  const email = document.getElementById('inv-email')?.value.trim().toLowerCase();
  const role  = document.getElementById('inv-role')?.value || 'member';

  if (!email || !email.includes('@')) { toast('সঠিক Gmail দিন', 'er'); return; }

  // Check already a member
  const isMember = _members.some(m => m.email?.toLowerCase() === email);
  if (isMember) { toast('এই ইমেইল ইতিমধ্যে সদস্য', 'er'); return; }

  ld('Invite পাঠানো হচ্ছে…');
  try {
    const token    = crypto.randomUUID();
    const expiresAt = new Date(Date.now() + 24*60*60*1000);

    // Store invite in messes/{messId}/invites/{token}
    await setDoc(doc(db,'messes',_ctx.messId,'invites',token), {
      email, role,
      invitedBy:  _ctx.profile.uid,
      createdAt:  serverTimestamp(),
      expiresAt,
      used:       false
    });

    // Store invite index for fast lookup on login
    const idxKey = email.replace(/\./g,'_');
    await setDoc(doc(db,'inviteIndex',idxKey), {
      messId: _ctx.messId, token, role, email
    });

    toast(`Invite তৈরি হয়েছে! ${email} কে link পাঠান।`, 'ok');
    document.getElementById('inv-email').value = '';
    await _loadInvites();
  } catch (err) {
    toast('Invite ব্যর্থ: ' + err.message, 'er');
  } finally {
    uld();
  }
}

async function _remove(uid) {
  const member = _members.find(m => m.uid === uid);
  if (!window.confirm(`"${member?.name || uid}" কে মেস থেকে বের করবেন?`)) return;

  ld('সরানো হচ্ছে…');
  try {
    const batch = writeBatch(db);
    batch.delete(doc(db,'messes',_ctx.messId,'members',uid));
    batch.update(doc(db,'users',uid), { currentMessId: null, status: 'pending' });
    await batch.commit();
    toast('সদস্য সরানো হয়েছে', 'ok');
    await _load();
  } catch (err) {
    toast('সরাতে ব্যর্থ: ' + err.message, 'er');
  } finally {
    uld();
  }
}

async function _deleteInvite(inviteId) {
  try {
    const inv = _invites.find(i => i.id === inviteId);
    if (inv) {
      const idxKey = inv.email?.replace(/\./g,'_');
      const batch = writeBatch(db);
      batch.delete(doc(db,'messes',_ctx.messId,'invites',inviteId));
      if (idxKey) batch.delete(doc(db,'inviteIndex',idxKey));
      await batch.commit();
    }
    toast('Invite বাতিল হয়েছে', 'ok');
    await _loadInvites();
  } catch (err) {
    toast('বাতিল ব্যর্থ: ' + err.message, 'er');
  }
}

const _esc = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

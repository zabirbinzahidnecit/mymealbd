// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/pages/mess/meal.js
//  মিল এন্ট্রি: slot-based, guest, multi-day, member table
//  import { render } from './meal.js';
// ══════════════════════════════════════════════════════════

import { db } from '../../firebase.js';
import { taka, toast, pad, dim, moName } from '../../utils.js';
import {
  collection, getDocs, doc, getDoc, setDoc,
  query, orderBy
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _ctx = {};
let _vy = TODAY.getFullYear(), _vm = TODAY.getMonth();
let _members = [], _meals = {};

export async function render(root, ctx) {
  _ctx = ctx;
  const slots = ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const SICO  = ['☀️','🌤','🌙','🍳','🍱','🌮'];

  root.innerHTML = `
<div>
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <button class="btn btn-ghost btn-sm" onclick="window.__mealMNav(-1)">◀</button>
    <span style="font-size:14px;font-weight:700;min-width:130px;text-align:center" id="meal-month-lbl"></span>
    <button class="btn btn-ghost btn-sm" onclick="window.__mealMNav(1)">▶</button>
    <button class="btn btn-ghost btn-sm" onclick="window.__mealGoToday()">আজ</button>
    <button class="btn btn-p btn-sm" onclick="window.__mealMultiDay()" style="margin-left:auto">📅 একাধিক দিন</button>
  </div>

  <!-- Today quick slots (admin/coadmin: member select) -->
  <div class="card" style="margin-bottom:14px">
    <div class="ch">
      <h3>🍚 মিল এন্ট্রি</h3>
      <span style="font-size:11px;color:var(--ink3)" id="meal-today-lbl"></span>
    </div>
    <div class="cb">
      ${ctx.myMessRole !== 'member' ? `
      <div class="field">
        <label class="lbl">সদস্য</label>
        <select class="inp inp-sm" id="meal-member-sel" onchange="window.__mealMemberChange()">
          <option value="${ctx.profile.uid}">${_esc(ctx.profile.name || ctx.profile.email)} (আমি)</option>
        </select>
      </div>` : ''}
      <div class="slot-row" id="meal-slots"></div>
      <div class="cutoff-notice" id="meal-cutoff">⏰ মিল পরিবর্তনের সময় পার হয়েছে</div>
      <div style="margin-top:10px">
        <label class="lbl">Guest মিল (সংখ্যা)</label>
        <div style="display:flex;gap:8px;align-items:center">
          <input class="inp inp-sm" id="meal-guest-inp" type="number" min="0" max="20" placeholder="0" style="width:90px"/>
          <button class="btn btn-ghost btn-sm" onclick="window.__mealSaveGuest()">Guest সেভ</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Member meal table for selected day -->
  <div class="card">
    <div class="ch">
      <h3>📅 সদস্যদের মিল</h3>
      <input type="date" id="meal-date-pick" class="inp inp-sm" style="width:auto"
        onchange="window.__mealDateChange(this.value)"/>
    </div>
    <div class="cb" style="overflow-x:auto" id="meal-table-wrap">লোড হচ্ছে…</div>
  </div>
</div>

<!-- Multi-day modal -->
<div class="mo" id="md-mo" style="display:none">
  <div class="mbox" style="max-width:480px">
    <h3>📅 একাধিক দিনের মিল</h3>
    <p style="font-size:12px;color:var(--ink3);margin-bottom:12px">দিন ও বেলা নির্বাচন করুন</p>
    <div id="md-content"></div>
    <div class="mact">
      <button class="btn btn-ghost" onclick="window.__mdClose()">বাতিল</button>
      <button class="btn btn-p" onclick="window.__mdApply()">✓ প্রয়োগ</button>
    </div>
  </div>
</div>`;

  window.__mealMNav       = d => { _vm+=d; if(_vm>11){_vm=0;_vy++} if(_vm<0){_vm=11;_vy--} _load(); };
  window.__mealGoToday    = () => { _vy=TODAY.getFullYear();_vm=TODAY.getMonth(); _load(); };
  window.__mealSlotToggle = (uid,i) => _toggleSlot(uid,i);
  window.__mealSaveGuest  = () => _saveGuest();
  window.__mealMemberChange = () => _onMemberChange();
  window.__mealDateChange = v => _loadDayTable(v);
  window.__mealMultiDay   = () => _openMultiDay();
  window.__mdClose        = () => document.getElementById('md-mo').style.display='none';
  window.__mdApply        = () => _applyMultiDay();

  // Set today's date in picker
  const pick = document.getElementById('meal-date-pick');
  if (pick) pick.value = `${TODAY.getFullYear()}-${pad(TODAY.getMonth()+1)}-${pad(TODAY.getDate())}`;

  await _load();
}

async function _load() {
  document.getElementById('meal-month-lbl').textContent = `${moName(_vm)} ${_vy}`;
  document.getElementById('meal-today-lbl').textContent =
    `${TODAY.getDate()} ${moName(TODAY.getMonth())} ${TODAY.getFullYear()}`;

  const { messId } = _ctx;
  // Load members
  const mSnap = await getDocs(query(collection(db,'messes',messId,'members'), orderBy('joinedAt')));
  _members = mSnap.docs.map(d=>({uid:d.id,...d.data()}));

  // Populate member select
  const sel = document.getElementById('meal-member-sel');
  if (sel) {
    sel.innerHTML = _members.map(m =>
      `<option value="${m.uid}">${_esc(m.name||m.email)}${m.uid===_ctx.profile.uid?' (আমি)':''}</option>`
    ).join('');
    sel.value = _ctx.profile.uid;
  }

  _renderMySlots(_ctx.profile.uid);

  // Load today's table
  await _loadDayTable(`${TODAY.getFullYear()}-${pad(TODAY.getMonth()+1)}-${pad(TODAY.getDate())}`);
}

function _renderMySlots(uid) {
  const slots = _ctx.messSettings?.slots||['সকাল','দুপুর','রাত'];
  const SICO=['☀️','🌤','🌙','🍳','🍱'];
  const cutoff = _ctx.messSettings?.cutoffHour??10;
  const isPast = uid===_ctx.profile.uid && TODAY.getHours()>=cutoff;

  document.getElementById('meal-slots').innerHTML = slots.map((s,i)=>
    `<button class="slt ${isPast&&uid===_ctx.profile.uid?'locked':''}" id="meal-slt-${uid}-${i}"
      onclick="window.__mealSlotToggle('${uid}',${i})">
      ${SICO[i]||'🍽'} ${_esc(s)}
    </button>`).join('');

  document.getElementById('meal-cutoff')?.classList.toggle('show', isPast&&uid===_ctx.profile.uid);

  // Load current slot states
  const todayKey = `${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}_${pad(TODAY.getDate())}_${uid}`;
  getDoc(doc(db,'messes',_ctx.messId,'meals',todayKey)).then(snap=>{
    const s = snap.exists()?(snap.data().slots||[]):[];
    slots.forEach((_,i)=>document.getElementById(`meal-slt-${uid}-${i}`)?.classList.toggle('on',!!s[i]));
    const gInp = document.getElementById('meal-guest-inp');
    if(gInp) gInp.value = snap.exists()?(snap.data().guestSlots||[]).filter(Boolean).length||'':'';
  });
}

async function _toggleSlot(uid,i) {
  const cutoff=_ctx.messSettings?.cutoffHour??10;
  if(uid===_ctx.profile.uid && TODAY.getHours()>=cutoff && !['mess-admin','mess-co-admin'].includes(_ctx.myMessRole)) return;

  const key=`${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}_${pad(TODAY.getDate())}_${uid}`;
  const ref=doc(db,'messes',_ctx.messId,'meals',key);
  const snap=await getDoc(ref);
  const slots=snap.exists()?(snap.data().slots||[]):[];
  slots[i]=!slots[i];
  const max=_ctx.messSettings?.maxMealsPerDay??3;
  if(slots.filter(Boolean).length>max){toast(`সর্বোচ্চ ${max}টি মিল`,'er');return;}
  await setDoc(ref,{slots,memberId:uid},'merge'?{merge:true}:{});
  document.getElementById(`meal-slt-${uid}-${i}`)?.classList.toggle('on',!!slots[i]);
  _loadDayTable(`${TODAY.getFullYear()}-${pad(TODAY.getMonth()+1)}-${pad(TODAY.getDate())}`);
}

async function _saveGuest() {
  const n=parseInt(document.getElementById('meal-guest-inp')?.value)||0;
  const uid=document.getElementById('meal-member-sel')?.value||_ctx.profile.uid;
  const key=`${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}_${pad(TODAY.getDate())}_${uid}`;
  const guestSlots=Array(n).fill(true);
  await setDoc(doc(db,'messes',_ctx.messId,'meals',key),{guestSlots,memberId:uid},{merge:true});
  toast('Guest মিল সেভ হয়েছে','ok');
}

function _onMemberChange() {
  const uid=document.getElementById('meal-member-sel')?.value||_ctx.profile.uid;
  _renderMySlots(uid);
}

async function _loadDayTable(dateStr) {
  const wrap=document.getElementById('meal-table-wrap');
  if(!wrap) return;
  const [y,m,d]=dateStr.split('-').map(Number);
  const slots=_ctx.messSettings?.slots||['সকাল','দুপুর','রাত'];

  const keys=_members.map(mb=>`${y}_${pad(m)}_${pad(d)}_${mb.uid}`);
  const snaps=await Promise.all(keys.map(k=>getDoc(doc(db,'messes',_ctx.messId,'meals',k))));
  const mealMap={};
  snaps.forEach((s,i)=>{mealMap[_members[i].uid]=s.exists()?s.data():{};});

  wrap.innerHTML=`<table class="dt">
<thead><tr>
  <th class="tl">সদস্য</th>
  ${slots.map(s=>`<th>${_esc(s)}</th>`).join('')}
  <th>Guest</th><th>মোট</th>
</tr></thead><tbody>
${_members.map(mb=>{
  const md=mealMap[mb.uid]||{};
  const s=md.slots||[];
  const g=(md.guestSlots||[]).filter(Boolean).length;
  const tot=s.filter(Boolean).length+g;
  return `<tr>
  <td class="tl" style="font-weight:600">${_esc(mb.name||mb.email)}</td>
  ${slots.map((_,i)=>`<td><div class="mdot ${s[i]?'don':'doff'}">${s[i]?'✓':''}</div></td>`).join('')}
  <td>${g||'—'}</td><td style="font-weight:700">${tot||'—'}</td>
  </tr>`;
}).join('')}
</tbody></table>`;
}

function _openMultiDay() {
  const mo=document.getElementById('md-mo');
  const cont=document.getElementById('md-content');
  const slots=_ctx.messSettings?.slots||['সকাল','দুপুর','রাত'];
  const days=dim(_vy,_vm);

  cont.innerHTML=`
<div style="margin-bottom:10px">
  <label class="lbl">দিন নির্বাচন করুন</label>
  <div style="display:flex;flex-wrap:wrap;gap:5px">
  ${Array.from({length:days},(_, i)=>i+1).map(d=>`
    <button class="btn btn-ghost btn-sm md-day ${d===TODAY.getDate()&&_vy===TODAY.getFullYear()&&_vm===TODAY.getMonth()?'active':''}"
      style="min-width:36px" onclick="this.classList.toggle('active')">${d}</button>`).join('')}
  </div>
</div>
<div>
  <label class="lbl">বেলা নির্বাচন করুন</label>
  <div class="slot-row">
    ${slots.map((s,i)=>`<button class="slt md-slot" onclick="this.classList.toggle('on')">${_esc(s)}</button>`).join('')}
  </div>
</div>`;
  mo.style.display='flex';
}

async function _applyMultiDay() {
  const days=[...document.querySelectorAll('.md-day.active')].map(b=>parseInt(b.textContent));
  const slots=[...document.querySelectorAll('.md-slot')].map(b=>b.classList.contains('on'));
  if(!days.length){toast('দিন নির্বাচন করুন','er');return;}

  for(const d of days){
    const key=`${_vy}_${pad(_vm+1)}_${pad(d)}_${_ctx.profile.uid}`;
    await setDoc(doc(db,'messes',_ctx.messId,'meals',key),{slots,memberId:_ctx.profile.uid},{merge:true});
  }
  toast(`${days.length}টি দিনের মিল সেভ হয়েছে`,'ok');
  document.getElementById('md-mo').style.display='none';
}

const _esc=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/pages/mess/requests.js
//  অনুমোদন: pending বাজার + ডিপোজিট approve/reject
// ══════════════════════════════════════════════════════════

import { db } from '../../firebase.js';
import { toast, taka, formatDate, CICO } from '../../utils.js';
import {
  collection, getDocs, updateDoc, doc,
  query, where, orderBy, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _ctx = {};

export async function render(root, ctx) {
  _ctx = ctx;

  if (!['mess-admin','mess-co-admin'].includes(ctx.myMessRole)) {
    root.innerHTML = `
<div class="card">
  <div class="cb" style="text-align:center;padding:30px;color:var(--ink3)">
    <div style="font-size:32px;margin-bottom:8px">🔒</div>
    <p style="font-size:13px">এই পেজ শুধুমাত্র Mess Admin ও Co-Admin দেখতে পারবেন।</p>
  </div>
</div>`;
    return;
  }

  root.innerHTML = `
<div>
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px">
    <div>
      <h2 style="font-size:17px;font-weight:700;color:var(--ink);margin:0">✅ অনুমোদন</h2>
      <p style="font-size:12px;color:var(--ink3);margin:3px 0 0" id="req-pending-count">লোড হচ্ছে…</p>
    </div>
    <button class="btn btn-ghost btn-sm" onclick="window.__reqRefresh()">🔄 রিফ্রেশ</button>
  </div>

  <!-- Tabs -->
  <div class="adm-tabs">
    <button class="adm-tab active" id="reqtab-expense" onclick="window.__reqTab('expense')">🛒 বাজার</button>
    <button class="adm-tab"        id="reqtab-deposit" onclick="window.__reqTab('deposit')">💰 ডিপোজিট</button>
  </div>

  <div id="req-content" style="display:flex;flex-direction:column;gap:8px">
    <div style="padding:20px;text-align:center;color:var(--ink3)">লোড হচ্ছে…</div>
  </div>
</div>

<style>
.req-item{
  background:#fff;border:1px solid var(--line);border-radius:12px;
  padding:12px 14px;box-shadow:var(--sh);
}
.req-item-hd{display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:8px}
.req-item-hd h3{font-size:13px;font-weight:700;color:var(--ink);margin:0}
.req-item-hd p{font-size:11px;color:var(--ink3);margin:3px 0 0}
.req-item-acts{display:flex;gap:6px;flex-wrap:wrap;margin-top:10px}
</style>`;

  window.__reqRefresh = () => _load();
  window.__reqTab     = t  => _switchTab(t);
  window.__reqApproveExp = id => _approveExp(id);
  window.__reqRejectExp  = id => _rejectExp(id);
  window.__reqApproveDep = id => _approveDep(id);
  window.__reqRejectDep  = id => _rejectDep(id);

  await _load();
}

let _pendingExp = [], _pendingDep = [], _activeTab = 'expense';

async function _load() {
  try {
    const [expSnap, depSnap] = await Promise.all([
      getDocs(query(collection(db,'messes',_ctx.messId,'expenses'), where('status','==','pending'), orderBy('createdAt','desc'))),
      getDocs(query(collection(db,'messes',_ctx.messId,'deposits'), where('status','==','pending'), orderBy('createdAt','desc'))),
    ]);

    _pendingExp = expSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    _pendingDep = depSnap.docs.map(d => ({ id: d.id, ...d.data() }));

    const total = _pendingExp.length + _pendingDep.length;
    const countEl = document.getElementById('req-pending-count');
    if (countEl) countEl.textContent = `${total}টি অনুমোদন অপেক্ষামাণ`;

    _renderTab();
  } catch (err) {
    toast('লোড ব্যর্থ: ' + err.message, 'er');
  }
}

function _switchTab(tab) {
  _activeTab = tab;
  document.getElementById('reqtab-expense')?.classList.toggle('active', tab === 'expense');
  document.getElementById('reqtab-deposit')?.classList.toggle('active', tab === 'deposit');
  _renderTab();
}

function _renderTab() {
  const content = document.getElementById('req-content');
  if (!content) return;

  if (_activeTab === 'expense') {
    if (!_pendingExp.length) {
      content.innerHTML = `<div style="padding:30px;text-align:center;color:var(--ink3)">
        <div style="font-size:28px;margin-bottom:8px">✅</div>
        <p>কোনো pending বাজার নেই</p></div>`;
      return;
    }
    content.innerHTML = _pendingExp.map(e => `
<div class="req-item">
  <div class="req-item-hd">
    <div>
      <h3>${CICO[e.category]||'📦'} ${_esc(e.item)}</h3>
      <p>যোগ করেছেন: ${_esc(e.addedByName || '—')} · ${e.date || '—'}</p>
    </div>
    <span style="font-size:15px;font-weight:700;font-family:var(--mono);color:var(--g1)">${taka(e.amount)}</span>
  </div>
  ${e.note ? `<p style="font-size:12px;color:var(--ink3);margin-bottom:6px">📝 ${_esc(e.note)}</p>` : ''}
  <span class="badge b-amber">${_esc(e.category)}</span>
  <div class="req-item-acts">
    <button class="btn btn-sm btn-p" onclick="window.__reqApproveExp('${e.id}')">✓ অনুমোদন</button>
    <button class="btn btn-sm btn-danger" onclick="window.__reqRejectExp('${e.id}')">✗ বাতিল</button>
  </div>
</div>`).join('');
  } else {
    if (!_pendingDep.length) {
      content.innerHTML = `<div style="padding:30px;text-align:center;color:var(--ink3)">
        <div style="font-size:28px;margin-bottom:8px">✅</div>
        <p>কোনো pending ডিপোজিট নেই</p></div>`;
      return;
    }
    content.innerHTML = _pendingDep.map(d => `
<div class="req-item">
  <div class="req-item-hd">
    <div>
      <h3>💰 ${_esc(d.memberName || '—')}</h3>
      <p>তারিখ: ${d.date || '—'}</p>
    </div>
    <span style="font-size:15px;font-weight:700;font-family:var(--mono);color:var(--b0)">${taka(d.amount)}</span>
  </div>
  ${d.note ? `<p style="font-size:12px;color:var(--ink3);margin-bottom:6px">📝 ${_esc(d.note)}</p>` : ''}
  <div class="req-item-acts">
    <button class="btn btn-sm btn-p" onclick="window.__reqApproveDep('${d.id}')">✓ অনুমোদন</button>
    <button class="btn btn-sm btn-danger" onclick="window.__reqRejectDep('${d.id}')">✗ বাতিল</button>
  </div>
</div>`).join('');
  }
}

async function _approveExp(id) {
  await updateDoc(doc(db,'messes',_ctx.messId,'expenses',id),
    { status:'approved', approvedBy:_ctx.profile.uid, approvedAt:serverTimestamp() });
  toast('অনুমোদন দেওয়া হয়েছে', 'ok');
  _pendingExp = _pendingExp.filter(e => e.id !== id);
  _renderTab();
  _updateCount();
}
async function _rejectExp(id) {
  await updateDoc(doc(db,'messes',_ctx.messId,'expenses',id), { status:'rejected' });
  toast('বাতিল করা হয়েছে', 'ok');
  _pendingExp = _pendingExp.filter(e => e.id !== id);
  _renderTab();
  _updateCount();
}
async function _approveDep(id) {
  await updateDoc(doc(db,'messes',_ctx.messId,'deposits',id),
    { status:'approved', approvedBy:_ctx.profile.uid, approvedAt:serverTimestamp() });
  toast('অনুমোদন দেওয়া হয়েছে', 'ok');
  _pendingDep = _pendingDep.filter(d => d.id !== id);
  _renderTab();
  _updateCount();
}
async function _rejectDep(id) {
  await updateDoc(doc(db,'messes',_ctx.messId,'deposits',id), { status:'rejected' });
  toast('বাতিল করা হয়েছে', 'ok');
  _pendingDep = _pendingDep.filter(d => d.id !== id);
  _renderTab();
  _updateCount();
}

function _updateCount() {
  const total = _pendingExp.length + _pendingDep.length;
  const el = document.getElementById('req-pending-count');
  if (el) el.textContent = `${total}টি অনুমোদন অপেক্ষামাণ`;
  const dot = document.getElementById('req-badge-dot');
  if (dot) dot.classList.toggle('show', total > 0);
}

const _esc = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

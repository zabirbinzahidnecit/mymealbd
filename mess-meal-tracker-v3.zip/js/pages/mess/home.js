// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/pages/mess/home.js
//  Dashboard: summary cards, quick meal, notices, month nav
//  import { render } from './home.js';
// ══════════════════════════════════════════════════════════

import { db } from '../../firebase.js';
import { taka, toast, ld, uld, moName, pad, dim, formatDate } from '../../utils.js';
import {
  collection, getDocs, doc, getDoc, setDoc, updateDoc,
  query, orderBy, limit, where, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _ctx = {};
let _vy = TODAY.getFullYear();
let _vm = TODAY.getMonth();

export async function render(root, ctx) {
  _ctx = ctx;
  const { messId, messSettings, profile } = ctx;
  const slots = messSettings?.slots || ['সকাল','দুপুর','রাত'];

  root.innerHTML = `
<div>
  <!-- Month navigation -->
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <button class="btn btn-ghost btn-sm" onclick="window.__homeMonthNav(-1)">◀</button>
    <span style="font-size:14px;font-weight:700;min-width:130px;text-align:center" id="home-month-lbl"></span>
    <button class="btn btn-ghost btn-sm" onclick="window.__homeMonthNav(1)">▶</button>
    <button class="btn btn-ghost btn-sm" onclick="window.__homeGoToday()">আজ</button>
    <button class="btn btn-ghost btn-sm" style="margin-left:auto" onclick="window.__homeRefresh()">🔄</button>
  </div>

  <!-- Summary cards -->
  <div class="gA" id="home-summary" style="margin-bottom:16px">
    <div class="sc sg"><div class="sl">মোট মিল</div><div class="sv" id="hc-meal">—</div><div class="ss">এই মাসে</div></div>
    <div class="sc sa"><div class="sl">মিলের দাম</div><div class="sv" id="hc-meal-rate">—</div><div class="ss">প্রতি মিল</div></div>
    <div class="sc sb"><div class="sl">মোট বাজার</div><div class="sv" id="hc-bazar">—</div><div class="ss">এই মাসে</div></div>
    <div class="sc sr"><div class="sl">ব্যালেন্স</div><div class="sv" id="hc-balance">—</div><div class="ss">জমা − খরচ</div></div>
  </div>

  <!-- Quick meal entry -->
  <div class="card" style="margin-bottom:14px">
    <div class="ch"><h3>🍚 আজকের মিল</h3><span style="font-size:11px;color:var(--ink3)" id="home-today-date"></span></div>
    <div class="cb">
      <div class="slot-row" id="home-slot-row"></div>
      <div class="cutoff-notice" id="home-cutoff">⏰ মিল পরিবর্তনের সময় পার হয়ে গেছে</div>
      <div class="done-bar" id="home-done">✓ আজকের মিল সেভ আছে</div>
    </div>
  </div>

  <!-- Recent notices -->
  <div class="card">
    <div class="ch">
      <h3>📢 সর্বশেষ নোটিশ</h3>
      <button class="btn btn-ghost btn-sm" onclick="window.dispatchEvent(new CustomEvent('mm:navigate',{detail:{page:'notice'}}))">সব দেখুন</button>
    </div>
    <div class="cb" id="home-notices">লোড হচ্ছে…</div>
  </div>
</div>`;

  window.__homeMonthNav = (d) => { _vm += d; if (_vm > 11) { _vm=0; _vy++; } if (_vm < 0) { _vm=11; _vy--; } _loadData(); };
  window.__homeGoToday  = () => { _vy=TODAY.getFullYear(); _vm=TODAY.getMonth(); _loadData(); };
  window.__homeRefresh  = () => _loadData();
  window.__homeSlotToggle = (i) => _toggleSlot(i);

  _updateMonthLabel();
  _renderSlots();
  await _loadData();
}

function _updateMonthLabel() {
  const el = document.getElementById('home-month-lbl');
  if (el) el.textContent = `${moName(_vm)} ${_vy}`;

  const dateEl = document.getElementById('home-today-date');
  if (dateEl) {
    dateEl.textContent = `${TODAY.getDate()} ${moName(TODAY.getMonth())} ${TODAY.getFullYear()}`;
  }
}

function _renderSlots() {
  const row = document.getElementById('home-slot-row');
  if (!row) return;
  const slots = _ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const SICO  = ['☀️','🌤','🌙','🍳','🍱','🌮'];
  const cutoff = _ctx.messSettings?.cutoffHour ?? 10;
  const isPast = TODAY.getHours() >= cutoff;

  row.innerHTML = slots.map((s, i) => `
<button class="slt ${isPast ? 'locked' : ''}" id="slt-${i}"
  onclick="window.__homeSlotToggle(${i})">
  <span>${SICO[i] || '🍽'}</span>${_esc(s)}
</button>`).join('');

  const cutoffEl = document.getElementById('home-cutoff');
  if (cutoffEl) cutoffEl.classList.toggle('show', isPast);
}

async function _loadData() {
  _updateMonthLabel();
  const { messId, profile } = _ctx;
  const monthPrefix = `${_vy}_${pad(_vm + 1)}`;

  try {
    // Load all meals for month
    const mealsSnap = await getDocs(collection(db, 'messes', messId, 'meals'));
    let totalMeals = 0;
    mealsSnap.forEach(d => {
      if (d.id.startsWith(monthPrefix)) {
        const data = d.data();
        totalMeals += (data.slots || []).filter(Boolean).length;
        totalMeals += (data.guestSlots || []).filter(Boolean).length;
      }
    });

    // Load expenses for month
    const expSnap = await getDocs(query(
      collection(db, 'messes', messId, 'expenses'),
      where('status','==','approved')
    ));
    let totalBazar = 0;
    expSnap.forEach(d => {
      const data = d.data();
      if (data.date?.startsWith?.(`${_vy}-${pad(_vm+1)}`) ||
          data.date?.startsWith?.(monthPrefix.replace('_','-'))) {
        totalBazar += parseFloat(data.amount) || 0;
      }
    });

    // Load deposits for month
    const depSnap = await getDocs(query(
      collection(db, 'messes', messId, 'deposits'),
      where('status','==','approved')
    ));
    let totalDeposit = 0;
    depSnap.forEach(d => {
      const data = d.data();
      if (data.date?.startsWith?.(`${_vy}-${pad(_vm+1)}`)) {
        totalDeposit += parseFloat(data.amount) || 0;
      }
    });

    const mealRate = totalMeals > 0 ? totalBazar / totalMeals : 0;
    const balance  = totalDeposit - totalBazar;

    _setStat('hc-meal',     String(totalMeals));
    _setStat('hc-meal-rate', taka(mealRate));
    _setStat('hc-bazar',    taka(totalBazar));
    _setStat('hc-balance',  taka(balance));

    // Load today's meal
    const isToday = _vy === TODAY.getFullYear() && _vm === TODAY.getMonth();
    if (isToday) {
      const tkKey = `${_vy}_${pad(_vm+1)}_${pad(TODAY.getDate())}_${profile.uid}`;
      const mealSnap = await getDoc(doc(db, 'messes', messId, 'meals', tkKey));
      const mySlots  = mealSnap.exists() ? (mealSnap.data().slots || []) : [];
      const slots    = _ctx.messSettings?.slots || [];
      slots.forEach((_, i) => {
        const btn = document.getElementById(`slt-${i}`);
        if (btn) btn.classList.toggle('on', !!mySlots[i]);
      });
      document.getElementById('home-done')?.classList.toggle('show', mySlots.some(Boolean));
    }

    // Load notices
    await _loadNotices();
  } catch (err) {
    console.error('Dashboard load error:', err);
    toast('ড্যাশবোর্ড লোড ব্যর্থ', 'er');
  }
}

async function _loadNotices() {
  const noticeEl = document.getElementById('home-notices');
  if (!noticeEl) return;
  try {
    const snap = await getDocs(query(
      collection(db, 'messes', _ctx.messId, 'notices'),
      orderBy('createdAt','desc'),
      limit(5)
    ));
    if (snap.empty) {
      noticeEl.innerHTML = '<p style="color:var(--ink3);font-size:12px">কোনো নোটিশ নেই</p>';
      return;
    }
    noticeEl.innerHTML = snap.docs.map(d => {
      const n = d.data();
      return `
<div style="padding:9px 0;border-bottom:.5px solid var(--line)">
  <p style="font-size:13px;color:var(--ink);line-height:1.5">${_esc(n.text || '')}</p>
  <p style="font-size:10px;color:var(--ink4);margin-top:3px">— ${_esc(n.addedByName || '—')} · ${n.createdAt ? formatDate(n.createdAt) : ''}</p>
</div>`;
    }).join('');
  } catch (e) {
    noticeEl.innerHTML = '<p style="color:var(--ink3);font-size:12px">নোটিশ লোড ব্যর্থ</p>';
  }
}

async function _toggleSlot(i) {
  const { messId, profile, messSettings } = _ctx;
  const cutoff = messSettings?.cutoffHour ?? 10;
  if (TODAY.getHours() >= cutoff) return;

  const tkKey  = `${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}_${pad(TODAY.getDate())}_${profile.uid}`;
  const ref    = doc(db, 'messes', messId, 'meals', tkKey);
  const snap   = await getDoc(ref);
  const slots  = snap.exists() ? (snap.data().slots || []) : [];

  slots[i] = !slots[i];

  // Check max meals
  const max = messSettings?.maxMealsPerDay ?? 3;
  if (slots.filter(Boolean).length > max) {
    toast(`সর্বোচ্চ ${max}টি মিল`, 'er'); return;
  }

  await setDoc(ref, { slots, memberId: profile.uid, memberName: profile.name || '' }, { merge: true });

  const btn = document.getElementById(`slt-${i}`);
  if (btn) btn.classList.toggle('on', !!slots[i]);
  document.getElementById('home-done')?.classList.toggle('show', slots.some(Boolean));
}

const _setStat = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
const _esc = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/auth.js  (fixed v3)
//  Fix: spinner loop, inviteIndex reserved name, COOP popup fallback
// ══════════════════════════════════════════════════════════

import { auth, db, googleProvider } from './firebase.js';
import { toast, ld, uld } from './utils.js';
import {
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut,
  onAuthStateChanged
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import {
  doc, getDoc, setDoc, updateDoc, serverTimestamp, writeBatch
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';
import { renderRouter } from './router.js';

// ── Current user state ────────────────────────────────────
export let currentUser    = null;
export let currentProfile = null;

// ── Google Sign-In (popup → redirect fallback) ────────────
export async function startAuth() {
  const btn = document.getElementById('btn-login');
  if (btn) btn.disabled = true;
  ld('লগইন হচ্ছে…');

  try {
    await signInWithPopup(auth, googleProvider);
    // সফল → onAuthStateChanged handle করবে, সেখানে uld() হবে
  } catch (err) {
    const code = err.code || '';

    if (code === 'auth/popup-blocked') {
      // Popup block → redirect এ চেষ্টা
      try {
        toast('Popup block — redirect এ যাচ্ছে…', 'info');
        await signInWithRedirect(auth, googleProvider);
        return; // page redirect হবে, uld দরকার নেই
      } catch (e2) { /* ignore */ }
    }

    // User নিজে বন্ধ করেছে বা অন্য কিছু — spinner বন্ধ
    uld();
    if (btn) btn.disabled = false;

    if (
      code !== 'auth/popup-closed-by-user' &&
      code !== 'auth/cancelled-popup-request'
    ) {
      toast('লগইন ব্যর্থ: ' + (err.message || code), 'er');
    }
  }
}

// ── Handle redirect result (page load এ) ──────────────────
export async function handleRedirectResult() {
  try {
    await getRedirectResult(auth);
    // সফল হলে onAuthStateChanged fire করবে
  } catch (err) {
    const code = err.code || '';
    if (code && code !== 'auth/no-auth-event') {
      console.warn('[Auth] Redirect error:', code);
    }
  }
}

// ── Logout ───────────────────────────────────────────────
export async function logout() {
  try {
    currentUser = null;
    currentProfile = null;
    await signOut(auth);
  } catch (err) {
    toast('লগআউট ব্যর্থ', 'er');
  }
}

// ── Ensure user doc exists ────────────────────────────────
async function ensureUserDoc(firebaseUser) {
  const ref  = doc(db, 'users', firebaseUser.uid);
  const snap = await getDoc(ref);

  if (!snap.exists()) {
    await setDoc(ref, {
      email:         firebaseUser.email,
      name:          firebaseUser.displayName || firebaseUser.email.split('@')[0],
      avatar:        firebaseUser.photoURL || null,
      status:        'pending',
      platformRole:  null,
      currentMessId: null,
      createdAt:     serverTimestamp()
    });
    return (await getDoc(ref)).data();
  }

  const data    = snap.data();
  const updates = {};
  if (firebaseUser.photoURL && data.avatar !== firebaseUser.photoURL)
    updates.avatar = firebaseUser.photoURL;
  if (Object.keys(updates).length) await updateDoc(ref, updates);
  return { ...data, ...updates };
}

// ── Check & accept pending invite ─────────────────────────
// NOTE: 'inviteIndex' — double underscore নেই (Firestore reserved names)
async function checkAndAcceptInvite(firebaseUser) {
  const email = firebaseUser.email?.toLowerCase();
  if (!email) return false;
  try {
    const idxRef  = doc(db, 'inviteIndex', email.replace(/\./g, '_'));
    const idxSnap = await getDoc(idxRef);
    if (!idxSnap.exists()) return false;

    const { messId, token, role } = idxSnap.data();
    const tokenRef  = doc(db, 'messes', messId, 'invites', token);
    const tokenSnap = await getDoc(tokenRef);
    if (!tokenSnap.exists()) return false;

    const inv = tokenSnap.data();
    if (inv.used || inv.expiresAt?.toDate() < new Date()) return false;

    const batch = writeBatch(db);
    batch.set(doc(db, 'messes', messId, 'members', firebaseUser.uid), {
      name:     firebaseUser.displayName || email,
      email,
      avatar:   firebaseUser.photoURL || null,
      role,
      joinedAt: serverTimestamp()
    });
    batch.update(doc(db, 'users', firebaseUser.uid), {
      status: 'active', currentMessId: messId
    });
    batch.update(tokenRef, { used: true });
    batch.delete(idxRef);
    await batch.commit();

    toast('মেসে যোগ হয়েছে! স্বাগতম 🎉', 'ok');
    return true;
  } catch (e) {
    console.warn('Invite check error:', e.message);
    return false;
  }
}

// ── Auth State Listener ───────────────────────────────────
let _processing = false;

export function initAuth() {
  // Page load এ redirect result আগে check করো
  handleRedirectResult();

  onAuthStateChanged(auth, async (firebaseUser) => {
    if (_processing) return;
    _processing = true;

    if (!firebaseUser) {
      currentUser    = null;
      currentProfile = null;
      uld();
      _processing = false;
      renderRouter(null, null);
      return;
    }

    ld('প্রোফাইল লোড হচ্ছে…');

    try {
      currentUser = firebaseUser;

      let profile = await ensureUserDoc(firebaseUser);

      if (!profile.currentMessId) {
        const accepted = await checkAndAcceptInvite(firebaseUser);
        if (accepted) {
          const snap = await getDoc(doc(db, 'users', firebaseUser.uid));
          profile = snap.data();
        }
      }

      currentProfile = { uid: firebaseUser.uid, ...profile };
      uld();
      _processing = false;
      renderRouter(currentUser, currentProfile);

    } catch (err) {
      console.error('Auth state error:', err);
      uld();
      _processing = false;
      toast('প্রোফাইল লোড ব্যর্থ — পুনরায় চেষ্টা করুন', 'er');
      renderRouter(firebaseUser, null);
    }
  });
}

// ── Role helpers ──────────────────────────────────────────
export const isPlatformAdmin   = () => currentProfile?.platformRole === 'admin';
export const isPlatformCoAdmin = () => ['admin','co-admin'].includes(currentProfile?.platformRole);
export const hasMessAccess     = () => !!currentProfile?.currentMessId;

// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/router.js  (fixed v2)
//  সমস্যা সমাধান:
//  _currentPage guard সরানো হয়েছে messShell/adminShell এর জন্য —
//  logout → login → re-login এ আটকে যাওয়ার bug fix
// ══════════════════════════════════════════════════════════

import { isPlatformCoAdmin } from './auth.js';

const PAGE_LOADERS = {
  login:      () => import('./pages/login.js'),
  pending:    () => import('./pages/pending.js'),
  adminShell: () => import('./pages/admin/admin-shell.js'),
  messShell:  () => import('./pages/mess/mess-shell.js'),
};

// Shells যেগুলো সবসময় re-render করতে হয় (auth change এ)
const ALWAYS_RERENDER = new Set(['messShell','adminShell','login','pending']);

let _currentPage = null;

export async function renderRouter(firebaseUser, profile) {
  const root = document.getElementById('app');
  if (!root) return;

  let targetPage;

  if (!firebaseUser) {
    targetPage = 'login';
  } else if (!profile) {
    targetPage = 'login';
  } else if (isPlatformCoAdmin()) {
    targetPage = 'adminShell';
  } else if (profile.currentMessId) {
    targetPage = 'messShell';
  } else {
    targetPage = 'pending';
  }

  // Auth change এ সবসময় re-render করো
  // (শুধু same page এ navigate এর ক্ষেত্রে guard কাজ করবে না)
  await _loadPage(targetPage, root, { firebaseUser, profile });
}

async function _loadPage(name, root, props = {}) {
  // Login → mess বা mess → login এ সবসময় re-render করতে হবে
  // শুধু একই shell এর ভেতরে navigate এ skip করা যাবে না
  const shouldSkip = _currentPage === name && !ALWAYS_RERENDER.has(name);
  if (shouldSkip) return;

  _currentPage = name;

  // Root clear করো শুধু shell change এ
  try {
    const mod = await PAGE_LOADERS[name]?.();
    if (mod?.render) {
      await mod.render(root, props);
    }
  } catch (err) {
    console.error(`Failed to load page: ${name}`, err);
    _currentPage = null; // reset so retry works
    root.innerHTML = `
<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;
  min-height:100vh;gap:16px;font-family:'Hind Siliguri',sans-serif;
  color:#0a180e;padding:24px;text-align:center;background:#f1f5f2">
  <div style="font-size:40px">⚠️</div>
  <h2 style="font-size:18px;font-weight:700">পেজ লোড হয়নি</h2>
  <p style="font-size:13px;color:#4a7055;max-width:320px">${err.message || 'অজানা ত্রুটি'}</p>
  <button onclick="location.reload()"
    style="height:40px;padding:0 20px;background:#146b40;color:#fff;
      border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer">
    🔄 পুনরায় লোড করুন
  </button>
</div>`;
  }
}

export function navigate(page, params = {}) {
  window.dispatchEvent(new CustomEvent('mm:navigate', { detail: { page, params } }));
}

export function resetRouter() {
  _currentPage = null;
}

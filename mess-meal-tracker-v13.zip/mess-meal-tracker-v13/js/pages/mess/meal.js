// meal.js — v11: calendar removed, meal rate shown, all bugs fixed

import { db } from '../../firebase.js';
import { toast, ld, uld, pad, dim, moName, taka, takaF } from '../../utils.js';
import {
  collection, getDocs, doc, getDoc, setDoc, query, orderBy, where
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _ctx={}, _vy=TODAY.getFullYear(), _vm=TODAY.getMonth(), _members=[];

export async function render(root, ctx) {
  _ctx = ctx;
  const slots  = ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const cutoff = ctx.messSettings?.cutoffHour ?? 10;
  const now    = TODAY.getHours();
  const isPast = now >= cutoff;

  const ENTRY_DATE = isPast
    ? new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate()+1)
    : TODAY;

  const SICO = ['☀️','🌤','🌙','🍳','🍱','🌮'];

  root.innerHTML = `
<div>
  <!-- Month nav for table -->
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <button class="btn btn-ghost btn-sm" id="mp">◀</button>
    <span style="font-size:14px;font-weight:700;min-width:130px;text-align:center" id="m-lbl"></span>
    <button class="btn btn-ghost btn-sm" id="mn">▶</button>
    <button class="btn btn-ghost btn-sm" id="mt">আজ</button>
    <button class="btn btn-p btn-sm" id="mmd" style="margin-left:auto">📅 একাধিক দিন</button>
  </div>

  <!-- Meal rate info card -->
  <div class="card" style="margin-bottom:14px">
    <div class="cb" style="padding:10px 14px">
      <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center">
        <div style="flex:1;min-width:130px">
          <p style="font-size:10px;font-weight:700;color:var(--ink3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">এই মাসের মিল রেট</p>
          <p style="font-size:22px;font-weight:700;font-family:var(--mono);color:var(--g1)" id="m-rate">—</p>
          <p style="font-size:11px;color:var(--ink3)" id="m-rate-sub">লোড হচ্ছে…</p>
        </div>
        <div style="display:flex;gap:12px;flex-wrap:wrap">
          <div style="text-align:center">
            <p style="font-size:10px;color:var(--ink3);font-weight:700">মোট মিল</p>
            <p style="font-size:18px;font-weight:700;font-family:var(--mono);color:var(--ink)" id="m-total-meals">—</p>
          </div>
          <div style="text-align:center">
            <p style="font-size:10px;color:var(--ink3);font-weight:700">মোট বাজার</p>
            <p style="font-size:18px;font-weight:700;font-family:var(--mono);color:var(--ink)" id="m-total-bazar">—</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Today's entry -->
  <div class="card" style="margin-bottom:14px;background:${isPast?'var(--r4)':'var(--g7)'};
    border-color:${isPast?'var(--r3)':'var(--g5)'}">
    <div class="cb" style="padding:12px 14px">
      <div>
        <p style="font-size:11px;font-weight:700;color:${isPast?'var(--r1)':'var(--g2)'};
          text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">
          ${isPast?'🔒 আজকের মিল বন্ধ — আগামীকালের মিল চালু':'⏰ আজকের মিল এন্ট্রি চালু'}
        </p>
        <p style="font-size:13px;color:var(--ink)">
          ${isPast
            ? `আগামীকাল (${ENTRY_DATE.getDate()} ${moName(ENTRY_DATE.getMonth())}) এর মিল দিন`
            : `মিল বন্ধ হবে <strong>${cutoff}:00</strong> তে · ${TODAY.getDate()} ${moName(TODAY.getMonth())}`}
        </p>
      </div>
      <div class="slot-row" style="margin-top:12px" id="m-slots"></div>
      <div style="margin-top:8px;display:flex;align-items:center;gap:8px;flex-wrap:wrap">
        <label style="font-size:11px;font-weight:700;color:var(--ink3)">Guest মিল:</label>
        <input class="inp inp-sm" id="m-guest" type="number" min="0" max="20"
          placeholder="0" style="width:80px"/>
        <button class="btn btn-ghost btn-sm" id="m-guest-save">সেভ</button>
      </div>
      ${ctx.myMessRole !== 'member' ? `
      <div style="margin-top:10px;padding-top:10px;border-top:1px solid rgba(0,0,0,.08)">
        <label class="lbl">অন্য সদস্যের মিল দিন</label>
        <select class="inp inp-sm" id="m-sel" style="max-width:220px"></select>
      </div>` : ''}
    </div>
  </div>

  <!-- Slot summary for cook -->
  <div class="card" style="margin-bottom:14px">
    <div class="ch">
      <h3>📋 আজকের মিল তালিকা — বুয়ার জন্য</h3>
      <span style="font-size:11px;color:var(--ink3)">${TODAY.getDate()} ${moName(TODAY.getMonth())}</span>
    </div>
    <div class="cb" id="m-slot-summary">লোড হচ্ছে…</div>
  </div>

  <!-- Day detail table -->
  <div class="card">
    <div class="ch">
      <h3>📅 দিনের বিস্তারিত</h3>
      <input type="date" id="m-date" class="inp inp-sm" style="width:auto"/>
    </div>
    <div class="cb" style="overflow-x:auto" id="m-table">লোড হচ্ছে…</div>
  </div>
</div>

<!-- Multiday modal -->
<div style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);
  z-index:300;align-items:center;justify-content:center;padding:20px" id="md-mo">
  <div style="background:#fff;border-radius:16px;padding:22px;max-width:500px;
    width:100%;max-height:90vh;overflow-y:auto">
    <h3 style="font-size:15px;font-weight:700;margin-bottom:4px">📅 একাধিক দিনের মিল</h3>
    <p style="font-size:11px;color:var(--ink3);margin-bottom:12px">
      সবুজ = মিল আছে • সাদা = মিল নেই • ক্লিক করে toggle করুন
    </p>
    <div id="md-content"></div>
    <div id="md-slot-area" style="margin-top:10px"></div>
    <div style="display:flex;gap:8px;margin-top:14px">
      <button class="btn btn-ghost" id="md-close">বাতিল</button>
      <button class="btn btn-p" id="md-apply">✓ প্রয়োগ</button>
    </div>
  </div>
</div>`;

  root.querySelector('#mp').addEventListener('click', ()=>{ _vm--; if(_vm<0){_vm=11;_vy--} _load(root); });
  root.querySelector('#mn').addEventListener('click', ()=>{ _vm++; if(_vm>11){_vm=0;_vy++} _load(root); });
  root.querySelector('#mt').addEventListener('click', ()=>{ _vy=TODAY.getFullYear();_vm=TODAY.getMonth(); _load(root); });
  root.querySelector('#mmd').addEventListener('click', ()=> _openMulti(root));
  root.querySelector('#m-guest-save').addEventListener('click', ()=> _saveGuest(root, ENTRY_DATE));
  root.querySelector('#md-close').addEventListener('click', ()=>{ root.querySelector('#md-mo').style.display='none'; });
  root.querySelector('#md-prev-mo').addEventListener('click', ()=>{
    _vm--; if(_vm<0){_vm=11;_vy--;} _syncModalMonthSel(root); _openMulti(root);
  });
  root.querySelector('#md-next-mo').addEventListener('click', ()=>{
    _vm++; if(_vm>11){_vm=0;_vy++;} _syncModalMonthSel(root); _openMulti(root);
  });
  root.querySelector('#md-month-sel').addEventListener('change', e=>{
    _vm=parseInt(e.target.value); _openMulti(root);
  });
  root.querySelector('#md-year-sel').addEventListener('change', e=>{
    _vy=parseInt(e.target.value); _openMulti(root);
  });
  root.querySelector('#md-apply').addEventListener('click', ()=> _applyMulti(root));
  root.querySelector('#m-sel')?.addEventListener('change', e=> _renderSlots(root, e.target.value, ENTRY_DATE));

  root.querySelector('#m-slots').addEventListener('click', e=>{
    const btn = e.target.closest('[data-si]');
    if (btn) _toggle(root, btn.dataset.uid, parseInt(btn.dataset.si), ENTRY_DATE);
  });

  const dp = root.querySelector('#m-date');
  if (dp) dp.value = `${TODAY.getFullYear()}-${pad(TODAY.getMonth()+1)}-${pad(TODAY.getDate())}`;
  root.querySelector('#m-date').addEventListener('change', e=> _loadTable(root, e.target.value));

  root.querySelector('#m-lbl').textContent = `${moName(_vm)} ${_vy}`;
  await _load(root);
}

async function _load(root) {
  root.querySelector('#m-lbl').textContent = `${moName(_vm)} ${_vy}`;
  ld('সদস্য লোড হচ্ছে…');
  try {
    const snap = await getDocs(query(collection(db,'messes',_ctx.messId,'members'), orderBy('joinedAt')));
    _members = snap.docs.map(d=>({uid:d.id,...d.data()}));

    const sel = root.querySelector('#m-sel');
    if (sel) {
      sel.innerHTML = _members.map(m=>
        `<option value="${m.uid}">${_e(m.name||m.email)}${m.uid===_ctx.profile.uid?' (আমি)':''}</option>`
      ).join('');
      sel.value = _ctx.profile.uid;
    }

    const cutoff    = _ctx.messSettings?.cutoffHour ?? 10;
    const isPast    = TODAY.getHours() >= cutoff;
    const ENTRY_DATE = isPast
      ? new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate()+1)
      : TODAY;

    _renderSlots(root, _ctx.profile.uid, ENTRY_DATE);

    const dp = root.querySelector('#m-date');
    if (dp) await _loadTable(root, dp.value);
    await _loadSlotSummary(root);
    await _loadMealRate(root);
  } finally { uld(); }
}

// ── Meal rate এই মাসের ──────────────────────────────────
async function _loadMealRate(root) {
  try {
    const monthStr = `${_vy}-${pad(_vm+1)}`;
    const monthPfx = `${_vy}_${pad(_vm+1)}`;

    // Total meals
    const mealSnap = await getDocs(collection(db,'messes',_ctx.messId,'meals'));
    let totalMeals = 0;
    mealSnap.forEach(d=>{
      if (d.id.startsWith(monthPfx)) {
        totalMeals += (d.data().slots||[]).filter(Boolean).length;
        totalMeals += (d.data().guestSlots||[]).filter(Boolean).length;
      }
    });

    // Total approved bazar
    const expSnap = await getDocs(query(
      collection(db,'messes',_ctx.messId,'expenses'), where('status','==','approved')
    ));
    let totalBazar = 0;
    expSnap.forEach(d=>{ if(d.data().date?.startsWith(monthStr)) totalBazar+=parseFloat(d.data().amount)||0; });

    const rate = totalMeals>0 ? totalBazar/totalMeals : 0;

    const rateEl = root.querySelector('#m-rate');
    const subEl  = root.querySelector('#m-rate-sub');
    const mealEl = root.querySelector('#m-total-meals');
    const bazEl  = root.querySelector('#m-total-bazar');

    if (rateEl) rateEl.textContent = totalMeals>0 ? takaF(rate) : '—';
    if (subEl)  subEl.textContent  = `প্রতি মিল · ${moName(_vm)} ${_vy}`;
    if (mealEl) mealEl.textContent = totalMeals || '০';
    if (bazEl)  bazEl.textContent  = taka(totalBazar);
  } catch(e) { console.warn('Rate load error:', e); }
}

async function _loadSlotSummary(root) {
  const el = root.querySelector('#m-slot-summary');
  if (!el) return;
  const slots = _ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const SICO  = ['☀️','🌤','🌙','🍳','🍱','🌮'];
  const slotCounts = new Array(slots.length).fill(0);
  let guestTotal = 0;

  // Promise.all — not sequential
  const keys = _members.map(m=>`${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}_${pad(TODAY.getDate())}_${m.uid}`);
  const snaps = await Promise.all(keys.map(k=>getDoc(doc(db,'messes',_ctx.messId,'meals',k))));
  snaps.forEach(snap=>{
    if (!snap.exists()) return;
    const data = snap.data();
    (data.slots||[]).forEach((on,i)=>{ if(on) slotCounts[i]++; });
    guestTotal += (data.guestSlots||[]).filter(Boolean).length;
  });

  const grandTotal = slotCounts.reduce((a,b)=>a+b,0) + guestTotal;

  el.innerHTML = `
<div style="margin-bottom:12px">
  <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px">
    ${slots.map((s,i)=>`
    <div style="background:${slotCounts[i]>0?'var(--g7)':'var(--paper)'};
      border:1px solid ${slotCounts[i]>0?'var(--g5)':'var(--line)'};
      border-radius:12px;padding:10px 16px;text-align:center;min-width:90px">
      <div style="font-size:20px;margin-bottom:4px">${SICO[i]||'🍽'}</div>
      <div style="font-size:12px;font-weight:600;color:var(--ink)">${_e(s)}</div>
      <div style="font-size:24px;font-weight:700;color:${slotCounts[i]>0?'var(--g1)':'var(--ink4)'}">
        ${slotCounts[i]}
      </div>
      <div style="font-size:10px;color:var(--ink4)">জন</div>
    </div>`).join('')}
    ${guestTotal>0?`
    <div style="background:var(--b4);border:1px solid var(--b3);
      border-radius:12px;padding:10px 16px;text-align:center;min-width:90px">
      <div style="font-size:20px;margin-bottom:4px">👥</div>
      <div style="font-size:12px;font-weight:600;color:var(--ink)">Guest</div>
      <div style="font-size:24px;font-weight:700;color:var(--b0)">${guestTotal}</div>
      <div style="font-size:10px;color:var(--ink4)">জন</div>
    </div>`:''}
  </div>
  <div style="background:var(--g2);color:#fff;border-radius:10px;
    padding:10px 16px;display:flex;justify-content:space-between;align-items:center">
    <span style="font-size:13px;font-weight:600">মোট মিল আজ</span>
    <span style="font-size:22px;font-weight:700;font-family:var(--mono)">${grandTotal}</span>
  </div>
</div>
<p style="font-size:11px;color:var(--ink4)">⚠️ এই তালিকা বুয়াকে দেখান — কোন বেলায় কতজনের রান্না করতে হবে</p>`;
}

function _renderSlots(root, uid, entryDate) {
  const slots  = _ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const SICO   = ['☀️','🌤','🌙','🍳','🍱','🌮'];
  const cutoff = _ctx.messSettings?.cutoffHour ?? 10;
  // Lock: normal member + past cutoff + own uid
  const isPast = uid===_ctx.profile.uid
    && TODAY.getHours()>=cutoff
    && !['mess-admin','mess-co-admin'].includes(_ctx.myMessRole);

  root.querySelector('#m-slots').innerHTML = slots.map((s,i)=>
    `<button class="slt${isPast?' locked':''}" data-uid="${uid}" data-si="${i}" id="ms-${uid}-${i}">
      ${SICO[i]||'🍽'} ${_e(s)}
    </button>`).join('');

  const d   = entryDate || TODAY;
  const key = `${d.getFullYear()}_${pad(d.getMonth()+1)}_${pad(d.getDate())}_${uid}`;
  getDoc(doc(db,'messes',_ctx.messId,'meals',key)).then(snap=>{
    const s = snap.exists()?(snap.data().slots||[]):[];
    slots.forEach((_,i)=>root.querySelector(`#ms-${uid}-${i}`)?.classList.toggle('on',!!s[i]));
    const gi = root.querySelector('#m-guest');
    if (gi) gi.value = snap.exists()?((snap.data().guestSlots||[]).filter(Boolean).length||''):'';
  });
}

async function _toggle(root, uid, i, entryDate) {
  const d   = entryDate || TODAY;
  const key = `${d.getFullYear()}_${pad(d.getMonth()+1)}_${pad(d.getDate())}_${uid}`;
  const ref = doc(db,'messes',_ctx.messId,'meals',key);
  const snap = await getDoc(ref);
  const slots = snap.exists() ? [...(snap.data().slots||[])] : [];
  slots[i] = !slots[i];
  const max = _ctx.messSettings?.maxMealsPerDay ?? 3;
  if (slots.filter(Boolean).length > max) { toast(`সর্বোচ্চ ${max}টি মিল`,'er'); return; }
  await setDoc(ref, { slots, memberId: uid }, { merge: true });
  root.querySelector(`#ms-${uid}-${i}`)?.classList.toggle('on', !!slots[i]);
  await _loadSlotSummary(root);
}

async function _saveGuest(root, entryDate) {
  const n   = parseInt(root.querySelector('#m-guest')?.value)||0;
  const uid = root.querySelector('#m-sel')?.value || _ctx.profile.uid;
  const d   = entryDate || TODAY;
  const key = `${d.getFullYear()}_${pad(d.getMonth()+1)}_${pad(d.getDate())}_${uid}`;
  await setDoc(doc(db,'messes',_ctx.messId,'meals',key),
    { guestSlots: Array(n).fill(true), memberId: uid }, { merge: true });
  toast('Guest মিল সেভ হয়েছে','ok');
  await _loadSlotSummary(root);
}

async function _loadTable(root, dateStr) {
  const wrap = root.querySelector('#m-table');
  if (!wrap||!_members.length) return;
  const [y,m,d] = dateStr.split('-').map(Number);
  const slots = _ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const SICO  = ['☀️','🌤','🌙','🍳','🍱'];

  const snaps = await Promise.all(
    _members.map(mb=>getDoc(doc(db,'messes',_ctx.messId,'meals',`${y}_${pad(m)}_${pad(d)}_${mb.uid}`)))
  );
  const mealMap={};
  snaps.forEach((s,i)=>{ mealMap[_members[i].uid]=s.exists()?s.data():{}; });

  wrap.innerHTML = `<table class="dt">
<thead><tr>
  <th class="tl">সদস্য</th>
  ${slots.map((s,i)=>`<th>${SICO[i]||''} ${_e(s)}</th>`).join('')}
  <th>Guest</th><th>মোট</th>
</tr></thead><tbody>
${_members.map(mb=>{
  const md=mealMap[mb.uid]||{};
  const s=md.slots||[];
  const g=(md.guestSlots||[]).filter(Boolean).length;
  const t=s.filter(Boolean).length+g;
  return `<tr>
  <td class="tl" style="font-weight:600">${_e(mb.name||mb.email)}</td>
  ${slots.map((_,i)=>`<td><div class="mdot ${s[i]?'don':'doff'}">${s[i]?'✓':''}</div></td>`).join('')}
  <td>${g||'—'}</td>
  <td style="font-weight:700">${t||'—'}</td>
</tr>`;
}).join('')}
</tbody></table>`;
}

// ── Multiday modal ────────────────────────────────────────
function _syncModalMonthSel(root) {
  const mSel = root.querySelector('#md-month-sel');
  const ySel = root.querySelector('#md-year-sel');
  if (!mSel || !ySel) return;
  const MONTHS = ['জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন',
    'জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'];
  if (!mSel.options.length) {
    MONTHS.forEach((m,i)=>{
      const o=document.createElement('option'); o.value=i; o.textContent=m; mSel.appendChild(o);
    });
  }
  mSel.value = _vm;
  if (!ySel.options.length) {
    const cy=TODAY.getFullYear();
    for(let y=cy-1;y<=cy+2;y++){
      const o=document.createElement('option'); o.value=y; o.textContent=y; ySel.appendChild(o);
    }
  }
  ySel.value = _vy;
}

async function _openMulti(root) {
  const slots     = _ctx.messSettings?.slots||['সকাল','দুপুর','রাত'];
  const days      = dim(_vy,_vm);
  const todayD    = TODAY.getDate();
  const isThisMonth = _vy===TODAY.getFullYear() && _vm===TODAY.getMonth();
  const uid       = root.querySelector('#m-sel')?.value || _ctx.profile.uid;

  root.querySelector('#md-mo').style.display = 'flex';
  _syncModalMonthSel(root);
  root.querySelector('#md-content').innerHTML = `
    <div style="padding:30px;text-align:center;color:var(--ink3)">
      <div style="font-size:24px;margin-bottom:8px">⏳</div>
      মিলের তথ্য লোড হচ্ছে…
    </div>`;
  root.querySelector('#md-slot-area').innerHTML = '';

  const mealData = {};
  await Promise.all(
    Array.from({length:days},(_,i)=>i+1).map(async d => {
      const key  = `${_vy}_${pad(_vm+1)}_${pad(d)}_${uid}`;
      const snap = await getDoc(doc(db,'messes',_ctx.messId,'meals',key));
      mealData[d] = snap.exists() ? (snap.data().slots||[]) : [];
    })
  );

  function _dayColor(d) {
    const s = mealData[d] || [];
    const total = s.filter(Boolean).length;
    const max   = _ctx.messSettings?.maxMealsPerDay ?? slots.length;
    if (d === todayD && isThisMonth) {
      return total > 0 ? { bg:'#1fa860', color:'#fff', border:'#1fa860', label:'আজ ✓' }
                       : { bg:'#1a8a50', color:'#fff', border:'#1a8a50', label:'আজ' };
    }
    if (total === 0) return { bg:'#f1f5f2', color:'#243a2c', border:'#b0ceb8', label:'' };
    if (total < max) return { bg:'#e8a838', color:'#fff', border:'#d4922a', label:'আংশিক' };
    return { bg:'#146b40', color:'#fff', border:'#146b40', label:'✓' };
  }

  root.querySelector('#md-content').innerHTML = `
<div style="margin-bottom:8px">
  <label class="lbl">দিন নির্বাচন করুন (ক্লিক করে toggle করুন)</label>
  <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px;margin-top:8px" id="md-days-grid">
    ${Array.from({length:days},(_,i)=>i+1).map(d=>{
      const c = _dayColor(d);
      const hasMeal = (mealData[d]||[]).filter(Boolean).length > 0;
      const initSelected = hasMeal ? '1' : '0';
      return `<button
        class="md-day"
        data-day="${d}"
        data-has-meal="${hasMeal?'1':'0'}"
        data-selected="${initSelected}"
        style="height:40px;background:${c.bg};color:${c.color};
          border:2px solid ${c.border};border-radius:8px;font-size:12px;
          font-weight:700;cursor:pointer;display:flex;flex-direction:column;
          align-items:center;justify-content:center;gap:1px;transition:.1s">
        <span>${d}</span>
        ${c.label ? `<span style="font-size:8px;opacity:.85">${c.label}</span>` : ''}
      </button>`;
    }).join('')}
  </div>
  <div style="margin-top:8px;display:flex;gap:10px;flex-wrap:wrap">
    <span style="font-size:10px;color:var(--ink3)">🟢 সব বেলা আছে</span>
    <span style="font-size:10px;color:var(--ink3)">🟡 আংশিক</span>
    <span style="font-size:10px;color:var(--ink3)">⬜ মিল নেই</span>
    <span style="font-size:10px;color:#cc0000">🔴 বাদ দেওয়া হবে</span>
  </div>
</div>`;

  // Day toggle — addEventListener (no inline onclick)
  root.querySelector('#md-days-grid').addEventListener('click', e=>{
    const btn = e.target.closest('.md-day');
    if (!btn) return;
    const wasSelected = btn.dataset.selected === '1';
    const hasMeal     = btn.dataset.hasMeal === '1';
    btn.dataset.selected = wasSelected ? '0' : '1';
    const now = btn.dataset.selected === '1';
    if (hasMeal && !now) {
      btn.style.background='#fee2e2'; btn.style.color='#cc0000'; btn.style.borderColor='#fca5a5';
    } else if (now && hasMeal) {
      const c = _dayColor(parseInt(btn.dataset.day));
      btn.style.background=c.bg; btn.style.color=c.color; btn.style.borderColor=c.border;
    } else if (now) {
      btn.style.background='#146b40'; btn.style.color='#fff'; btn.style.borderColor='#146b40';
    } else {
      btn.style.background='#f1f5f2'; btn.style.color='#243a2c'; btn.style.borderColor='#b0ceb8';
    }
  });

  root.querySelector('#md-slot-area').innerHTML = `
<div style="margin-top:12px;padding-top:12px;border-top:1px solid var(--line)">
  <label class="lbl">কোন বেলার মিল দেবেন?</label>
  <p style="font-size:11px;color:var(--ink3);margin-bottom:8px">
    নির্বাচিত দিনে এই বেলাগুলো যোগ হবে (বাদ দেওয়া দিনে মিল সরে যাবে)
  </p>
  <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:6px" id="md-slots-row">
    ${slots.map((s,i)=>`
    <button class="slt md-slot" data-idx="${i}" data-on="0">
      ${_e(s)}
    </button>`).join('')}
  </div>
</div>`;

  root.querySelector('#md-slots-row').addEventListener('click', e=>{
    const btn = e.target.closest('.md-slot');
    if (!btn) return;
    btn.dataset.on = btn.dataset.on==='1' ? '0' : '1';
    btn.classList.toggle('on', btn.dataset.on==='1');
  });
}

async function _applyMulti(root) {
  const allDayBtns = [...root.querySelectorAll('.md-day')];
  const slots      = [...root.querySelectorAll('.md-slot')].map(b=>b.dataset.on==='1');
  const uid        = root.querySelector('#m-sel')?.value || _ctx.profile.uid;

  const addDays    = allDayBtns.filter(b=>b.dataset.selected==='1').map(b=>parseInt(b.dataset.day));
  const removeDays = allDayBtns.filter(b=>b.dataset.selected==='0'&&b.dataset.hasMeal==='1').map(b=>parseInt(b.dataset.day));

  if (!addDays.length && !removeDays.length) { toast('কোনো পরিবর্তন নেই','er'); return; }
  if (addDays.length && !slots.some(Boolean)) { toast('কমপক্ষে একটি বেলা নির্বাচন করুন','er'); return; }

  const total = addDays.length + removeDays.length;
  ld(`${total}টি দিন আপডেট হচ্ছে…`);

  try {
    for (const d of addDays) {
      const key = `${_vy}_${pad(_vm+1)}_${pad(d)}_${uid}`;
      await setDoc(doc(db,'messes',_ctx.messId,'meals',key),
        { slots, memberId: uid }, { merge: true });
    }
    for (const d of removeDays) {
      const key = `${_vy}_${pad(_vm+1)}_${pad(d)}_${uid}`;
      const emptySlots = new Array(_ctx.messSettings?.slots?.length||3).fill(false);
      await setDoc(doc(db,'messes',_ctx.messId,'meals',key),
        { slots: emptySlots, memberId: uid }, { merge: true });
    }

    const msg = [];
    if (addDays.length)    msg.push(`${addDays.length}টি দিনে মিল যোগ`);
    if (removeDays.length) msg.push(`${removeDays.length}টি দিন থেকে মিল বাদ`);
    toast(msg.join(', ') + ' ✓','ok');

    root.querySelector('#md-mo').style.display = 'none';
    await _loadSlotSummary(root);
    await _loadMealRate(root);
  } finally { uld(); }
}

const _e = s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

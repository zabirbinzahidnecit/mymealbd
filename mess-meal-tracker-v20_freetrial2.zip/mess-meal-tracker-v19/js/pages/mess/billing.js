// billing.js (mess page) — মেসের নিজের বিলিং টাইমলাইন ও বিস্তারিত হিসাব — view-only
// (পরিবর্তন/waive শুধু Platform Admin করতে পারবেন, Admin Payments পেজ থেকে)

import { getBillingTimeline, PLAN_LABEL, renderCalendarStrip } from '../../billing.js';
import { taka, moName, escapeHtml as _e } from '../../utils.js';
import { requestPayment } from '../../plan.js';

let _ctx = {};

export async function render(root, ctx) {
  _ctx = ctx;
  root.innerHTML = `
<div>
  <h2 style="font-size:17px;font-weight:700;color:var(--ink);margin-bottom:4px">💳 বিলিং</h2>
  <p style="font-size:13px;color:var(--ink3);margin-bottom:16px">আপনার মেসের Plan পেমেন্ট ইতিহাস ও বকেয়ার হিসাব</p>
  <div id="bill-content">লোড হচ্ছে…</div>
</div>`;

  await _load(root);
}

async function _load(root) {
  const el = root.querySelector('#bill-content');
  try {
    const tl = await getBillingTimeline(_ctx.messId);
    el.innerHTML = _renderTimeline(tl);
    root.querySelector('#bill-pay-btn')?.addEventListener('click', () =>
      requestPayment(_ctx.messId, _ctx.profile, _ctx.messData)
    );
  } catch(err) {
    el.innerHTML = `<p style="color:var(--r2);font-size:13px">লোড ব্যর্থ: ${_e(err.message)}</p>`;
  }
}

function _renderTimeline(tl) {
  const { history, dueInfo, currentPlan, currentExpiry } = tl;

  // ── স্ট্যাটাস কার্ড ──
  const statusCard = dueInfo.isExpired ? `
<div class="card" style="border-color:#dc2626;margin-bottom:16px">
  <div class="cb" style="padding:16px">
    <p style="font-size:12px;font-weight:700;color:#dc2626;text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px">
      ⚠️ বকেয়া আছে
    </p>
    <p style="font-size:24px;font-weight:700;color:#dc2626;font-family:var(--mono);margin-bottom:4px">
      ৳${dueInfo.dueAmount}
    </p>
    <p style="font-size:12px;color:var(--ink3);margin-bottom:12px">
      ${dueInfo.monthsOverdue} মাসের বকেয়া (প্রতি মাস ৳${dueInfo.monthlyPrice}) — Renew করলে এই পুরো অ্যামাউন্ট দিতে হবে
    </p>
    <button class="btn btn-p btn-sm" id="bill-pay-btn">⭐ এখনই Renew করুন</button>
  </div>
</div>` : currentPlan!=='free' ? `
<div class="card" style="border-color:var(--g4);margin-bottom:16px">
  <div class="cb" style="padding:16px">
    <p style="font-size:12px;font-weight:700;color:var(--g1);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px">
      ✅ সচল — কোনো বকেয়া নেই
    </p>
    <p style="font-size:16px;font-weight:700;color:var(--ink);margin-bottom:12px">
      ${PLAN_LABEL[currentPlan]||currentPlan} — মেয়াদ ${currentExpiry ? _fmt(currentExpiry) : '—'} পর্যন্ত
    </p>
    <button class="btn btn-ghost btn-sm" id="bill-pay-btn">🔄 আগেই Renew করুন / Plan পরিবর্তন করুন</button>
  </div>
</div>` : dueInfo.freeTrialExpired ? `
<div class="card" style="border-color:#dc2626;margin-bottom:16px">
  <div class="cb" style="padding:16px">
    <p style="font-size:12px;font-weight:700;color:#dc2626;text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px">
      ⚠️ ফ্রি ট্রায়াল শেষ হয়ে গেছে
    </p>
    <p style="font-size:13px;color:var(--ink3);margin-bottom:12px">
      আপনার ১ মাসের ফ্রি ট্রায়াল শেষ — চালিয়ে যেতে একটা Pro Plan নিতে হবে।
    </p>
    <button class="btn btn-p btn-sm" id="bill-pay-btn">⭐ Pro Plan নিন</button>
  </div>
</div>` : dueInfo.freeTrialDaysLeft!=null ? `
<div class="card" style="margin-bottom:16px">
  <div class="cb" style="padding:16px;text-align:center;color:var(--ink3);font-size:13px">
    <p style="margin-bottom:4px">🆓 Free Trial চলছে</p>
    <p style="font-size:20px;font-weight:700;color:var(--g1);margin-bottom:10px">আর ${dueInfo.freeTrialDaysLeft} দিন বাকি</p>
    <button class="btn btn-p btn-sm" id="bill-pay-btn">⭐ Pro Upgrade</button>
  </div>
</div>` : `
<div class="card" style="margin-bottom:16px">
  <div class="cb" style="padding:16px;text-align:center;color:var(--ink3);font-size:13px">
    <p style="margin-bottom:10px">🆓 বর্তমানে Free Plan — কোনো বিলিং ইতিহাস নেই</p>
    <button class="btn btn-p btn-sm" id="bill-pay-btn">⭐ Pro Upgrade</button>
  </div>
</div>`;

  // ── টাইমলাইন (বার আকারে) ──
  const timelineBars = history.map(h => `
<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--line)">
  <div style="width:10px;height:10px;border-radius:50%;background:var(--g1);flex-shrink:0"></div>
  <div style="flex:1;min-width:0">
    <p style="font-size:12px;font-weight:600;color:var(--ink)">
      ${_fmt(h.periodStart)} — ${_fmt(h.periodEnd)}
      ${h.wasOverdue ? `<span style="color:#dc2626;font-weight:700"> (${h.monthsOverdueAtPayment} মাস বকেয়া সহ পরিশোধ)</span>` : ''}
    </p>
    <p style="font-size:11px;color:var(--ink3)">${PLAN_LABEL[h.plan]||h.plan} · ${h.monthsCovered} মাস কভার${h.txnId?` · TxnID: ${_e(h.txnId)}`:''}</p>
  </div>
  <div style="font-weight:700;color:var(--g1);font-family:var(--mono);white-space:nowrap">৳${h.amount}</div>
</div>`).join('');

  const dueBar = dueInfo.isExpired ? `
<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--line)">
  <div style="width:10px;height:10px;border-radius:50%;background:#dc2626;flex-shrink:0"></div>
  <div style="flex:1;min-width:0">
    <p style="font-size:12px;font-weight:600;color:#dc2626">
      ${_fmt(currentExpiry)} থেকে এখন পর্যন্ত — বকেয়া (${dueInfo.monthsOverdue} মাস)
    </p>
    <p style="font-size:11px;color:var(--ink3)">এখনো পরিশোধ হয়নি</p>
  </div>
  <div style="font-weight:700;color:#dc2626;font-family:var(--mono);white-space:nowrap">৳${dueInfo.dueAmount}</div>
</div>` : '';

  const calendarSection = `
<div class="card" style="margin-bottom:16px">
  <div class="ch"><h3>📆 ক্যালেন্ডার ভিউ</h3></div>
  <div class="cb">${renderCalendarStrip(tl)}</div>
</div>`;

  const timelineSection = (history.length || dueInfo.isExpired) ? `
<div class="card">
  <div class="ch"><h3>📅 টাইমলাইন</h3></div>
  <div class="cb" style="padding:6px 16px">
    ${timelineBars}
    ${dueBar}
  </div>
</div>` : `
<div class="card"><div class="cb" style="padding:20px;text-align:center;color:var(--ink3);font-size:13px">
  এখনো কোনো পেমেন্ট ইতিহাস নেই
</div></div>`;

  return statusCard + calendarSection + timelineSection;
}

function _fmt(d) {
  if (!d) return '—';
  return `${d.getDate()} ${moName(d.getMonth())} ${d.getFullYear()}`;
}


// admin-messes.js — fixed: mess delete cascade

import { db } from '../../firebase.js';
import { toast, ld, uld, formatDate } from '../../utils.js';
import {
  collection, getDocs, doc, updateDoc, deleteDoc,
  query, orderBy, writeBatch
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _all=[], _tab='all';

export async function render(root) {
  root.innerHTML = `
<div>
  <div class="adp-hd">
    <div><h2 class="adp-h">সব মেস</h2><p class="adp-sub" id="mc">লোড হচ্ছে…</p></div>
    <button class="btn btn-ghost btn-sm" id="m-refresh">🔄 রিফ্রেশ</button>
  </div>
  <div class="adm-tabs">
    <button class="adm-tab active" data-tab="all">সব</button>
    <button class="adm-tab" data-tab="active">সক্রিয়</button>
    <button class="adm-tab" data-tab="deactive">নিষ্ক্রিয়</button>
  </div>
  <div id="mess-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px"></div>
</div>
<style>
.mc2{background:#fff;border:1px solid var(--line);border-radius:12px;box-shadow:var(--sh);overflow:hidden}
.mc2-hd{padding:12px 14px;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:10px}
.mc2-ic{width:38px;height:38px;background:var(--g7);border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}
.mc2-hd h3{font-size:13px;font-weight:700;color:var(--ink);margin:0;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mc2-hd p{font-size:11px;color:var(--ink3);margin:2px 0 0}
.mc2-bd{padding:12px 14px}
</style>`;

  root.querySelector('#m-refresh').addEventListener('click', () => _load(root));
  root.querySelector('.adm-tabs').addEventListener('click', e => {
    const b = e.target.closest('[data-tab]');
    if (!b) return;
    _tab = b.dataset.tab;
    root.querySelectorAll('.adm-tab').forEach(x => x.classList.toggle('active', x.dataset.tab===_tab));
    _render(root);
  });
  root.querySelector('#mess-grid').addEventListener('click', e => {
    const tog = e.target.closest('[data-toggle]');
    const del = e.target.closest('[data-delete]');
    if (tog) _toggle(root, tog.dataset.toggle, tog.dataset.status);
    if (del) _delete(root, del.dataset.delete, del.dataset.name);
  });

  await _load(root);
}

async function _load(root) {
  ld('মেস লোড হচ্ছে…');
  try {
    const snap = await getDocs(query(collection(db,'messes'), orderBy('createdAt','desc')));
    _all = snap.docs.map(d => ({ id:d.id, ...d.data() }));
    root.querySelector('#mc').textContent = `মোট ${_all.length}টি মেস`;
    _render(root);
  } catch(err) {
    root.querySelector('#mess-grid').innerHTML =
      `<div class="adm-loading" style="grid-column:1/-1">⚠️ ${err.message}</div>`;
  } finally { uld(); }
}

function _render(root) {
  const grid = root.querySelector('#mess-grid');
  if (!grid) return;
  const filtered = _tab==='all' ? _all : _all.filter(m => m.status===_tab);
  if (!filtered.length) {
    grid.innerHTML = '<div class="adm-loading" style="grid-column:1/-1">কোনো মেস নেই</div>';
    return;
  }
  grid.innerHTML = filtered.map(m => `
<div class="mc2">
  <div class="mc2-hd">
    <div class="mc2-ic">🏠</div>
    <div style="flex:1;min-width:0">
      <h3>${_e(m.name||'অজানা')}</h3>
      <p>${_e(m.address||'—')}</p>
    </div>
    <span class="badge ${m.status==='active'?'b-green':'b-red'}" style="flex-shrink:0;font-size:9px">
      ${m.status==='active'?'● সক্রিয়':'○ নিষ্ক্রিয়'}
    </span>
  </div>
  <div class="mc2-bd">
    <p style="font-size:11px;color:var(--ink3);margin-bottom:4px">
      👤 ${m.createdBy ? m.createdBy.slice(0,8)+'…' : '—'}
    </p>
    <p style="font-size:11px;color:var(--ink3);margin-bottom:10px">
      📅 ${m.createdAt ? formatDate(m.createdAt) : '—'}
    </p>
    <div style="display:flex;gap:6px;flex-wrap:wrap">
      <button class="btn btn-sm ${m.status==='active'?'btn-amber':'btn-ghost'}"
        data-toggle="${m.id}" data-status="${m.status}">
        ${m.status==='active'?'⏸ নিষ্ক্রিয়':'▶ সক্রিয়'}
      </button>
      <button class="btn btn-sm btn-danger"
        data-delete="${m.id}" data-name="${_e(m.name||'')}">
        🗑 মুছুন
      </button>
    </div>
  </div>
</div>`).join('');
}

async function _toggle(root, id, cur) {
  const next = cur==='active' ? 'deactive' : 'active';
  try {
    await updateDoc(doc(db,'messes',id), { status: next });
    const m = _all.find(x => x.id===id);
    if (m) m.status = next;
    _render(root);
    toast(`মেস ${next==='active'?'সক্রিয়':'নিষ্ক্রিয়'} হয়েছে`, 'ok');
  } catch(err) { toast('ব্যর্থ: '+err.message, 'er'); }
}

async function _delete(root, id, name) {
  if (!window.confirm(`"${name}" মেস সম্পূর্ণ মুছে ফেলবেন?\n\nসদস্যরা pending অবস্থায় চলে যাবে।`)) return;

  ld('মেস মুছে ফেলা হচ্ছে…');
  try {
    // ✅ FIXED: Cascade delete — members এর currentMessId clear করো
    const membersSnap = await getDocs(collection(db,'messes',id,'members'));

    const batch = writeBatch(db);

    // প্রতিটি member এর currentMessId null করো
    for (const memberDoc of membersSnap.docs) {
      const uid = memberDoc.id;
      batch.update(doc(db,'users',uid), {
        currentMessId: null,
        status: 'pending'
      });
    }

    // Mess doc delete
    batch.delete(doc(db,'messes',id));

    await batch.commit();

    _all = _all.filter(m => m.id!==id);
    root.querySelector('#mc').textContent = `মোট ${_all.length}টি মেস`;
    _render(root);
    toast('মেস মুছে ফেলা হয়েছে এবং সদস্যরা pending হয়েছে', 'ok');
  } catch(err) {
    toast('মুছতে ব্যর্থ: '+err.message, 'er');
  } finally { uld(); }
}

const _e = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

import { db } from '../../firebase.js';
import { currentProfile } from '../../auth.js';
import { toast, ld, uld, formatDate } from '../../utils.js';
import {
  collection, getDocs, doc, updateDoc, setDoc,
  query, orderBy, serverTimestamp, writeBatch
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _allReqs=[], _curTab='pending', _rejectId=null;

export async function render(root) {
  root.innerHTML = `
<div>
  <div class="adp-hd">
    <div>
      <h2 class="adp-h">মেস তৈরির অনুরোধ</h2>
      <p class="adp-sub" id="req-count">লোড হচ্ছে…</p>
    </div>
    <button class="btn btn-ghost btn-sm" id="req-refresh-btn">🔄 রিফ্রেশ</button>
  </div>
  <div class="adm-tabs">
    <button class="adm-tab active" data-tab="pending">অপেক্ষামাণ</button>
    <button class="adm-tab" data-tab="approved">অনুমোদিত</button>
    <button class="adm-tab" data-tab="rejected">বাতিল</button>
    <button class="adm-tab" data-tab="all">সব</button>
  </div>
  <div id="req-list" style="display:flex;flex-direction:column;gap:10px">
    <div class="adm-loading">লোড হচ্ছে…</div>
  </div>
</div>

<!-- Reject modal -->
<div id="reject-mo" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);
  z-index:300;align-items:center;justify-content:center;padding:20px">
  <div style="background:#fff;border-radius:14px;padding:22px;width:100%;max-width:400px">
    <h3 style="font-size:15px;font-weight:700;margin-bottom:10px">❌ অনুরোধ বাতিল</h3>
    <p style="font-size:12px;color:var(--ink3);margin-bottom:12px">কারণ লিখুন (ঐচ্ছিক):</p>
    <textarea id="reject-note" rows="3"
      style="width:100%;border:1.5px solid var(--line2);border-radius:8px;
        padding:9px 11px;font-size:13px;resize:vertical;outline:none"
      placeholder="বাতিলের কারণ…"></textarea>
    <div style="display:flex;gap:8px;margin-top:12px">
      <button class="btn btn-ghost btn-sm" id="reject-close-btn">বাতিল</button>
      <button class="btn btn-danger btn-sm" id="reject-confirm-btn">✗ বাতিল করুন</button>
    </div>
  </div>
</div>

<style>
.req-card{background:#fff;border:1px solid var(--line);border-radius:12px;
  box-shadow:var(--sh);padding:14px 16px;margin-bottom:8px}
.req-card-hd{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:10px}
.req-card-hd h3{font-size:14px;font-weight:700;color:var(--ink);margin:0}
.req-card-hd p{font-size:11px;color:var(--ink3);margin:3px 0 0}
.req-info{font-size:12px;color:var(--ink3);margin-bottom:12px;line-height:1.8}
.req-note{background:var(--a4);border:1px solid var(--a3);border-radius:8px;
  padding:8px 11px;font-size:12px;color:var(--a0);margin-top:10px}
</style>`;

  // Event listeners
  root.querySelector('#req-refresh-btn').addEventListener('click', _load);
  root.querySelector('.adm-tabs').addEventListener('click', e => {
    const btn = e.target.closest('[data-tab]');
    if (!btn) return;
    _curTab = btn.dataset.tab;
    root.querySelectorAll('.adm-tab').forEach(b => b.classList.toggle('active', b.dataset.tab===_curTab));
    _render();
  });
  root.querySelector('#reject-close-btn').addEventListener('click', _closeReject);
  root.querySelector('#reject-confirm-btn').addEventListener('click', () => _reject(_rejectId));

  // Delegate approve/reject buttons in list
  root.querySelector('#req-list').addEventListener('click', e => {
    const apBtn = e.target.closest('[data-approve]');
    const rjBtn = e.target.closest('[data-reject]');
    if (apBtn) _approve(apBtn.dataset.approve);
    if (rjBtn) { _rejectId = rjBtn.dataset.reject; document.getElementById('reject-mo').style.display='flex'; }
  });

  await _load();
}

async function _load() {
  try {
    const snap = await getDocs(query(collection(db,'messRequests'), orderBy('createdAt','desc')));
    _allReqs = snap.docs.map(d=>({id:d.id,...d.data()}));
    const pending = _allReqs.filter(r=>r.status==='pending').length;
    document.getElementById('req-count').textContent = `${pending}টি অপেক্ষামাণ`;
    _render();
  } catch (err) {
    document.getElementById('req-list').innerHTML = `<div class="adm-loading">⚠️ ${err.message}</div>`;
  }
}

function _render() {
  const list = document.getElementById('req-list');
  if (!list) return;
  const filtered = _curTab==='all' ? _allReqs : _allReqs.filter(r=>r.status===_curTab);
  if (!filtered.length) { list.innerHTML='<div class="adm-loading">কোনো অনুরোধ নেই</div>'; return; }

  const badge = {
    pending:  '<span class="badge b-amber">⏳ অপেক্ষামাণ</span>',
    approved: '<span class="badge b-green">✅ অনুমোদিত</span>',
    rejected: '<span class="badge b-red">❌ বাতিল</span>',
  };

  list.innerHTML = filtered.map(r=>`
<div class="req-card">
  <div class="req-card-hd">
    <div>
      <h3>🏠 ${_e(r.messName)}</h3>
      <p>${_e(r.requesterName)} · ${_e(r.requesterEmail)}</p>
    </div>
    ${badge[r.status]||''}
  </div>
  <div class="req-info">
    ${r.address?`<div>📍 ${_e(r.address)}</div>`:''}
    ${r.description?`<div>📝 ${_e(r.description)}</div>`:''}
    <div>📅 ${r.createdAt?formatDate(r.createdAt):'—'}</div>
  </div>
  ${r.reviewNote?`<div class="req-note">💬 ${_e(r.reviewNote)}</div>`:''}
  ${r.status==='pending'?`
  <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
    <button class="btn btn-sm btn-p" data-approve="${r.id}">✓ অনুমোদন</button>
    <button class="btn btn-sm btn-danger" data-reject="${r.id}">✗ বাতিল</button>
  </div>`:''}
</div>`).join('');
}

async function _approve(reqId) {
  const req = _allReqs.find(r=>r.id===reqId);
  if (!req) return;
  ld('মেস তৈরি হচ্ছে…');
  try {
    const batch   = writeBatch(db);
    const messRef = doc(collection(db,'messes'));

    batch.set(messRef, {
      name:      req.messName,
      address:   req.address||'',
      status:    'active',
      createdAt: serverTimestamp(),
      createdBy: req.requestedBy,
    });
    batch.set(doc(db,'messes',messRef.id,'settings','main'), {
      slots:['সকাল','দুপুর','রাত'], cutoffHour:10, maxMealsPerDay:3,
      rentEnabled:false, rentGas:0, rentElectric:0, rentWater:0, rentBua:0, lang:'bn',
    });
    batch.set(doc(db,'messes',messRef.id,'members',req.requestedBy), {
      name:req.requesterName, email:req.requesterEmail, avatar:null,
      role:'mess-admin', joinedAt:serverTimestamp(),
    });
    batch.update(doc(db,'users',req.requestedBy), {
      currentMessId: messRef.id, status:'active',
    });
    batch.update(doc(db,'messRequests',reqId), {
      status:'approved', reviewedBy: currentProfile?.uid||'', reviewNote:'',
    });

    await batch.commit();
    req.status = 'approved';
    _render();
    toast('মেস তৈরি ও অনুমোদন হয়েছে!','ok');
  } catch (err) {
    console.error('Approve error:', err);
    toast('অনুমোদন ব্যর্থ: ' + err.message,'er');
  } finally { uld(); }
}

async function _reject(reqId) {
  if (!reqId) return;
  const note = document.getElementById('reject-note')?.value.trim()||'';
  const req  = _allReqs.find(r=>r.id===reqId);
  if (!req) return;
  try {
    await updateDoc(doc(db,'messRequests',reqId), {
      status:'rejected', reviewedBy:currentProfile?.uid||'', reviewNote:note,
    });
    req.status='rejected'; req.reviewNote=note;
    _render();
    toast('অনুরোধ বাতিল হয়েছে','ok');
  } catch (err) {
    toast('ব্যর্থ: '+err.message,'er');
  }
  _closeReject();
}

function _closeReject() {
  _rejectId=null;
  document.getElementById('reject-mo').style.display='none';
  document.getElementById('reject-note').value='';
}

const _e = s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

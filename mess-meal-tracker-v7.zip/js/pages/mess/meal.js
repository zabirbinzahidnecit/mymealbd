// meal.js — FIXED setDoc merge, loading text, today's meal summary

import { db } from '../../firebase.js';
import { toast, ld, uld, pad, dim, moName } from '../../utils.js';
import {
  collection, getDocs, doc, getDoc, setDoc, query, orderBy
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _ctx={}, _vy=TODAY.getFullYear(), _vm=TODAY.getMonth(), _members=[];

export async function render(root, ctx) {
  _ctx = ctx;
  const slots = ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const cutoff = ctx.messSettings?.cutoffHour ?? 10;
  const now    = TODAY.getHours();
  const remaining = slots.filter((_,i) => i >= Math.floor(now / (24/slots.length))).length;

  root.innerHTML = `
<div>
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <button class="btn btn-ghost btn-sm" id="mp">◀</button>
    <span style="font-size:14px;font-weight:700;min-width:130px;text-align:center" id="m-lbl"></span>
    <button class="btn btn-ghost btn-sm" id="mn">▶</button>
    <button class="btn btn-ghost btn-sm" id="mt">আজ</button>
    <button class="btn btn-p btn-sm" id="mmd" style="margin-left:auto">📅 একাধিক দিন</button>
  </div>

  <!-- আজকের মিল info banner -->
  <div class="card" style="margin-bottom:14px;background:var(--g7);border-color:var(--g5)">
    <div class="cb" style="padding:12px 14px">
      <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
        <div>
          <p style="font-size:11px;font-weight:700;color:var(--g2);text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">
            আজকের মিল — ${TODAY.getDate()} ${moName(TODAY.getMonth())}
          </p>
          <p style="font-size:13px;color:var(--ink)">
            ${now < cutoff
              ? `⏰ মিল বন্ধ হবে <strong>${cutoff}:00</strong> তে`
              : `🔒 আজকের মিল entry বন্ধ হয়েছে`}
          </p>
        </div>
        <div style="text-align:right">
          <p style="font-size:22px;font-weight:700;color:var(--g1);font-family:var(--mono)"
            id="today-total">—</p>
          <p style="font-size:10px;color:var(--ink3)">আজকের মোট মিল</p>
        </div>
      </div>
      <!-- Today member summary -->
      <div id="today-summary" style="margin-top:10px;display:flex;flex-wrap:wrap;gap:6px"></div>
    </div>
  </div>

  <!-- Entry card -->
  <div class="card" style="margin-bottom:14px">
    <div class="ch">
      <h3>🍚 মিল এন্ট্রি</h3>
      <span style="font-size:11px;color:var(--ink3)">${TODAY.getDate()} ${moName(TODAY.getMonth())} ${TODAY.getFullYear()}</span>
    </div>
    <div class="cb">
      ${ctx.myMessRole !== 'member' ? `
      <div class="field">
        <label class="lbl">সদস্য নির্বাচন করুন</label>
        <select class="inp inp-sm" id="m-sel"></select>
      </div>` : ''}
      <div class="slot-row" id="m-slots"></div>
      <div class="cutoff-notice" id="m-cutoff">⏰ মিল পরিবর্তনের সময় পার হয়েছে</div>
      <div style="margin-top:10px">
        <label class="lbl">Guest মিল (সংখ্যা)</label>
        <div style="display:flex;gap:8px;align-items:center">
          <input class="inp inp-sm" id="m-guest" type="number" min="0" max="20" placeholder="0" style="width:90px"/>
          <button class="btn btn-ghost btn-sm" id="m-guest-save">Guest সেভ</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Day table -->
  <div class="card">
    <div class="ch">
      <h3>📅 দিনের মিল বিস্তারিত</h3>
      <input type="date" id="m-date" class="inp inp-sm" style="width:auto"/>
    </div>
    <div class="cb" style="overflow-x:auto" id="m-table">লোড হচ্ছে…</div>
  </div>
</div>

<div style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:300;
  align-items:center;justify-content:center;padding:20px" id="md-mo">
  <div style="background:#fff;border-radius:16px;padding:22px;max-width:480px;
    width:100%;max-height:90vh;overflow-y:auto">
    <h3 style="font-size:15px;font-weight:700;margin-bottom:12px">📅 একাধিক দিনের মিল</h3>
    <div id="md-content"></div>
    <div style="display:flex;gap:8px;margin-top:14px">
      <button class="btn btn-ghost" id="md-close">বাতিল</button>
      <button class="btn btn-p" id="md-apply">✓ প্রয়োগ</button>
    </div>
  </div>
</div>`;

  root.querySelector('#mp').addEventListener('click', () => { _vm--; if(_vm<0){_vm=11;_vy--} _load(root); });
  root.querySelector('#mn').addEventListener('click', () => { _vm++; if(_vm>11){_vm=0;_vy++} _load(root); });
  root.querySelector('#mt').addEventListener('click', () => { _vy=TODAY.getFullYear();_vm=TODAY.getMonth(); _load(root); });
  root.querySelector('#mmd').addEventListener('click', () => _openMulti(root));
  root.querySelector('#m-guest-save').addEventListener('click', () => _saveGuest(root));
  root.querySelector('#m-date').addEventListener('change', e => _loadTable(root, e.target.value));
  root.querySelector('#md-close').addEventListener('click', () => { root.querySelector('#md-mo').style.display='none'; });
  root.querySelector('#md-apply').addEventListener('click', () => _applyMulti(root));
  root.querySelector('#m-sel')?.addEventListener('change', e => _renderSlots(root, e.target.value));
  root.querySelector('#m-slots').addEventListener('click', e => {
    const btn = e.target.closest('[data-si]');
    if (btn) _toggle(root, btn.dataset.uid, parseInt(btn.dataset.si));
  });

  const dp = root.querySelector('#m-date');
  if (dp) dp.value = `${TODAY.getFullYear()}-${pad(TODAY.getMonth()+1)}-${pad(TODAY.getDate())}`;

  await _load(root);
}

async function _load(root) {
  root.querySelector('#m-lbl').textContent = `${moName(_vm)} ${_vy}`;
  ld('সদস্যদের মিল লোড হচ্ছে…');
  try {
    const snap = await getDocs(query(collection(db,'messes',_ctx.messId,'members'), orderBy('joinedAt')));
    _members = snap.docs.map(d=>({uid:d.id,...d.data()}));
    const sel = root.querySelector('#m-sel');
    if (sel) {
      sel.innerHTML = _members.map(m=>
        `<option value="${m.uid}">${_e(m.name||m.email)}${m.uid===_ctx.profile.uid?' (আমি)':''}</option>`
      ).join('');
      sel.value = _ctx.profile.uid;
    }
    _renderSlots(root, _ctx.profile.uid);
    const dp = root.querySelector('#m-date');
    if (dp) await _loadTable(root, dp.value);
    await _loadTodaySummary(root);
  } finally { uld(); }
}

async function _loadTodaySummary(root) {
  const slots = _ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const SICO  = ['☀️','🌤','🌙','🍳','🍱'];
  let total = 0;
  const chips = [];

  for (const m of _members) {
    const key  = `${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}_${pad(TODAY.getDate())}_${m.uid}`;
    const snap = await getDoc(doc(db,'messes',_ctx.messId,'meals',key));
    const data = snap.exists() ? snap.data() : {};
    const s    = (data.slots||[]).filter(Boolean).length;
    const g    = (data.guestSlots||[]).filter(Boolean).length;
    const t    = s + g;
    total += t;
    if (t > 0) {
      chips.push(`<span style="display:inline-flex;align-items:center;gap:5px;
        background:#fff;border:1px solid var(--g5);border-radius:20px;
        padding:3px 10px;font-size:11px;color:var(--g1)">
        <strong>${_e(m.name||m.email.split('@')[0])}</strong>
        ${(data.slots||[]).map((on,i)=>on?SICO[i]||'🍽':'').filter(Boolean).join('')}
        ${g>0?`+${g}G`:''}
      </span>`);
    }
  }

  const totalEl = root.querySelector('#today-total');
  if (totalEl) totalEl.textContent = total;
  const sumEl = root.querySelector('#today-summary');
  if (sumEl) sumEl.innerHTML = chips.length
    ? chips.join('')
    : `<p style="font-size:12px;color:var(--ink4)">এখনো কেউ মিল দেয়নি</p>`;
}

function _renderSlots(root, uid) {
  const slots  = _ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const SICO   = ['☀️','🌤','🌙','🍳','🍱'];
  const cutoff = _ctx.messSettings?.cutoffHour ?? 10;
  const isPast = uid===_ctx.profile.uid && TODAY.getHours()>=cutoff
    && !['mess-admin','mess-co-admin'].includes(_ctx.myMessRole);

  root.querySelector('#m-slots').innerHTML = slots.map((s,i)=>
    `<button class="slt${isPast?' locked':''}" data-uid="${uid}" data-si="${i}" id="ms-${uid}-${i}">
      ${SICO[i]||'🍽'} ${_e(s)}
    </button>`).join('');
  root.querySelector('#m-cutoff')?.classList.toggle('show', isPast);

  const key = `${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}_${pad(TODAY.getDate())}_${uid}`;
  getDoc(doc(db,'messes',_ctx.messId,'meals',key)).then(snap=>{
    const s = snap.exists()?(snap.data().slots||[]):[];
    slots.forEach((_,i)=>root.querySelector(`#ms-${uid}-${i}`)?.classList.toggle('on',!!s[i]));
    const gi = root.querySelector('#m-guest');
    if (gi) gi.value = snap.exists()?((snap.data().guestSlots||[]).filter(Boolean).length||''):'';
  });
}

async function _toggle(root, uid, i) {
  const cutoff = _ctx.messSettings?.cutoffHour ?? 10;
  if (uid===_ctx.profile.uid && TODAY.getHours()>=cutoff
    && !['mess-admin','mess-co-admin'].includes(_ctx.myMessRole)) {
    toast('মিল পরিবর্তনের সময় পার হয়েছে','er');
    return;
  }
  const key  = `${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}_${pad(TODAY.getDate())}_${uid}`;
  const ref  = doc(db,'messes',_ctx.messId,'meals',key);
  const snap = await getDoc(ref);
  const slots= snap.exists() ? [...(snap.data().slots||[])] : [];
  slots[i]   = !slots[i];
  const max  = _ctx.messSettings?.maxMealsPerDay ?? 3;
  if (slots.filter(Boolean).length > max) { toast(`সর্বোচ্চ ${max}টি মিল`,'er'); return; }

  // ✅ FIXED setDoc with correct merge option
  await setDoc(ref, { slots, memberId: uid }, { merge: true });
  root.querySelector(`#ms-${uid}-${i}`)?.classList.toggle('on', !!slots[i]);
  await _loadTodaySummary(root);

  const dp = root.querySelector('#m-date');
  if (dp) _loadTable(root, dp.value);
}

async function _saveGuest(root) {
  const n   = parseInt(root.querySelector('#m-guest')?.value)||0;
  const uid = root.querySelector('#m-sel')?.value || _ctx.profile.uid;
  const key = `${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}_${pad(TODAY.getDate())}_${uid}`;
  await setDoc(doc(db,'messes',_ctx.messId,'meals',key),
    { guestSlots: Array(n).fill(true), memberId: uid }, { merge: true });
  toast('Guest মিল সেভ হয়েছে','ok');
  await _loadTodaySummary(root);
}

async function _loadTable(root, dateStr) {
  const wrap = root.querySelector('#m-table');
  if (!wrap||!_members.length) return;
  const [y,m,d] = dateStr.split('-').map(Number);
  const slots = _ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const SICO  = ['☀️','🌤','🌙','🍳','🍱'];

  const snaps = await Promise.all(
    _members.map(mb=>getDoc(doc(db,'messes',_ctx.messId,'meals',`${y}_${pad(m)}_${pad(d)}_${mb.uid}`)))
  );
  const mealMap = {};
  snaps.forEach((s,i)=>{ mealMap[_members[i].uid]=s.exists()?s.data():{}; });

  wrap.innerHTML = `<table class="dt">
<thead><tr>
  <th class="tl">সদস্য</th>
  ${slots.map((s,i)=>`<th>${SICO[i]||''} ${_e(s)}</th>`).join('')}
  <th>Guest</th><th>মোট</th>
</tr></thead><tbody>
${_members.map(mb=>{
  const md=mealMap[mb.uid]||{};
  const s=md.slots||[];
  const g=(md.guestSlots||[]).filter(Boolean).length;
  const t=s.filter(Boolean).length+g;
  return `<tr>
  <td class="tl" style="font-weight:600">${_e(mb.name||mb.email)}</td>
  ${slots.map((_,i)=>`<td><div class="mdot ${s[i]?'don':'doff'}">${s[i]?'✓':''}</div></td>`).join('')}
  <td>${g||'—'}</td>
  <td style="font-weight:700">${t||'—'}</td>
</tr>`;
}).join('')}
</tbody></table>`;
}

function _openMulti(root) {
  const slots = _ctx.messSettings?.slots||['সকাল','দুপুর','রাত'];
  const days  = dim(_vy,_vm);
  root.querySelector('#md-content').innerHTML = `
<div style="margin-bottom:10px">
  <label class="lbl">দিন নির্বাচন করুন</label>
  <div style="display:flex;flex-wrap:wrap;gap:5px" id="md-days">
    ${Array.from({length:days},(_,i)=>i+1).map(d=>
      `<button class="btn btn-ghost btn-sm md-day" style="min-width:36px">${d}</button>`
    ).join('')}
  </div>
</div>
<div>
  <label class="lbl">বেলা নির্বাচন করুন</label>
  <div class="slot-row">
    ${slots.map(s=>`<button class="slt md-slot">${_e(s)}</button>`).join('')}
  </div>
</div>`;
  root.querySelectorAll('.md-day').forEach(b=>b.addEventListener('click',()=>b.classList.toggle('active')));
  root.querySelectorAll('.md-slot').forEach(b=>b.addEventListener('click',()=>b.classList.toggle('on')));
  root.querySelector('#md-mo').style.display='flex';
}

async function _applyMulti(root) {
  const days  = [...root.querySelectorAll('.md-day.active')].map(b=>parseInt(b.textContent));
  const slots = [...root.querySelectorAll('.md-slot')].map(b=>b.classList.contains('on'));
  if (!days.length){toast('দিন নির্বাচন করুন','er');return;}
  ld(`${days.length}টি দিনের মিল সেভ হচ্ছে…`);
  for (const d of days) {
    const key = `${_vy}_${pad(_vm+1)}_${pad(d)}_${_ctx.profile.uid}`;
    await setDoc(doc(db,'messes',_ctx.messId,'meals',key),
      { slots, memberId:_ctx.profile.uid }, { merge: true });
  }
  uld();
  toast(`${days.length}টি দিনের মিল সেভ হয়েছে`,'ok');
  root.querySelector('#md-mo').style.display='none';
  await _loadTodaySummary(root);
}

const _e = s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

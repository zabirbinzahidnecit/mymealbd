// home.js — fixed: today meal summary, loading text

import { db } from '../../firebase.js';
import { toast, ld, uld, taka, pad, moName, dim } from '../../utils.js';
import {
  collection, getDocs, doc, getDoc, setDoc,
  query, where
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _ctx={}, _vy=TODAY.getFullYear(), _vm=TODAY.getMonth(), _members=[];

export async function render(root, ctx) {
  _ctx = ctx;
  const slots  = ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const cutoff = ctx.messSettings?.cutoffHour ?? 10;
  const SICO   = ['☀️','🌤','🌙','🍳','🍱'];

  root.innerHTML = `
<div>
  <!-- Month nav -->
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <button class="btn btn-ghost btn-sm" id="h-prev">◀</button>
    <span style="font-size:14px;font-weight:700;min-width:130px;text-align:center" id="h-lbl"></span>
    <button class="btn btn-ghost btn-sm" id="h-next">▶</button>
    <button class="btn btn-ghost btn-sm" id="h-today">আজ</button>
    <button class="btn btn-ghost btn-sm" id="h-ref" style="margin-left:auto">🔄</button>
  </div>

  <!-- Summary cards -->
  <div class="gA" id="h-summary" style="margin-bottom:14px">
    <div class="sc sg"><div class="sl">মোট মিল</div><div class="sv" id="hc-meal">—</div><div class="ss">এই মাসে</div></div>
    <div class="sc sa"><div class="sl">মিলের দাম</div><div class="sv" id="hc-rate">—</div><div class="ss">প্রতি মিল</div></div>
    <div class="sc sb"><div class="sl">মোট বাজার</div><div class="sv" id="hc-bazar">—</div><div class="ss">এই মাসে</div></div>
    <div class="sc sr"><div class="sl">ব্যালেন্স</div><div class="sv" id="hc-bal">—</div><div class="ss">জমা − খরচ</div></div>
  </div>

  <!-- Today meal card -->
  <div class="card" style="margin-bottom:14px">
    <div class="ch">
      <h3>🍚 আজকের মিল — ${TODAY.getDate()} ${moName(TODAY.getMonth())}</h3>
      <span style="font-size:11px;color:${TODAY.getHours()<cutoff?'var(--g1)':'var(--r1)'};font-weight:600">
        ${TODAY.getHours()<cutoff?`⏰ বন্ধ হবে ${cutoff}:00 তে`:'🔒 বন্ধ হয়েছে'}
      </span>
    </div>
    <div class="cb">
      <!-- Slot buttons -->
      <div class="slot-row" id="h-slots">
        ${slots.map((s,i)=>`
        <button class="slt${TODAY.getHours()>=cutoff?' locked':''}" id="hs-${i}" data-si="${i}">
          ${SICO[i]||'🍽'} ${_e(s)}
        </button>`).join('')}
      </div>
      <div class="cutoff-notice${TODAY.getHours()>=cutoff?' show':''}">
        ⏰ মিল পরিবর্তনের সময় পার হয়েছে
      </div>
      <!-- Today member summary -->
      <div style="border-top:1px solid var(--line);margin-top:10px;padding-top:10px">
        <p style="font-size:11px;font-weight:700;color:var(--ink3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px">
          আজকের মিল — সদস্যভিত্তিক
        </p>
        <div id="h-today-list" style="display:flex;flex-wrap:wrap;gap:6px">
          <p style="font-size:12px;color:var(--ink4)">লোড হচ্ছে…</p>
        </div>
      </div>
    </div>
  </div>

  <!-- Notices -->
  <div class="card">
    <div class="ch">
      <h3>📢 সর্বশেষ নোটিশ</h3>
      <button class="btn btn-ghost btn-sm" id="h-notice-all">সব দেখুন</button>
    </div>
    <div class="cb" id="h-notices">লোড হচ্ছে…</div>
  </div>
</div>`;

  root.querySelector('#h-prev').addEventListener('click', ()=>{ _vm--; if(_vm<0){_vm=11;_vy--} _load(root); });
  root.querySelector('#h-next').addEventListener('click', ()=>{ _vm++; if(_vm>11){_vm=0;_vy++} _load(root); });
  root.querySelector('#h-today').addEventListener('click', ()=>{ _vy=TODAY.getFullYear();_vm=TODAY.getMonth(); _load(root); });
  root.querySelector('#h-ref').addEventListener('click', ()=> _load(root));
  root.querySelector('#h-notice-all').addEventListener('click', ()=>
    window.dispatchEvent(new CustomEvent('mm:navigate',{detail:{page:'notice'}}))
  );
  root.querySelector('#h-slots').addEventListener('click', e=>{
    const btn=e.target.closest('[data-si]');
    if(btn) _toggleSlot(root, parseInt(btn.dataset.si));
  });

  await _load(root);
}

async function _load(root) {
  document.getElementById('h-lbl') && (document.getElementById('h-lbl').textContent=`${moName(_vm)} ${_vy}`);
  root.querySelector('#h-lbl') && (root.querySelector('#h-lbl').textContent=`${moName(_vm)} ${_vy}`);

  ld('ড্যাশবোর্ড লোড হচ্ছে…');
  try {
    const monthStr = `${_vy}-${pad(_vm+1)}`;
    const monthPfx = `${_vy}_${pad(_vm+1)}`;

    // Members
    const mSnap = await getDocs(collection(db,'messes',_ctx.messId,'members'));
    _members = mSnap.docs.map(d=>({uid:d.id,...d.data()}));

    // Meals
    const allMeals = await getDocs(collection(db,'messes',_ctx.messId,'meals'));
    let totalMeals = 0;
    allMeals.forEach(d=>{
      if(d.id.startsWith(monthPfx)){
        totalMeals+=(d.data().slots||[]).filter(Boolean).length;
        totalMeals+=(d.data().guestSlots||[]).filter(Boolean).length;
      }
    });

    // Expenses
    const expSnap = await getDocs(query(collection(db,'messes',_ctx.messId,'expenses'),where('status','==','approved')));
    let totalBazar=0;
    expSnap.forEach(d=>{ if(d.data().date?.startsWith(monthStr)) totalBazar+=parseFloat(d.data().amount)||0; });

    // Deposits
    const depSnap = await getDocs(query(collection(db,'messes',_ctx.messId,'deposits'),where('status','==','approved')));
    let totalDep=0;
    depSnap.forEach(d=>{ if(d.data().date?.startsWith(monthStr)) totalDep+=parseFloat(d.data().amount)||0; });

    const rate = totalMeals>0 ? totalBazar/totalMeals : 0;
    const _s = (id,v)=>{ const el=root.querySelector('#'+id); if(el) el.textContent=v; };
    _s('hc-meal', String(totalMeals));
    _s('hc-rate', taka(rate));
    _s('hc-bazar', taka(totalBazar));
    _s('hc-bal', taka(totalDep-totalBazar));

    // Today slots
    const isToday = _vy===TODAY.getFullYear() && _vm===TODAY.getMonth();
    if(isToday) {
      const tk = `${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}_${pad(TODAY.getDate())}_${_ctx.profile.uid}`;
      const ms = await getDoc(doc(db,'messes',_ctx.messId,'meals',tk));
      const mySlots = ms.exists()?(ms.data().slots||[]):[];
      (_ctx.messSettings?.slots||[]).forEach((_,i)=>{
        root.querySelector(`#hs-${i}`)?.classList.toggle('on',!!mySlots[i]);
      });
    }

    // Today summary
    await _loadTodaySummary(root);

    // Notices
    await _loadNotices(root);
  } catch(err) {
    toast('লোড ব্যর্থ','er');
  } finally { uld(); }
}

async function _loadTodaySummary(root) {
  const SICO=['☀️','🌤','🌙','🍳','🍱'];
  const slots=_ctx.messSettings?.slots||['সকাল','দুপুর','রাত'];
  const chips=[];

  for(const m of _members) {
    const key=`${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}_${pad(TODAY.getDate())}_${m.uid}`;
    const snap=await getDoc(doc(db,'messes',_ctx.messId,'meals',key));
    const data=snap.exists()?snap.data():{};
    const s=(data.slots||[]).filter(Boolean).length;
    const g=(data.guestSlots||[]).filter(Boolean).length;
    const t=s+g;
    chips.push(`
<div style="display:flex;align-items:center;gap:6px;background:${t>0?'var(--g7)':'var(--paper)'};
  border:1px solid ${t>0?'var(--g5)':'var(--line)'};border-radius:20px;
  padding:4px 11px;font-size:12px;">
  <span style="font-weight:600;color:${t>0?'var(--g1)':'var(--ink3)'}">${_e(m.name||m.email.split('@')[0])}</span>
  <span style="color:var(--ink3)">${(data.slots||[]).map((on,i)=>on?SICO[i]||'🍽':'').filter(Boolean).join('')||'—'}${g>0?` +${g}G`:''}</span>
  <span style="font-weight:700;color:${t>0?'var(--g1)':'var(--ink4)'}">${t||0}</span>
</div>`);
  }

  const el=root.querySelector('#h-today-list');
  if(el) el.innerHTML=chips.join('')||'<p style="font-size:12px;color:var(--ink4)">এখনো কেউ মিল দেয়নি</p>';
}

async function _loadNotices(root) {
  const el=root.querySelector('#h-notices');
  if(!el) return;
  try {
    const snap=await getDocs(collection(db,'messes',_ctx.messId,'notices'));
    const sorted=snap.docs.sort((a,b)=>(b.data().createdAt?.seconds||0)-(a.data().createdAt?.seconds||0)).slice(0,3);
    if(!sorted.length){el.innerHTML='<p style="font-size:12px;color:var(--ink4)">কোনো নোটিশ নেই</p>';return;}
    el.innerHTML=sorted.map(d=>{
      const n=d.data();
      return `<div style="padding:8px 0;border-bottom:.5px solid var(--line)">
<p style="font-size:13px;color:var(--ink);line-height:1.5">${_e(n.text||'')}</p>
<p style="font-size:10px;color:var(--ink4);margin-top:3px">— ${_e(n.addedByName||'—')}</p>
</div>`;
    }).join('');
  } catch(e){el.innerHTML='<p style="font-size:12px;color:var(--r1)">লোড ব্যর্থ</p>';}
}

async function _toggleSlot(root, i) {
  const cutoff=_ctx.messSettings?.cutoffHour??10;
  if(TODAY.getHours()>=cutoff && !['mess-admin','mess-co-admin'].includes(_ctx.myMessRole)){
    toast('মিল পরিবর্তনের সময় পার হয়েছে','er'); return;
  }
  const key=`${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}_${pad(TODAY.getDate())}_${_ctx.profile.uid}`;
  const ref=doc(db,'messes',_ctx.messId,'meals',key);
  const snap=await getDoc(ref);
  const slots=[...(snap.exists()?(snap.data().slots||[]):[])];
  slots[i]=!slots[i];
  const max=_ctx.messSettings?.maxMealsPerDay??3;
  if(slots.filter(Boolean).length>max){toast(`সর্বোচ্চ ${max}টি মিল`,'er');return;}
  await setDoc(ref,{slots,memberId:_ctx.profile.uid},{merge:true});
  root.querySelector(`#hs-${i}`)?.classList.toggle('on',!!slots[i]);
  await _loadTodaySummary(root);
}

const _e=s=>String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

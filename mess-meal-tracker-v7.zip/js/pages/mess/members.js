// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/pages/mess/members.js
//  Fixed: invite link copy, inviteIndex write, UI improved
// ══════════════════════════════════════════════════════════

import { db } from '../../firebase.js';
import { toast, ld, uld, formatDate, ini, avColor, roleLabel } from '../../utils.js';
import {
  collection, getDocs, addDoc, deleteDoc,
  doc, query, orderBy, setDoc, updateDoc,
  where, writeBatch, serverTimestamp, getDoc
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _ctx = {}, _members = [], _invites = [];

export async function render(root, ctx) {
  _ctx = ctx;
  const isAdmin = ctx.myMessRole === 'mess-admin';

  root.innerHTML = `
<div>
  <div class="ptit">👥 সদস্য ব্যবস্থাপনা</div>
  <div class="psub" id="mem-count">লোড হচ্ছে…</div>

  ${isAdmin ? `
  <!-- Invite Form -->
  <div class="card" style="margin-bottom:14px">
    <div class="ch"><h3>📨 নতুন সদস্য Invite করুন</h3></div>
    <div class="cb">
      <div class="fr" style="align-items:flex-end;gap:8px;flex-wrap:wrap">
        <div class="field" style="flex:2;min-width:200px;margin:0">
          <label class="lbl">Gmail ঠিকানা *</label>
          <input class="inp inp-sm" id="inv-email" type="email" placeholder="example@gmail.com"/>
        </div>
        <div class="field" style="flex:1;min-width:140px;margin:0">
          <label class="lbl">ভূমিকা</label>
          <select class="inp inp-sm" id="inv-role">
            <option value="member">সদস্য</option>
            <option value="mess-co-admin">কো-অ্যাডমিন</option>
          </select>
        </div>
        <button class="btn btn-p btn-sm" id="inv-btn" style="flex-shrink:0;height:32px" onclick="window.__memInvite()">
          📤 Invite তৈরি করুন
        </button>
      </div>
      <p style="font-size:11px;color:var(--ink4);margin-top:8px">
        ⏱ Invite link ৭ দিন valid থাকবে। Link টি সেই ব্যক্তিকে পাঠান।
      </p>
    </div>
  </div>

  <!-- Invite link display -->
  <div id="inv-link-box" class="card" style="margin-bottom:14px;display:none">
    <div class="ch"><h3>🔗 Invite Link</h3></div>
    <div class="cb">
      <p style="font-size:12px;color:var(--ink3);margin-bottom:8px">নিচের link টি কপি করে সদস্যকে পাঠান:</p>
      <div style="display:flex;gap:8px;align-items:center">
        <input class="inp inp-sm" id="inv-link-text" readonly
          style="font-size:11px;font-family:var(--mono);background:#f8fdf8;flex:1"/>
        <button class="btn btn-ghost btn-sm" onclick="window.__memCopyLink()">📋 কপি</button>
      </div>
      <p style="font-size:11px;color:var(--ink4);margin-top:8px">
        এই link এ click করলে সেই ব্যক্তি Google login এর পর automatically মেসে join হবে।
      </p>
    </div>
  </div>

  <!-- Pending Invites -->
  <div class="card" style="margin-bottom:14px">
    <div class="ch">
      <h3>⏳ Pending Invites</h3>
      <button class="btn btn-ghost btn-sm" onclick="window.__memRefreshInvites()">🔄</button>
    </div>
    <div id="inv-list" class="cb">লোড হচ্ছে…</div>
  </div>` : ''}

  <!-- Member List -->
  <div class="card">
    <div class="ch"><h3>👥 সকল সদস্য</h3></div>
    <div id="mem-list">লোড হচ্ছে…</div>
  </div>
</div>

<style>
.mem-row{display:flex;align-items:center;gap:12px;padding:10px 14px;
  border-bottom:.5px solid var(--line)}
.mem-row:last-child{border-bottom:none}
.mem-av{width:40px;height:40px;border-radius:50%;flex-shrink:0;
  display:flex;align-items:center;justify-content:center;
  font-size:15px;font-weight:700;overflow:hidden}
.mem-av img{width:100%;height:100%;object-fit:cover}
.mem-info{flex:1;min-width:0}
.mem-info h3{font-size:13px;font-weight:600;color:var(--ink);margin:0;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mem-info p{font-size:11px;color:var(--ink3);margin:2px 0 0}
.inv-row{display:flex;align-items:center;justify-content:space-between;
  gap:8px;padding:8px 0;border-bottom:.5px solid var(--line);flex-wrap:wrap}
.inv-row:last-child{border-bottom:none}
</style>`;

  window.__memInvite         = () => _invite();
  window.__memCopyLink       = () => _copyLink();
  window.__memRefreshInvites = () => _loadInvites();
  window.__memRemove         = uid => _remove(uid);
  window.__memDeleteInvite   = id => _deleteInvite(id);

  await _load();
  if (isAdmin) await _loadInvites();
}

async function _load() {
  try {
    const snap = await getDocs(query(
      collection(db,'messes',_ctx.messId,'members'), orderBy('joinedAt')
    ));
    _members = snap.docs.map(d => ({ uid: d.id, ...d.data() }));

    const countEl = document.getElementById('mem-count');
    if (countEl) countEl.textContent = `মোট ${_members.length}জন সদস্য`;

    const isAdmin = _ctx.myMessRole === 'mess-admin';
    const list = document.getElementById('mem-list');
    if (!list) return;

    list.innerHTML = _members.map(m => {
      const isMe = m.uid === _ctx.profile.uid;
      const avContent = m.avatar
        ? `<img src="${_esc(m.avatar)}" alt=""/>`
        : `<span>${ini(m.name || m.email)}</span>`;
      const roleBadge = {
        'mess-admin':    '<span class="badge b-admin">🔑 অ্যাডমিন</span>',
        'mess-co-admin': '<span class="badge b-coadmin">🛡 কো-অ্যাডমিন</span>',
        'member':        '<span class="badge b-member">👤 সদস্য</span>',
      }[m.role] || '';

      return `
<div class="mem-row">
  <div class="mem-av ${m.avatar?'':avColor(m.name||m.email)}">${avContent}</div>
  <div class="mem-info">
    <h3>${_esc(m.name||'—')}${isMe?' <span style="font-size:10px;color:var(--ink4)">(আপনি)</span>':''}</h3>
    <p>${_esc(m.email||'—')}</p>
  </div>
  ${roleBadge}
  ${isAdmin && !isMe
    ? `<button class="btn btn-xs btn-danger" onclick="window.__memRemove('${m.uid}')">বের করুন</button>`
    : ''}
</div>`;
    }).join('') || '<div style="padding:20px;text-align:center;color:var(--ink3)">কোনো সদস্য নেই</div>';
  } catch (err) {
    toast('লোড ব্যর্থ: ' + err.message, 'er');
  }
}

async function _loadInvites() {
  const list = document.getElementById('inv-list');
  if (!list) return;
  try {
    const snap = await getDocs(query(
      collection(db,'messes',_ctx.messId,'invites'),
      where('used','==',false)
    ));
    _invites = snap.docs.map(d => ({ id: d.id, ...d.data() }));

    if (!_invites.length) {
      list.innerHTML = '<p style="font-size:12px;color:var(--ink3)">কোনো pending invite নেই</p>';
      return;
    }
    list.innerHTML = _invites.map(inv => {
      const expired = inv.expiresAt?.toDate ? inv.expiresAt.toDate() < new Date() : false;
      return `
<div class="inv-row">
  <div>
    <p style="font-size:13px;font-weight:600;color:var(--ink)">${_esc(inv.email||'—')}</p>
    <p style="font-size:11px;color:var(--ink3)">
      ${_roleLabel(inv.role)}
      · ${expired ? '<span style="color:var(--r1)">মেয়াদ শেষ</span>' : '<span style="color:var(--g1)">সক্রিয়</span>'}
    </p>
  </div>
  <div style="display:flex;gap:6px">
    <button class="btn btn-xs btn-ghost" onclick="window.__memShowInviteLink('${inv.id}','${_esc(inv.email)}')">🔗 Link</button>
    <button class="btn btn-xs btn-danger" onclick="window.__memDeleteInvite('${inv.id}')">বাতিল</button>
  </div>
</div>`;
    }).join('');
  } catch (err) {
    list.innerHTML = '<p style="font-size:12px;color:var(--r1)">লোড ব্যর্থ</p>';
  }
}

// ── Invite তৈরি ───────────────────────────────────────────
async function _invite() {
  const email = document.getElementById('inv-email')?.value.trim().toLowerCase();
  const role  = document.getElementById('inv-role')?.value || 'member';

  if (!email || !email.includes('@')) { toast('সঠিক Gmail দিন', 'er'); return; }
  if (_members.some(m => m.email?.toLowerCase() === email)) {
    toast('এই email ইতিমধ্যে সদস্য', 'er'); return;
  }

  const btn = document.getElementById('inv-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'তৈরি হচ্ছে…'; }

  try {
    const token     = _genToken();
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // ৭ দিন

    // 1. invites sub-collection এ save
    await setDoc(doc(db, 'messes', _ctx.messId, 'invites', token), {
      email, role,
      invitedBy:   _ctx.profile.uid,
      invitedByName: _ctx.profile.name || '',
      messId:      _ctx.messId,
      messName:    _ctx.messData?.name || '',
      createdAt:   serverTimestamp(),
      expiresAt,
      used:        false
    });

    // 2. inviteIndex — email → token lookup (login এ ব্যবহার হয়)
    // NOTE: Firestore rules এ inviteIndex collection এ write দিতে হবে
    try {
      const idxKey = email.replace(/\./g, '_').replace(/@/g, '_at_');
      await setDoc(doc(db, 'inviteIndex', idxKey), {
        messId:  _ctx.messId,
        token,
        role,
        email,
        expiresAt
      });
    } catch (idxErr) {
      // inviteIndex write fail হলেও invite তৈরি হবে
      // login এ redirect link দিয়ে join হবে
      console.warn('inviteIndex write failed (check Firestore rules):', idxErr.code);
    }

    // 3. Invite link তৈরি — GitHub Pages URL
    const baseUrl = window.location.origin + window.location.pathname.replace(/\/[^/]*$/, '/');
    const inviteUrl = `${baseUrl}?invite=${token}&mess=${_ctx.messId}`;

    // Link box দেখাও
    const box = document.getElementById('inv-link-box');
    const inp = document.getElementById('inv-link-text');
    if (box && inp) {
      inp.value = inviteUrl;
      box.style.display = 'block';
      box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    document.getElementById('inv-email').value = '';
    toast('Invite তৈরি হয়েছে! Link কপি করে পাঠান।', 'ok');
    await _loadInvites();
  } catch (err) {
    toast('Invite ব্যর্থ: ' + err.message, 'er');
    console.error('Invite error:', err);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '📤 Invite তৈরি করুন'; }
  }
}

function _copyLink() {
  const inp = document.getElementById('inv-link-text');
  if (!inp?.value) return;
  navigator.clipboard?.writeText(inp.value)
    .then(() => toast('Link কপি হয়েছে! ✓', 'ok'))
    .catch(() => {
      inp.select();
      document.execCommand('copy');
      toast('Link কপি হয়েছে! ✓', 'ok');
    });
}

// Existing invite এর link দেখাও
window.__memShowInviteLink = (token, email) => {
  const baseUrl   = window.location.origin + window.location.pathname.replace(/\/[^/]*$/, '/');
  const inviteUrl = `${baseUrl}?invite=${token}&mess=${_ctx.messId}`;
  const box = document.getElementById('inv-link-box');
  const inp = document.getElementById('inv-link-text');
  if (box && inp) {
    inp.value = inviteUrl;
    box.style.display = 'block';
    box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
};

async function _remove(uid) {
  const m = _members.find(x => x.uid === uid);
  if (!window.confirm(`"${m?.name || uid}" কে মেস থেকে বের করবেন?`)) return;
  ld('সরানো হচ্ছে…');
  try {
    const batch = writeBatch(db);
    batch.delete(doc(db,'messes',_ctx.messId,'members',uid));
    batch.update(doc(db,'users',uid), { currentMessId: null, status: 'pending' });
    await batch.commit();
    toast('সদস্য সরানো হয়েছে', 'ok');
    await _load();
  } catch (err) {
    toast('সরাতে ব্যর্থ: ' + err.message, 'er');
  } finally { uld(); }
}

async function _deleteInvite(inviteId) {
  try {
    const inv = _invites.find(i => i.id === inviteId);
    const batch = writeBatch(db);
    batch.delete(doc(db,'messes',_ctx.messId,'invites',inviteId));
    if (inv?.email) {
      const idxKey = inv.email.replace(/\./g,'_').replace(/@/g,'_at_');
      try { batch.delete(doc(db,'inviteIndex',idxKey)); } catch(e) {}
    }
    await batch.commit();
    toast('Invite বাতিল হয়েছে', 'ok');
    await _loadInvites();
    // link box hide
    const box = document.getElementById('inv-link-box');
    if (box) box.style.display = 'none';
  } catch (err) {
    toast('বাতিল ব্যর্থ: ' + err.message, 'er');
  }
}

function _genToken() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return Date.now().toString(36) + Math.random().toString(36).slice(2);
}

function _roleLabel(r) {
  return { 'member':'সদস্য', 'mess-co-admin':'কো-অ্যাডমিন', 'mess-admin':'অ্যাডমিন' }[r] || r;
}

const _esc = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

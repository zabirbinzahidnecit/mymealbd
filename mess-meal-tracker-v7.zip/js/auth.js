// ══════════════════════════════════════════════════════════
//  মেস মিল ট্র্যাকার — js/auth.js  (final)
// ══════════════════════════════════════════════════════════

import { auth, db, googleProvider } from './firebase.js';
import { toast, ld, uld } from './utils.js';
import {
  signInWithPopup, signInWithRedirect, getRedirectResult,
  signOut, onAuthStateChanged
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import {
  doc, getDoc, setDoc, updateDoc, serverTimestamp, writeBatch
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';
import { renderRouter } from './router.js';
import { processPendingInvite } from './invite-handler.js';

export let currentUser    = null;
export let currentProfile = null;

// ── Google Sign-In ────────────────────────────────────────
export async function startAuth() {
  const btn = document.getElementById('btn-login');
  if (btn) btn.disabled = true;
  ld('লগইন হচ্ছে…');
  try {
    await signInWithPopup(auth, googleProvider);
  } catch (err) {
    const code = err.code || '';
    if (code === 'auth/popup-blocked') {
      toast('Popup block — redirect এ যাচ্ছে…', 'info');
      try { await signInWithRedirect(auth, googleProvider); return; } catch(e2) {}
    }
    uld();
    if (btn) btn.disabled = false;
    if (code !== 'auth/popup-closed-by-user' && code !== 'auth/cancelled-popup-request') {
      toast('লগইন ব্যর্থ: ' + (err.message || code), 'er');
    }
  }
}

// ── Handle redirect result ────────────────────────────────
export async function handleRedirectResult() {
  try {
    await getRedirectResult(auth);
  } catch (err) {
    if (err.code && err.code !== 'auth/no-auth-event') {
      console.warn('[Auth] Redirect error:', err.code);
    }
  }
}

// ── Logout ───────────────────────────────────────────────
export async function logout() {
  try {
    currentUser = null; currentProfile = null;
    await signOut(auth);
  } catch (err) {
    toast('লগআউট ব্যর্থ', 'er');
  }
}

// ── Ensure user doc ───────────────────────────────────────
async function ensureUserDoc(firebaseUser) {
  const ref  = doc(db, 'users', firebaseUser.uid);
  const snap = await getDoc(ref);
  if (!snap.exists()) {
    await setDoc(ref, {
      email: firebaseUser.email,
      name:  firebaseUser.displayName || firebaseUser.email.split('@')[0],
      avatar: firebaseUser.photoURL || null,
      status: 'pending', platformRole: null, currentMessId: null,
      createdAt: serverTimestamp()
    });
    return (await getDoc(ref)).data();
  }
  const data = snap.data();
  const upd  = {};
  if (firebaseUser.photoURL && data.avatar !== firebaseUser.photoURL)
    upd.avatar = firebaseUser.photoURL;
  if (Object.keys(upd).length) await updateDoc(ref, upd);
  return { ...data, ...upd };
}

// ── inviteIndex দিয়ে invite check ────────────────────────
async function checkInviteByEmail(firebaseUser) {
  const email = firebaseUser.email?.toLowerCase();
  if (!email) return false;
  try {
    const idxKey  = email.replace(/\./g,'_').replace(/@/g,'_at_');
    const idxRef  = doc(db, 'inviteIndex', idxKey);
    const idxSnap = await getDoc(idxRef);
    if (!idxSnap.exists()) return false;

    const { messId, token, role } = idxSnap.data();
    const tokenRef  = doc(db, 'messes', messId, 'invites', token);
    const tokenSnap = await getDoc(tokenRef);
    if (!tokenSnap.exists()) return false;

    const inv = tokenSnap.data();
    if (inv.used || (inv.expiresAt?.toDate?.() ?? new Date(inv.expiresAt)) < new Date()) return false;

    const batch = writeBatch(db);
    batch.set(doc(db,'messes',messId,'members',firebaseUser.uid), {
      name: firebaseUser.displayName||email, email,
      avatar: firebaseUser.photoURL||null, role, joinedAt: serverTimestamp()
    });
    batch.update(doc(db,'users',firebaseUser.uid), { status:'active', currentMessId: messId });
    batch.update(tokenRef, { used: true, usedBy: firebaseUser.uid, usedAt: serverTimestamp() });
    batch.delete(idxRef);
    await batch.commit();
    toast('মেসে যোগ হয়েছে! স্বাগতম 🎉', 'ok');
    return true;
  } catch (e) {
    console.warn('Email invite check error:', e.code);
    return false;
  }
}

// ── Auth State Listener ───────────────────────────────────
let _processing = false;

export function initAuth() {
  handleRedirectResult();

  onAuthStateChanged(auth, async (firebaseUser) => {
    if (_processing) return;
    _processing = true;

    if (!firebaseUser) {
      currentUser = null; currentProfile = null;
      uld(); _processing = false;
      renderRouter(null, null);
      return;
    }

    ld('প্রোফাইল লোড হচ্ছে…');

    try {
      currentUser = firebaseUser;
      let profile = await ensureUserDoc(firebaseUser);

      if (!profile.currentMessId) {
        // 1. URL invite link (localStorage এ)
        const joinedViaLink = await processPendingInvite(firebaseUser);
        if (joinedViaLink) {
          const s = await getDoc(doc(db,'users',firebaseUser.uid));
          profile = s.data();
        } else {
          // 2. inviteIndex দিয়ে email-based invite
          const joinedViaEmail = await checkInviteByEmail(firebaseUser);
          if (joinedViaEmail) {
            const s = await getDoc(doc(db,'users',firebaseUser.uid));
            profile = s.data();
          }
        }
      }

      currentProfile = { uid: firebaseUser.uid, ...profile };
      uld(); _processing = false;
      renderRouter(currentUser, currentProfile);

    } catch (err) {
      console.error('Auth state error:', err);
      uld(); _processing = false;
      toast('প্রোফাইল লোড ব্যর্থ', 'er');
      renderRouter(firebaseUser, null);
    }
  });
}

export const isPlatformAdmin   = () => currentProfile?.platformRole === 'admin';
export const isPlatformCoAdmin = () => ['admin','co-admin'].includes(currentProfile?.platformRole);
export const hasMessAccess     = () => !!currentProfile?.currentMessId;

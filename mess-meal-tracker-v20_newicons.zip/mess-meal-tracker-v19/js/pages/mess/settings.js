// settings.js — v12 fixed: App Update card in admin view, non-admin view clean

import { db } from '../../firebase.js';
import { toast, escapeHtml as _e } from '../../utils.js';
import {
  doc, updateDoc, setDoc, getDoc, deleteDoc, serverTimestamp,
  Timestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _ctx={}, _settings={};

export async function render(root, ctx) {
  _ctx     = ctx;
  _settings = { ...ctx.messSettings };

  if (ctx.myMessRole !== 'mess-admin') {
    // Non-admin: শুধু App Update দেখাবে
    root.innerHTML = `
<div>
  <h2 style="font-size:17px;font-weight:700;color:var(--ink);margin-bottom:14px">⚙️ সেটিংস</h2>
  <div class="card" style="margin-bottom:14px">
    <div class="cb" style="text-align:center;padding:20px;color:var(--ink3)">
      <div style="font-size:32px;margin-bottom:8px">🔒</div>
      <p>Settings শুধুমাত্র Mess Admin পরিবর্তন করতে পারবেন।</p>
    </div>
  </div>
  ${_updateCardHTML()}
</div>`;
    _attachUpdateListeners(root);
    return;
  }

  _renderAll(root, ctx);
}

function _updateCardHTML() {
  return `
<div class="card" style="border-color:var(--b3)">
  <div class="ch"><h3 style="color:var(--b0)">🔄 অ্যাপ আপডেট</h3></div>
  <div class="cb">
    <p style="font-size:12px;color:var(--ink3);margin-bottom:12px;line-height:1.6">
      নতুন আপডেট থাকলে cache মুছে fresh ডাউনলোড হবে।
      App install করা থাকলেও কাজ করবে।
    </p>
    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:8px">
      <button class="btn btn-sm" id="btn-check-update"
        style="background:var(--b0);color:#fff;border-color:var(--b0)">
        🔍 আপডেট চেক করুন
      </button>
      <button class="btn btn-ghost btn-sm" id="btn-force-update">
        ⚡ Force Reload
      </button>
    </div>
    <div id="update-status" style="font-size:11px;color:var(--ink3)"></div>
  </div>
</div>`;
}

function _attachUpdateListeners(root) {
  root.querySelector('#btn-check-update')?.addEventListener('click', () => _checkUpdate(root));
  root.querySelector('#btn-force-update')?.addEventListener('click', () => _forceUpdate(root));
}

function _renderAll(root, ctx) {
  root.innerHTML = `
<div>
  <h2 style="font-size:17px;font-weight:700;color:var(--ink);margin-bottom:14px">⚙️ সেটিংস</h2>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:13px">

    <!-- Mess info -->
    <div class="card">
      <div class="ch"><h3>🏠 মেসের তথ্য</h3></div>
      <div class="cb">
        <div class="field"><label class="lbl">মেসের নাম</label>
          <input class="inp inp-sm" id="set-name" value="${_e(ctx.messData?.name||'')}"/></div>
        <div class="field"><label class="lbl">ঠিকানা</label>
          <input class="inp inp-sm" id="set-addr" value="${_e(ctx.messData?.address||'')}"/></div>
        <button class="btn btn-p btn-sm" id="btn-save-name">✓ সংরক্ষণ</button>
        <div id="name-msg" style="font-size:11px;margin-top:6px"></div>
      </div>
    </div>

    <!-- Join Code -->
    <div class="card">
      <div class="ch"><h3>🔑 মেস জয়েন কোড</h3></div>
      <div class="cb">
        <p style="font-size:12px;color:var(--ink3);margin-bottom:12px;line-height:1.6">
          এই ৬-সংখ্যার কোড দিয়ে নতুন সদস্য সরাসরি মেসে join করতে পারবে।
          কোড শেয়ার করুন — invite link এর বিকল্প সহজ উপায়।
        </p>
        <div id="join-code-display" style="margin-bottom:12px"></div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn btn-p btn-sm" id="btn-gen-code">🔄 নতুন কোড তৈরি করুন</button>
          <button class="btn btn-danger btn-sm" id="btn-revoke-code" style="display:none">🚫 কোড বাতিল করুন</button>
        </div>
      </div>
    </div>

    <!-- Slots -->
    <div class="card">
      <div class="ch"><h3>🍽 খাবারের বেলা</h3></div>
      <div class="cb">
        <p style="font-size:11px;color:var(--ink3);margin-bottom:10px">সর্বোচ্চ ৫টি বেলা</p>
        <div id="slot-list" style="display:flex;flex-direction:column;gap:6px;margin-bottom:10px"></div>
        <button class="btn btn-ghost btn-sm" style="width:100%" id="btn-add-slot">+ নতুন বেলা</button>
        <hr style="margin:12px 0;border-color:var(--line)"/>
        <div class="field"><label class="lbl">মিল বন্ধের সময় (ঘণ্টা ০-২৩)</label>
          <input class="inp inp-sm" id="set-cutoff" type="number" min="0" max="23"
            value="${_settings.cutoffHour??10}"/></div>
        <div class="field"><label class="lbl">দিনে সর্বোচ্চ মিল</label>
          <input class="inp inp-sm" id="set-maxmeals" type="number" min="1" max="10"
            value="${_settings.maxMealsPerDay??3}"/></div>
        <hr style="margin:12px 0;border-color:var(--line)"/>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0">
          <div>
            <p style="font-size:13px;font-weight:600;color:var(--ink);margin:0">💰 বাজারে Auto-Deposit</p>
            <p style="font-size:11px;color:var(--ink3);margin:3px 0 0">
              চালু থাকলে যে বাজার করবে তার নামে স্বয়ংক্রিয়ভাবে ডিপোজিট যোগ হবে
            </p>
          </div>
          <label style="display:flex;align-items:center;gap:6px;cursor:pointer;flex-shrink:0;margin-left:12px">
            <input type="checkbox" id="set-auto-dep"
              style="accent-color:var(--g2);width:18px;height:18px"
              ${_settings.autoDeposit!==false?'checked':''}/>
            <span id="auto-dep-lbl" style="font-size:12px;font-weight:700;color:var(--g1)">
              ${_settings.autoDeposit!==false?'চালু':'বন্ধ'}
            </span>
          </label>
        </div>
        <button class="btn btn-p btn-sm" id="btn-save-slots">✓ সংরক্ষণ</button>
        <div id="slot-msg" style="font-size:11px;margin-top:6px"></div>
      </div>
    </div>

    <!-- Rent -->
    <div class="card">
      <div class="ch"><h3>🏡 বাড়ি ভাড়া</h3></div>
      <div class="cb">
        <div style="display:flex;align-items:center;justify-content:space-between;
          margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid var(--line)">
          <span style="font-size:13px;font-weight:600">বাড়ি ভাড়া চালু করুন</span>
          <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
            <input type="checkbox" id="rent-toggle"
              style="accent-color:var(--g2);width:16px;height:16px"
              ${_settings.rentEnabled?'checked':''}/>
            <span id="rent-lbl" style="font-size:12px;color:var(--ink3)">
              ${_settings.rentEnabled?'চালু':'বন্ধ'}
            </span>
          </label>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
          <div><label class="lbl">🏠 বাসা ভাড়া (৳)</label>
            <input class="inp inp-sm" id="set-house" type="number" value="${_settings.rentHouse||0}"/></div>
          <div><label class="lbl">🔥 গ্যাস (৳)</label>
            <input class="inp inp-sm" id="set-gas" type="number" value="${_settings.rentGas||0}"/></div>
          <div><label class="lbl">💡 বিদ্যুৎ (৳)</label>
            <input class="inp inp-sm" id="set-elec" type="number" value="${_settings.rentElectric||0}"/></div>
          <div><label class="lbl">💧 পানি (৳)</label>
            <input class="inp inp-sm" id="set-water" type="number" value="${_settings.rentWater||0}"/></div>
          <div><label class="lbl">🧹 বুয়া (৳)</label>
            <input class="inp inp-sm" id="set-bua" type="number" value="${_settings.rentBua||0}"/></div>
        </div>
        <button class="btn btn-p btn-sm" id="btn-save-rent">✓ সংরক্ষণ</button>
        <div id="rent-msg" style="font-size:11px;margin-top:6px"></div>
      </div>
    </div>

    <!-- App Update -->
    ${_updateCardHTML()}

  </div>
</div>`;

  _renderSlots(root);

  root.querySelector('#btn-gen-code').addEventListener('click', () => _generateJoinCode(root));
  root.querySelector('#btn-revoke-code').addEventListener('click', () => _revokeJoinCode(root));
  root.querySelector('#btn-save-name').addEventListener('click', () => _saveName(root));
  root.querySelector('#btn-save-slots').addEventListener('click', () => _saveSlots(root));
  root.querySelector('#btn-add-slot').addEventListener('click', () => _addSlot(root));
  root.querySelector('#btn-save-rent').addEventListener('click', () => _saveRent(root));
  root.querySelector('#set-auto-dep').addEventListener('change', e => {
    const lbl = root.querySelector('#auto-dep-lbl');
    if (lbl) { lbl.textContent = e.target.checked?'চালু':'বন্ধ'; lbl.style.color = e.target.checked?'var(--g1)':'var(--ink3)'; }
  });
  root.querySelector('#rent-toggle').addEventListener('change', e => {
    root.querySelector('#rent-lbl').textContent = e.target.checked ? 'চালু' : 'বন্ধ';
  });
  root.querySelector('#slot-list').addEventListener('click', e => {
    const btn = e.target.closest('[data-del-slot]');
    if (btn) _delSlot(root, parseInt(btn.dataset.delSlot));
  });
  _attachUpdateListeners(root);
}

function _renderSlots(root) {
  const slots  = _settings.slots || [];
  const listEl = root.querySelector('#slot-list');
  if (!listEl) return;
  listEl.innerHTML = slots.map((s,i) => `
<div style="display:flex;gap:6px;align-items:center">
  <input class="inp inp-sm slot-inp" style="flex:1" data-slot-i="${i}"
    value="${_e(s)}" placeholder="বেলার নাম"/>
  <button class="btn btn-xs btn-danger" data-del-slot="${i}">✕</button>
</div>`).join('');
  const addBtn = root.querySelector('#btn-add-slot');
  if (addBtn) addBtn.style.display = slots.length >= 5 ? 'none' : '';
}

function _addSlot(root) {
  if ((_settings.slots||[]).length >= 5) { toast('সর্বোচ্চ ৫টি বেলা','er'); return; }
  _settings.slots = [...(_settings.slots||[]), 'নতুন বেলা'];
  _renderSlots(root);
}

function _delSlot(root, i) {
  if ((_settings.slots||[]).length <= 1) { toast('কমপক্ষে ১টি বেলা রাখুন','er'); return; }
  _settings.slots.splice(i, 1);
  _renderSlots(root);
}

async function _saveName(root) {
  const name = root.querySelector('#set-name')?.value.trim();
  const addr = root.querySelector('#set-addr')?.value.trim();
  if (!name) { toast('মেসের নাম দিন','er'); return; }
  try {
    await updateDoc(doc(db,'messes',_ctx.messId), { name, address: addr||'' });
    if (_ctx.messData) { _ctx.messData.name=name; _ctx.messData.address=addr; }
    const msg = root.querySelector('#name-msg');
    if (msg) { msg.textContent='✓ সংরক্ষণ হয়েছে'; msg.style.color='var(--g1)'; }
    document.getElementById('sb-mess-name') && (document.getElementById('sb-mess-name').textContent=name);
    document.getElementById('sb-mess-addr') && (document.getElementById('sb-mess-addr').textContent=addr||'');
    toast('মেস তথ্য আপডেট হয়েছে','ok');
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
}

async function _saveSlots(root) {
  const inputs = root.querySelectorAll('.slot-inp');
  const slots  = [...inputs].map(i => i.value.trim()).filter(Boolean);
  if (!slots.length) { toast('কমপক্ষে ১টি বেলা দিন','er'); return; }
  const cutoff   = parseInt(root.querySelector('#set-cutoff')?.value)||10;
  const maxMeals = parseInt(root.querySelector('#set-maxmeals')?.value)||3;
  try {
    const autoDep = root.querySelector('#set-auto-dep')?.checked ?? true;
    await updateDoc(doc(db,'messes',_ctx.messId,'settings','main'),
      { slots, cutoffHour:cutoff, maxMealsPerDay:maxMeals, autoDeposit:autoDep });
    _settings.slots=slots; _settings.cutoffHour=cutoff; _settings.maxMealsPerDay=maxMeals; _settings.autoDeposit=autoDep;
    Object.assign(_ctx.messSettings, {slots, cutoffHour:cutoff, maxMealsPerDay:maxMeals, autoDeposit:autoDep});
    const msg = root.querySelector('#slot-msg');
    if (msg) { msg.textContent='✓ সংরক্ষণ হয়েছে'; msg.style.color='var(--g1)'; }
    toast('বেলা সেটিংস সেভ হয়েছে','ok');
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
}

async function _saveRent(root) {
  const enabled  = root.querySelector('#rent-toggle')?.checked||false;
  const house    = parseFloat(root.querySelector('#set-house')?.value)||0;
  const gas      = parseFloat(root.querySelector('#set-gas')?.value)||0;
  const electric = parseFloat(root.querySelector('#set-elec')?.value)||0;
  const water    = parseFloat(root.querySelector('#set-water')?.value)||0;
  const bua      = parseFloat(root.querySelector('#set-bua')?.value)||0;
  try {
    await updateDoc(doc(db,'messes',_ctx.messId,'settings','main'),
      { rentEnabled:enabled, rentHouse:house, rentGas:gas, rentElectric:electric, rentWater:water, rentBua:bua });
    Object.assign(_settings, {rentEnabled:enabled,rentHouse:house,rentGas:gas,rentElectric:electric,rentWater:water,rentBua:bua});
    Object.assign(_ctx.messSettings, {rentEnabled:enabled});
    const msg = root.querySelector('#rent-msg');
    if (msg) { msg.textContent='✓ সংরক্ষণ হয়েছে'; msg.style.color='var(--g1)'; }
    toast('ভাড়া সেটিংস সেভ হয়েছে','ok');
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
}

async function _checkUpdate(root) {
  const statusEl = root.querySelector('#update-status');
  const btn      = root.querySelector('#btn-check-update');
  if (btn) { btn.disabled=true; btn.textContent='চেক হচ্ছে…'; }
  if (statusEl) statusEl.textContent = '';
  try {
    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.getRegistration();
      if (reg) {
        await reg.update();
        if (reg.waiting) {
          if (statusEl) statusEl.innerHTML =
            '<span style="color:var(--g1);font-weight:700">✅ নতুন আপডেট পাওয়া গেছে! Reload হচ্ছে…</span>';
          setTimeout(() => _forceUpdate(root), 1200);
          return;
        }
      }
    }
    if (statusEl) statusEl.innerHTML =
      '<span style="color:var(--g1)">✓ অ্যাপ সর্বশেষ version এ আছে</span>';
  } catch(err) {
    if (statusEl) statusEl.innerHTML =
      `<span style="color:var(--r1)">⚠️ চেক করতে ব্যর্থ: ${err.message}</span>`;
  } finally {
    if (btn) { btn.disabled=false; btn.textContent='🔍 আপডেট চেক করুন'; }
  }
}

async function _forceUpdate(root) {
  const statusEl = root.querySelector('#update-status');
  if (statusEl) statusEl.innerHTML =
    '<span style="color:var(--b0);font-weight:700">⏳ Cache মুছে নতুন করে লোড হচ্ছে…</span>';
  try {
    if ('caches' in window) {
      const names = await caches.keys();
      await Promise.all(names.map(n => caches.delete(n)));
    }
    if ('serviceWorker' in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map(r => r.unregister()));
    }
    setTimeout(() => location.reload(true), 400);
  } catch { location.reload(true); }
}

async function _loadJoinCode(root) {
  const display = root.querySelector('#join-code-display');
  const revokeBtn = root.querySelector('#btn-revoke-code');
  if (!display) return;
  try {
    const messSnap = await getDoc(doc(db,'messes',_ctx.messId));
    const code = messSnap.exists() ? messSnap.data().joinCode : null;
    const expiry = messSnap.exists() ? messSnap.data().joinCodeExpiry : null;

    if (code) {
      const expDate = expiry?.toDate ? expiry.toDate() : (expiry ? new Date(expiry.seconds*1000) : null);
      const isExpired = expDate && expDate < new Date();
      display.innerHTML = `
<div style="background:${isExpired?'var(--r4)':'var(--g8)'};border:1.5px solid ${isExpired?'var(--r3)':'var(--g5)'};
  border-radius:10px;padding:14px;text-align:center">
  <p style="font-size:11px;color:var(--ink3);font-weight:700;margin-bottom:6px">বর্তমান কোড</p>
  <p style="font-size:28px;font-weight:700;font-family:var(--mono);letter-spacing:4px;
    color:${isExpired?'var(--r1)':'var(--g1)'}">${code}</p>
  ${isExpired ? '<p style="font-size:11px;color:var(--r1);margin-top:4px">⚠️ মেয়াদ শেষ — নতুন কোড তৈরি করুন</p>'
    : expDate ? `<p style="font-size:11px;color:var(--ink3);margin-top:4px">মেয়াদ: ${expDate.toLocaleDateString('bn-BD')}</p>` : ''}
</div>`;
      if (revokeBtn) revokeBtn.style.display = isExpired ? 'none' : '';
    } else {
      display.innerHTML = `
<div style="background:var(--paper);border:1px dashed var(--line2);border-radius:10px;
  padding:14px;text-align:center;color:var(--ink4);font-size:12px">
  কোনো active কোড নেই
</div>`;
      if (revokeBtn) revokeBtn.style.display = 'none';
    }
  } catch(err) { console.warn('Join code load error:', err); }
}

async function _generateJoinCode(root) {
  const code = String(Math.floor(100000 + Math.random()*900000));
  const expiry = Timestamp.fromDate(new Date(Date.now() + 7*24*60*60*1000)); // 7 days

  try {
    await updateDoc(doc(db,'messes',_ctx.messId), {
      joinCode: code, joinCodeExpiry: expiry,
    });
    // Global lookup collection — joinCodes/{code} → messId
    await setDoc(doc(db,'joinCodes',code), {
      messId: _ctx.messId,
      messName: _ctx.messData?.name||'মেস',
      createdAt: serverTimestamp(),
      expiresAt: expiry,
    });
    toast(`নতুন কোড তৈরি হয়েছে: ${code} ✓`,'ok');
    await _loadJoinCode(root);
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
}

async function _revokeJoinCode(root) {
  if (!window.confirm('কোডটি বাতিল করবেন? নতুন কোড ছাড়া কেউ join করতে পারবে না।')) return;
  try {
    const messSnap = await getDoc(doc(db,'messes',_ctx.messId));
    const code = messSnap.data()?.joinCode;
    await updateDoc(doc(db,'messes',_ctx.messId), {
      joinCode: null, joinCodeExpiry: null,
    });
    if (code) {
      try { await deleteDoc(doc(db,'joinCodes',code)); } catch(e) {}
    }
    toast('কোড বাতিল করা হয়েছে','ok');
    await _loadJoinCode(root);
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
}


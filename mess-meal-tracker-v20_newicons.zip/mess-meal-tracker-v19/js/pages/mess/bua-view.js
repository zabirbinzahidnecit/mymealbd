// bua-view.js — বুয়া role এর জন্য restricted view: শুধু আজকের মিল (কোন বেলায় কতজন)
// কোনো এডিট/লিংক/অন্য পেজে যাওয়ার অপশন নেই — একদম read-only

import { db } from '../../firebase.js';
import { pad, moName, getDocsByIds, escapeHtml as _e } from '../../utils.js';
import { getCachedMembers } from '../../members-cache.js';
import { collection } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();

export async function render(root, ctx) {
  root.innerHTML = `
<div>
  <h2 style="font-size:17px;font-weight:700;color:var(--ink);margin-bottom:4px">🍚 আজকের মিল</h2>
  <p style="font-size:13px;color:var(--ink3);margin-bottom:16px">
    ${TODAY.getDate()} ${moName(TODAY.getMonth())} ${TODAY.getFullYear()}
  </p>
  <div id="bua-slots">লোড হচ্ছে…</div>
</div>`;

  const slots = ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const SICO  = ['☀️','🌤','🌙','🍳','🍱','🌮'];
  const el = root.querySelector('#bua-slots');

  try {
    const members = await getCachedMembers(ctx.messId);
    const keys = members.map(m=>`${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}_${pad(TODAY.getDate())}_${m.uid}`);
    const dataMap = await getDocsByIds(collection(db,'messes',ctx.messId,'meals'), keys);

    const counts = new Array(slots.length).fill(0);
    let guestTotal = 0;
    keys.forEach(k=>{
      const data = dataMap[k];
      if (!data) return;
      (data.slots||[]).forEach((on,i)=>{ if(on) counts[i]++; });
      guestTotal += (data.guestSlots||[]).filter(Boolean).length;
    });

    el.innerHTML = `
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px">
  ${slots.map((s,i)=>`
  <div class="card" style="text-align:center;padding:20px 10px">
    <div style="font-size:26px;margin-bottom:6px">${SICO[i]||'🍽'}</div>
    <div style="font-size:13px;color:var(--ink3);margin-bottom:8px">${_e(s)}</div>
    <div style="font-size:28px;font-weight:700;color:var(--g1);font-family:var(--mono)">${counts[i]}</div>
    <div style="font-size:11px;color:var(--ink4)">জন</div>
  </div>`).join('')}
</div>
${guestTotal>0 ? `<p style="margin-top:14px;font-size:13px;color:var(--ink3);text-align:center">+ ${guestTotal} জন গেস্ট মিল</p>` : ''}
<p style="margin-top:20px;font-size:12px;color:var(--ink4);text-align:center">
  🔄 নতুন তথ্যের জন্য পেজ রিফ্রেশ করুন
</p>`;
  } catch(err) {
    el.innerHTML = `<p style="font-size:13px;color:var(--r1);text-align:center">লোড ব্যর্থ: ${_e(err.message)}</p>`;
  }
}


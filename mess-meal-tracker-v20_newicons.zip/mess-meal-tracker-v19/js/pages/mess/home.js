// home.js — v11: fixed balance (user-specific), Promise.all slot summary, no window.__ globals

import { db } from '../../firebase.js';
import { toast, ld, uld, taka, takaF, pad, moName, getDocsByIds, monthDocIdRange, monthDateRange, escapeHtml as _e } from '../../utils.js';
import { getCachedMembers } from '../../members-cache.js';
import {
  collection, getDocs, doc, getDoc, setDoc,
  query, where, orderBy, limit, documentId
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TODAY = new Date();
let _ctx={}, _vy=TODAY.getFullYear(), _vm=TODAY.getMonth(), _members=[];

export async function render(root, ctx) {
  _ctx = ctx;
  const slots  = ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const cutoff = ctx.messSettings?.cutoffHour ?? 10;
  const isPast = TODAY.getHours() >= cutoff;
  const SICO   = ['☀️','🌤','🌙','🍳','🍱','🌮'];

  root.innerHTML = `
<div>
  <div id="h-global-notice"></div>
  <div id="h-poll-card" style="margin-bottom:14px"></div>

  <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;flex-wrap:wrap">
    <button class="btn btn-ghost btn-sm" id="h-prev">◀</button>
    <span style="font-size:14px;font-weight:700;min-width:130px;text-align:center" id="h-lbl"></span>
    <button class="btn btn-ghost btn-sm" id="h-next">▶</button>
    <button class="btn btn-ghost btn-sm" id="h-today">আজ</button>
    <button class="btn btn-ghost btn-sm" id="h-ref" style="margin-left:auto">🔄</button>
  </div>

  <!-- ✅ FIXED: 4th card shows MY balance, not mess-level balance -->
  <div class="gA" style="margin-bottom:14px">
    <div class="sc sg"><div class="sl">মোট মিল</div><div class="sv" id="hc-meal">—</div><div class="ss">এই মাসে (মেস)</div></div>
    <div class="sc sa"><div class="sl">মিলের দাম</div><div class="sv" id="hc-rate">—</div><div class="ss">প্রতি মিল</div></div>
    <div class="sc sc-blue"><div class="sl">মোট বাজার</div><div class="sv" id="hc-bazar">—</div><div class="ss">এই মাসে</div></div>
    <div class="sc" id="hc-bal-card">
      <div class="sl">আমার ব্যালেন্স</div>
      <div class="sv" id="hc-bal">—</div>
      <div class="ss" id="hc-bal-note">জমা − আমার খরচ</div>
    </div>
  </div>

  <div class="card" style="margin-bottom:14px">
    <div class="ch">
      <h3>🍽 আজকের মিল — ${TODAY.getDate()} ${moName(TODAY.getMonth())}</h3>
      <span style="font-size:11px;font-weight:600;color:${isPast?'var(--r1)':'var(--g1)'}">
        ${isPast?'🔒 বন্ধ':`⏰ বন্ধ ${cutoff}:00 তে`}
      </span>
    </div>
    <div class="cb">
      <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px" id="h-slot-cards">
        ${slots.map((s,i)=>`
        <div style="background:var(--paper);border:1px solid var(--line);border-radius:12px;
          padding:10px 14px;text-align:center;min-width:85px;flex:1" id="hsc-card-${i}">
          <div style="font-size:18px;margin-bottom:3px">${SICO[i]||'🍽'}</div>
          <div style="font-size:12px;font-weight:600;color:var(--ink)">${_e(s)}</div>
          <div style="font-size:26px;font-weight:700;color:var(--ink4);font-family:var(--mono)" id="hsc-${i}">—</div>
          <div style="font-size:10px;color:var(--ink4)">জন</div>
        </div>`).join('')}
        <div style="background:var(--g7);border:1px solid var(--g5);border-radius:12px;
          padding:10px 14px;text-align:center;min-width:85px;flex:1">
          <div style="font-size:18px;margin-bottom:3px">🍱</div>
          <div style="font-size:12px;font-weight:600;color:var(--g1)">মোট</div>
          <div style="font-size:26px;font-weight:700;color:var(--g1);font-family:var(--mono)" id="hsc-total">—</div>
          <div style="font-size:10px;color:var(--ink4)">মিল</div>
        </div>
      </div>

      <div style="border-top:1px solid var(--line);padding-top:12px">
        <p style="font-size:11px;font-weight:700;color:var(--ink3);text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px">সদস্যভিত্তিক আজকের মিল</p>
        <div id="h-member-chips" style="display:flex;flex-wrap:wrap;gap:6px">
          <p style="font-size:12px;color:var(--ink4)">লোড হচ্ছে…</p>
        </div>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="ch">
      <h3>📢 সর্বশেষ নোটিশ</h3>
      <button class="btn btn-ghost btn-sm" id="h-notice-all">সব দেখুন</button>
    </div>
    <div class="cb" id="h-notices">লোড হচ্ছে…</div>
  </div>
</div>`;

  root.querySelector('#h-prev').addEventListener('click', ()=>{ _vm--; if(_vm<0){_vm=11;_vy--} _load(root); });
  root.querySelector('#h-next').addEventListener('click', ()=>{ _vm++; if(_vm>11){_vm=0;_vy++} _load(root); });
  root.querySelector('#h-today').addEventListener('click', ()=>{ _vy=TODAY.getFullYear();_vm=TODAY.getMonth(); _load(root); });
  root.querySelector('#h-ref').addEventListener('click', ()=> _load(root));
  root.querySelector('#h-notice-all').addEventListener('click', ()=>
    window.dispatchEvent(new CustomEvent('mm:navigate',{detail:{page:'notice'}}))
  );
  // Upgrade event from ad banner
  window.removeEventListener('mm:upgrade', _onUpgrade);
  _onUpgrade = ()=> {
    import('../../plan.js').then(m=>m.requestPayment(_ctx.messId, _ctx.profile));
  };
  window.addEventListener('mm:upgrade', _onUpgrade);

  await _load(root);
}

let _onUpgrade = null;

// ✅ boot-time prefetch — mess-shell.js এই ফাংশনটা messId জানার সাথে সাথেই
// (mess context load হওয়ার অপেক্ষা না করে) সমান্তরালে কল করে রাখে, যাতে
// Home পেজে আসার আগেই ডেটা আনা শুরু হয়ে যায় — auth→profile→mess-context→
// home-data এই ৪-ধাপের waterfall থেকে একটা ধাপ কমে যায়।
export async function preloadHomeData(messId, year, month) {
  const { start, end } = monthDocIdRange(year, month);
  const { start:dStart, end:dEnd } = monthDateRange(year, month);
  const [members, allMeals, expSnap, depSnap] = await Promise.all([
    getCachedMembers(messId),
    getDocs(query(
      collection(db,'messes',messId,'meals'),
      where(documentId(), '>=', start),
      where(documentId(), '<', end)
    )),
    getDocs(query(collection(db,'messes',messId,'expenses'),
      where('status','==','approved'), where('date','>=',dStart), where('date','<',dEnd))),
    getDocs(query(collection(db,'messes',messId,'deposits'),
      where('status','==','approved'), where('date','>=',dStart), where('date','<',dEnd))),
  ]);
  return { members, allMeals, expSnap, depSnap };
}

async function _load(root) {
  root.querySelector('#h-lbl').textContent = `${moName(_vm)} ${_vy}`;
  ld('ড্যাশবোর্ড লোড হচ্ছে…');
  try {
    const monthStr = `${_vy}-${pad(_vm+1)}`;
    const uid      = _ctx.profile.uid;

    // ✅ boot-time prefetch থাকলে (শুধু প্রথমবার, চলতি মাসের জন্যই) সেটাই
    // ব্যবহার করবে — নতুন করে fetch করবে না। মাস পরিবর্তন করলে বা preload
    // না থাকলে স্বাভাবিকভাবে fresh fetch হবে।
    const isCurrentMonth = _vy===TODAY.getFullYear() && _vm===TODAY.getMonth();
    let members, allMeals, expSnap, depSnap;
    if (isCurrentMonth && _ctx.params?.homePreload) {
      const preloaded = await _ctx.params.homePreload.catch(()=>null);
      _ctx.params.homePreload = null; // একবারই ব্যবহার হবে
      if (preloaded) ({ members, allMeals, expSnap, depSnap } = preloaded);
    }
    if (!members) {
      ({ members, allMeals, expSnap, depSnap } = await preloadHomeData(_ctx.messId, _vy, _vm));
    }

    _members = members;

    // Mess-level totals
    let totalMeals=0, myMeals=0;
    allMeals.forEach(d=>{
      const s = (d.data().slots||[]).filter(Boolean).length;
      const g = (d.data().guestSlots||[]).filter(Boolean).length;
      totalMeals += s+g;
      if (d.id.endsWith('_'+uid)) myMeals += s+g;
    });

    let totalBazar=0;
    expSnap.forEach(d=>{ if(d.data().date?.startsWith(monthStr)) totalBazar+=parseFloat(d.data().amount)||0; });

    // ✅ FIXED: My balance = my deposit - my meal cost
    let myDep=0, totalDep=0;
    depSnap.forEach(d=>{
      if (!d.data().date?.startsWith(monthStr)) return;
      totalDep += parseFloat(d.data().amount)||0;
      if (d.data().memberId===uid) myDep += parseFloat(d.data().amount)||0;
    });

    const rate    = totalMeals>0 ? totalBazar/totalMeals : 0;
    const myCost  = myMeals*rate;
    const myBal   = myDep-myCost;

    const _sv=(id,v)=>{ const el=root.querySelector('#'+id); if(el) el.textContent=v; };
    _sv('hc-meal',  String(totalMeals));
    _sv('hc-rate',  takaF(rate));
    _sv('hc-bazar', taka(totalBazar));
    _sv('hc-bal',   takaF(myBal));

    const balCard = root.querySelector('#hc-bal-card');
    const balNote = root.querySelector('#hc-bal-note');
    if (balCard) balCard.className = `sc ${myBal>=0?'sg':'sr'}`;
    if (balNote) balNote.textContent = myBal>=0
      ? `${taka(myBal)} পাবেন` : `${taka(Math.abs(myBal))} দেবেন`;

    // ✅ মূল সংখ্যা (রেট/মিল/বাজার/ব্যালেন্স) রেডি হলেই loading spinner সরে
    // যাবে — Notice/Poll/আজকের মিল সামারি এগুলো সেকেন্ডারি কনটেন্ট, এগুলোর
    // জন্য পুরো পেজ আটকে রাখার দরকার নেই, এরা নিজেদের জায়গায় আলাদাভাবে
    // (নিজস্ব "লোড হচ্ছে…" দেখিয়ে) ব্যাকগ্রাউন্ডে লোড হবে।
    _loadTodaySlotSummary(root);
    _loadNotices(root);
    _loadGlobalNotice(root);
    _loadActivePoll(root);
  } catch(err) { console.error(err); toast('লোড ব্যর্থ','er'); }
  finally { uld(); }
}

async function _loadTodaySlotSummary(root) {
  const slots = _ctx.messSettings?.slots || ['সকাল','দুপুর','রাত'];
  const SICO  = ['☀️','🌤','🌙','🍳','🍱'];
  const counts = new Array(Math.max(slots.length,1)).fill(0);
  let gTotal=0;

  // ✅ একটাই batched query — আগে ছিল প্রতি member-এর জন্য আলাদা getDoc (N+1)
  const keys  = _members.map(m=>`${TODAY.getFullYear()}_${pad(TODAY.getMonth()+1)}_${pad(TODAY.getDate())}_${m.uid}`);
  const dataMap = await getDocsByIds(collection(db,'messes',_ctx.messId,'meals'), keys);

  const chips = keys.map((k,idx)=>{
    const m = _members[idx];
    const data = dataMap[k];
    if (!data) return {name:m.name||m.email.split('@')[0],slots:[],g:0,t:0};
    const s=data.slots||[];
    const g=(data.guestSlots||[]).filter(Boolean).length;
    s.forEach((on,i)=>{ if(on) counts[i]++; }); gTotal+=g;
    return {name:m.name||m.email.split('@')[0],slots:s,g,t:s.filter(Boolean).length+g};
  });

  const grand = counts.reduce((a,b)=>a+b,0)+gTotal;
  slots.forEach((_,i)=>{
    const el   = root.querySelector(`#hsc-${i}`);
    const card = root.querySelector(`#hsc-card-${i}`);
    if(el)  { el.textContent=counts[i]; el.style.color=counts[i]>0?'var(--g1)':'var(--ink4)'; }
    if(card){ card.style.background=counts[i]>0?'var(--g7)':'var(--paper)'; card.style.borderColor=counts[i]>0?'var(--g5)':'var(--line)'; }
  });
  const tot=root.querySelector('#hsc-total'); if(tot) tot.textContent=isNaN(grand)?0:grand;

  const chipsEl=root.querySelector('#h-member-chips');
  if (chipsEl) chipsEl.innerHTML=chips.map(c=>`
<div style="display:flex;align-items:center;gap:6px;
  background:${c.t>0?'var(--g7)':'var(--paper)'};
  border:1px solid ${c.t>0?'var(--g5)':'var(--line)'};
  border-radius:20px;padding:4px 11px;font-size:12px">
  <span style="font-weight:600;color:${c.t>0?'var(--g1)':'var(--ink3)'}">${_e(c.name)}</span>
  <span>${c.slots.map((on,i)=>on?(['☀️','🌤','🌙','🍳','🍱'][i]||'🍽'):'').filter(Boolean).join('')||'—'}${c.g>0?`+${c.g}G`:''}</span>
  <span style="font-weight:700;font-family:var(--mono);color:${c.t>0?'var(--g1)':'var(--ink4)'}">${c.t}</span>
</div>`).join('');
}

async function _loadNotices(root) {
  const el=root.querySelector('#h-notices'); if(!el) return;
  try {
    // ✅ ফিক্স: আগে পুরো notices collection টানত (কোনো limit ছাড়া), তারপর
    // client-side sort করে উপরের ৩টা দেখাত। মেসে যত বেশি নোটিশ জমবে, এটা
    // তত ধীর হতে থাকত। এখন সরাসরি server-side sort+limit query।
    const snap=await getDocs(query(collection(db,'messes',_ctx.messId,'notices'),orderBy('createdAt','desc'),limit(3)));
    if(snap.empty){ el.innerHTML='<p style="font-size:12px;color:var(--ink4)">কোনো নোটিশ নেই</p>'; return; }
    el.innerHTML=snap.docs.map(d=>{
      const n=d.data();
      return `<div style="padding:8px 0;border-bottom:.5px solid var(--line)">
<p style="font-size:13px;color:var(--ink);line-height:1.5">${_e(n.text||'')}</p>
<p style="font-size:10px;color:var(--ink4);margin-top:3px">— ${_e(n.addedByName||'—')}</p>
</div>`;
    }).join('');
  } catch { el.innerHTML='<p style="color:var(--r1);font-size:12px">লোড ব্যর্থ</p>'; }
}

async function _loadGlobalNotice(root) {
  const el=root.querySelector('#h-global-notice'); if(!el) return;
  try {
    const snap=await getDocs(query(collection(db,'globalNotices'),orderBy('createdAt','desc'),limit(1)));
    if(snap.empty){ el.innerHTML=''; return; }
    const n=snap.docs[0].data();
    if(n.targetMessId&&n.targetMessId!=='all'&&n.targetMessId!==_ctx.messId){ el.innerHTML=''; return; }
    el.innerHTML=`
<div style="background:var(--b4);border:1px solid var(--b3);border-radius:12px;
  padding:12px 14px;margin-bottom:14px;display:flex;gap:10px;align-items:flex-start">
  <span style="font-size:20px;flex-shrink:0">📣</span>
  <div>
    <p style="font-size:11px;font-weight:700;color:var(--b0);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Platform Notice</p>
    <p style="font-size:13px;color:var(--ink);line-height:1.5">${_e(n.text||'')}</p>
  </div>
</div>`;
  } catch { el.innerHTML=''; }
}

async function _loadActivePoll(root) {
  const el=root.querySelector('#h-poll-card'); if(!el) return;
  try {
    const snap=await getDocs(query(collection(db,'messes',_ctx.messId,'polls'),orderBy('createdAt','desc'),limit(3)));
    const now=new Date();
    const active=snap.docs.map(d=>({id:d.id,...d.data()})).find(p=>{
      const exp=p.expiresAt?.toDate?p.expiresAt.toDate():new Date((p.expiresAt?.seconds||0)*1000);
      return exp>now;
    });
    if(!active){ el.innerHTML=''; return; }

    const uid=_ctx.profile.uid;
    const myVote=active.votes?.[uid];
    const totalVotes=Object.keys(active.votes||{}).length;

    el.innerHTML=`
<div style="background:var(--a4);border:1px solid var(--a3);border-radius:12px;padding:14px;margin-bottom:14px">
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
    <span style="font-size:18px">🗳️</span>
    <p style="font-size:13px;font-weight:700;color:var(--a0);flex:1">${_e(active.question)}</p>
    <button class="btn btn-ghost btn-sm" id="h-go-poll">সব দেখুন</button>
  </div>
  <div style="display:flex;flex-wrap:wrap;gap:6px" id="h-poll-opts">
    ${(active.options||[]).map((opt,i)=>{
      const count=Object.values(active.votes||{}).filter(v=>v===i).length;
      const voted=myVote===i;
      return `<button
        class="h-poll-vote-btn"
        data-poll-id="${active.id}" data-opt="${i}"
        ${myVote!==undefined?'disabled':''}
        style="padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600;
          background:${voted?'var(--a2)':myVote!==undefined?'var(--paper)':'var(--a3)'};
          color:${voted?'#fff':'var(--a0)'};
          border:1.5px solid ${voted?'var(--a1)':'var(--a3)'};cursor:${myVote!==undefined?'default':'pointer'};
          opacity:${myVote!==undefined&&!voted?.7:1}">
        ${voted?'✓ ':''} ${_e(opt)} ${myVote!==undefined?`(${count})`:''}</button>`;
    }).join('')}
  </div>
  <p style="font-size:10px;color:var(--a0);margin-top:8px">${totalVotes}জন vote দিয়েছেন</p>
</div>`;

    // ✅ FIXED: addEventListener, no window.__ global
    root.querySelector('#h-go-poll')?.addEventListener('click', ()=>
      window.dispatchEvent(new CustomEvent('mm:navigate',{detail:{page:'poll'}}))
    );
    el.querySelectorAll('.h-poll-vote-btn').forEach(btn=>{
      btn.addEventListener('click', async ()=>{
        if (myVote!==undefined) return;
        const {updateDoc, doc:fDoc} = await import('https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js');
        try {
          await updateDoc(fDoc(db,'messes',_ctx.messId,'polls',active.id),{[`votes.${uid}`]:parseInt(btn.dataset.opt)});
          toast('Vote দেওয়া হয়েছে ✓','ok');
          await _loadActivePoll(root);
        } catch(e) { toast('ব্যর্থ: '+e.message,'er'); }
      });
    });

  } catch { el.innerHTML=''; }
}


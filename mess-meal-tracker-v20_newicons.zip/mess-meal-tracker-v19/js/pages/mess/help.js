// help.js — v19: User Manual + FAQ accordion
import { escapeHtml as _e } from '../../utils.js';

const FAQ = [
  {
    cat: '🏠 শুরু করা',
    items: [
      { q: 'নতুন মেস কীভাবে তৈরি করব?',
        a: '"নতুন মেস তৈরির অনুরোধ" ফর্মে মেসের নাম, ঠিকানা দিয়ে সাবমিট করুন। Auto-approve চালু থাকলে সাথে সাথে মেস হয়ে যাবে, না থাকলে Admin অনুমোদন করলে active হবে।' },
      { q: 'অন্য মেসে কীভাবে join করব?',
        a: 'দুই উপায়ে: (১) Admin এর পাঠানো Invite Link এ click করুন, (২) Settings থেকে Admin এর দেওয়া ৬-সংখ্যার Join Code লিখে join করুন।' },
      { q: 'একই সাথে একাধিক মেসে থাকা যাবে কি?',
        a: 'না, একটি account একসাথে শুধু একটি মেসের সদস্য হতে পারবে। নতুন মেসে যোগ দিতে আগেরটি থেকে বের হতে হবে।' },
    ]
  },
  {
    cat: '🍽 মিল ব্যবস্থাপনা',
    items: [
      { q: 'মিল এন্ট্রি করব কীভাবে?',
        a: '"মিল এন্ট্রি" পেজে গিয়ে আজকের দিনের slot (সকাল/দুপুর/রাত) এ ক্লিক করুন। একাধিক দিনের জন্য Multi-day বোতাম ব্যবহার করুন।' },
      { q: 'একসাথে অনেকগুলো দিনে একই বেলা কীভাবে দিব?',
        a: '"📅 একাধিক দিন" বোতামে ক্লিক করুন। মোডাল খুললে "🔗 একসাথে (একই বেলা)" মোড ডিফল্ট ভাবে চালু থাকবে — যত খুশি দিন (যেমন ১০-২০টা) ক্লিক করে সিলেক্ট করুন (checkbox এর মতো), তারপর নিচে একবার বেলা বাছাই করলে সিলেক্ট করা সব দিনে একসাথে সেই বেলা বসে যাবে। শেষে "✓ প্রয়োগ" চাপুন।' },
      { q: 'ভিন্ন ভিন্ন দিনে ভিন্ন ভিন্ন বেলা (যেমন আজ সকাল, কাল দুপুর) কীভাবে দিব?',
        a: '"📅 একাধিক দিন" মোডালে "🔀 আলাদা আলাদা" মোডে সুইচ করুন। একটা একটা দিন ক্লিক করে সেই দিনের জন্য আলাদাভাবে বেলা বাছাই করুন — একদিনের বাছাই শেষ করে অন্য দিনে ক্লিক করলে আগেরটা মুছে যায় না, শুধু আপাতত আড়ালে থাকে। শেষে "✓ প্রয়োগ" চাপলে সবগুলো একসাথে সেভ হবে।' },
      { q: 'গতকালের বা পুরনো দিনের মিল পরিবর্তন করতে পারব কি?',
        a: 'সাধারণ সদস্য শুধু আজকের মিল (নির্দিষ্ট সময়ের আগে) পরিবর্তন করতে পারবে। পুরনো দিনের মিল শুধুমাত্র Mess Admin বা Co-Admin সংশোধন করতে পারবেন।' },
      { q: 'মিল বন্ধের সময় (cutoff) কী?',
        a: 'প্রতিদিন একটি নির্দিষ্ট সময়ের পর (Admin সেট করেন, যেমন সকাল ১০টা) ওইদিনের মিল এন্ট্রি বন্ধ হয়ে যায় — Admin ছাড়া কেউ পরিবর্তন করতে পারে না।' },
    ]
  },
  {
    cat: '🛒 বাজার ও টাকা',
    items: [
      { q: 'বাজার করলে কীভাবে হিসাব হয়?',
        a: 'বাজার যোগ করলে Settings এ "Auto-Deposit" চালু থাকলে সেই টাকা স্বয়ংক্রিয়ভাবে আপনার জমায় যুক্ত হয়ে যায়। Co-Admin/Admin অনুমোদন করলে এটি চূড়ান্ত হয়।' },
      { q: 'মিল রেট কীভাবে হিসাব হয়?',
        a: 'মিল রেট = মোট অনুমোদিত বাজার ÷ মোট মিল সংখ্যা। প্রতি মাসে এটি স্বয়ংক্রিয়ভাবে আপডেট হয়।' },
      { q: 'ব্যালেন্স ঋণাত্মক (নেগেটিভ) হলে কী হয়?',
        a: 'এর মানে আপনার মিল খরচ আপনার জমার চেয়ে বেশি — অর্থাৎ আপনাকে মেসে আরও টাকা জমা দিতে হবে।' },
      { q: 'বাড়ি ভাড়া কীভাবে হিসাব হয়?',
        a: '"বাড়ি ভাড়া" পেজে Admin প্রতি মাসে বাসা ভাড়া, গ্যাস, বিদ্যুৎ, পানি ও বুয়ার বেতন — এই ৫টি আলাদা করে বসান। সব যোগ করে মোট থেকে সদস্যপ্রতি সমান ভাগ (Auto Split) হিসাব করে দেখানো হয়।' },
      { q: 'ভাড়ার হিসাবে সবাইকে কি সমান ভাগে ধরা হয়?',
        a: 'ডিফল্ট ভাবে হ্যাঁ, প্রত্যেক সদস্যকে সমান ভাগে ধরা হয়। তবে "সদস্য" পেজে Admin প্রতিটা সদস্যের পাশে "হিসাবে গণনা" নামে একটা টগল দেখবেন — সেটা বন্ধ করলে সেই সদস্যকে ভাড়ার ভাগে আর ধরা হবে না (যেমন Admin নিজে মেসে না থাকলে, বা বুয়া যেহেতু স্টাফ)।' },
    ]
  },
  {
    cat: '👥 সদস্য ও ভূমিকা',
    items: [
      { q: 'Admin, Co-Admin, Member এর মধ্যে পার্থক্য কী?',
        a: 'Admin: সব নিয়ন্ত্রণ, role পরিবর্তন, মাস বন্ধ করা। Co-Admin: বাজার/জমা অনুমোদন, নোটিশ দেওয়া। Member: মিল এন্ট্রি, বাজার যোগ, রিপোর্ট দেখা।' },
      { q: 'একজন সদস্যের role কীভাবে পরিবর্তন করব?',
        a: '"সদস্য" পেজে গিয়ে সেই সদস্যের পাশের ড্রপডাউন থেকে নতুন role বেছে "💾 সেভ" বোতামে ক্লিক করুন। শুধু Admin এই কাজ করতে পারবেন।' },
      { q: 'কোনো সদস্যকে মেস থেকে বের করলে কী হয়?',
        a: 'সেই সদস্যের অ্যাকাউন্ট থেকে মেস access সাথে সাথে বাতিল হয়ে যায়, এবং সে নতুন মেস তৈরি বা join করার page এ চলে যায়।' },
      { q: 'বুয়ার জন্য আলাদা অ্যাকাউন্ট দেওয়া যায় কি?',
        a: 'হ্যাঁ। "সদস্য" পেজে Invite করার সময় বা কোনো সদস্যের role পরিবর্তনের ড্রপডাউনে "🧹 বুয়া" অপশন বেছে নিন। বুয়া role এর অ্যাকাউন্টে লগইন করলে শুধু "আজকের মিল" — কোন বেলায় কতজনের মিল আছে — সেটাই দেখতে পাবে, অন্য কোনো পেজ বা তথ্য দেখতে/পরিবর্তন করতে পারবে না।' },
      { q: 'বুয়াকে কি ভাড়া বা মিলের হিসাবে ধরা হয়?',
        a: 'ডিফল্ট ভাবে বুয়াকে বাড়ি ভাড়ার সমান-ভাগের হিসাবে ধরা হয় না (যেহেতু সে স্টাফ, বোর্ডার না)। চাইলে Admin "সদস্য" পেজ থেকে তার পাশের "হিসাবে গণনা" টগল চালু করে দিতে পারেন। Plan এর সদস্য সীমার (member limit) হিসাবে অবশ্য বুয়া ও Admin — উভয়েই অন্য সবার মতোই গণনা হবে।' },
    ]
  },
  {
    cat: '💳 Plan ও Payment',
    items: [
      { q: 'Free Plan এ কী কী সীমাবদ্ধতা আছে?',
        a: 'Free Plan এ সব ফিচার (মিল, বাজার, রিপোর্ট ইত্যাদি) সম্পূর্ণ চালু থাকে — শুধুমাত্র সর্বোচ্চ সদস্য সংখ্যার একটি সীমা থাকে (Admin নির্ধারণ করেন)।' },
      { q: 'Pro Plan কীভাবে কিনব?',
        a: 'Settings বা Sidebar থেকে "Pro Plan নিন" বাটনে ক্লিক করুন, পছন্দের Plan (Pro 10/15/Custom) ও Payment method (bKash/নগদ/Rocket) বেছে Transaction ID দিয়ে Submit করুন। Admin verify করলে Plan activate হবে।' },
      { q: 'Plan এর মেয়াদ শেষ হলে কী হবে?',
        a: 'মেসের নামের পাশে হলুদ "⚠️ Expired" ব্যাজ দেখাবে, এবং নির্ধারিত সদস্য সীমার বেশি নতুন সদস্য যোগ করা যাবে না — নবায়ন করতে হবে।' },
    ]
  },
  {
    cat: '📊 রিপোর্ট',
    items: [
      { q: 'মাসিক রিপোর্ট কীভাবে দেখব/ডাউনলোড করব?',
        a: '"রিপোর্ট" পেজে "মেস রিপোর্ট" বা "আমার রিপোর্ট" ট্যাব বেছে নিন, তারপর 📥 Excel বা 🖨️ PDF বোতামে ক্লিক করে ডাউনলোড করুন।' },
      { q: '"মাস বন্ধ" করলে কী হয়?',
        a: 'মাস বন্ধ করলে সেই মাসের চূড়ান্ত হিসাব সংরক্ষিত হয় এবং কেউ Meal, Bazar বা Deposit পরিবর্তন করতে পারবে না। শুধুমাত্র Admin এই কাজ করতে পারবেন।' },
    ]
  },
  {
    cat: '👤 প্রোফাইল',
    items: [
      { q: 'প্রোফাইল ছবি কীভাবে পরিবর্তন করব?',
        a: '"আমার প্রোফাইল" পেজে "📷 ছবি পরিবর্তন করুন" বোতামে ক্লিক করে যেকোনো ছবি বেছে নিন। ছবি স্বয়ংক্রিয়ভাবে ছোট (compress) হয়ে আপলোড হয়ে যাবে — Google অ্যাকাউন্টের ছবির উপর নির্ভর করার প্রয়োজন নেই।' },
      { q: 'নাম পরিবর্তন করা যাবে কি?',
        a: 'হ্যাঁ, "আমার প্রোফাইল" পেজে নাম লিখে "✓ আপডেট করুন" চাপলেই নতুন নাম সব জায়গায় (সদস্য তালিকা, রিপোর্ট ইত্যাদি) আপডেট হয়ে যাবে।' },
    ]
  },
  {
    cat: '🆕 সাম্প্রতিক আপডেট',
    items: [
      { q: 'সম্প্রতি অ্যাপে কী কী নতুন যোগ হয়েছে?',
        a: 'প্রোফাইল ছবি আপলোড, বাড়ি ভাড়ায় "বাসা ভাড়া" ফিল্ড, একসাথে অনেক দিনে একই বেলা মিল দেওয়ার বাল্ক অপশন, Admin/বুয়ার জন্য ভাড়ার হিসাব থেকে বাদ দেওয়ার টগল, বুয়ার জন্য শুধু আজকের মিল দেখার সীমিত অ্যাকাউন্ট, এবং মোবাইলে অ্যাপ দ্রুত চালানোর জন্য বেশ কিছু পারফরম্যান্স উন্নয়ন।' },
    ]
  },
];

export async function render(root, ctx) {
  const inMess = !!ctx?.messId;
  root.innerHTML = `
<div style="max-width:720px;margin:0 auto">
  <div style="text-align:center;margin-bottom:20px">
    <h2 style="font-size:19px;font-weight:700;color:var(--ink);margin-bottom:6px">❓ User Manual / FAQ</h2>
    <p style="font-size:13px;color:var(--ink3)">যেকোনো প্রশ্নের উত্তর এখানে খুঁজুন</p>
  </div>

  <div class="field" style="margin-bottom:20px">
    <input class="inp inp-sm" id="faq-search" placeholder="🔍 প্রশ্ন খুঁজুন…" style="font-size:13px"/>
  </div>

  <div id="faq-list"></div>

  ${inMess ? `
  <div class="card" style="margin-top:20px">
    <div class="cb" style="text-align:center;padding:20px">
      <p style="font-size:13px;color:var(--ink3);margin-bottom:10px">
        উত্তর খুঁজে পাননি? সরাসরি যোগাযোগ করুন
      </p>
      <button class="btn btn-p btn-sm" id="faq-go-contact">📩 Contact Us এ যান</button>
    </div>
  </div>` : ''}
</div>

<style>
.faq-cat{font-size:12px;font-weight:700;color:var(--g1);text-transform:uppercase;
  letter-spacing:.5px;margin:18px 0 8px}
.faq-cat:first-child{margin-top:0}
.faq-item{background:#fff;border:1px solid var(--line);border-radius:10px;
  margin-bottom:8px;overflow:hidden}
.faq-q{display:flex;align-items:center;justify-content:space-between;gap:10px;
  padding:13px 16px;cursor:pointer;font-size:13px;font-weight:600;color:var(--ink)}
.faq-q:hover{background:var(--paper)}
.faq-arrow{transition:.2s;flex-shrink:0;color:var(--ink4);font-size:12px}
.faq-item.open .faq-arrow{transform:rotate(180deg)}
.faq-a{max-height:0;overflow:hidden;transition:max-height .25s ease}
.faq-item.open .faq-a{max-height:400px}
.faq-a-inner{padding:0 16px 14px;font-size:12.5px;color:var(--ink3);line-height:1.7}
</style>`;

  _renderList(root, FAQ);

  root.querySelector('#faq-search').addEventListener('input', e => {
    const term = e.target.value.trim().toLowerCase();
    if (!term) { _renderList(root, FAQ); return; }
    const filtered = FAQ.map(cat => ({
      ...cat,
      items: cat.items.filter(i =>
        i.q.toLowerCase().includes(term) || i.a.toLowerCase().includes(term))
    })).filter(cat => cat.items.length > 0);
    _renderList(root, filtered, term);
  });

  root.querySelector('#faq-go-contact')?.addEventListener('click', () =>
    window.dispatchEvent(new CustomEvent('mm:navigate', { detail:{ page:'contact' } }))
  );
}

function _renderList(root, data, searchTerm = '') {
  const listEl = root.querySelector('#faq-list');
  if (!listEl) return;

  if (!data.length) {
    listEl.innerHTML = `<div style="text-align:center;padding:30px;color:var(--ink3);font-size:13px">
      কোনো ফলাফল পাওয়া যায়নি</div>`;
    return;
  }

  listEl.innerHTML = data.map(cat => `
<div class="faq-cat">${cat.cat}</div>
${cat.items.map((item, i) => `
<div class="faq-item${searchTerm?' open':''}">
  <div class="faq-q" data-toggle>
    <span>${_e(item.q)}</span>
    <span class="faq-arrow">▼</span>
  </div>
  <div class="faq-a"><div class="faq-a-inner">${_e(item.a)}</div></div>
</div>`).join('')}
`).join('');

  listEl.querySelectorAll('[data-toggle]').forEach(q => {
    q.addEventListener('click', () => {
      q.closest('.faq-item').classList.toggle('open');
    });
  });
}


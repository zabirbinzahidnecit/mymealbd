// মেস মিল ট্র্যাকার — profile.js (no storage needed)

import { db, storage } from '../../firebase.js';
import { toast, taka, pad, moName, ini, avColor, LANG, setLang, monthDocIdRange, monthDateRange, escapeHtml as _e } from '../../utils.js';
import { isPaid, isPlanExpired, requestPayment, getPlanDueInfo } from '../../plan.js';
import { compressImage } from '../../compress.js';
import { invalidateMembersCache } from '../../members-cache.js';
import {
  doc, updateDoc, collection, getDocs, query, where, writeBatch, serverTimestamp, documentId
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';
import {
  ref, uploadBytes, getDownloadURL
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js';

const TODAY = new Date();
let _ctx = {};

export async function render(root, ctx) {
  _ctx = ctx;
  const { profile } = ctx;
  const paid    = isPaid(ctx.messData);
  const expired = isPlanExpired(ctx.messData);
  const dueInfo = expired ? await getPlanDueInfo(ctx.messData) : { isExpired:false, monthsOverdue:0, dueAmount:0 };

  root.innerHTML = `
<div>
  <h2 style="font-size:17px;font-weight:700;color:var(--ink);margin-bottom:14px">👤 আমার প্রোফাইল</h2>

  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:13px">

    <!-- Avatar — এখন সরাসরি ছবি upload করা যাবে -->
    <div class="card">
      <div class="ch"><h3>🖼 প্রোফাইল ছবি</h3></div>
      <div class="cb" style="display:flex;flex-direction:column;align-items:center;gap:10px">
        <div id="prof-av-preview" style="width:80px;height:80px;border-radius:50%;border:3px solid var(--g4);
          overflow:hidden;display:flex;align-items:center;justify-content:center;
          font-size:28px;font-weight:700;background:var(--g7);color:var(--g1)">
          ${profile.avatar
            ? `<img src="${_e(profile.avatar)}" style="width:100%;height:100%;object-fit:cover" alt=""/>`
            : `<span>${ini(profile.name||profile.email)}</span>`}
        </div>
        <input type="file" id="prof-av-input" accept="image/*" style="display:none"/>
        <button class="btn btn-ghost btn-sm" id="prof-av-btn">📷 ছবি পরিবর্তন করুন</button>
        <p style="font-size:11px;color:var(--ink4);text-align:center">JPG/PNG, স্বয়ংক্রিয়ভাবে ছোট হয়ে যাবে</p>
        <div id="prof-av-msg" style="font-size:12px"></div>
      </div>
    </div>

    <!-- Info -->
    <div class="card">
      <div class="ch"><h3>📝 মূল তথ্য</h3></div>
      <div class="cb">
        <div class="field">
          <label class="lbl">নাম</label>
          <input class="inp inp-sm" id="prof-name" value="${_e(profile.name||'')}" placeholder="আপনার নাম"/>
        </div>
        <div class="field">
          <label class="lbl">Email</label>
          <input class="inp inp-sm" value="${_e(profile.email||'')}" disabled style="opacity:.6"/>
        </div>
        <div class="field">
          <label class="lbl">ভাষা</label>
          <select class="inp inp-sm" id="prof-lang">
            <option value="bn" ${LANG==='bn'?'selected':''}>বাংলা</option>
            <option value="en" ${LANG==='en'?'selected':''}>English</option>
          </select>
        </div>
        <button class="btn btn-p btn-sm" id="prof-save-btn">✓ আপডেট করুন</button>
        <div id="prof-msg" style="font-size:12px;margin-top:6px"></div>
      </div>
    </div>

    <!-- Plan -->
    <div class="card" style="border-color:${paid?'var(--g4)':expired?'#dc2626':'var(--a2)'}">
      <div class="ch">
        <h3>${paid?'⭐ Pro Plan':expired?'⚠️ Pro Plan (মেয়াদ শেষ)':'🆓 Free Plan'}</h3>
        ${paid
          ? `<span class="badge b-green">সক্রিয়</span>`
          : expired
          ? `<span class="badge" style="background:#fee2e2;color:#dc2626">বকেয়া আছে</span>`
          : `<span class="badge b-amber">বিজ্ঞাপন সহ</span>`}
      </div>
      <div class="cb">
        ${paid
          ? `<p style="font-size:12px;color:var(--ink3)">মেয়াদ: ${_expiry(ctx.messData?.planExpiry)}</p>`
          : expired
          ? `<p style="font-size:12px;color:var(--ink);margin-bottom:6px;line-height:1.6">
              এই মেসের Pro Plan-এর মেয়াদ <strong>${dueInfo.monthsOverdue} মাস</strong> আগে শেষ হয়েছে।
            </p>
            <p style="font-size:13px;color:#dc2626;font-weight:700;margin-bottom:12px">
              মোট বকেয়া: ৳${dueInfo.dueAmount} (নতুন মাস সহ)
            </p>
            <button class="btn btn-p btn-sm" id="upgrade-btn">⭐ বকেয়া দিয়ে Renew করুন</button>`
          : `<p style="font-size:12px;color:var(--ink3);margin-bottom:12px;line-height:1.6">
              Pro Plan এ upgrade করলে বিজ্ঞাপন থাকবে না।
            </p>
            <button class="btn btn-p btn-sm" id="upgrade-btn">⭐ Pro Upgrade</button>`}
      </div>
    </div>

    <!-- Monthly summary -->
    <div class="card">
      <div class="ch">
        <h3>📊 এই মাসের হিসাব</h3>
        <span style="font-size:11px;color:var(--ink3)">${moName(TODAY.getMonth())} ${TODAY.getFullYear()}</span>
      </div>
      <div class="cb" id="prof-summary">লোড হচ্ছে…</div>
    </div>

    <!-- Leave mess -->
    <div class="card" style="border-color:var(--r3)">
      <div class="ch"><h3 style="color:var(--r1)">🚪 মেস ছাড়ুন</h3></div>
      <div class="cb">
        <p style="font-size:12px;color:var(--ink3);margin-bottom:12px;line-height:1.6">
          মেস ছাড়লে আপনার data থাকবে কিন্তু মেসে আর access থাকবে না।
        </p>
        <button class="btn btn-danger btn-sm" id="prof-leave-btn">মেস ছাড়ুন</button>
      </div>
    </div>
  </div>
</div>`;

  root.querySelector('#prof-save-btn').addEventListener('click', () => _save(root));
  root.querySelector('#prof-leave-btn').addEventListener('click', () => _leave());
  root.querySelector('#prof-av-btn')?.addEventListener('click', () => root.querySelector('#prof-av-input')?.click());
  root.querySelector('#prof-av-input')?.addEventListener('change', e => _uploadPhoto(root, e.target.files?.[0]));
  root.querySelector('#upgrade-btn')?.addEventListener('click', () =>
    requestPayment(ctx.messId, ctx.profile, ctx.messData)
  );

  await _loadSummary(root);
}

async function _uploadPhoto(root, file) {
  if (!file) return;
  if (!file.type.startsWith('image/')) { toast('শুধু ছবি ফাইল দিন','er'); return; }

  const msg = root.querySelector('#prof-av-msg');
  const btn = root.querySelector('#prof-av-btn');
  if (msg) { msg.textContent = 'ছবি প্রসেস হচ্ছে…'; msg.style.color='var(--ink3)'; }
  if (btn) btn.disabled = true;

  try {
    const blob = await compressImage(file, 200, 400);
    const fileRef = ref(storage, `avatars/${_ctx.profile.uid}/avatar.jpg`);
    await uploadBytes(fileRef, blob, { contentType:'image/jpeg' });
    const url = await getDownloadURL(fileRef);

    await Promise.all([
      updateDoc(doc(db,'users',_ctx.profile.uid), { avatar: url }),
      updateDoc(doc(db,'messes',_ctx.messId,'members',_ctx.profile.uid), { avatar: url }),
    ]);

    _ctx.profile.avatar = url;
    invalidateMembersCache();
    const preview = root.querySelector('#prof-av-preview');
    if (preview) preview.innerHTML = `<img src="${_e(url)}" style="width:100%;height:100%;object-fit:cover" alt=""/>`;
    // sidebar avatar update
    const sbAv = document.querySelector('.sb-av');
    if (sbAv) sbAv.innerHTML = `<img src="${_e(url)}" alt=""/>`;

    if (msg) { msg.textContent = '✓ ছবি আপডেট হয়েছে'; msg.style.color='var(--g1)'; }
    toast('প্রোফাইল ছবি আপডেট হয়েছে', 'ok');
  } catch(err) {
    if (msg) { msg.textContent = 'ব্যর্থ: '+err.message; msg.style.color='var(--r2)'; }
    toast('ছবি আপলোড ব্যর্থ: '+err.message, 'er');
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function _save(root) {
  const name = root.querySelector('#prof-name')?.value.trim();
  const lang = root.querySelector('#prof-lang')?.value || 'bn';
  if (!name) { toast('নাম দিন', 'er'); return; }

  const btn = root.querySelector('#prof-save-btn');
  if (btn) { btn.disabled=true; btn.textContent='সেভ হচ্ছে…'; }

  try {
    await Promise.all([
      updateDoc(doc(db,'users',_ctx.profile.uid), { name }),
      updateDoc(doc(db,'messes',_ctx.messId,'members',_ctx.profile.uid), { name }),
    ]);
    _ctx.profile.name = name;
    invalidateMembersCache();
    setLang(lang);
    const msg = root.querySelector('#prof-msg');
    if (msg) { msg.textContent='✓ আপডেট হয়েছে'; msg.style.color='var(--g1)'; }
    toast('প্রোফাইল আপডেট হয়েছে', 'ok');
    // sidebar name update
    const sbName = document.getElementById('sb-mess-name');
    if (sbName && _ctx.messData?.name) sbName.textContent = _ctx.messData.name;
  } catch(err) {
    toast('ব্যর্থ: '+err.message, 'er');
  } finally {
    if (btn) { btn.disabled=false; btn.textContent='✓ আপডেট করুন'; }
  }
}

async function _loadSummary(root) {
  const el = root.querySelector('#prof-summary');
  if (!el) return;
  const monthStr    = `${TODAY.getFullYear()}-${pad(TODAY.getMonth()+1)}`;

  try {
    // ✅ ফিক্স: আগে পুরো মেসের সব মাসের সব মিল ডকুমেন্ট টানত (ALL-TIME scan!),
    // তারপর client-side এ ফিল্টার করে শুধু নিজের এই মাসের গণনা বের করত।
    // এটাই ছিল profile পেজ ধীর হওয়ার একটা বড় কারণ। এখন শুধু এই মাসের
    // রেঞ্জেই সরাসরি query হবে।
    const { start, end } = monthDocIdRange(TODAY.getFullYear(), TODAY.getMonth());
    const mealSnap = await getDocs(query(
      collection(db,'messes',_ctx.messId,'meals'),
      where(documentId(), '>=', start),
      where(documentId(), '<', end)
    ));
    let myMeals = 0;
    mealSnap.forEach(d => {
      if (d.id.endsWith('_'+_ctx.profile.uid)) {
        myMeals += (d.data().slots||[]).filter(Boolean).length;
        myMeals += (d.data().guestSlots||[]).filter(Boolean).length;
      }
    });

    const { start:dStart, end:dEnd } = monthDateRange(TODAY.getFullYear(), TODAY.getMonth());
    const depSnap = await getDocs(query(
      collection(db,'messes',_ctx.messId,'deposits'),
      where('memberId','==',_ctx.profile.uid),
      where('status','==','approved'),
      where('date','>=',dStart), where('date','<',dEnd)
    ));
    let myDeposit = 0;
    depSnap.forEach(d => {
      if (d.data().date?.startsWith(monthStr))
        myDeposit += parseFloat(d.data().amount)||0;
    });

    el.innerHTML = `
<div class="g2" style="gap:8px">
  <div class="sc sg">
    <div class="sl">আমার মিল</div>
    <div class="sv" style="font-size:20px">${myMeals}</div>
    <div class="ss">এই মাসে</div>
  </div>
  <div class="sc sc-blue">
    <div class="sl">আমার জমা</div>
    <div class="sv" style="font-size:20px">${taka(myDeposit)}</div>
    <div class="ss">এই মাসে</div>
  </div>
</div>`;
  } catch(err) {
    el.innerHTML = '<p style="font-size:12px;color:var(--r1)">লোড ব্যর্থ</p>';
  }
}

async function _leave() {
  // ✅ Loophole-প্রতিরোধ: কেউ যদি এই মেসের একমাত্র mess-admin হয়, তাকে
  // ছাড়তে দেওয়া হবে না — নাহলে trial/plan শেষ হওয়া মেস ছেড়ে সাথে সাথে
  // নতুন মেস বানিয়ে ফ্রেশ ফ্রি ট্রায়াল নেওয়া সম্ভব হতো, আর পুরনো মেসের
  // বাকি সদস্যরা কোনো অ্যাডমিন ছাড়াই আটকে যেত।
  if (_ctx.myMessRole === 'mess-admin') {
    try {
      const membersSnap = await getDocs(collection(db,'messes',_ctx.messId,'members'));
      const otherAdmins = membersSnap.docs.filter(d =>
        d.id !== _ctx.profile.uid && d.data().role === 'mess-admin');
      if (otherAdmins.length === 0) {
        toast('আপনি এই মেসের একমাত্র অ্যাডমিন — আগে অন্য কাউকে "সদস্য" পেজ থেকে mess-admin বানান, তারপর মেস ছাড়তে পারবেন।', 'er');
        return;
      }
    } catch(err) {
      toast('চেক করতে ব্যর্থ: '+err.message, 'er');
      return;
    }
  }
  if (!window.confirm('আপনি কি সত্যিই এই মেস ছাড়তে চান?')) return;
  try {
    const batch = writeBatch(db);
    batch.delete(doc(db,'messes',_ctx.messId,'members',_ctx.profile.uid));
    batch.update(doc(db,'users',_ctx.profile.uid), { currentMessId:null, status:'pending' });
    await batch.commit();
    toast('আপনি মেস ছেড়েছেন', 'ok');
    setTimeout(() => location.reload(), 800);
  } catch(err) {
    toast('ব্যর্থ: '+err.message, 'er');
  }
}

function _expiry(ts) {
  if (!ts) return '—';
  const d = ts?.toDate ? ts.toDate() : new Date(ts);
  return `${d.getDate()}/${d.getMonth()+1}/${d.getFullYear()}`;
}


// poll.js — v11: fixed Timestamp bug, expired filter, removed inline onclick

import { db } from '../../firebase.js';
import { toast, ld, uld, formatDate, escapeHtml as _e } from '../../utils.js';
import {
  collection, getDocs, addDoc, doc, updateDoc, deleteDoc,
  query, orderBy, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _ctx={}, _polls=[];

export async function render(root, ctx) {
  _ctx = ctx;
  const isAdmin = ['mess-admin','mess-co-admin'].includes(ctx.myMessRole);

  root.innerHTML = `
<div>
  <div style="display:flex;align-items:center;justify-content:space-between;
    margin-bottom:14px;flex-wrap:wrap;gap:8px">
    <div>
      <h2 style="font-size:17px;font-weight:700;color:var(--ink);margin:0">🗳️ Meal Poll</h2>
      <p style="font-size:12px;color:var(--ink3);margin:3px 0 0">আজকের রান্নায় vote দিন</p>
    </div>
    <div style="display:flex;gap:6px;align-items:center">
      <label style="display:flex;align-items:center;gap:5px;font-size:12px;color:var(--ink3);cursor:pointer">
        <input type="checkbox" id="poll-show-expired"> মেয়াদ শেষ দেখুন
      </label>
      <button class="btn btn-ghost btn-sm" id="poll-refresh">🔄</button>
    </div>
  </div>

  ${isAdmin ? `
  <div class="card" style="margin-bottom:14px">
    <div class="ch"><h3>➕ নতুন Poll তৈরি করুন</h3></div>
    <div class="cb">
      <div class="field">
        <label class="lbl">প্রশ্ন *</label>
        <input class="inp inp-sm" id="poll-question"
          placeholder="যেমন: আজকের দুপুরের রান্না কী হবে?" maxlength="150"/>
      </div>
      <div class="field">
        <label class="lbl">Options (একটি করে লিখুন)</label>
        <div id="poll-options-list" style="display:flex;flex-direction:column;gap:6px;margin-bottom:8px">
          <div style="display:flex;gap:6px" class="poll-opt-row">
            <input class="inp inp-sm poll-opt" placeholder="Option ১" maxlength="60" style="flex:1"/>
            <button class="btn btn-xs btn-ghost poll-opt-del">✕</button>
          </div>
          <div style="display:flex;gap:6px" class="poll-opt-row">
            <input class="inp inp-sm poll-opt" placeholder="Option ২" maxlength="60" style="flex:1"/>
            <button class="btn btn-xs btn-ghost poll-opt-del">✕</button>
          </div>
        </div>
        <button class="btn btn-ghost btn-sm" id="add-opt-btn">+ Option যোগ করুন</button>
      </div>
      <div style="display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap">
        <div class="field" style="margin:0;flex:1;min-width:120px">
          <label class="lbl">শেষ হবে</label>
          <select class="inp inp-sm" id="poll-expires">
            <option value="1">১ ঘণ্টা পরে</option>
            <option value="3">৩ ঘণ্টা পরে</option>
            <option value="6" selected>৬ ঘণ্টা পরে</option>
            <option value="12">১২ ঘণ্টা পরে</option>
            <option value="24">২৪ ঘণ্টা পরে</option>
          </select>
        </div>
        <button class="btn btn-p btn-sm" id="poll-create-btn">🗳️ Poll তৈরি করুন</button>
      </div>
    </div>
  </div>` : ''}

  <div id="poll-list" style="display:flex;flex-direction:column;gap:12px">
    <div style="padding:20px;text-align:center;color:var(--ink3)">লোড হচ্ছে…</div>
  </div>
</div>

<style>
.poll-card{background:#fff;border:1px solid var(--line);border-radius:14px;
  padding:16px;box-shadow:var(--sh)}
.poll-q{font-size:14px;font-weight:700;color:var(--ink);margin-bottom:4px}
.poll-meta{font-size:11px;color:var(--ink3);margin-bottom:14px}
.poll-opt-bar{height:36px;border-radius:8px;border:1.5px solid var(--line2);
  background:var(--paper);position:relative;overflow:hidden;flex:1;
  display:flex;align-items:center;padding:0 10px;transition:.3s;cursor:pointer}
.poll-opt-fill{position:absolute;top:0;left:0;bottom:0;background:var(--g7);
  border-radius:6px;transition:width .4s ease}
.poll-opt-fill.voted{background:rgba(20,107,64,.2)}
.poll-opt-label{position:relative;z-index:1;font-size:13px;color:var(--ink);flex:1}
.poll-opt-count{position:relative;z-index:1;font-size:12px;font-weight:700;color:var(--g1)}
.poll-opt-pct{position:relative;z-index:1;font-size:11px;color:var(--ink3);min-width:35px;text-align:right}
</style>`;

  root.querySelector('#poll-refresh').addEventListener('click', ()=> _load(root));
  root.querySelector('#poll-show-expired').addEventListener('change', ()=> _render(root));

  // ✅ FIXED: addEventListener instead of inline onclick for option delete
  root.querySelector('#poll-options-list').addEventListener('click', e=>{
    if (e.target.closest('.poll-opt-del')) {
      const row = e.target.closest('.poll-opt-row');
      if (root.querySelectorAll('.poll-opt-row').length > 2) row?.remove();
      else toast('কমপক্ষে ২টি option থাকতে হবে','er');
    }
  });

  root.querySelector('#add-opt-btn')?.addEventListener('click', ()=>{
    const list = root.querySelector('#poll-options-list');
    const n    = list.querySelectorAll('.poll-opt').length + 1;
    const div  = document.createElement('div');
    div.style.cssText = 'display:flex;gap:6px';
    div.className = 'poll-opt-row';
    div.innerHTML = `
      <input class="inp inp-sm poll-opt" placeholder="Option ${n}" maxlength="60" style="flex:1"/>
      <button class="btn btn-xs btn-ghost poll-opt-del">✕</button>`;
    list.appendChild(div);
  });

  root.querySelector('#poll-create-btn')?.addEventListener('click', ()=> _create(root));

  // Event delegation for vote and delete
  root.querySelector('#poll-list').addEventListener('click', e=>{
    const voteBtn = e.target.closest('[data-vote-opt]');
    const delBtn  = e.target.closest('[data-del-poll]');
    if (voteBtn) _vote(root, voteBtn.dataset.pollId, parseInt(voteBtn.dataset.voteOpt));
    if (delBtn)  _delete(root, delBtn.dataset.delPoll);
  });

  await _load(root);
}

async function _load(root) {
  ld('Poll লোড হচ্ছে…');
  try {
    const snap = await getDocs(query(
      collection(db,'messes',_ctx.messId,'polls'), orderBy('createdAt','desc')
    ));
    _polls = snap.docs.map(d=>({id:d.id,...d.data()}));
    _render(root);
  } catch(err) {
    root.querySelector('#poll-list').innerHTML =
      `<div style="padding:20px;text-align:center;color:var(--r1)">⚠️ ${_e(err.message)}</div>`;
  } finally { uld(); }
}

function _toDate(ts) {
  // ✅ FIXED: Handle all Timestamp shapes correctly
  if (!ts) return new Date(0);
  if (typeof ts.toDate === 'function') return ts.toDate();
  if (ts.seconds !== undefined) return new Date(ts.seconds * 1000);
  return new Date(ts);
}

function _render(root) {
  const list        = root.querySelector('#poll-list');
  const isAdmin     = ['mess-admin','mess-co-admin'].includes(_ctx.myMessRole);
  const uid         = _ctx.profile.uid;
  const now         = new Date();
  const showExpired = root.querySelector('#poll-show-expired')?.checked;

  const visible = _polls.filter(p=>{
    const expiry = _toDate(p.expiresAt);
    return showExpired || expiry > now;
  });

  if (!visible.length) {
    list.innerHTML=`<div class="card"><div class="cb" style="text-align:center;padding:24px;color:var(--ink3)">
<div style="font-size:32px;margin-bottom:8px">🗳️</div>
<p>${showExpired ? 'কোনো poll নেই' : 'কোনো active poll নেই'}</p>
${isAdmin?'<p style="font-size:12px;margin-top:6px">উপরে নতুন poll তৈরি করুন</p>':''}
</div></div>`;
    return;
  }

  list.innerHTML = visible.map(p=>{
    const expiry     = _toDate(p.expiresAt);
    const expired    = expiry < now;
    const myVote     = p.votes?.[uid];
    const hasVoted   = myVote !== undefined;
    const totalVotes = Object.keys(p.votes||{}).length;
    const timeLeft   = !expired ? _timeLeft(expiry) : '';

    return `
<div class="poll-card">
  <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:4px">
    <div class="poll-q" style="flex:1">${_e(p.question)}</div>
    ${expired?`<span style="font-size:10px;font-weight:700;color:var(--r1);
      background:var(--r4);border-radius:6px;padding:2px 7px;white-space:nowrap;flex-shrink:0">শেষ</span>`:''}
  </div>
  <div class="poll-meta">
    📅 ${formatDate(p.createdAt)}
    ${!expired ? ` · ⏳ ${timeLeft} বাকি` : ''}
    · ${totalVotes}জন vote দিয়েছেন
  </div>

  <div style="${expired?'opacity:.7':''}">
    ${(p.options||[]).map((opt,i)=>{
      const count = Object.values(p.votes||{}).filter(v=>v===i).length;
      const pct   = totalVotes>0 ? Math.round((count/totalVotes)*100) : 0;
      const voted = myVote===i;
      const show  = hasVoted || expired;
      return `
<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
  <div class="poll-opt-bar" ${!expired&&!hasVoted?`data-vote-opt="${i}" data-poll-id="${p.id}"`:''}>
    ${show?`<div class="poll-opt-fill${voted?' voted':''}" style="width:${pct}%"></div>`:''}
    <span class="poll-opt-label">${voted?'✓ ':''} ${_e(opt)}</span>
    ${show?`<span class="poll-opt-count">${count}</span>
            <span class="poll-opt-pct">${pct}%</span>`:''}
  </div>
  ${!expired&&!hasVoted?`<button class="btn btn-ghost btn-xs" style="flex-shrink:0"
    data-vote-opt="${i}" data-poll-id="${p.id}">Vote</button>`:''}
</div>`;
    }).join('')}
  </div>

  ${isAdmin?`
  <div style="margin-top:12px;padding-top:10px;border-top:1px solid var(--line)">
    <button class="btn btn-xs btn-danger" data-del-poll="${p.id}">🗑 Poll মুছুন</button>
  </div>`:''}
</div>`;
  }).join('');
}

function _timeLeft(expiry) {
  const diff = expiry - new Date();
  if (diff <= 0) return '০ মিনিট';
  const h = Math.floor(diff/3600000);
  const m = Math.floor((diff%3600000)/60000);
  return h>0 ? `${h} ঘণ্টা ${m} মিনিট` : `${m} মিনিট`;
}

async function _create(root) {
  const question = root.querySelector('#poll-question')?.value.trim();
  const options  = [...root.querySelectorAll('.poll-opt')].map(i=>i.value.trim()).filter(Boolean);
  const hours    = parseInt(root.querySelector('#poll-expires')?.value)||6;

  if (!question)       { toast('প্রশ্ন লিখুন','er'); return; }
  if (options.length<2){ toast('কমপক্ষে ২টি option দিন','er'); return; }

  const btn = root.querySelector('#poll-create-btn');
  if (btn) { btn.disabled=true; btn.textContent='তৈরি হচ্ছে…'; }
  ld('Poll তৈরি হচ্ছে…');
  try {
    const expiresAt = new Date(Date.now() + hours*3600000);
    await addDoc(collection(db,'messes',_ctx.messId,'polls'), {
      question, options, votes:{},
      createdBy: _ctx.profile.uid, createdByName: _ctx.profile.name||'',
      createdAt: serverTimestamp(),
      expiresAt, active: true,
    });
    root.querySelector('#poll-question').value='';
    root.querySelectorAll('.poll-opt').forEach(i=>i.value='');
    toast('Poll তৈরি হয়েছে ✓','ok');
    await _load(root);
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
  finally {
    if (btn) { btn.disabled=false; btn.textContent='🗳️ Poll তৈরি করুন'; }
    uld();
  }
}

async function _vote(root, pollId, optIdx) {
  const poll = _polls.find(p=>p.id===pollId);
  if (!poll) return;
  const uid = _ctx.profile.uid;
  if (poll.votes?.[uid] !== undefined) { toast('আপনি ইতিমধ্যে vote দিয়েছেন','er'); return; }
  if (_toDate(poll.expiresAt) < new Date()) { toast('Poll শেষ হয়ে গেছে','er'); return; }
  try {
    await updateDoc(doc(db,'messes',_ctx.messId,'polls',pollId),{[`votes.${uid}`]: optIdx});
    if (!poll.votes) poll.votes={};
    poll.votes[uid] = optIdx;
    _render(root);
    toast('Vote দেওয়া হয়েছে ✓','ok');
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
}

async function _delete(root, pollId) {
  if (!window.confirm('Poll মুছে ফেলবেন?')) return;
  try {
    await deleteDoc(doc(db,'messes',_ctx.messId,'polls',pollId));
    _polls = _polls.filter(p=>p.id!==pollId);
    _render(root);
    toast('Poll মুছে ফেলা হয়েছে','ok');
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
}


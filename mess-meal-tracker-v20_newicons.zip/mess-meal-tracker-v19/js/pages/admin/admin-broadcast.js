// admin-broadcast.js — সব মেসে বা নির্দিষ্ট মেসে notice পাঠানো

import { db } from '../../firebase.js';
import { toast, ld, uld, formatDate, escapeHtml as _e } from '../../utils.js';
import { currentProfile } from '../../auth.js';
import {
  collection, getDocs, addDoc, deleteDoc,
  doc, query, orderBy, serverTimestamp, writeBatch
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _messes=[], _notices=[];

export async function render(root) {
  root.innerHTML = `
<div>
  <div class="adp-hd">
    <div>
      <h2 class="adp-h">📢 Broadcast Notice</h2>
      <p class="adp-sub">সব মেসে বা নির্দিষ্ট মেসে notice পাঠান</p>
    </div>
    <button class="btn btn-ghost btn-sm" id="bc-refresh">🔄 রিফ্রেশ</button>
  </div>

  <!-- Send form -->
  <div class="card" style="margin-bottom:14px">
    <div class="ch"><h3>✏️ নতুন Notice পাঠান</h3></div>
    <div class="cb">
      <div class="field">
        <label class="lbl">কোথায় পাঠাবেন?</label>
        <select class="inp inp-sm" id="bc-target">
          <option value="all">সব মেসে (Global)</option>
        </select>
      </div>
      <div class="field">
        <label class="lbl">Notice *</label>
        <textarea class="inp" id="bc-text" rows="4"
          style="resize:vertical;min-height:90px"
          placeholder="Notice এর বিষয় লিখুন… (সর্বোচ্চ ৫০০ অক্ষর)"
          maxlength="500"></textarea>
        <div style="display:flex;justify-content:space-between;margin-top:4px">
          <span style="font-size:11px;color:var(--ink4)" id="bc-char">0/500</span>
          <span style="font-size:11px;color:var(--ink4)">
            Global notice সব মেসের সব সদস্য দেখতে পাবে
          </span>
        </div>
      </div>
      <button class="btn btn-p btn-sm" id="bc-send-btn">📤 Notice পাঠান</button>
    </div>
  </div>

  <!-- Global notices list -->
  <div class="card">
    <div class="ch">
      <h3>🌐 Global Notice ইতিহাস</h3>
      <span style="font-size:11px;color:var(--ink3)" id="bc-count"></span>
    </div>
    <div id="bc-list" style="padding:4px 0">লোড হচ্ছে…</div>
  </div>
</div>

<style>
.bc-item{padding:12px 14px;border-bottom:.5px solid var(--line)}
.bc-item:last-child{border-bottom:none}
.bc-item p{font-size:13px;color:var(--ink);line-height:1.5;white-space:pre-wrap;word-break:break-word}
.bc-item .bc-meta{display:flex;align-items:center;justify-content:space-between;
  margin-top:8px;flex-wrap:wrap;gap:6px}
.bc-item .bc-meta span{font-size:11px;color:var(--ink4)}
.bc-target-badge{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;
  border-radius:20px;font-size:10px;font-weight:700}
.bc-global{background:var(--b4);color:var(--b0)}
.bc-mess{background:var(--g7);color:var(--g1)}
</style>`;

  // Character counter
  const txt = root.querySelector('#bc-text');
  if (txt) {
    txt.addEventListener('input', ()=>{
      const c = root.querySelector('#bc-char');
      if (c) c.textContent = `${txt.value.length}/500`;
    });
  }

  root.querySelector('#bc-refresh').addEventListener('click', ()=> _load(root));
  root.querySelector('#bc-send-btn').addEventListener('click', ()=> _send(root));
  root.querySelector('#bc-list').addEventListener('click', e=>{
    const dl = e.target.closest('[data-delete]');
    if (dl) _delete(root, dl.dataset.delete);
  });

  await _loadMesses(root);
  await _load(root);
}

async function _loadMesses(root) {
  try {
    const snap = await getDocs(collection(db,'messes'));
    _messes = snap.docs.map(d=>({id:d.id,...d.data()})).filter(m=>m.status==='active');
    const sel = root.querySelector('#bc-target');
    if (sel) {
      sel.innerHTML = `<option value="all">🌐 সব মেসে (Global)</option>` +
        _messes.map(m=>`<option value="${m.id}">🏠 ${_e(m.name||'অজানা')}</option>`).join('');
    }
  } catch(e) {}
}

async function _load(root) {
  ld('Notice লোড হচ্ছে…');
  try {
    const snap = await getDocs(query(
      collection(db,'globalNotices'), orderBy('createdAt','desc')
    ));
    _notices = snap.docs.map(d=>({id:d.id,...d.data()}));
    const c = root.querySelector('#bc-count');
    if (c) c.textContent = `মোট ${_notices.length}টি`;
    _renderList(root);
  } catch(err) {
    root.querySelector('#bc-list').innerHTML =
      `<div style="padding:20px;text-align:center;color:var(--r1)">⚠️ ${err.message}</div>`;
  } finally { uld(); }
}

function _renderList(root) {
  const list = root.querySelector('#bc-list');
  if (!list) return;
  if (!_notices.length) {
    list.innerHTML='<div style="padding:20px;text-align:center;color:var(--ink3)">কোনো global notice নেই</div>';
    return;
  }
  list.innerHTML = _notices.map(n=>{
    const isGlobal = !n.targetMessId || n.targetMessId==='all';
    const messName = isGlobal ? null : _messes.find(m=>m.id===n.targetMessId)?.name;
    return `
<div class="bc-item">
  <p>${_e(n.text||'')}</p>
  <div class="bc-meta">
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
      <span class="bc-target-badge ${isGlobal?'bc-global':'bc-mess'}">
        ${isGlobal?'🌐 সব মেস':'🏠 '+_e(messName||n.targetMessId)}
      </span>
      <span>— ${_e(n.sentByName||'Admin')} · ${n.createdAt?formatDate(n.createdAt):'—'}</span>
    </div>
    <button class="btn btn-xs btn-danger" data-delete="${n.id}">🗑 মুছুন</button>
  </div>
</div>`;
  }).join('');
}

async function _send(root) {
  const text   = root.querySelector('#bc-text')?.value.trim();
  const target = root.querySelector('#bc-target')?.value;
  if (!text) { toast('Notice লিখুন','er'); return; }

  const targetLabel = target==='all' ? 'সব মেসে' :
    (_messes.find(m=>m.id===target)?.name||'নির্দিষ্ট মেসে');

  if (!window.confirm(`"${targetLabel}" notice পাঠাবেন?`)) return;

  const btn = root.querySelector('#bc-send-btn');
  if (btn) { btn.disabled=true; btn.textContent='পাঠানো হচ্ছে…'; }
  ld('Notice পাঠানো হচ্ছে…');

  try {
    // Global notice collection এ save
    await addDoc(collection(db,'globalNotices'), {
      text,
      targetMessId:  target,
      sentBy:        currentProfile?.uid||'',
      sentByName:    currentProfile?.name||'Admin',
      createdAt:     serverTimestamp(),
    });

    // নির্দিষ্ট মেস হলে সেই মেসের notices collection এও save
    if (target !== 'all') {
      await addDoc(collection(db,'messes',target,'notices'), {
        text,
        addedBy:     currentProfile?.uid||'',
        addedByName: currentProfile?.name||'Admin',
        isGlobal:    false,
        createdAt:   serverTimestamp(),
      });
    }

    root.querySelector('#bc-text').value = '';
    root.querySelector('#bc-char').textContent = '0/500';
    toast('Notice পাঠানো হয়েছে ✓','ok');
    await _load(root);
  } catch(err) {
    toast('পাঠানো যায়নি: '+err.message,'er');
  } finally {
    if (btn) { btn.disabled=false; btn.textContent='📤 Notice পাঠান'; }
    uld();
  }
}

async function _delete(root, noticeId) {
  if (!window.confirm('Notice মুছে ফেলবেন?')) return;
  try {
    await deleteDoc(doc(db,'globalNotices',noticeId));
    _notices = _notices.filter(n=>n.id!==noticeId);
    _renderList(root);
    const c = root.querySelector('#bc-count');
    if (c) c.textContent = `মোট ${_notices.length}টি`;
    toast('মুছে ফেলা হয়েছে','ok');
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
}


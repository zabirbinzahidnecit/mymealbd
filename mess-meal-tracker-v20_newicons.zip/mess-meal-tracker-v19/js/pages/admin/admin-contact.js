// admin-contact.js — v18: Platform admin views & replies to contact messages,
// and can set the contact email shown to users

import { db } from '../../firebase.js';
import { toast, ld, uld, formatDate, escapeHtml as _e } from '../../utils.js';
import { getCachedAppConfig, invalidateAppConfigCache } from '../../app-config-cache.js';
import {
  collection, getDocs, doc, getDoc, setDoc, updateDoc,
  query, orderBy, where, writeBatch, Timestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _messages = [], _filter = 'all', _roleFilter = 'all';

export async function render(root, { profile }) {
  root.innerHTML = `
<div>
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px">
    <h2 style="font-size:17px;font-weight:700;color:#0a180e;margin:0">📩 Contact Messages</h2>
    <button class="btn btn-ghost btn-sm" id="ac-refresh">🔄</button>
  </div>

  <!-- Contact email setting -->
  <div class="card" style="margin-bottom:14px">
    <div class="ch"><h3>📧 যোগাযোগ ইমেইল</h3></div>
    <div class="cb">
      <p style="font-size:12px;color:var(--ink3);margin-bottom:10px">
        এই ইমেইল ঠিকানা সব user এর Contact Us page এ দেখাবে।
      </p>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <input class="inp inp-sm" id="ac-email-inp" type="email"
          placeholder="support@example.com" style="flex:1;min-width:200px"/>
        <button class="btn btn-p btn-sm" id="ac-email-save">✓ সংরক্ষণ</button>
      </div>
    </div>
  </div>

  <!-- Old-message TTL backfill -->
  <div class="card" style="margin-bottom:14px">
    <div class="ch"><h3>🗑 পুরনো মেসেজ Auto-Delete Backfill</h3></div>
    <div class="cb">
      <p style="font-size:12px;color:var(--ink3);margin-bottom:10px">
        নতুন মেসেজ ৩০ দিন পর স্বয়ংক্রিয়ভাবে মুছে যায় (Firestore TTL)। কিন্তু এই ফিচার
        চালুর <strong>আগে</strong> পাঠানো পুরনো মেসেজগুলোতে TTL ফিল্ড নেই, তাই সেগুলো
        auto-delete হবে না — এই বাটনে ক্লিক করলে সেই পুরনো মেসেজগুলোতেও TTL ফিল্ড
        (তৈরির তারিখ থেকে ৩০ দিন) বসিয়ে দেওয়া হবে, একবারই লাগবে।
      </p>
      <button class="btn btn-ghost btn-sm" id="ac-backfill-ttl">🔄 পুরনো মেসেজ Backfill করুন</button>
      <span id="ac-backfill-status" style="font-size:12px;color:var(--ink3);margin-left:8px"></span>
    </div>
  </div>

  <!-- Filters -->
  <div class="adm-tabs" style="margin-bottom:8px">
    <button class="adm-tab active" data-f="all">সব</button>
    <button class="adm-tab" data-f="unread">⏳ অপেক্ষমান</button>
    <button class="adm-tab" data-f="read">👁 দেখা হয়েছে</button>
    <button class="adm-tab" data-f="replied">✓ উত্তর দেওয়া</button>
  </div>

  <!-- Source filter: Mess Admin vs Member -->
  <div class="adm-tabs" style="margin-bottom:12px">
    <button class="adm-role-tab active" data-r="all" style="background:var(--paper)">📨 সব উৎস</button>
    <button class="adm-role-tab" data-r="mess-admin">🔑 Mess Admin বার্তা</button>
    <button class="adm-role-tab" data-r="member">👤 সদস্য বার্তা</button>
  </div>

  <div id="ac-list" style="display:flex;flex-direction:column;gap:10px">
    <div style="padding:30px;text-align:center;color:#4a7055">লোড হচ্ছে…</div>
  </div>
</div>

<!-- Reply modal -->
<div id="ac-reply-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);
  z-index:1000;align-items:center;justify-content:center;padding:20px">
  <div style="background:#fff;border-radius:16px;padding:22px;max-width:480px;
    width:100%;max-height:85vh;overflow-y:auto">
    <h3 style="font-size:15px;font-weight:700;margin-bottom:4px">✍️ উত্তর দিন</h3>
    <p style="font-size:11px;color:#8aaa90;margin-bottom:14px" id="ac-reply-to"></p>
    <div style="background:#f1f5f2;border-radius:10px;padding:10px;margin-bottom:14px;
      font-size:12px;color:#243a2c;max-height:120px;overflow-y:auto" id="ac-reply-original"></div>
    <textarea id="ac-reply-text" rows="5" maxlength="1000"
      style="width:100%;border:1px solid #b0ceb8;border-radius:8px;padding:10px;
      font-family:inherit;font-size:13px;resize:vertical" placeholder="আপনার উত্তর লিখুন…"></textarea>
    <div style="display:flex;gap:8px;margin-top:14px">
      <button id="ac-reply-cancel" class="btn btn-ghost" style="flex:1">বাতিল</button>
      <button id="ac-reply-submit" class="btn btn-p" style="flex:1">✓ উত্তর পাঠান</button>
    </div>
  </div>
</div>`;

  root.querySelector('#ac-refresh').addEventListener('click', ()=> _load(root));
  root.querySelector('#ac-email-save').addEventListener('click', ()=> _saveEmail(root));
  root.querySelector('#ac-backfill-ttl').addEventListener('click', e=> _backfillTTL(e.target));
  root.querySelectorAll('.adm-tab').forEach(b=>
    b.addEventListener('click', ()=>{
      _filter = b.dataset.f;
      root.querySelectorAll('.adm-tab').forEach(x=>x.classList.toggle('active', x===b));
      _render(root);
    })
  );
  root.querySelectorAll('.adm-role-tab').forEach(b=>
    b.addEventListener('click', ()=>{
      _roleFilter = b.dataset.r;
      root.querySelectorAll('.adm-role-tab').forEach(x=>{
        const active = x===b;
        x.classList.toggle('active', active);
        x.style.background = active ? 'var(--g2)' : 'var(--paper)';
        x.style.color = active ? '#fff' : 'var(--ink2)';
      });
      _render(root);
    })
  );
  root.querySelector('#ac-list').addEventListener('click', e=>{
    const replyBtn = e.target.closest('[data-reply]');
    const markBtn  = e.target.closest('[data-mark-read]');
    if (replyBtn) _openReply(root, replyBtn.dataset.reply);
    if (markBtn)  _markRead(root, markBtn.dataset.markRead);
  });
  root.querySelector('#ac-reply-cancel').addEventListener('click', ()=>{
    root.querySelector('#ac-reply-modal').style.display='none';
  });
  root.querySelector('#ac-reply-submit').addEventListener('click', ()=> _submitReply(root));

  await _loadEmail(root);
  await _load(root);
}

async function _loadEmail(root) {
  try {
    const cfg = await getCachedAppConfig();
    const email = cfg.contactEmail || '';
    const inp = root.querySelector('#ac-email-inp');
    if (inp) inp.value = email||'';
  } catch(e) {}
}

async function _backfillTTL(btn) {
  const statusEl = document.getElementById('ac-backfill-status');
  btn.disabled = true;
  btn.textContent = 'চেক করা হচ্ছে…';
  if (statusEl) statusEl.textContent = '';

  try {
    // এটা একটা এক-বারের maintenance অ্যাকশন, তাই পুরো collection স্ক্যান করা
    // এখানে গ্রহণযোগ্য (নিয়মিত hot-path অপারেশন না)
    const snap = await getDocs(collection(db,'contactMessages'));
    const missing = snap.docs.filter(d => !d.data().expireAt);

    if (!missing.length) {
      btn.disabled = false;
      btn.textContent = '🔄 পুরনো মেসেজ Backfill করুন';
      if (statusEl) { statusEl.textContent = '✓ সব মেসেজেই আগে থেকেই TTL আছে'; statusEl.style.color = 'var(--g1)'; }
      return;
    }

    btn.textContent = `${missing.length}টা আপডেট হচ্ছে…`;

    // Firestore batch limit ৫০০ — প্রয়োজনে একাধিক batch এ ভাগ করে দিলাম
    const THIRTY_DAYS = 30*24*60*60*1000;
    for (let i = 0; i < missing.length; i += 500) {
      const chunk = missing.slice(i, i+500);
      const batch = writeBatch(db);
      chunk.forEach(d => {
        const data = d.data();
        const createdAt = data.createdAt?.toDate ? data.createdAt.toDate() : new Date();
        batch.update(doc(db,'contactMessages',d.id), {
          expireAt: Timestamp.fromDate(new Date(createdAt.getTime()+THIRTY_DAYS)),
        });
      });
      await batch.commit();
    }

    btn.disabled = false;
    btn.textContent = '🔄 পুরনো মেসেজ Backfill করুন';
    if (statusEl) { statusEl.textContent = `✓ ${missing.length}টা মেসেজ আপডেট হয়েছে`; statusEl.style.color = 'var(--g1)'; }
    toast(`${missing.length}টা পুরনো মেসেজে TTL যোগ হয়েছে ✓`, 'ok');
  } catch(err) {
    btn.disabled = false;
    btn.textContent = '🔄 পুরনো মেসেজ Backfill করুন';
    if (statusEl) { statusEl.textContent = 'ব্যর্থ: '+err.message; statusEl.style.color = 'var(--r2)'; }
    toast('ব্যর্থ: '+err.message, 'er');
  }
}

async function _saveEmail(root) {
  const email = root.querySelector('#ac-email-inp')?.value.trim();
  try {
    await setDoc(doc(db,'appConfig','main'), { contactEmail: email }, { merge:true });
    invalidateAppConfigCache();
    toast('যোগাযোগ ইমেইল সংরক্ষণ হয়েছে ✓','ok');
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
}

async function _load(root) {
  ld('মেসেজ লোড হচ্ছে…');
  try {
    const snap = await getDocs(query(collection(db,'contactMessages'), orderBy('createdAt','desc')));
    _messages = snap.docs.map(d=>({id:d.id,...d.data()}));
    _render(root);
  } catch(err) {
    root.querySelector('#ac-list').innerHTML =
      `<div style="padding:20px;text-align:center;color:#b83030">⚠️ ${_e(err.message)}</div>`;
  } finally { uld(); }
}

function _render(root) {
  const list = root.querySelector('#ac-list');
  if (!list) return;
  let filtered = _filter==='all' ? _messages : _messages.filter(m=>m.status===_filter);
  if (_roleFilter !== 'all') {
    filtered = filtered.filter(m => (m.userRole || 'member') === _roleFilter);
  }

  if (!filtered.length) {
    list.innerHTML = '<div style="padding:30px;text-align:center;color:#8aaa90">কোনো মেসেজ নেই</div>';
    return;
  }

  list.innerHTML = filtered.map(m=>{
    const statusBadge = m.status==='replied'
      ? '<span class="badge b-green">✓ উত্তর দেওয়া</span>'
      : m.status==='read'
        ? '<span class="badge b-amber">👁 দেখা হয়েছে</span>'
        : '<span class="badge b-member" style="background:#fde8e8;color:#b83030">⏳ অপেক্ষমান</span>';

    return `
<div class="card">
  <div class="cb">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:6px">
      <div>
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          <strong style="font-size:13px">${_e(m.subject||'(বিষয় নেই)')}</strong>
          <span class="badge" style="font-size:9px;${
            (m.userRole||'member')==='mess-admin'
              ? 'background:#e7f0fe;color:#1a3a8c'
              : 'background:#f0f7f2;color:#4a7055'
          }">
            ${(m.userRole||'member')==='mess-admin' ? '🔑 Mess Admin' : '👤 সদস্য'}
          </span>
        </div>
        <p style="font-size:11px;color:#8aaa90;margin-top:2px">
          ${_e(m.userName||'—')} · ${_e(m.userEmail||'')}
          ${m.messName?` · মেস: ${_e(m.messName)}`:''}
        </p>
      </div>
      ${statusBadge}
    </div>
    <p style="font-size:12px;color:#243a2c;line-height:1.5;white-space:pre-wrap;margin-bottom:8px">${_e(m.message)}</p>
    <p style="font-size:10px;color:#8aaa90;margin-bottom:10px">${m.createdAt?formatDate(m.createdAt):''}</p>

    ${m.adminReply?`
    <div style="padding:8px 10px;background:#f1f5f2;border-radius:8px;border-left:3px solid #1fa860;margin-bottom:10px">
      <p style="font-size:10px;font-weight:700;color:#146b40;margin-bottom:3px">আপনার উত্তর:</p>
      <p style="font-size:12px;color:#243a2c">${_e(m.adminReply)}</p>
    </div>`:''}

    <div style="display:flex;gap:6px;flex-wrap:wrap">
      ${m.status==='unread'?`<button class="btn btn-xs btn-ghost" data-mark-read="${m.id}">👁 দেখা হয়েছে চিহ্নিত করুন</button>`:''}
      <button class="btn btn-xs btn-p" data-reply="${m.id}">✍️ ${m.adminReply?'উত্তর সম্পাদনা':'উত্তর দিন'}</button>
    </div>
  </div>
</div>`;
  }).join('');
}

async function _markRead(root, id) {
  try {
    await updateDoc(doc(db,'contactMessages',id), { status:'read' });
    const m = _messages.find(x=>x.id===id);
    if (m) m.status='read';
    _render(root);
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
}

function _openReply(root, id) {
  const m = _messages.find(x=>x.id===id);
  if (!m) return;
  root.querySelector('#ac-reply-to').textContent = `${m.userName||'—'} (${m.userEmail||''})`;
  root.querySelector('#ac-reply-original').textContent = m.message;
  root.querySelector('#ac-reply-text').value = m.adminReply||'';
  root.querySelector('#ac-reply-modal').dataset.msgId = id;
  root.querySelector('#ac-reply-modal').style.display = 'flex';
}

async function _submitReply(root) {
  const modal = root.querySelector('#ac-reply-modal');
  const id    = modal.dataset.msgId;
  const reply = root.querySelector('#ac-reply-text')?.value.trim();
  if (!reply) { toast('উত্তর লিখুন','er'); return; }

  const btn = root.querySelector('#ac-reply-submit');
  if (btn) { btn.disabled=true; btn.textContent='পাঠানো হচ্ছে…'; }
  try {
    await updateDoc(doc(db,'contactMessages',id), {
      adminReply: reply, status:'replied',
    });
    const m = _messages.find(x=>x.id===id);
    if (m) { m.adminReply=reply; m.status='replied'; }
    modal.style.display='none';
    toast('উত্তর পাঠানো হয়েছে ✓','ok');
    _render(root);
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
  finally { if (btn) { btn.disabled=false; btn.textContent='✓ উত্তর পাঠান'; } }
}


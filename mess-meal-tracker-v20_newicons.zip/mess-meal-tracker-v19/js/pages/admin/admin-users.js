import { db } from '../../firebase.js';
import { currentProfile } from '../../auth.js';
import { toast, formatDate, ini, avColor, escapeHtml as _e } from '../../utils.js';
import {
  collection, getDocs, doc, updateDoc, query, orderBy, where, getCountFromServer
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _all=[], _tab='pending', _loadedTabs=new Set();

export async function render(root) {
  root.innerHTML=`
<div>
  <div class="adp-hd">
    <div><h2 class="adp-h">ব্যবহারকারী</h2><p class="adp-sub" id="uc">লোড হচ্ছে…</p></div>
    <button class="btn btn-ghost btn-sm" id="u-refresh">🔄 রিফ্রেশ</button>
  </div>
  <div class="adm-tabs">
    <button class="adm-tab active" data-tab="pending">মেসবিহীন</button>
    <button class="adm-tab" data-tab="active">সক্রিয় (লোড করুন)</button>
    <button class="adm-tab" data-tab="all">সব (লোড করুন)</button>
  </div>
  <div id="u-list" style="display:flex;flex-direction:column;gap:8px"></div>
</div>
<style>
.u-row{background:#fff;border:1px solid var(--line);border-radius:12px;
  padding:12px 14px;display:flex;align-items:center;gap:12px;box-shadow:var(--sh);flex-wrap:wrap}
.u-av{width:42px;height:42px;border-radius:50%;flex-shrink:0;display:flex;
  align-items:center;justify-content:center;font-size:16px;font-weight:700;overflow:hidden}
.u-av img{width:100%;height:100%;object-fit:cover}
.u-info{flex:1;min-width:0}
.u-info h3{font-size:13px;font-weight:700;color:var(--ink);margin:0;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.u-info p{font-size:11px;color:var(--ink3);margin:2px 0 0}
</style>`;

  root.querySelector('#u-refresh').addEventListener('click',()=>{ _loadedTabs.clear(); _load(root); });
  root.querySelector('.adm-tabs').addEventListener('click',e=>{
    const b=e.target.closest('[data-tab]');
    if(!b) return;
    _tab=b.dataset.tab;
    root.querySelectorAll('.adm-tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===_tab));
    _load(root);
  });
  root.querySelector('#u-list').addEventListener('click',e=>{
    const add=e.target.closest('[data-add-coadmin]');
    const rem=e.target.closest('[data-rem-coadmin]');
    const loadBtn=e.target.closest('[data-load-tab]');
    if(add) _setCoadmin(add.dataset.addCoadmin, 'co-admin', root);
    if(rem) _setCoadmin(rem.dataset.remCoadmin, null, root);
    if(loadBtn) _load(root, true);
  });

  await _load(root);
}

// ✅ ডিফল্টভাবে শুধু: (ক) মোট ইউজার সংখ্যা (getCountFromServer — কোনো ডকুমেন্ট
// ডাউনলোড ছাড়াই সার্ভার থেকে শুধু গণনা আসে), আর (খ) যেসব ইউজার এখনো কোনো
// মেসে নেই (currentMessId==null) — এটাই আসলে সবচেয়ে বেশি দরকারি তালিকা,
// যেহেতু এখানেই Admin-কে action নিতে হয় (approve/reject)।
// "সক্রিয়"/"সব" ট্যাব ইচ্ছাকৃতভাবে ভারী — শুধু স্পষ্টভাবে ক্লিক করলেই লোড হবে।
async function _load(root, forceLoad=false) {
  const listEl = root.querySelector('#u-list');
  try {
    // মোট সংখ্যা — lightweight, সবসময় দেখানো হয়
    const countSnap = await getCountFromServer(collection(db,'users'));
    root.querySelector('#uc').textContent = `মোট ${countSnap.data().count} জন ইউজার`;

    if (_tab === 'pending') {
      // ✅ শুধু মেসবিহীন ইউজার — হালকা query
      const snap = await getDocs(query(collection(db,'users'), where('currentMessId','==',null)));
      _all = snap.docs.map(d=>({id:d.id,...d.data()}));
      _render(root);
      return;
    }

    // active/all ট্যাব — ভারী, শুধু বাটনে ক্লিক করলেই লোড হবে
    if (!forceLoad && !_loadedTabs.has(_tab)) {
      listEl.innerHTML = `
<div style="text-align:center;padding:30px">
  <p style="font-size:12px;color:var(--ink3);margin-bottom:10px">এই তালিকা পুরো ইউজার collection টানবে — প্রয়োজন হলেই লোড করুন</p>
  <button class="btn btn-p btn-sm" data-load-tab="1">📥 লোড করুন</button>
</div>`;
      return;
    }

    _loadedTabs.add(_tab);
    const snap = await getDocs(query(collection(db,'users'), orderBy('createdAt','desc')));
    _all = snap.docs.map(d=>({id:d.id,...d.data()}));
    _render(root);
  } catch(err){
    listEl.innerHTML=`<div class="adm-loading">⚠️ ${err.message}</div>`;
  }
}

function _render(root) {
  const list=root.querySelector('#u-list');
  if(!list) return;
  const filtered=_tab==='all'?_all:_tab==='pending'?_all:_all.filter(u=>!!u.currentMessId);
  if(!filtered.length){list.innerHTML='<div class="adm-loading">কোনো ব্যবহারকারী নেই</div>';return;}

  list.innerHTML=filtered.map(u=>{
    const isMe=u.id===currentProfile?.uid;
    const isAdmin=u.platformRole==='admin';
    const av=u.avatar?`<img src="${_e(u.avatar)}" alt=""/>`:`<span>${ini(u.name||u.email)}</span>`;
    const roleBadge=u.platformRole==='admin'?'<span class="badge b-green">🔑 Admin</span>':
      u.platformRole==='co-admin'?'<span class="badge b-blue">🛡 Co-Admin</span>':
      u.currentMessId?'<span class="badge b-muted">🏠 মেসে</span>':
      '<span class="badge b-amber">⏳ Pending</span>';
    return `
<div class="u-row">
  <div class="u-av ${u.avatar?'':avColor(u.name||u.email)}">${av}</div>
  <div class="u-info">
    <h3>${_e(u.name||'—')}${isMe?' (আপনি)':''}</h3>
    <p>${_e(u.email||'—')}</p>
  </div>
  ${roleBadge}
  ${!isMe&&!isAdmin?
    u.platformRole==='co-admin'
      ?`<button class="btn btn-xs btn-danger" data-rem-coadmin="${u.id}">Co-Admin সরান</button>`
      :`<button class="btn btn-xs btn-blue" data-add-coadmin="${u.id}">+ Co-Admin</button>`
    :''}
</div>`;
  }).join('');
}

async function _setCoadmin(uid, role, root) {
  const msg=role?'Co-Admin করবেন?':'Co-Admin role সরাবেন?';
  if(!window.confirm(msg)) return;
  try {
    await updateDoc(doc(db,'users',uid),{platformRole:role});
    const u=_all.find(x=>x.id===uid); if(u) u.platformRole=role;
    _render(root);
    toast(role?'Co-Admin করা হয়েছে':'Role সরানো হয়েছে','ok');
  } catch(err){toast('ব্যর্থ: '+err.message,'er');}
}


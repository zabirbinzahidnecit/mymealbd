// admin-messes-cache.js — session-level cache for the full `messes` collection
// (প্ল্যাটফর্ম-অ্যাডমিন সাইড)
//
// কেন: admin-messes.js, admin-payments.js, admin-dashboard.js, admin-reports.js
// — চারটা পেজই হুবহু একই `messes` কালেকশন পুরোটা আলাদা করে fetch করতো। এডমিন
// প্যানেলে ট্যাব পাল্টানো (Dashboard ↔ Payments ↔ Messes) খুব ঘনঘন হয়, তাই
// ৩০ সেকেন্ডের ছোট TTL cache দিয়ে বার বার পুরো কালেকশন-স্ক্যান এড়ানো হচ্ছে।
// TTL ছোট রাখা হয়েছে (members-cache/app-config-cache-এর চেয়ে) কারণ এই
// লিস্টে status/plan প্রায়ই বদলায় (approve, activate/deactivate, delete)।
//
// যেসব জায়গায় messes ডেটা বদলায় (toggle status, delete, plan approve) সেখান
// থেকে invalidateMessesCache() কল করা হয়, যাতে পরের read fresh ডেটা পায়।

import { db } from '../../firebase.js';
import {
  collection, getDocs, query, orderBy
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TTL_MS = 30_000;
let _cache = { messes: null, ts: 0, promise: null };

export async function getCachedMesses({ force=false } = {}) {
  const now = Date.now();
  if (!force && _cache.messes && (now - _cache.ts) < TTL_MS) {
    return _cache.messes;
  }
  if (!force && _cache.promise) {
    return _cache.promise;
  }
  const p = (async () => {
    const snap = await getDocs(query(collection(db,'messes'), orderBy('createdAt','desc')));
    const messes = snap.docs.map(d => ({ id:d.id, ...d.data() }));
    _cache = { messes, ts: Date.now(), promise: null };
    return messes;
  })();
  _cache = { messes: _cache.messes, ts: _cache.ts, promise: p };
  return p;
}

export function invalidateMessesCache() {
  _cache = { messes: null, ts: 0, promise: null };
}

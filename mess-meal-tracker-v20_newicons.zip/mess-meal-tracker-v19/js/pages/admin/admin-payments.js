// admin-payments.js — Billing management: মেস-নাম লিস্ট → ক্লিক করলে full-screen
// ডিটেইল (timeline + pending payment approve/reject + waive/manual entry)

import { db } from '../../firebase.js';
import { toast, ld, uld, taka, formatDate, moName, escapeHtml as _e } from '../../utils.js';
import { currentProfile } from '../../auth.js';
import { getPlanDueInfoSync, getMemberLimit } from '../../plan.js';
import { getBillingTimeline, PLAN_LABEL, renderCalendarStrip, computeRenewalQuote } from '../../billing.js';
import { getCachedAppConfig } from '../../app-config-cache.js';
import { getCachedMesses, invalidateMessesCache } from './admin-messes-cache.js';
import {
  collection, getDocs, doc, updateDoc, getDoc, addDoc,
  query, where, orderBy, serverTimestamp, writeBatch, Timestamp
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

let _view = 'list';        // 'list' | 'detail'
let _messList = [], _cfg = {};
let _selectedMessId = null;
let _detailPending = [];   // নির্বাচিত মেসের payment request গুলো
let _payTab = 'all';       // 'all' | 'free' | 'pro10' | 'pro15' | 'pro20plus' | 'requests'

export async function render(root, { force=false } = {}) {
  if (_view === 'detail' && _selectedMessId) await _renderDetail(root);
  else await _renderList(root, { force });
}

// ────────────────────────────────────────────────────────────
// মেস তালিকা (ডিফল্ট ভিউ)
// ────────────────────────────────────────────────────────────
async function _renderList(root, { force=false } = {}) {
  root.innerHTML = `
<div>
  <div class="adp-hd">
    <div><h2 class="adp-h">💰 Payment / Billing</h2><p class="adp-sub" id="pay-count">লোড হচ্ছে…</p></div>
    <button class="btn btn-ghost btn-sm" id="pay-refresh">🔄 রিফ্রেশ</button>
  </div>
  <div class="adm-tabs" style="flex-wrap:wrap;gap:4px;margin-bottom:10px" id="pay-tabs">
    <button class="adm-tab${_payTab==='all'?' active':''}" data-pay-tab="all">সব</button>
    <button class="adm-tab${_payTab==='free'?' active':''}" data-pay-tab="free">🆓 Free</button>
    <button class="adm-tab${_payTab==='pro10'?' active':''}" data-pay-tab="pro10">⭐ Pro 10</button>
    <button class="adm-tab${_payTab==='pro15'?' active':''}" data-pay-tab="pro15">⭐⭐ Pro 15</button>
    <button class="adm-tab${_payTab==='pro20plus'?' active':''}" data-pay-tab="pro20plus">⭐⭐⭐ Custom</button>
    <button class="adm-tab${_payTab==='requests'?' active':''}" data-pay-tab="requests">🔔 Payment Request<span id="pay-req-badge"></span></button>
  </div>
  <div class="field" style="margin-bottom:12px">
    <input class="inp inp-sm" id="pay-search" placeholder="🔍 মেসের নাম খুঁজুন…"/>
  </div>
  <div id="pay-mess-list">লোড হচ্ছে…</div>
</div>`;

  root.querySelector('#pay-refresh').addEventListener('click', () => render(root, { force:true }));
  root.querySelector('#pay-search').addEventListener('input', e => _renderMessList(root, e.target.value));
  root.querySelector('#pay-tabs').addEventListener('click', e => {
    const b = e.target.closest('[data-pay-tab]');
    if (!b) return;
    _payTab = b.dataset.payTab;
    root.querySelectorAll('#pay-tabs .adm-tab').forEach(x=>x.classList.toggle('active', x.dataset.payTab===_payTab));
    _renderMessList(root, root.querySelector('#pay-search')?.value||'');
  });

  try {
    const [messList, cfg, pendingSnap] = await Promise.all([
      getCachedMesses({ force }),
      getCachedAppConfig({ force }),
      getDocs(query(collection(db,'paymentRequests'), where('status','==','pending'))),
    ]);
    _cfg = cfg;
    _messList = messList.map(m => ({ ...m }));

    const pendingCounts = {};
    pendingSnap.forEach(d => { const mid = d.data().messId; if (mid) pendingCounts[mid] = (pendingCounts[mid]||0)+1; });
    _messList.forEach(m => { m._pendingCount = pendingCounts[m.id]||0; });

    const totalPending = pendingSnap.size;
    const badgeEl = root.querySelector('#pay-req-badge');
    if (badgeEl) badgeEl.innerHTML = totalPending>0
      ? ` <span class="badge" style="background:#fee2e2;color:#dc2626;font-size:9px">${totalPending}</span>` : '';

    root.querySelector('#pay-count').textContent = `মোট ${_messList.length}টি মেস`;
    _renderMessList(root, '');
  } catch(err) {
    root.querySelector('#pay-mess-list').innerHTML = `<div class="adm-loading">⚠️ ${_e(err.message)}</div>`;
  }
}

function _renderMessList(root, term) {
  const list = root.querySelector('#pay-mess-list');
  if (!list) return;
  term = (term||'').trim().toLowerCase();
  let filtered = term ? _messList.filter(m => (m.name||'').toLowerCase().includes(term)) : _messList;

  // ✅ ট্যাব-ফিল্টার — plan অনুযায়ী (Free/Pro10/Pro15/Custom) অথবা শুধু
  // যেসব মেসের pending payment request আছে সেগুলো ('requests' ট্যাব)
  if (_payTab === 'requests') {
    filtered = filtered.filter(m => (m._pendingCount||0) > 0);
  } else if (_payTab !== 'all') {
    filtered = filtered.filter(m => (m.plan||'free') === _payTab);
  }

  if (!filtered.length) {
    list.innerHTML = `<div class="adm-loading">${_payTab==='requests'?'এখন কোনো pending payment request নেই':'কোনো মেস পাওয়া যায়নি'}</div>`;
    return;
  }

  // ✅ Plan অনুযায়ী আলাদা সেকশনে ভাগ — Free আলাদা, Pro 10 আলাদা, ইত্যাদি
  // ('requests' ট্যাবে বা নির্দিষ্ট একটা plan-ট্যাবে থাকলে শুধু প্রাসঙ্গিক
  // group(গুলো)-ই non-empty থাকবে, বাকিগুলো এমনিতেই ফিল্টার হয়ে খালি যাবে)
  const PLAN_ORDER = ['pro20plus','pro15','pro10','free'];
  const groups = {};
  PLAN_ORDER.forEach(p => groups[p] = []);
  filtered.forEach(m => {
    const plan = PLAN_ORDER.includes(m.plan) ? m.plan : 'free';
    groups[plan].push({ m, due: getPlanDueInfoSync(m, _cfg) });
  });

  const sortGroup = arr => arr.sort((a,b) => {
    if ((b.m._pendingCount>0) !== (a.m._pendingCount>0)) return (b.m._pendingCount>0)?1:-1;
    if (b.due.isExpired !== a.due.isExpired) return b.due.isExpired?1:-1;
    return 0;
  });

  const sectionsHtml = PLAN_ORDER.map(plan => {
    const rows = sortGroup(groups[plan]);
    if (!rows.length) return '';
    return `
<div style="margin-bottom:18px">
  <h3 style="font-size:12px;font-weight:700;color:var(--ink3);text-transform:uppercase;
    letter-spacing:.5px;margin-bottom:8px">${PLAN_LABEL[plan]} (${rows.length}টি)</h3>
  ${rows.map(({m,due}) => `
  <div class="pay-mess-row" data-open-mess="${m.id}" style="background:#fff;border:1px solid var(--line);
    border-radius:12px;padding:12px 14px;display:flex;align-items:center;gap:10px;
    margin-bottom:8px;cursor:pointer;box-shadow:var(--sh)">
    <div style="flex:1;min-width:0">
      <h3 style="font-size:13px;font-weight:700;color:var(--ink);margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
        ${_e(m.name||'অজানা মেস')}
      </h3>
      <p style="font-size:11px;color:var(--ink3);margin:2px 0 0">
        ${due.isExpired ? `<span style="color:#dc2626;font-weight:700">⚠️ বকেয়া ৳${due.dueAmount}</span>`
          : due.freeTrialExpired ? `<span style="color:#dc2626;font-weight:700">⚠️ ট্রায়াল শেষ</span>`
          : due.freeTrialDaysLeft!=null ? `🆓 ট্রায়াল — আর ${due.freeTrialDaysLeft} দিন`
          : plan==='free' ? 'সচল' : '✅ সচল'}
      </p>
    </div>
    ${m._pendingCount>0 ? `<span class="badge" style="background:#fee2e2;color:#dc2626;font-size:10px">${m._pendingCount} pending</span>` : ''}
    <span style="color:var(--ink4);font-size:16px">›</span>
  </div>`).join('')}
</div>`;
  }).join('');

  list.innerHTML = sectionsHtml || '<div class="adm-loading">কোনো মেস পাওয়া যায়নি</div>';

  list.querySelectorAll('[data-open-mess]').forEach(el => {
    el.addEventListener('click', () => {
      _view = 'detail'; _selectedMessId = el.dataset.openMess;
      render(root);
    });
  });
}

// ────────────────────────────────────────────────────────────
// একটা মেসের ফুল-স্ক্রিন বিলিং ডিটেইল
// ────────────────────────────────────────────────────────────
async function _renderDetail(root) {
  root.innerHTML = `
<div>
  <button class="btn btn-ghost btn-sm" id="pay-back" style="margin-bottom:14px">← মেস তালিকায় ফিরে যান</button>
  <div id="pay-detail-body">লোড হচ্ছে…</div>
</div>`;
  root.querySelector('#pay-back').addEventListener('click', () => { _view='list'; render(root); });

  await _loadDetail(root);
}

async function _loadDetail(root) {
  const body = root.querySelector('#pay-detail-body');
  if (!body) return;
  try {
    const [tl, pendingSnap] = await Promise.all([
      getBillingTimeline(_selectedMessId),
      getDocs(query(collection(db,'paymentRequests'), where('messId','==',_selectedMessId), orderBy('createdAt','desc'))),
    ]);
    _detailPending = pendingSnap.docs.map(d => ({ id:d.id, ...d.data() }));
    _renderDetailBody(root, tl);
  } catch(err) {
    body.innerHTML = `<p style="color:var(--r2);font-size:13px">লোড ব্যর্থ: ${_e(err.message)}</p>`;
  }
}

function _renderDetailBody(root, tl) {
  const body = root.querySelector('#pay-detail-body');
  const { history, dueInfo, currentPlan, currentExpiry, totalPaid, messData } = tl;
  const fmt = d => d ? `${d.getDate()} ${moName(d.getMonth())} ${d.getFullYear()}` : '—';
  const pending = _detailPending.filter(p => p.status==='pending');
  const reviewed = _detailPending.filter(p => p.status!=='pending');

  body.innerHTML = `
<h2 style="font-size:16px;font-weight:700;margin-bottom:4px">${_e(messData?.name||_selectedMessId)}</h2>
<p style="font-size:12px;color:var(--ink3);margin-bottom:14px">Mess ID: ${_selectedMessId}</p>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px">
  <div style="background:var(--paper);border-radius:8px;padding:10px">
    <p style="font-size:10px;color:var(--ink3);font-weight:700">বর্তমান Plan</p>
    <p style="font-size:14px;font-weight:700">${PLAN_LABEL[currentPlan]||currentPlan}</p>
  </div>
  <div style="background:var(--paper);border-radius:8px;padding:10px">
    <p style="font-size:10px;color:var(--ink3);font-weight:700">মোট পরিশোধিত (সব সময়)</p>
    <p style="font-size:14px;font-weight:700;color:var(--g1)">৳${totalPaid}</p>
  </div>
</div>

${dueInfo.isExpired ? `
<div style="background:#fee2e2;border:1px solid #dc2626;border-radius:10px;padding:12px 14px;margin-bottom:14px">
  <p style="font-size:13px;font-weight:700;color:#dc2626">⚠️ বকেয়া: ৳${dueInfo.dueAmount} (${dueInfo.monthsOverdue} মাস, প্রতি মাস ৳${dueInfo.monthlyPrice})</p>
  <p style="font-size:11px;color:#991b1b;margin-top:2px">মেয়াদ শেষ হয়েছিল: ${fmt(currentExpiry)}</p>
  <button class="btn btn-sm" id="pay-waive" style="margin-top:8px;background:#fff;border:1px solid #dc2626;color:#dc2626">
    🎁 বকেয়া মওকুফ করুন
  </button>
</div>` : currentPlan!=='free' ? `
<div style="background:var(--g7);border:1px solid var(--g5);border-radius:10px;padding:12px 14px;margin-bottom:14px">
  <p style="font-size:13px;font-weight:700;color:var(--g1)">✅ সচল, মেয়াদ ${fmt(currentExpiry)} পর্যন্ত</p>
</div>` : ''}

${pending.length ? `
<h3 style="font-size:13px;font-weight:700;margin-bottom:8px">⏳ Pending Payment (${pending.length})</h3>
${pending.map(p => `
<div style="background:#fffbeb;border:1px solid #fcd34d;border-radius:10px;padding:12px 14px;margin-bottom:8px">
  <p style="font-size:12px">💳 ${_e(p.planName||p.plan)} — <strong>৳${p.amount}</strong> · ${_e(p.paymentMethod||'')} · TxnID: ${_e(p.txnId||'—')}</p>
  <p style="font-size:11px;color:var(--ink3)">${_e(p.requesterName||'')} · ${p.createdAt?formatDate(p.createdAt):''}</p>
  ${p.plan==='pro20plus' && p.requestedMemberCount ? `<p style="font-size:11px;color:var(--ink3)">চাহিদা: ${p.requestedMemberCount} জন সদস্য</p>` : ''}
  ${p.plan==='pro20plus' ? `
  <div style="display:flex;align-items:center;gap:8px;margin:8px 0;background:#fff;border-radius:8px;padding:6px 10px">
    <label class="lbl" style="margin:0;font-size:11px">চূড়ান্ত সদস্য সীমা:</label>
    <input class="inp inp-sm" type="number" id="final-limit-${p.id}" min="1" value="${p.requestedMemberCount||20}" style="width:70px"/>
  </div>` : ''}
  <div style="display:flex;gap:8px;margin-top:8px">
    <button class="btn btn-p btn-sm" data-approve="${p.id}" data-plan="${p.plan}">✓ Approve</button>
    <button class="btn btn-danger btn-sm" data-reject="${p.id}">✗ Reject</button>
  </div>
</div>`).join('')}` : ''}

<div style="display:flex;gap:8px;margin-bottom:16px">
  <button class="btn btn-ghost btn-sm" id="pay-manual-toggle">✏️ ম্যানুয়াল এন্ট্রি যোগ করুন</button>
</div>
<div id="pay-manual-form" style="display:none;background:var(--paper);border-radius:10px;padding:14px;margin-bottom:16px">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">
    <div><label class="lbl">Plan</label>
      <select class="inp inp-sm" id="mn-plan">
        <option value="pro10">⭐ Pro 10</option>
        <option value="pro15">⭐⭐ Pro 15</option>
        <option value="pro20plus">⭐⭐⭐ Custom</option>
      </select>
    </div>
    <div><label class="lbl">টাকা</label>
      <input class="inp inp-sm" type="number" id="mn-amount" min="0" value="0"/></div>
    <div style="grid-column:span 2"><label class="lbl">নোট (ঐচ্ছিক)</label>
      <input class="inp inp-sm" id="mn-note" placeholder="যেমন: ক্যাশে পরিশোধ"/></div>
  </div>
  <p style="font-size:11px;color:var(--ink3);margin-bottom:8px">টাকার পরিমাণ অনুযায়ী কতদিন যোগ হবে তা স্বয়ংক্রিয়ভাবে হিসাব হবে</p>
  <button class="btn btn-p btn-sm" id="pay-manual-save">✓ যোগ করুন</button>
</div>

<h3 style="font-size:13px;font-weight:700;margin-bottom:8px">📆 ক্যালেন্ডার ভিউ</h3>
<div style="margin-bottom:16px">${renderCalendarStrip(tl)}</div>

<h3 style="font-size:13px;font-weight:700;margin-bottom:8px">📅 টাইমলাইন</h3>
<div style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:6px 14px;margin-bottom:16px">
  ${history.length ? history.map(h => `
  <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--line)">
    <div>
      <p style="font-size:12px;font-weight:600">${fmt(h.periodStart)} — ${fmt(h.periodEnd)}</p>
      <p style="font-size:11px;color:var(--ink3)">
        ${PLAN_LABEL[h.plan]||h.plan} · ${h.monthsCovered} মাস
        ${h.wasOverdue?` · ${h.monthsOverdueAtPayment} মাস বকেয়া সহ`:''}
        ${h.txnId?` · TxnID: ${_e(h.txnId)}`:h.paymentMethod==='manual'?' · ম্যানুয়াল এন্ট্রি':''}
      </p>
    </div>
    <div style="font-weight:700;color:var(--g1);font-family:var(--mono)">৳${h.amount}</div>
  </div>`).join('') : '<p style="font-size:12px;color:var(--ink3);padding:12px 0">কোনো ইতিহাস নেই</p>'}
</div>

${reviewed.length ? `
<h3 style="font-size:13px;font-weight:700;margin-bottom:8px">📋 আগের Payment Request</h3>
${reviewed.slice(0,10).map(p => `
<div style="font-size:11px;color:var(--ink3);padding:6px 0;border-bottom:1px solid var(--line)">
  ${p.status==='approved'?'✓':'✗'} ${_e(p.planName||p.plan)} — ৳${p.amount} · ${p.createdAt?formatDate(p.createdAt):''}
</div>`).join('')}` : ''}
`;

  body.querySelectorAll('[data-approve]').forEach(btn => {
    btn.addEventListener('click', () => {
      const payId = btn.dataset.approve;
      const limitInput = body.querySelector(`#final-limit-${payId}`);
      const customLimit = limitInput ? parseInt(limitInput.value)||null : null;
      _approve(root, payId, _selectedMessId, btn.dataset.plan, customLimit);
    });
  });
  body.querySelectorAll('[data-reject]').forEach(btn => {
    btn.addEventListener('click', () => _reject(root, btn.dataset.reject));
  });
  body.querySelector('#pay-waive')?.addEventListener('click', () => _waiveDue(root, dueInfo, currentExpiry));
  body.querySelector('#pay-manual-toggle')?.addEventListener('click', () => {
    const f = body.querySelector('#pay-manual-form');
    f.style.display = f.style.display==='none' ? '' : 'none';
  });
  body.querySelector('#pay-manual-save')?.addEventListener('click', () => _addManualEntry(root));
}

// ────────────────────────────────────────────────────────────
// Approve / Reject / Waive / Manual entry
// ────────────────────────────────────────────────────────────
async function _approve(root, payId, messId, plan, customLimit=null) {
  const p = _detailPending.find(x=>x.id===payId);
  const amountPaid = parseFloat(p?.amount)||0;

  let quote = null;
  let messData = {};
  try {
    const [messSnap, cfgSnap] = await Promise.all([
      getDoc(doc(db,'messes',messId)),
      getDoc(doc(db,'appConfig','main')),
    ]);
    messData = messSnap.exists() ? messSnap.data() : {};
    const cfg = cfgSnap.exists() ? cfgSnap.data() : {};
    const targetMemberCount = plan==='pro20plus' ? (customLimit || messData.customMemberLimit || null) : null;
    quote = computeRenewalQuote({ messData, cfg, targetPlan: plan, amountPaid, targetMemberCount });
  } catch(err) { toast('হিসাব করতে ব্যর্থ: '+err.message,'er'); return; }

  // ✅ Downgrade safety check — নতুন প্ল্যানের সদস্য-সীমা বর্তমান সদস্য
  // সংখ্যার চেয়ে কম হলে Approve করার আগেই admin কে সতর্ক করা উচিত, নাহলে
  // মেসটা silently "over-limit" অবস্থায় চলে যাবে (কেউ টের পাবে না কেন নতুন
  // সদস্য যোগ করা যাচ্ছে না)।
  let overLimitWarning = '';
  try {
    const targetLimitData = plan==='pro20plus'
      ? { ...messData, plan, customMemberLimit: customLimit || messData.customMemberLimit }
      : { ...messData, plan };
    const [membersSnap, newLimit] = await Promise.all([
      getDocs(collection(db,'messes',messId,'members')),
      getMemberLimit(targetLimitData),
    ]);
    if (membersSnap.size > newLimit) {
      overLimitWarning = `\n\n⚠️ সতর্কতা: এই মেসে এখন ${membersSnap.size} জন সদস্য আছে, কিন্তু নতুন প্ল্যানের সীমা মাত্র ${newLimit} জন। Approve করলে মেসটা "over-limit" অবস্থায় চলে যাবে — কেউ বের না হওয়া পর্যন্ত নতুন সদস্য যোগ করা যাবে না।`;
    }
  } catch(e) { console.warn('Member-limit check skipped:', e); }

  const fmt = d => d ? `${d.getDate()}/${d.getMonth()+1}/${d.getFullYear()}` : '—';
  let confirmMsg = `৳${amountPaid} পেমেন্ট approve করে "${PLAN_LABEL[plan]||plan}" প্ল্যান ${fmt(quote.newExpiry)} পর্যন্ত সচল করবেন? (${quote.totalDays} দিন যোগ হবে)`;
  if (quote.dueInfo.isExpired) {
    confirmMsg = `⚠️ এই মেসের বকেয়া ৳${quote.dueInfo.dueAmount} (${quote.dueInfo.monthsOverdue} মাস)।\n\n৳${amountPaid} পেমেন্টে বকেয়ার দিন থেকে হিসাব করে মোট ${quote.totalDays} দিন যোগ হবে, নতুন মেয়াদ হবে ${fmt(quote.newExpiry)}।\n\nটাকার পরিমাণ পুরো বকেয়া কভার না করলে মেয়াদ কম বাড়বে — নিশ্চিত হয়ে Approve করুন।`;
  } else if (quote.oldPlan !== (plan||'pro10') && quote.oldPlan!=='free') {
    confirmMsg = `প্ল্যান পরিবর্তন: ${PLAN_LABEL[quote.oldPlan]||quote.oldPlan} → ${PLAN_LABEL[plan]||plan}\n\nপুরনো প্ল্যানের বাকি সময়ের মূল্য (৳${quote.carryValue}) নতুন প্ল্যানে রূপান্তরিত হয়ে মোট ${quote.totalDays} দিন যোগ হবে। নতুন মেয়াদ: ${fmt(quote.newExpiry)}।`;
  }
  confirmMsg += overLimitWarning;
  if (!window.confirm(confirmMsg)) return;

  ld('Plan activate হচ্ছে…');
  try {
    const batch = writeBatch(db);

    if (messId) {
      const patch = { plan: plan || 'pro10', planExpiry: quote.newExpiry, planActivatedAt: serverTimestamp() };
      if (plan === 'pro20plus' && customLimit) patch.customMemberLimit = customLimit;
      batch.update(doc(db,'messes',messId), patch);
    }

    batch.update(doc(db,'paymentRequests',payId), {
      status: 'approved', reviewedBy: currentProfile?.uid||'', reviewedAt: serverTimestamp(),
    });

    if (messId) {
      batch.set(doc(collection(db,'messes',messId,'billingHistory')), {
        plan: plan || 'pro10',
        periodStart: Timestamp.fromDate(quote.baseDate),
        periodEnd:   Timestamp.fromDate(quote.newExpiry),
        monthsCovered: +(quote.totalDays/30).toFixed(1),
        daysCovered: quote.totalDays,
        amount: amountPaid,
        wasOverdue: quote.dueInfo.isExpired,
        monthsOverdueAtPayment: quote.dueInfo.monthsOverdue,
        carryDays: quote.carryDays,
        carryValue: quote.carryValue,
        planChangedFrom: quote.oldPlan !== (plan||'pro10') ? quote.oldPlan : null,
        paymentRequestId: payId,
        paymentMethod: p?.paymentMethod || null,
        txnId: p?.txnId || null,
        approvedBy: currentProfile?.uid || '',
        createdAt: serverTimestamp(),
      });
    }

    await batch.commit();
    invalidateMessesCache();
    toast('Plan activate হয়েছে ✓','ok');
    await _loadDetail(root);
  } catch(err) {
    toast('ব্যর্থ: '+err.message,'er');
  } finally { uld(); }
}

async function _reject(root, payId) {
  const note = window.prompt('Reject এর কারণ লিখুন (ঐচ্ছিক):');
  if (note === null) return;
  try {
    await updateDoc(doc(db,'paymentRequests',payId), {
      status: 'rejected', reviewNote: note||'',
      reviewedBy: currentProfile?.uid||'', reviewedAt: serverTimestamp(),
    });
    toast('Payment reject হয়েছে','ok');
    await _loadDetail(root);
  } catch(err) { toast('ব্যর্থ: '+err.message,'er'); }
}

async function _waiveDue(root, dueInfo, currentExpiry) {
  if (!window.confirm(`৳${dueInfo.dueAmount} বকেয়া (${dueInfo.monthsOverdue} মাস) সম্পূর্ণ মওকুফ করবেন? এই মেসের মেয়াদ আজকের তারিখ পর্যন্ত ক্লিয়ার হয়ে যাবে (নতুন কোনো সময় যোগ হবে না, শুধু বকেয়া মুছবে)।`)) return;
  ld('মওকুফ করা হচ্ছে…');
  try {
    const now = new Date();
    const messSnap = await getDoc(doc(db,'messes',_selectedMessId));
    const batch = writeBatch(db);
    batch.update(doc(db,'messes',_selectedMessId), { planExpiry: now });
    batch.set(doc(collection(db,'messes',_selectedMessId,'billingHistory')), {
      plan: messSnap.data()?.plan || 'free',
      periodStart: Timestamp.fromDate(currentExpiry || now),
      periodEnd: Timestamp.fromDate(now),
      monthsCovered: 0,
      amount: 0,
      wasOverdue: true,
      monthsOverdueAtPayment: dueInfo.monthsOverdue,
      paymentRequestId: null,
      paymentMethod: 'waived',
      txnId: null,
      approvedBy: currentProfile?.uid || '',
      createdAt: serverTimestamp(),
    });
    await batch.commit();
    invalidateMessesCache();
    toast('বকেয়া মওকুফ করা হয়েছে ✓','ok');
    await _loadDetail(root);
  } catch(err) {
    toast('ব্যর্থ: '+err.message,'er');
  } finally { uld(); }
}

async function _addManualEntry(root) {
  const plan   = document.getElementById('mn-plan')?.value || 'pro10';
  const amount = parseFloat(document.getElementById('mn-amount')?.value)||0;
  const note   = document.getElementById('mn-note')?.value || '';

  ld('এন্ট্রি যোগ হচ্ছে…');
  try {
    const [messSnap, cfgSnap] = await Promise.all([
      getDoc(doc(db,'messes',_selectedMessId)),
      getDoc(doc(db,'appConfig','main')),
    ]);
    const messData = messSnap.exists() ? messSnap.data() : {};
    const cfg = cfgSnap.exists() ? cfgSnap.data() : {};
    const quote = computeRenewalQuote({ messData, cfg, targetPlan: plan, amountPaid: amount });

    const batch = writeBatch(db);
    batch.update(doc(db,'messes',_selectedMessId), { plan, planExpiry: quote.newExpiry, planActivatedAt: serverTimestamp() });
    batch.set(doc(collection(db,'messes',_selectedMessId,'billingHistory')), {
      plan, periodStart: Timestamp.fromDate(quote.baseDate), periodEnd: Timestamp.fromDate(quote.newExpiry),
      monthsCovered: +(quote.totalDays/30).toFixed(1), daysCovered: quote.totalDays, amount,
      wasOverdue: quote.dueInfo.isExpired, monthsOverdueAtPayment: quote.dueInfo.monthsOverdue,
      carryDays: quote.carryDays, carryValue: quote.carryValue,
      planChangedFrom: quote.oldPlan !== plan ? quote.oldPlan : null,
      paymentRequestId: null, paymentMethod: 'manual', txnId: null, note,
      approvedBy: currentProfile?.uid || '', createdAt: serverTimestamp(),
    });
    await batch.commit();
    invalidateMessesCache();
    toast(`ম্যানুয়াল এন্ট্রি যোগ হয়েছে ✓ (${quote.totalDays} দিন, নতুন মেয়াদ ${quote.newExpiry.getDate()}/${quote.newExpiry.getMonth()+1}/${quote.newExpiry.getFullYear()})`,'ok');
    await _loadDetail(root);
  } catch(err) {
    toast('ব্যর্থ: '+err.message,'er');
  } finally { uld(); }
}

function _methodIcon(method) {
  if (method==='nagad')  return '🟠';
  if (method==='rocket') return '🟣';
  return '💚';
}


// utils.js — fixed with loading bar support

import {
  getDocs, query, where, documentId
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

export let LANG = localStorage.getItem('mm_lang') || 'bn';

export function setLang(l) {
  LANG = l;
  localStorage.setItem('mm_lang', l);
  document.getElementById('html-root')?.setAttribute('lang', l);
}

const TR = {
  bn: {
    months: ['জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'],
    days_short: ['রোব','সোম','মঙ্গল','বুধ','বৃহ','শুক্র','শনি'],
  },
  en: {
    months: ['January','February','March','April','May','June','July','August','September','October','November','December'],
    days_short: ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],
  }
};

export function t(key) { return TR[LANG]?.[key] ?? TR.bn[key] ?? key; }
export function moName(m) { return (TR[LANG]?.months || TR.bn.months)[m] ?? ''; }
export function dayName(d) { return (TR[LANG]?.days_short || TR.bn.days_short)[d] ?? ''; }

export const taka  = n => `৳${(parseFloat(n)||0).toFixed(0)}`;
export const takaF = n => `৳${(parseFloat(n)||0).toFixed(2)}`;
export const pad   = n => String(n).padStart(2,'0');

// HTML-escape — 30টা page ফাইলে আলাদা আলাদা কপি ছিল (কিছুতে quote-escape ছিল,
// কিছুতে ছিল না); এখন এখানেই একটা কমন, সবচেয়ে safe (quote-সহ) ভার্সন রাখা হলো।
export const escapeHtml = s => String(s??'')
  .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
export const ini   = n => (n||'').split(' ').map(w=>w[0]||'').join('').slice(0,2).toUpperCase()||'?';
export const avColor = name => 'av'+((name?.charCodeAt(0)||0)%10);
export const dim   = (y,m) => new Date(y,m+1,0).getDate();

export function formatDate(d) {
  if (!d) return '';
  let dt;
  if (typeof d.toDate === 'function') dt = d.toDate();
  else if (d.seconds !== undefined)   dt = new Date(d.seconds * 1000);
  else                                dt = new Date(d);
  if (isNaN(dt)) return '';
  return `${dt.getDate()} ${moName(dt.getMonth())} ${dt.getFullYear()}`;
}
export function dateKey(date=new Date()) {
  return `${date.getFullYear()}_${pad(date.getMonth()+1)}_${pad(date.getDate())}`;
}

// ── Toast ─────────────────────────────────────────────────
let _tt = null;
export function toast(msg, type='ok', ms=2800) {
  let el = document.getElementById('toast');
  if (!el) { el=document.createElement('div'); el.id='toast'; document.body.appendChild(el); }
  el.className = `toast ${type}`;
  el.textContent = msg;
  requestAnimationFrame(() => el.classList.add('on'));
  clearTimeout(_tt);
  _tt = setTimeout(() => el.classList.remove('on'), ms);
}

// ── Loading overlay with PROGRESS BAR ────────────────────
let _ldTimer = null;

export function ld(msg, progress=null) {
  const el = document.getElementById('lov');
  if (!el) return;
  el.classList.add('on');

  const p = document.getElementById('lov-msg');
  if (p) p.textContent = msg || 'লোড হচ্ছে…';

  // Progress bar
  const bar = document.getElementById('lov-bar-inner');
  if (bar) {
    if (progress !== null) {
      bar.style.width = Math.min(100, progress) + '%';
    } else {
      // Animated indeterminate progress
      bar.style.width = '0%';
      bar.style.transition = 'none';
      requestAnimationFrame(() => {
        bar.style.transition = 'width 2s ease-out';
        bar.style.width = '85%';
      });
    }
  }

  // Safety timeout — 10s পরেও spinner চললে বন্ধ করো
  clearTimeout(_ldTimer);
  _ldTimer = setTimeout(() => uld(), 10000);
}

export function uld() {
  clearTimeout(_ldTimer);
  const el = document.getElementById('lov');
  if (!el) return;

  // Bar 100% তারপর hide
  const bar = document.getElementById('lov-bar-inner');
  if (bar) {
    bar.style.transition = 'width .2s ease';
    bar.style.width = '100%';
  }
  setTimeout(() => {
    el.classList.remove('on');
    if (bar) bar.style.width = '0%';
  }, 200);
}

// ── Confirm ───────────────────────────────────────────────
export function confirm(msg) { return window.confirm(msg); }

// ── Role label ────────────────────────────────────────────
export function roleLabel(r) {
  return {'mess-admin':'মেস অ্যাডমিন','mess-co-admin':'কো-অ্যাডমিন','member':'সদস্য','admin':'Admin','co-admin':'Co-Admin'}[r] || r;
}

export const CATS = ['বাজার','রান্না','গ্যাস','বিদ্যুৎ','পানি','পরিষ্কার','অন্যান্য'];
export const CICO = { বাজার:'🛒',রান্না:'🍳',গ্যাস:'🔥',বিদ্যুৎ:'💡',পানি:'💧',পরিষ্কার:'🧹',অন্যান্য:'📦' };

// ── Help/FAQ modal — login ও mess-create/join পেজেও ব্যবহারের জন্য ──
// (এই পেজগুলোতে এখনো mess-shell router নেই, তাই আলাদা overlay হিসেবে দেখানো হয়)
export async function openHelpModal() {
  if (document.getElementById('__help-modal-overlay')) return;
  const overlay = document.createElement('div');
  overlay.id = '__help-modal-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.6);'+
    'display:flex;align-items:flex-start;justify-content:center;padding:24px 16px;overflow-y:auto';
  overlay.innerHTML = `
<div style="background:#fff;border-radius:16px;max-width:760px;width:100%;
  position:relative;padding:44px 20px 24px;margin:auto">
  <button id="__help-modal-close" aria-label="বন্ধ করুন"
    style="position:absolute;top:12px;right:12px;width:32px;height:32px;border-radius:50%;
    border:none;background:var(--paper,#f1f5f2);font-size:16px;cursor:pointer;z-index:2">✕</button>
  <div id="__help-modal-body"></div>
</div>`;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
  overlay.querySelector('#__help-modal-close').addEventListener('click', () => overlay.remove());
  try {
    const mod = await import('./pages/mess/help.js');
    await mod.render(overlay.querySelector('#__help-modal-body'), null);
  } catch(err) {
    overlay.querySelector('#__help-modal-body').innerHTML =
      '<p style="text-align:center;color:var(--r1)">Help লোড করা যায়নি।</p>';
  }
}

// ── মাসভিত্তিক meals doc-ID রেঞ্জ — পুরো collection স্ক্যান না করে ────
// meal doc ID ফরম্যাট: YYYY_MM_DD_uid (lexicographically sortable)।
// এই রেঞ্জ দিয়ে সরাসরি Firestore query করলে শুধু ওই মাসের ডকুমেন্টই আসবে,
// ক্লায়েন্ট-সাইডে পুরো collection টেনে এনে ফিল্টার করতে হবে না।
// ── মাসভিত্তিক expense/deposit `date` ফিল্ড রেঞ্জ ────────────────
// expenses/deposits এ doc ID date-prefixed না (auto-generated ID), কিন্তু
// প্রতিটাতে একটা `date` ফিল্ড (স্ট্রিং, 'YYYY-MM-DD') থাকে — এটা দিয়ে সরাসরি
// range query করা যায়, পুরো collection টেনে client-side ফিল্টার করা লাগে না।
export function monthDateRange(year, monthIndex0) {
  const start = `${year}-${pad(monthIndex0+1)}-01`;
  const nextY = monthIndex0===11 ? year+1 : year;
  const nextM = monthIndex0===11 ? 0 : monthIndex0+1;
  const end   = `${nextY}-${pad(nextM+1)}-01`;
  return { start, end };
}

export function monthDocIdRange(year, monthIndex0) {
  const start = `${year}_${pad(monthIndex0+1)}_`;
  const nextY = monthIndex0===11 ? year+1 : year;
  const nextM = monthIndex0===11 ? 0 : monthIndex0+1;
  const end   = `${nextY}_${pad(nextM+1)}_`;
  return { start, end };
}

// ── ব্যাচড ডকুমেন্ট ফেচ — N+1 getDoc() loop এর বদলে ────────
// একাধিক ডকুমেন্ট ID একসাথে single query তে আনার জন্য (Firestore 'in' query,
// সর্বোচ্চ ৩০টা ID/query, বেশি হলে নিজে থেকে chunk হয়ে যায়)।
// রিটার্ন করে { id: data, ... } — যেসব ID-র ডকুমেন্ট নেই সেগুলো ম্যাপে থাকবে না।
export async function getDocsByIds(collRef, ids) {
  const uniqueIds = [...new Set(ids)].filter(Boolean);
  const map = {};
  if (!uniqueIds.length) return map;
  const chunks = [];
  for (let i = 0; i < uniqueIds.length; i += 30) chunks.push(uniqueIds.slice(i, i + 30));
  const snaps = await Promise.all(
    chunks.map(c => getDocs(query(collRef, where(documentId(), 'in', c))))
  );
  snaps.forEach(snap => snap.forEach(d => { map[d.id] = d.data(); }));
  return map;
}

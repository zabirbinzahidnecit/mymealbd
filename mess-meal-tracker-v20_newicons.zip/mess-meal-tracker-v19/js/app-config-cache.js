// app-config-cache.js — session-level cache for appConfig/main
//
// কেন: appConfig (plan price, member limit, payment number, ইত্যাদি) প্রায়
// প্রতিটা পেজেই আলাদা করে fetch হতো (plan.js, billing.js, admin-messes.js,
// admin-payments.js...) — অথচ এই ডেটা প্ল্যাটফর্ম-অ্যাডমিন খুব কম পরিবর্তন
// করেন। ২ মিনিটের TTL cache দিয়ে বার বার ট্যাব পাল্টানো/পেজ লোড হওয়ার সময়
// একই read বার বার না হয়ে একবারই হয়।
//
// admin-settings.js (যেখানে এই config আসলে এডিট হয়) নিজে সবসময় fresh রাখে
// এবং প্রতিটা save-এর পর invalidateAppConfigCache() কল করে, যাতে বাকি সব
// পেজ পরের বার আপ-টু-ডেট মান পায় — max ২ মিনিট স্টেল থাকতে পারে।

import { db } from './firebase.js';
import {
  doc, getDoc
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const TTL_MS = 120_000;
let _cache = { data: null, ts: 0, promise: null };

export async function getCachedAppConfig({ force=false } = {}) {
  const now = Date.now();
  if (!force && _cache.data && (now - _cache.ts) < TTL_MS) {
    return _cache.data;
  }
  if (!force && _cache.promise) {
    return _cache.promise;
  }
  const p = (async () => {
    const snap = await getDoc(doc(db,'appConfig','main'));
    const data = snap.exists() ? snap.data() : {};
    _cache = { data, ts: Date.now(), promise: null };
    return data;
  })();
  _cache = { data: _cache.data, ts: _cache.ts, promise: p };
  return p;
}

export function invalidateAppConfigCache() {
  _cache = { data: null, ts: 0, promise: null };
}

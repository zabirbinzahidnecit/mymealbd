// test/firestore.rules.test.js
//
// firestore.rules-এর জন্য emulator টেস্ট। এখানে মূলত সেই ৫টা security-gap
// টেস্ট করা হয়েছে যেগুলো আগে fix করা হয়েছিল, যাতে ভবিষ্যতে কেউ ভুলে rule
// আবার আলগা করে দিলে টেস্ট ফেল করে ধরিয়ে দেয়।
//
// চালানোর নিয়ম (README.md-এও লেখা আছে):
//   npm install
//   npm run test:rules
//
// এটা `firebase emulators:exec` দিয়ে চলে, তাই আসল Firebase প্রজেক্টে কোনো
// প্রভাব ফেলে না — সম্পূর্ণ local emulator-এ চলে।

const assert = require('assert');
const fs = require('fs');
const {
  initializeTestEnvironment,
  assertSucceeds,
  assertFails,
} = require('@firebase/rules-unit-testing');

const MESS_ID = 'mess1';
const ADMIN_UID = 'admin1';       // mess-admin
const COADMIN_UID = 'coadmin1';   // mess-co-admin
const MEMBER_UID = 'member1';     // সাধারণ সদস্য
const OTHER_MEMBER_UID = 'member2'; // অন্য সাধারণ সদস্য
const OUTSIDER_UID = 'outsider1'; // এই মেসের সদস্যই না

let testEnv;

before(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: 'mess-meal-tracker-test',
    firestore: {
      rules: fs.readFileSync('firestore.rules', 'utf8'),
    },
  });
});

after(async () => {
  await testEnv.cleanup();
});

beforeEach(async () => {
  await testEnv.clearFirestore();
  // ✅ সিকিউরিটি-রুল বাইপাস করে ফিক্সচার ডেটা বসানো (withSecurityRulesDisabled)
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.doc(`messes/${MESS_ID}`).set({ name: 'Test Mess', status: 'active' });
    await db.doc(`messes/${MESS_ID}/members/${ADMIN_UID}`).set({ role: 'mess-admin' });
    await db.doc(`messes/${MESS_ID}/members/${COADMIN_UID}`).set({ role: 'mess-co-admin' });
    await db.doc(`messes/${MESS_ID}/members/${MEMBER_UID}`).set({ role: 'member' });
    await db.doc(`messes/${MESS_ID}/members/${OTHER_MEMBER_UID}`).set({ role: 'member' });
  });
});

function ctxAs(uid) {
  return testEnv.authenticatedContext(uid).firestore();
}

// ── ১. meals — সাধারণ member শুধু নিজের মিল লিখতে পারবে ─────────────────
describe('meals write rule', () => {
  it('সাধারণ member নিজের মিল লিখতে পারবে', async () => {
    const db = ctxAs(MEMBER_UID);
    const mealId = `2026_07_18_${MEMBER_UID}`;
    await assertSucceeds(
      db.doc(`messes/${MESS_ID}/meals/${mealId}`).set({ slots: [true, false, true] })
    );
  });

  it('সাধারণ member অন্য member-এর মিল লিখতে পারবে না (আগের bug)', async () => {
    const db = ctxAs(MEMBER_UID);
    const mealId = `2026_07_18_${OTHER_MEMBER_UID}`;
    await assertFails(
      db.doc(`messes/${MESS_ID}/meals/${mealId}`).set({ slots: [true, false, true] })
    );
  });

  it('mess-co-admin অন্য member-এর মিল লিখতে পারবে (ইচ্ছাকৃত ফিচার — ভাঙা যাবে না)', async () => {
    const db = ctxAs(COADMIN_UID);
    const mealId = `2026_07_18_${MEMBER_UID}`;
    await assertSucceeds(
      db.doc(`messes/${MESS_ID}/meals/${mealId}`).set({ slots: [true, true, false] })
    );
  });
});

// ── ২. expenses — create-এ status/addedBy/amount validation ─────────────
describe('expenses create rule', () => {
  it('সাধারণ member status:pending, addedBy:নিজে দিয়ে expense লিখতে পারবে', async () => {
    const db = ctxAs(MEMBER_UID);
    await assertSucceeds(
      db.collection(`messes/${MESS_ID}/expenses`).add({
        amount: 500, addedBy: MEMBER_UID, status: 'pending', date: '2026-07-18',
      })
    );
  });

  it('সাধারণ member সরাসরি status:approved দিয়ে expense লিখতে পারবে না (আগের bug)', async () => {
    const db = ctxAs(MEMBER_UID);
    await assertFails(
      db.collection(`messes/${MESS_ID}/expenses`).add({
        amount: 500, addedBy: MEMBER_UID, status: 'approved', date: '2026-07-18',
      })
    );
  });

  it('অন্যের নামে (addedBy স্পুফ করে) expense লিখতে পারবে না', async () => {
    const db = ctxAs(MEMBER_UID);
    await assertFails(
      db.collection(`messes/${MESS_ID}/expenses`).add({
        amount: 500, addedBy: OTHER_MEMBER_UID, status: 'pending', date: '2026-07-18',
      })
    );
  });

  it('negative amount দিয়ে expense লিখতে পারবে না', async () => {
    const db = ctxAs(MEMBER_UID);
    await assertFails(
      db.collection(`messes/${MESS_ID}/expenses`).add({
        amount: -100, addedBy: MEMBER_UID, status: 'pending', date: '2026-07-18',
      })
    );
  });

  it('co-admin সরাসরি status:approved দিয়ে expense লিখতে পারবে', async () => {
    const db = ctxAs(COADMIN_UID);
    await assertSucceeds(
      db.collection(`messes/${MESS_ID}/expenses`).add({
        amount: 500, addedBy: COADMIN_UID, status: 'approved', date: '2026-07-18',
      })
    );
  });
});

// ── ৩. deposits — একই validation ─────────────────────────────────────────
describe('deposits create rule', () => {
  it('সাধারণ member status:pending দিয়ে deposit লিখতে পারবে', async () => {
    const db = ctxAs(MEMBER_UID);
    await assertSucceeds(
      db.collection(`messes/${MESS_ID}/deposits`).add({
        amount: 1000, addedBy: MEMBER_UID, memberId: MEMBER_UID,
        status: 'pending', date: '2026-07-18',
      })
    );
  });

  it('সাধারণ member সরাসরি status:approved দিয়ে deposit লিখতে পারবে না', async () => {
    const db = ctxAs(MEMBER_UID);
    await assertFails(
      db.collection(`messes/${MESS_ID}/deposits`).add({
        amount: 1000, addedBy: MEMBER_UID, memberId: MEMBER_UID,
        status: 'approved', date: '2026-07-18',
      })
    );
  });
});

// ── ৪. joinCodes — শুধু মেসের admin/co-admin create/delete করতে পারবে ────
describe('joinCodes rule', () => {
  it('মেসের admin নিজের মেসের জন্য join code তৈরি করতে পারবে', async () => {
    const db = ctxAs(ADMIN_UID);
    await assertSucceeds(
      db.doc('joinCodes/ABC123').set({ messId: MESS_ID })
    );
  });

  it('সাধারণ member join code তৈরি করতে পারবে না', async () => {
    const db = ctxAs(MEMBER_UID);
    await assertFails(
      db.doc('joinCodes/ABC123').set({ messId: MESS_ID })
    );
  });

  it('অন্য মেসের admin এই মেসের join code delete করতে পারবে না (আগের bug)', async () => {
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      await ctx.firestore().doc('joinCodes/XYZ999').set({ messId: MESS_ID });
      await ctx.firestore().doc(`messes/otherMess/members/${OUTSIDER_UID}`)
        .set({ role: 'mess-admin' });
      await ctx.firestore().doc('messes/otherMess').set({ name: 'Other Mess' });
    });
    const db = ctxAs(OUTSIDER_UID);
    await assertFails(db.doc('joinCodes/XYZ999').delete());
  });
});

// ── ৫. inviteIndex — শুধু মেসের co-admin+ create/update পারবে ────────────
describe('inviteIndex rule', () => {
  it('মেসের co-admin invite তৈরি করতে পারবে', async () => {
    const db = ctxAs(COADMIN_UID);
    await assertSucceeds(
      db.doc('inviteIndex/test_at_example_com').set({
        messId: MESS_ID, token: 'tok123', role: 'member', email: 'test@example.com',
      })
    );
  });

  it('সাধারণ member invite তৈরি করতে পারবে না', async () => {
    const db = ctxAs(MEMBER_UID);
    await assertFails(
      db.doc('inviteIndex/test_at_example_com').set({
        messId: MESS_ID, token: 'tok123', role: 'member', email: 'test@example.com',
      })
    );
  });
});
